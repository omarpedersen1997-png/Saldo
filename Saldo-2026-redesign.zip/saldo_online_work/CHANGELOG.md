# Saldo 3.7.0

- Ny rapport med månedlig sammenligning af indtægter, udgifter og netto for de seneste seks måneder.
- Beholder budgetadvarsler, forfaldne regninger, gældsoversigt, brændstofstatistik, eksport og sikkerhedskopiering fra tidligere arbejdsversioner.
- Versionsnummer opdateret til 3.7.0.

Bemærk: Historikken beregnes ud fra registrerede poster og er ikke en bankbalance. Android-build og funktioner er ikke testet på en enhed i denne arbejdsversion; kør GitHub Actions-build før installation.


## 3.9.1
- Tilføjet bløde overgange mellem hovedfaner.
- Tilføjet filtre til poster: Alle, Indtægt og Udgift.
- Rettet overblikket, så indtægter og udgifter viser den aktuelle måned frem for alle historiske poster.
- Tilføjet animation ved ændring af postkort.

## 2026 moderniseret brugerflade
- Opdateret farvepalette, kontrast, kortformer og typografi til et mere moderne fintech-udtryk.
- Tilføjet en animeret pengestrømsindikator på overblikket, der viser månedens forbrug i forhold til indtægter.
- Redesignet indstillingshandlinger til kompakte kort med ikoner og forklarende undertekster i stedet for store ensfarvede knapper.
- Bruger nu betegnelsen Partner i brugergrænsefladen og migrerer eksisterende ejerfelter fra den tidligere betegnelse ved indlæsning.
- Saldo-logoets billedfiler er bevaret uændret.
- GitHub Actions accepterer både det nye arkivnavn og det tidligere arkivnavn.
