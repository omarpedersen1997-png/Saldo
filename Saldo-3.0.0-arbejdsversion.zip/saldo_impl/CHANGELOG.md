# Saldo – ændringslog

## 2.3.0
- Bevarer det beskårne S-logo fra den godkendte designreference som app-logo.
- Udvider navigationen med kalender, opsparing, rapporter og indstillinger.
- Tilføjer visuelle skærme til kalender, opsparingsmål, rapporter og indstillinger i samme mørke marineblå/lilla stil.
- Versionsnummer hævet, så denne APK kan skelnes fra tidligere builds.

Bemærk: Dette er en UI-prototype. Import af Betalingsservice-skærmbilleder med automatisk OCR, vedvarende lagring, ægte PDF-eksport og fuld temaændring er ikke færdigimplementeret.

## 2.5.0
- Tilføjet en mørk, professionel splash screen med Saldo-logo, gradientbaggrund og diskret indtonings-/skaleringseffekt.
- Sat status- og navigationsbjælker til appens mørke farver under opstart.
- Versioneret Android-pakken til 2.5.0.

## 2.5.1
- Splashskærmen justeret til brugerens præcise visuelle reference.
- Reference-logo med neonfarvet cyan/blå/pink S-form integreret som appens logoressource.
- Logoet vises i større størrelse på ensartet mørk marineblå baggrund.
- Undertitel og tre farvede statusstreger tilpasset designreferencen.
