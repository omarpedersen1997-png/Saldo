# Saldo 3.0.0 — funktionsstatus

## Implementeret i denne pakke
- Lokal, persistent lagring af indtægter og udgifter med dato, kategori og type.
- Råderumsberegning ud fra registrerede poster og ubetalte regninger. Beløbet er kun så komplet som de data, brugeren indtaster.
- Indtastning af næste løndato og løn hver 14. dag.
- 30/60/90-dages simpel prognose baseret på den registrerede nettoindtægt; ikke en fuld kontantstrømsmodel.
- Regninger med forfaldsdato, kategori, gentagelsesfelt og statusfelt.
- Månedlige budgetgrænser pr. kategori med sammenligning mod registrerede udgifter.
- Opsparingsmål, gæld (saldo/rente/afdrag), tankninger (liter/pris/km), abonnementer.
- CSV-delings-eksport for poster og regninger.
- PIN-lås som lokal app-PIN. Den er ikke biometrisk og bør ikke betragtes som stærk kryptering.
- Data gemmes lokalt på enheden via SharedPreferences/JSON.
- Mørk splashskærm med logoressourcen.

## Stadig ikke implementeret / kræver særskilt arbejde
- OCR fra billede/PDF, automatisk udtræk og dubletkontrol af regninger.
- Planlagte notifikationer og gentagelse af regninger automatisk.
- Fællesbudget med brugerdefinerede fordelingsprocenter og synkronisering mellem telefoner.
- Biometrisk lås, krypteret backup/restore, egentlig filbaseret backup-eksport.
- PDF-rapport, interaktive historiske diagrammer og korrekt månedsafgrænset statistik.
- Betaling via bank, live benzinpriser og bankintegration.

## Vigtigt
Denne version indeholder reelle lokale datafunktioner, men er ikke en komplet erstatning for bank-/betalingsapps. Android-bygget er ikke verificeret i dette miljø; kør GitHub Actions-workflowet og test APK'en på en fysisk telefon før brug.
