# Saldo Android – 3.0.0

Android-projekt i Kotlin/Jetpack Compose med mørkt marineblåt design, lilla/blå gradienter og Saldo-logoet.

## Med i projektet
- Overblik, budgetter, regninger, statistik, kalender, opsparing, rapporter og indstillinger.
- Separate visninger for eget budget, partnerbudget og fællesbudget.
- Registrering af udgifter; antal og samlet beløb gemmes lokalt på telefonen, også når appen lukkes.
- Oversigtsvisning for kommende regninger, grafer og opsparingsmål.
- GitHub Actions-workflow til at bygge en debug-APK.

## Funktioner, der kræver videre implementering
Denne version er stadig en prototype, ikke en færdig økonomiapp. De ønskede funktioner er beskrevet i `FEATURES.md`. Automatisk OCR af Betalingsservice-billeder, reelle betalingsnotifikationer, løn-/pengestrømsprognoser, dynamiske budgetter, fuld fælles datasynkronisering, PDF/CSV-eksport, PIN/biometri, automatisk sikkerhedskopiering og live brændstofpriser kræver yderligere kode, tilladelser og/eller eksterne datakilder. Skærme med eksempeldata må ikke opfattes som faktiske bankdata.

## Build via GitHub Actions
Upload denne ZIP i roden af dit repository med navnet `Saldo-Android-startpakke-ny-download-1.zip`. Workflowet `.github/workflows/android-build.yml` pakker den ud, bygger debug-APK og uploader APK'en som artifact `Saldo-Android-debug-APK`.

## Privatliv
Registrerede udgifter i denne prototype gemmes lokalt i appens private SharedPreferences. Der er endnu ingen bankintegration eller cloud-synkronisering.


### Version 3.0.0 – opstartsskærm
Opstartsskærmen er tilpasset den angivne reference med mørk marineblå baggrund, neon-S-logo, SALDO-tekst, undertitel og tre farvede streger. Logoressourcen `ic_saldo_logo.png` er en direkte kopi af `logo-reference-crop.png` fra brugerens reference, uden at tegne logoet om.
