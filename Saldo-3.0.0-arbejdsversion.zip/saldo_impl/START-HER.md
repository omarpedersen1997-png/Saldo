# Start her – Saldo 2.5.1

1. Upload denne ZIP til roden af dit GitHub-repository med navnet `Saldo-Android-startpakke-ny-download-1.zip`.
2. Sørg for, at workflowet `.github/workflows/android-build.yml` i selve repositoryet bruger præcis samme ZIP-filnavn.
3. Åbn GitHub → Actions → Build Saldo → Run workflow.
4. Hvis workflowet lykkes, hent `Saldo-Android-debug-APK` under Artifacts og pak artifact-ZIP'en ud på telefonen for at finde APK-filen.
5. Installér APK-filen og test den på telefonen.

## Vigtigt om status
Dette projekt er en prototype/MVP. Opstartsskærm og logo er i projektet, og registrering af udgifter gemmes lokalt. Flere viste skærme bruger fortsat eksempeldata, og ikke alle ønskede funktioner er implementeret. Se `FEATURES.md` før brug til økonomiske beslutninger. Buildet skal verificeres via GitHub Actions.
