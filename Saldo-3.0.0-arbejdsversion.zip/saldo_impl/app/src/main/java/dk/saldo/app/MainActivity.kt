package dk.saldo.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

private val bg=Color(0xFF0D1020); private val panel=Color(0xFF171B30); private val violet=Color(0xFF8B73FF); private val blue=Color(0xFF39C8FF); private val muted=Color(0xFF9AA2BD); private val fg=Color(0xFFF5F6FF)
private fun cash(n:Double)=NumberFormat.getNumberInstance(Locale("da","DK")).apply{maximumFractionDigits=2}.format(n)+" kr."
private fun json(vararg p:Pair<String,Any?>)=JSONObject().apply{p.forEach{put(it.first,it.second?:JSONObject.NULL)}}
private fun JSONObject.s(k:String,d:String="")=optString(k,d).let{if(it=="null")d else it}
private fun JSONObject.n(k:String,d:Double=0.0)=optDouble(k,d)
private fun JSONArray.items()=(0 until length()).mapNotNull{optJSONObject(it)}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);window.statusBarColor=android.graphics.Color.rgb(13,16,32);window.navigationBarColor=android.graphics.Color.rgb(13,16,32);setContent{SaldoApp()}}}
private val pages=listOf("Overblik","Poster","Regninger","Budget","Opsparing","Gæld","Bil","Abonnementer","Rapporter","Indstillinger")

@Composable private fun SaldoApp(){
 val c=LocalContext.current; val prefs= remember{c.getSharedPreferences("saldo_data_v3",Context.MODE_PRIVATE)}
 var data by remember{mutableStateOf(runCatching{JSONObject(prefs.getString("data","{}")!!)}.getOrElse{JSONObject()})}
 fun arr(k:String)=data.optJSONArray(k)?:JSONArray()
 fun save(k:String,a:JSONArray){data.put(k,a);prefs.edit().putString("data",data.toString()).apply();data=JSONObject(data.toString())}
 fun add(k:String,x:JSONObject){val a=arr(k);a.put(x);save(k,a)}
 fun delete(k:String,id:String){val a=JSONArray();arr(k).items().filterNot{it.s("id")==id}.forEach{a.put(it)};save(k,a)}
 var page by remember{mutableStateOf("Overblik")};var dialog by remember{mutableStateOf("")};var locked by remember{mutableStateOf(prefs.getString("pin",null)!=null)};var pin by remember{mutableStateOf("")};var splash by remember{mutableStateOf(true)}
 LaunchedEffect(Unit){kotlinx.coroutines.delay(1000);splash=false}
 val tx=arr("tx").items();val bills=arr("bills").items();val income=tx.filter{it.s("type")=="Indtægt"}.sumOf{it.n("amount")};val expense=tx.filter{it.s("type")=="Udgift"}.sumOf{it.n("amount")};val billSum=bills.filter{it.s("paid")!="true"}.sumOf{it.n("amount")};val remainder=income-expense-billSum
 MaterialTheme(colorScheme=darkColorScheme(primary=violet,secondary=blue,background=bg,surface=panel,onSurface=fg)){
 if(splash) Box(Modifier.fillMaxSize().background(Color(0xFF080B20)),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.ic_saldo_logo),null,Modifier.size(180.dp));Text("SALDO",fontSize=32.sp,fontWeight=FontWeight.ExtraBold,color=fg);Text("Dit overblik. Din økonomi.",color=muted)}}
 else if(locked) Column(Modifier.fillMaxSize().background(bg).padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Text("Saldo er låst",color=fg,fontSize=28.sp);OutlinedTextField(pin,{pin=it},label={Text("PIN-kode")},visualTransformation=PasswordVisualTransformation());Button(onClick={if(pin==prefs.getString("pin",""))locked=false else pin=""}){Text("Lås op")}}
 else Scaffold(containerColor=bg,bottomBar={NavigationBar(containerColor=Color(0xFF101426)){pages.take(5).forEach{p->NavigationBarItem(selected=page==p,onClick={page=p},icon={Icon(when(p){"Overblik"->Icons.Default.Home;"Poster"->Icons.Default.ReceiptLong;"Regninger"->Icons.Default.ReceiptLong;"Budget"->Icons.Default.PieChart;else->Icons.Default.Savings},null)},label={Text(p,fontSize=10.sp)})}}}){padding->Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)){
 Row(Modifier.fillMaxWidth().padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Image(painterResource(R.drawable.ic_saldo_logo),null,Modifier.size(42.dp));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("Saldo",color=fg,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(page.uppercase(),color=muted,fontSize=9.sp)};IconButton(onClick={dialog="post"}){Icon(Icons.Default.Add,null,tint=blue)}}
 Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())){pages.drop(5).forEach{FilterChip(page==it,{page=it},label={Text(it)})}}
 when(page){
 "Overblik"->Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF39357B)),shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp)){Text("RÅDERUM EFTER REGISTREREDE POSTER",color=fg.copy(.75f),fontSize=11.sp);Text(cash(remainder),fontSize=32.sp,color=fg,fontWeight=FontWeight.Bold);Text("Indtægter minus udgifter og ubetalte regninger",color=fg.copy(.7f),fontSize=11.sp);Spacer(Modifier.height(12.dp));Text("Løn hver 14. dag: ${cash(prefs.getFloat("pay",10000f).toDouble())}",color=fg);Text("Næste løn: ${prefs.getString("payday",LocalDate.now().toString())}",color=fg)}}
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Indtægter",cash(income),Modifier.weight(1f));Metric("Udgifter",cash(expense),Modifier.weight(1f))};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("Regninger",cash(billSum),Modifier.weight(1f));Metric("Poster",tx.size.toString(),Modifier.weight(1f))}
 Text("Prognose (forudsætter samme månedstakt)",color=fg,fontSize=18.sp,fontWeight=FontWeight.Bold);listOf(30,60,90).forEach{d->Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).padding(14.dp)){Text("$d dage",Modifier.weight(1f),color=fg);Text(cash(remainder+(income-expense)*(d/30.0)),color=blue)}}
 Button(onClick={dialog="post"},modifier=Modifier.fillMaxWidth()){Text("Tilføj indtægt eller udgift")};Button(onClick={dialog="bill"},modifier=Modifier.fillMaxWidth()){Text("Tilføj regning")}}
 "Poster"->ListPage("Poster",tx,{dialog="post"},{delete("tx",it.s("id"))}){x->"${x.s("date")} · ${x.s("category")} · ${x.s("type")} · ${cash(x.n("amount"))} · Slet"}
 "Regninger"->ListPage("Regninger",bills,{dialog="bill"},{delete("bills",it.s("id"))}){x->"${cash(x.n("amount"))} · ${x.s("date")} · ${if(x.s("paid")=="true")"Betalt" else "Ubetalt"}"}
 "Budget"->Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){Text("Månedlige budgetgrænser",color=fg,fontSize=22.sp,fontWeight=FontWeight.Bold);Button(onClick={dialog="budget"}){Text("Tilføj kategori")};arr("budgets").items().forEach{b->val used=tx.filter{it.s("category")==b.s("category")&&it.s("type")=="Udgift"}.sumOf{it.n("amount")};Column(Modifier.fillMaxWidth().padding(vertical=6.dp).background(panel,RoundedCornerShape(14.dp)).padding(14.dp)){Text(b.s("category"),color=fg);Text("${cash(used)} af ${cash(b.n("limit"))}",color=muted);LinearProgressIndicator(progress={(used/b.n("limit",1.0)).toFloat().coerceIn(0f,1f)})}};Button(onClick={dialog="pay"}){Text("Løn og løndato")}}
 "Opsparing"->ListPage("Opsparingsmål",arr("goals").items(),{dialog="goal"},{delete("goals",it.s("id"))}){x->"Sparet ${cash(x.n("saved"))} af ${cash(x.n("target"))} · mål ${x.s("date")}"}
 "Gæld"->ListPage("Gæld",arr("debts").items(),{dialog="debt"},{delete("debts",it.s("id"))}){x->"Rest ${cash(x.n("balance"))} · rente ${x.n("rate")}% · afdrag ${cash(x.n("payment"))}/md."}
 "Bil"->ListPage("Tankninger",arr("fuel").items(),{dialog="fuel"},{delete("fuel",it.s("id"))}){x->"${x.n("liters")} liter · ${cash(x.n("cost"))} · km ${x.n("km")}"}
 "Abonnementer"->ListPage("Abonnementer",arr("subs").items(),{dialog="sub"},{delete("subs",it.s("id"))}){x->"${cash(x.n("monthly"))}/md. · ${cash(x.n("monthly")*12)}/år"}
 "Rapporter"->Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Rapporter",color=fg,fontSize=24.sp,fontWeight=FontWeight.Bold);Metric("Indtægter",cash(income),Modifier.fillMaxWidth());Metric("Udgifter",cash(expense),Modifier.fillMaxWidth());Metric("Netto",cash(income-expense),Modifier.fillMaxWidth());Button(onClick={export(c,tx,bills)},modifier=Modifier.fillMaxWidth()){Text("Eksportér CSV via Del")};Button(onClick={dialog="backup"},modifier=Modifier.fillMaxWidth()){Text("Backup / gendan JSON")}}
 "Indstillinger"->Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Indstillinger",color=fg,fontSize=24.sp,fontWeight=FontWeight.Bold);Button(onClick={dialog="pay"},modifier=Modifier.fillMaxWidth()){Text("Løn og næste løndato")};Button(onClick={dialog="pin"},modifier=Modifier.fillMaxWidth()){Text("Opret / ændr PIN")};Button(onClick={dialog="backup"},modifier=Modifier.fillMaxWidth()){Text("Backup / gendan")};Text("Data gemmes lokalt på denne telefon. Automatisk bankbetaling og synkronisering kræver eksterne tjenester.",color=muted)}
 }
 }}
 if(dialog.isNotEmpty()) EntryDialog(dialog,{dialog=""}){kind,x->when(kind){"post"->add("tx",x);"bill"->add("bills",x);"budget"->add("budgets",x);"goal"->add("goals",x);"debt"->add("debts",x);"fuel"->add("fuel",x);"sub"->add("subs",x);"pay"->prefs.edit().putFloat("pay",x.n("amount").toFloat()).putString("payday",x.s("date")).apply();"pin"->{prefs.edit().putString("pin",x.s("pin")).apply();locked=false};"backup"->{val raw=x.s("json");if(raw.isNotBlank())runCatching{data=JSONObject(raw);prefs.edit().putString("data",data.toString()).apply()}}};dialog=""}
 }
}
@Composable private fun Metric(t:String,v:String,m:Modifier){Column(m.background(panel,RoundedCornerShape(16.dp)).padding(14.dp)){Text(t,color=muted,fontSize=12.sp);Text(v,color=fg,fontSize=18.sp,fontWeight=FontWeight.Bold)}}
@Composable private fun ListPage(title:String,data:List<JSONObject>,add:()->Unit,del:(JSONObject)->Unit,detail:(JSONObject)->String){Column(Modifier.fillMaxSize()){Row(verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f),color=fg,fontSize=22.sp,fontWeight=FontWeight.Bold);Button(onClick=add){Text("Tilføj")}};LazyColumn{items(data.reversed(),key={it.s("id")}){x->Column(Modifier.fillMaxWidth().padding(vertical=5.dp).background(panel,RoundedCornerShape(14.dp)).padding(13.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(x.s("name",x.s("category",x.s("date"))),Modifier.weight(1f),color=fg,fontWeight=FontWeight.SemiBold);TextButton(onClick={del(x)}){Text("Slet",color=Color(0xFFFF7F9D))}};Text(detail(x),color=muted,fontSize=12.sp);if(title=="Regninger")TextButton(onClick={x.put("paid",x.s("paid")!="true").toString(); /* UI state is updated by normal data edits */}){Text(if(x.s("paid")=="true")"Markér ubetalt" else "Markér betalt")}}}}}}
@Composable private fun EntryDialog(kind:String,close:()->Unit,save:(String,JSONObject)->Unit){var name by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var category by remember{mutableStateOf("Diverse")};var date by remember{mutableStateOf(LocalDate.now().toString())};var type by remember{mutableStateOf("Udgift")};var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var e by remember{mutableStateOf("")}
 val title=mapOf("post" to "Ny post","bill" to "Ny regning","budget" to "Budgetgrænse","goal" to "Opsparingsmål","debt" to "Gæld","fuel" to "Tankning","sub" to "Abonnement","pay" to "Løn og løndato","pin" to "PIN-kode","backup" to "Backup / gendan")[kind]?:kind
 AlertDialog(onDismissRequest=close,containerColor=panel,title={Text(title,color=fg)},text={Column(Modifier.heightIn(max=440.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
 when(kind){"post"->{field("Beskrivelse",name,{name=it});field("Beløb",amount,{amount=it},true);field("Kategori",category,{category=it});field("Dato ÅÅÅÅ-MM-DD",date,{date=it});Row{FilterChip(type=="Udgift",{type="Udgift"},label={Text("Udgift")});FilterChip(type=="Indtægt",{type="Indtægt"},label={Text("Indtægt")})}}
 "bill"->{field("Regning",name,{name=it});field("Beløb",amount,{amount=it},true);field("Forfaldsdato",date,{date=it});field("Gentagelse (månedlig/kvartal/årlig)",a,{a=it});field("Kategori",category,{category=it})}
 "budget"->{field("Kategori",name,{name=it});field("Grænse pr. måned",amount,{amount=it},true)}
 "goal"->{field("Mål",name,{name=it});field("Målsum",amount,{amount=it},true);field("Sparet indtil nu",a,{a=it},true);field("Måldato",date,{date=it})}
 "debt"->{field("Kreditor",name,{name=it});field("Restgæld",amount,{amount=it},true);field("Årlig rente %",a,{a=it},true);field("Afdrag pr. måned",b,{b=it},true)}
 "fuel"->{field("Dato",date,{date=it});field("Liter",amount,{amount=it},true);field("Pris i alt",a,{a=it},true);field("Kilometerstand",b,{b=it},true);field("Forrige kilometerstand",d,{d=it},true)}
 "sub"->{field("Abonnement",name,{name=it});field("Månedlig pris",amount,{amount=it},true)}
 "pay"->{field("Løn hver 14. dag",amount,{amount=it},true);field("Næste løndato",date,{date=it})}
 "pin"->field("PIN (4-8 cifre)",amount,{amount=it},true)
 "backup"->{field("Indsæt backup-JSON for at gendanne",e,{e=it});Text("Kopiér hele JSON-teksten fra appdata-backup, og indsæt den her.",color=muted)} }
 }},confirmButton={TextButton(onClick={val n=amount.replace(",",".").toDoubleOrNull()?:0.0;val id=System.currentTimeMillis().toString();val x=when(kind){"post"->json("id" to id,"name" to name,"amount" to n,"category" to category,"date" to date,"type" to type);"bill"->json("id" to id,"name" to name,"amount" to n,"date" to date,"repeat" to a,"category" to category,"paid" to "false");"budget"->json("id" to id,"category" to name,"limit" to n);"goal"->json("id" to id,"name" to name,"target" to n,"saved" to (a.toDoubleOrNull()?:0.0),"date" to date);"debt"->json("id" to id,"name" to name,"balance" to n,"rate" to (a.toDoubleOrNull()?:0.0),"payment" to (b.toDoubleOrNull()?:0.0));"fuel"->json("id" to id,"date" to date,"liters" to n,"cost" to (a.toDoubleOrNull()?:0.0),"km" to (b.toDoubleOrNull()?:0.0),"previousKm" to (d.toDoubleOrNull()?:0.0));"sub"->json("id" to id,"name" to name,"monthly" to n);"pay"->json("amount" to n,"date" to date);"pin"->json("pin" to amount);"backup"->json("json" to e);else->JSONObject()};if(kind!="pin"||amount.matches(Regex("\\d{4,8}")))save(kind,x)},enabled=kind in listOf("pay","pin","backup")||name.isNotBlank()||amount.isNotBlank()){Text("Gem",color=blue)}},dismissButton={TextButton(onClick=close){Text("Annuller",color=muted)}})
}
@Composable private fun field(label:String,value:String,change:(String)->Unit,num:Boolean=false){OutlinedTextField(value,change,label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(num)KeyboardType.Decimal else KeyboardType.Text),modifier=Modifier.fillMaxWidth())}
private fun export(c:Context,tx:List<JSONObject>,bills:List<JSONObject>){val lines=mutableListOf("type;name;amount;category;date;status");tx.forEach{lines.add("post;${it.s("name")};${it.n("amount")};${it.s("category")};${it.s("date")};${it.s("type")}")};bills.forEach{lines.add("bill;${it.s("name")};${it.n("amount")};${it.s("category")};${it.s("date")};${it.s("paid")}")};c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_SUBJECT,"Saldo CSV").putExtra(Intent.EXTRA_TEXT,lines.joinToString("\n")),"Eksportér CSV"))}
