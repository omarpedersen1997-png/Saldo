# Saldo – ændringslog

## 3.1.0
- Bevarer den eksisterende Saldo-logofil uændret.
- Omorganiserer appens navigation: fem hovedpunkter og øvrige værktøjer under Mere.
- Tilføjer lokale poster for indtægter/udgifter, regninger, budgetter, opsparing, gæld, brændstof og abonnementer.
- Tilføjer beregnet rådighedsoversigt, løndato, grundlæggende dubletkontrol, CSV-eksport og JSON-backup/gendannelse.
- Tilføjer billed-OCR med ML Kit til visning af genkendt tekst.
- Ikke verificeret build; se README.md og FEATURES.md for mangler.
