# Saldo 3.1.0 – funktionsstatus

## Implementeret i koden (ikke endnu verificeret med Android-build)
- [x] Lokal registrering af indtægter/udgifter med kategori, dato og ejer.
- [x] Rådighedsoversigt baseret på registrerede poster og ubetalte regninger.
- [x] Lønindstilling hver 14. dag og beregning af dage til næste løndato.
- [x] Regninger, forfaldsdatoer, gentagelsesfelt, betalt-status og grundlæggende dubletkontrol.
- [x] Budgetgrænser og sammenligning med registrerede udgifter i samme kategori.
- [x] Opsparingsmål, gæld med rente-/afdragsestimat, brændstofposter og abonnementer.
- [x] CSV-eksport via Androids delingsmenu.
- [x] JSON-backup via delingsmenu og gendannelse fra indsat JSON.
- [x] Enkel lokal PIN-lås.
- [x] Billedtekstgenkendelse via ML Kit, der viser genkendt tekst til manuel kontrol.
- [x] Original logofil bevaret uændret.

## Mangler / ikke verificeret
- [ ] OCR-udtræk af modtager, beløb og dato; PDF-OCR.
- [ ] Planlagte lokale notifikationer om regningsforfald.
- [ ] Biometrisk lås.
- [ ] PDF-rapporter og mere komplet statistik/månedssammenligning.
- [ ] Automatisk brændstofeffektivitet ud fra sammenhængende tankninger.
- [ ] Automatiske gentagne regninger (gentagelsesfeltet gemmes, men genererer ikke nye regninger automatisk).
- [ ] Fuld validering af datoer, kategorier, fordelingsregler og økonomiberegninger.
- [ ] Succesfuldt Android-build og test på fysisk enhed.

## Udsat som aftalt
- Synkronisering mellem telefoner (kræver backend).
- Automatiske bankbetalinger (kræver bankintegration).
