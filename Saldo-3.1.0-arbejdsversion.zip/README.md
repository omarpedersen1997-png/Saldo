# Saldo Android 3.1.0

Android-projekt i Kotlin/Jetpack Compose. Det eksisterende logo i `app/src/main/res/drawable/ic_saldo_logo.png` er bevaret uændret.

## I denne version
- Ryddelig navigation med fem hovedpunkter og øvrige værktøjer samlet under **Mere**.
- Lokalt gemte poster med indtægt/udgift, kategori, dato og ejer (Mig/Kæreste/Fælles).
- Rådighedsoversigt beregnet fra de poster og regninger, brugeren selv registrerer.
- Regninger med forfaldsdato, gentagelsesfelt, betalt-status og grundlæggende dubletkontrol.
- Budgetgrænser pr. kategori/ejer, opsparingsmål, gæld med rente-/afdragsestimat, brændstofposter og abonnementer.
- Lønindstilling, CSV-deling, JSON-sikkerhedskopi/gendannelse og PIN-lås.
- Billed-OCR via ML Kit til at vise tekst fra valgte regningsbilleder.

## Begrænsninger, der stadig skal færdiggøres og testes
- OCR viser den genkendte tekst, men udtrækker ikke automatisk og sikkert modtager, beløb og dato til felter. PDF-OCR er ikke implementeret.
- Der er ikke automatiske, planlagte forfaldsnotifikationer eller biometrisk lås endnu.
- PDF-rapport, fuld måned-for-måned statistik/scenarier og test af alle beregninger mangler.
- Brændstofforbrug beregnes ikke endnu ud fra en komplet tankningshistorik.
- Synkronisering mellem telefoner og automatiske bankbetalinger er bevidst udsat og kræver eksterne løsninger.
- Der er ikke gennemført en verificeret Android-build i dette miljø. Byg via GitHub Actions og ret eventuelle buildfejl før installation.

## Build
Upload `Saldo-Android-startpakke-ny-download.zip` til repositoryets rod, og kør GitHub Actions-workflowet `Build Saldo`. APK'en findes under workflowets Artifacts, hvis buildet lykkes.

## Data og sikkerhed
Data gemmes lokalt i appens private SharedPreferences. JSON-backup skal opbevares sikkert; PIN-funktionen er en enkel lokal adgangslås og er ikke en erstatning for krypteret datalagring.
