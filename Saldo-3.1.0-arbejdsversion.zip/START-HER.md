# Start her – Saldo 3.1.0

1. Upload ZIP-filen `Saldo-Android-startpakke-ny-download.zip` til roden af GitHub-repositoryet.
2. Åbn GitHub → Actions → **Build Saldo** → **Run workflow**.
3. Vent på workflow-resultatet. Ved succes hentes `Saldo-Android-debug-APK` under Artifacts.
4. Installer APK'en på din Android-telefon og test alle flows med testdata først.

Bemærk: Koden er opdateret, men denne version er ikke blevet bygget/testet i dette miljø. Se FEATURES.md for præcis funktionsstatus.
