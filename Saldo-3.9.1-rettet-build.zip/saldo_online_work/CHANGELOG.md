# Saldo 3.7.0

- Ny rapport med månedlig sammenligning af indtægter, udgifter og netto for de seneste seks måneder.
- Beholder budgetadvarsler, forfaldne regninger, gældsoversigt, brændstofstatistik, eksport og sikkerhedskopiering fra tidligere arbejdsversioner.
- Versionsnummer opdateret til 3.7.0.

Bemærk: Historikken beregnes ud fra registrerede poster og er ikke en bankbalance. Android-build og funktioner er ikke testet på en enhed i denne arbejdsversion; kør GitHub Actions-build før installation.


## 3.9.1
- Tilføjet bløde overgange mellem hovedfaner.
- Tilføjet filtre til poster: Alle, Indtægt og Udgift.
- Rettet overblikket, så indtægter og udgifter viser den aktuelle måned frem for alle historiske poster.
- Tilføjet animation ved ændring af postkort.
