# Saldo – funktionsoversigt

## Budget og overblik
- Registrering af indtægter og udgifter med kategori, dato og ejer.
- Søgning i poster.
- Budgetgrænser pr. kategori og ejer med advarsel ved 80 % og overskridelse.
- Overblik over forfaldne og kommende regninger.
- Prognoser for 30, 60 og 90 dage baseret på registrerede data.

## Regninger
- Opret, markér betalt og slet regninger.
- Gentagne månedlige regninger med kontrol for dubletter.
- Skærmbillede-OCR til forslag om afsender, beløb og dato; brugeren skal kontrollere før gemning.
- Lokale påmindelser via Android WorkManager, afhængigt af tilladelser og systemets batteristyring.

## Økonomiværktøjer
- Opsparingsmål.
- Gæld med rente, afdrag og estimeret tilbagebetalingstid.
- Bil/brændstofregistrering med liter, pris og kilometertal samt vejledende forbrugsestimat.
- Abonnementer med månedlig og årlig pris.
- Rapporter for indeværende måned, kategorier og samlet økonomi.
- CSV-eksport, PDF-rapport og lokal JSON-backup/gendannelse.

## Konto og data
- Online-login via Supabase, når URL, nøgle og projekt er konfigureret.
- Manuel upload/hentning af appdata via Supabase.
- PIN og valgfri biometrisk oplåsning.

## Begrænsninger
- Automatisk bankintegration/betaling er ikke implementeret.
- Automatisk live-synkronisering mellem enheder er ikke implementeret; synkronisering er manuel.
- OCR læser billeder, ikke direkte PDF-dokumenter.
- Forbrugsberegning for bil er vejledende og afhænger af korrekte kilometertal og tankningsdata.
- Funktionen er ikke verificeret med en lokal Android-build i dette miljø; kør GitHub Actions og test på en fysisk enhed.


## Nyt i 3.7.0
- Rapport over de seneste seks måneders indtægter, udgifter og nettoresultat pr. måned.


### Brugerflade og arbejdsgang (3.9.1)
- Animerede overgange mellem faner.
- Filtrering af poster efter indtægt/udgift.
- Månedskorrekte summer på overblikket.
- Animerede ændringer i postkort.
