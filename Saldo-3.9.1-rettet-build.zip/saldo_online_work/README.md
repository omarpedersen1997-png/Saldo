# Saldo 3.9.1

Android-app til privatøkonomi. Se `START-HER.md` for opsætning og `FEATURES.md` for funktionsoversigt og begrænsninger.

## Bygning

Upload `Saldo-3.9.1-moderne-funktioner.zip` til repositoryets rod. Kopiér workflow-filen fra den udpakkede projektmappe til `.github/workflows/android-build.yml`, tilføj GitHub Actions Secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY`, og kør workflowet fra fanen Actions.

APK-artifact udgives som `Saldo-Android-debug-APK`, hvis buildet lykkes.


## Saldo 3.9.1
- Animerede, bløde overgange mellem faner.
- Transaktionsfiltre: Alle, Indtægt og Udgift.
- Overblikkets indtægter og udgifter beregnes for den aktuelle måned.
- Små størrelsesændringer i postkort animeres for en mere flydende oplevelse.
