# Kom i gang med Saldo 3.5.0

## GitHub Actions
1. Upload `Saldo-3.5.0-udvidede-funktioner.zip` til roden af dit GitHub-repository.
2. Kopiér workflow-filen fra ZIP'ens `.github/workflows/android-build.yml` til samme sti i selve GitHub-repositoryet.
3. Under repository → Settings → Secrets and variables → Actions skal du have `SUPABASE_URL` og `SUPABASE_ANON_KEY`.
4. I Supabase SQL Editor skal du køre `SUPABASE-SCHEMA.sql` fra ZIP-filen.
5. Gå til Actions → Build Saldo Android APK → Run workflow.
6. Når workflow lykkes, hentes APK'en under Artifacts med navnet `Saldo-Android-debug-APK`.

## Nye funktioner
- Manuel upload/hentning af backup online fra Indstillinger.
- PDF-rapport fra Indstillinger.
- Biometrisk oplåsning kan aktiveres i Indstillinger; den bruges ved næste app-start og på låseskærmen.
- Daglige baggrundskontroller af ubetalte regninger, der forfalder inden for tre dage (tillad notifikationer i Android).
- Månedlige regninger kan oprette næste forekomst, når den nuværende er markeret betalt.

## Begrænsninger
APK-build og enhedstest skal stadig udføres via GitHub Actions og på en Android-telefon. Cloud backup er manuel og erstatter hele datasættet ved hentning; der er ikke konfliktfletning. OCR læser billeder og kræver manuel kontrol. Ingen bankbetalinger eller automatisk banksynkronisering.
