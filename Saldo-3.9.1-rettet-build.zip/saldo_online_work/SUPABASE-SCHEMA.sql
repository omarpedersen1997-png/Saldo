-- Kør i Supabase Dashboard → SQL Editor → New query.
-- Hver bruger kan kun læse/skrive sin egen Saldo-backup.
create table if not exists public.saldo_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.saldo_user_data enable row level security;

drop policy if exists "Users can read their own Saldo data" on public.saldo_user_data;
drop policy if exists "Users can insert their own Saldo data" on public.saldo_user_data;
drop policy if exists "Users can update their own Saldo data" on public.saldo_user_data;

create policy "Users can read their own Saldo data"
  on public.saldo_user_data for select to authenticated
  using (auth.uid() = user_id);

create policy "Users can insert their own Saldo data"
  on public.saldo_user_data for insert to authenticated
  with check (auth.uid() = user_id);

create policy "Users can update their own Saldo data"
  on public.saldo_user_data for update to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

grant select, insert, update on public.saldo_user_data to authenticated;
