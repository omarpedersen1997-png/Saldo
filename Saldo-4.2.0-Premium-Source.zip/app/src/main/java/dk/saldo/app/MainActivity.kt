package dk.saldo.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.security.MessageDigest
import kotlin.math.ceil
import kotlin.math.ln

private val Night = Color(0xFF0A100F)
private val Panel = Color(0xFF121B19)
private val PanelRaised = Color(0xFF1B2925)
private val Violet = Color(0xFFB6F36A)
private val Blue = Color(0xFF75E0B7)
private val Mint = Color(0xFF9BEA83)
private val Muted = Color(0xFFA0B3AB)
private val White = Color(0xFFF3F8F4)
private val BorderSubtle = Color(0x20FFFFFF)
private fun money(v: Double) = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(v) + " kr."
private fun JSONObject.s(k: String, d: String = "") = optString(k, d).let { if (it == "null") d else it }
private fun JSONObject.n(k: String, d: Double = 0.0) = optDouble(k, d)
private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
private fun record(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(10, 16, 15)
        window.navigationBarColor = android.graphics.Color.rgb(10, 16, 15)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("saldo-bill-reminders", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<BillReminderWorker>(24, TimeUnit.HOURS).build())
        setContent { SaldoApp() }
    }
}

private val mainTabs = listOf("Overblik", "Poster", "Regninger", "Budget", "Mere")
private val moreTabs = listOf("Opsparing", "Gæld", "Bil", "Abonnementer", "Kalender", "Prognoser", "Rapporter", "Indstillinger")

@Composable private fun SaldoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("saldo_data_v4", Context.MODE_PRIVATE) }
    var data by remember {
        mutableStateOf(runCatching {
            val loaded = JSONObject(prefs.getString("data", "{}") ?: "{}")
            listOf("transactions", "bills", "budgets").forEach { key ->
                loaded.optJSONArray(key)?.objects()?.forEach { item ->
                    if (item.s("owner").equals("Kæreste", ignoreCase = true)) item.put("owner", "Partner")
                }
            }
            loaded
        }.getOrElse { JSONObject() })
    }
    LaunchedEffect(Unit) { prefs.edit().putString("data", data.toString()).apply() }
    fun list(key: String) = data.optJSONArray(key) ?: JSONArray()
    fun store(key: String, arr: JSONArray) { data.put(key, arr); prefs.edit().putString("data", data.toString()).apply(); data = JSONObject(data.toString()) }
    fun add(key: String, obj: JSONObject) { val arr = list(key); arr.put(obj); store(key, arr) }
    fun delete(key: String, id: String) { val arr = JSONArray(); list(key).objects().filterNot { it.s("id") == id }.forEach { arr.put(it) }; store(key, arr) }
    var tab by remember { mutableStateOf("Overblik") }
    var dialog by remember { mutableStateOf("") }
    var transactionSearch by remember { mutableStateOf("") }
    var transactionTypeFilter by remember { mutableStateOf("Alle") }
    var pin by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginConfirm by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loginMode by remember { mutableStateOf(false) }
    var accountUnlocked by remember { mutableStateOf(prefs.getString("online_access_token", null) != null) }
    var loginLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scheduleDueBillNotification(context, list("bills").objects())
        else Toast.makeText(context, "Notifikationer er slået fra. Aktivér dem i Android-indstillinger.", Toast.LENGTH_LONG).show()
    }
    var cloudStatus by remember { mutableStateOf("Ikke synkroniseret") }
    var cloudBusy by remember { mutableStateOf(false) }
    var unlocked by remember { mutableStateOf(prefs.getString("pin", null) == null && !prefs.getBoolean("biometric_enabled", false)) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1000); splash = false }
    val tx = list("transactions").objects()
    val bills = list("bills").objects()
    val income = tx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
    val expenses = tx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
    val thisMonthTx = tx.filter { runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> d.year == LocalDate.now().year && d.month == LocalDate.now().month } == true }
    val monthIncome = thisMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
    val monthExpenses = thisMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
    val unpaid = bills.filter { !it.optBoolean("paid", false) }.sumOf { it.n("amount") }
    val payday = runCatching { LocalDate.parse(prefs.getString("payday", LocalDate.now().toString())) }.getOrElse { LocalDate.now() }
    val payAmount = prefs.getFloat("pay_amount", 10000f).toDouble()
    val daysToPay = ChronoUnit.DAYS.between(LocalDate.now(), payday).toInt().let { ((it % 14) + 14) % 14 }
    LaunchedEffect(Unit) {
        val existing = (data.optJSONArray("bills") ?: JSONArray()).objects()
        val today = LocalDate.now()
        val additions = existing.filter { it.optBoolean("paid", false) && it.s("repeat").contains("måned", true) }.mapNotNull { bill ->
            val oldDate = runCatching { LocalDate.parse(bill.s("date")) }.getOrNull() ?: return@mapNotNull null
            val next = oldDate.plusMonths(1)
            if (next.isBefore(today.minusDays(3))) return@mapNotNull null
            val already = existing.any { it.s("name").equals(bill.s("name"), true) && it.s("date") == next.toString() && kotlin.math.abs(it.n("amount") - bill.n("amount")) < .01 }
            if (already) null else JSONObject(bill.toString()).put("id", "rec-${bill.s("id")}-${next}").put("date", next.toString()).put("paid", false)
        }
        if (additions.isNotEmpty()) { val arr = JSONArray(); (existing + additions).forEach { arr.put(it) }; store("bills", arr) }
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PanelRaised,
            onPrimary = White,
            secondary = Blue,
            onSecondary = Color(0xFF081A20),
            tertiary = Mint,
            background = Night,
            surface = Panel,
            surfaceVariant = PanelRaised,
            onSurface = White,
            onBackground = White,
            outline = BorderSubtle
        ),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(26.dp)
        )
    ) {
        if (splash) {
            Box(Modifier.fillMaxSize().background(Color(0xFF080B20)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(145.dp))
                    Spacer(Modifier.height(22.dp)); Text("SALDO", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = 4.sp)
                    Spacer(Modifier.height(7.dp)); Text("Dit overblik. Din økonomi.", color = Muted)
                    Spacer(Modifier.height(35.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf(Violet, Blue, Mint).forEach { Box(Modifier.size(6.dp).background(it, RoundedCornerShape(50))) } }
                }
            }
        } else if (!accountUnlocked) {
            Column(Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(112.dp))
                Spacer(Modifier.height(18.dp))
                Text(if (loginMode) "Opret onlinekonto" else "Log ind på Saldo", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Log ind via internettet med din e-mail og adgangskode.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))
                Field("E-mail", loginEmail, { loginEmail = it }, password = false)
                Field("Adgangskode", loginPassword, { loginPassword = it }, password = true)
                if (loginMode) Field("Gentag adgangskode", loginConfirm, { loginConfirm = it }, password = true)
                if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF7F9D), fontSize = 12.sp)
                Button(onClick = {
                    val email = loginEmail.trim().lowercase(Locale.ROOT)
                    when {
                        BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_ANON_KEY.isBlank() -> loginError = "Online-login er ikke konfigureret endnu. Tilføj SUPABASE_URL og SUPABASE_ANON_KEY i GitHub Secrets."
                        !email.contains("@") || loginPassword.length < 8 -> loginError = "Indtast en gyldig e-mail og adgangskode på mindst 8 tegn."
                        loginMode && loginPassword != loginConfirm -> loginError = "Adgangskoderne er ikke ens."
                        else -> {
                            loginLoading = true; loginError = ""
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    runCatching { supabaseAuth(email, loginPassword, loginMode) }
                                }
                                loginLoading = false
                                result.onSuccess { response ->
                                    val token = response.optString("access_token")
                                    if (loginMode && token.isBlank()) {
                                        loginError = "Kontoen er oprettet. Tjek din e-mail for bekræftelse, og log derefter ind."
                                    } else if (token.isBlank()) {
                                        loginError = "Serveren returnerede ingen login-session."
                                    } else {
                                        prefs.edit().putString("online_access_token", token).putString("online_refresh_token", response.optString("refresh_token")).putString("account_email", email).apply()
                                        accountUnlocked = true
                                    }
                                }.onFailure { e -> loginError = e.message ?: "Kunne ikke oprette forbindelse. Kontrollér internet og konto." }
                            }
                        }
                    }
                }, enabled = !loginLoading, modifier = Modifier.fillMaxWidth()) { Text(if (loginLoading) "Forbinder…" else if (loginMode) "Opret onlinekonto" else "Log ind") }
                TextButton(onClick = { loginMode = !loginMode; loginError = "" }) { Text(if (loginMode) "Jeg har allerede en konto" else "Opret onlinekonto", color = Blue) }
                Text("Login bruger en onlinekonto. Kontooplysninger gemmes ikke som en lokal adgangskode.", color = Muted, fontSize = 11.sp)
            }
        } else if (!unlocked) {
            Column(Modifier.fillMaxSize().background(Night).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(90.dp)); Text("Saldo er låst", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Field("PIN-kode", pin, { pin = it }, numeric = true, password = true)
                Button(onClick = { if (pin == prefs.getString("pin", "")) unlocked = true else pin = "" }) { Text("Lås op med PIN") }
                if (prefs.getBoolean("biometric_enabled", false)) Button(onClick = { val activity = context as? FragmentActivity; if (activity != null) startBiometric(activity, context) { unlocked = true } }, modifier = Modifier.fillMaxWidth()) { Text("Lås op med fingeraftryk") }
            }
        } else {
            Scaffold(containerColor = Night, bottomBar = {
                Surface(
                    color = Color(0xFF10151D),
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    tonalElevation = 0.dp,
                    shadowElevation = 12.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .055f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 9.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        mainTabs.forEach { t ->
                            val selected = tab == t
                            val icon = when (t) {
                                "Overblik" -> Icons.Default.Home
                                "Poster" -> Icons.Default.ReceiptLong
                                "Regninger" -> Icons.Default.CalendarMonth
                                "Budget" -> Icons.Default.PieChart
                                else -> Icons.Default.GridView
                            }
                            Surface(
                                onClick = { tab = t },
                                color = if (selected) Color(0xFF263D32) else Color.Transparent,
                                shape = RoundedCornerShape(17.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(icon, contentDescription = t, tint = if (selected) Blue else Muted, modifier = Modifier.size(20.dp))
                                    Text(t, color = if (selected) White else Muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(Color(0xFF101E19), Night, Color(0xFF080D0C)))).padding(horizontal = 20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(38.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("DIN ØKONOMI · ENKELT", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.55.sp)
                            Text(if (tab == "Overblik") "Godt overblik" else tab, color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.0).sp)
                        }
                        Surface(shape = RoundedCornerShape(14.dp), color = PanelRaised, border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .08f))) {
                            IconButton(onClick = { dialog = "post" }, modifier = Modifier.size(44.dp)) { Icon(Icons.Default.Add, "Tilføj post", tint = Blue, modifier = Modifier.size(22.dp)) }
                        }
                    }
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                        label = "Saldo-tab-transition"
                    ) { activeTab ->
                    when (activeTab) {
                        "Overblik" -> LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                            contentPadding = PaddingValues(bottom = 22.dp)
                        ) {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(
                                        LocalDate.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() } + " ${LocalDate.now().year}",
                                        color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .5.sp
                                    )
                                    Text("Mere styr på pengene.", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.65).sp)
                                    Text("Din måned samlet på ét sted.", color = Muted, fontSize = 12.sp)
                                }
                            }
                            item {
                                val available = monthIncome - monthExpenses - unpaid
                                val spendRatio = if (monthIncome > 0) (monthExpenses / monthIncome).toFloat().coerceIn(0f, 1f) else 0f
                                val animatedSpend by animateFloatAsState(spendRatio, animationSpec = tween(900, easing = FastOutSlowInEasing), label = "hero-spend")
                                Surface(
                                    shape = RoundedCornerShape(26.dp),
                                    color = Color.Transparent,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF203D31), Color(0xFF152820), Color(0xFF10201B))))) {
                                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(color = Color.White.copy(alpha = .10f), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) {
                                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountBalanceWallet, null, tint = Blue, modifier = Modifier.size(22.dp)) }
                                                }
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    Text("RÅDIGHEDSBELØB", color = White.copy(alpha = .72f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.35.sp)
                                                    Text("Efter registrerede regninger", color = Muted, fontSize = 11.sp)
                                                }
                                                Surface(color = if (available >= 0) Color(0x263CE0B0) else Color(0x26FF7798), shape = RoundedCornerShape(50)) {
                                                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                                        Box(Modifier.size(6.dp).background(if (available >= 0) Mint else Color(0xFFFF91A9), RoundedCornerShape(50)))
                                                        Text(if (available >= 0) "På sporet" else "Underskud", color = if (available >= 0) Mint else Color(0xFFFF91A9), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                }
                                            }
                                            AnimatedContent(targetState = available, transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(140)) }, label = "balance-number") { amount ->
                                                Text(money(amount), color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.25).sp, maxLines = 1)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("FORBRUG AF INDTÆGTER", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .6.sp)
                                                    Text("${(spendRatio * 100).toInt()}% brugt", color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(58.dp)) {
                                                    CircularProgressIndicator(progress = { animatedSpend }, modifier = Modifier.fillMaxSize(), color = Blue, trackColor = Color.White.copy(alpha = .12f), strokeWidth = 5.dp)
                                                    Icon(if (spendRatio < .8f) Icons.Default.TrendingUp else Icons.Default.TrendingDown, null, tint = if (spendRatio < .8f) Mint else Color(0xFFFFC078), modifier = Modifier.size(20.dp))
                                                }
                                            }
                                            Box(Modifier.fillMaxWidth().height(7.dp).background(Color.White.copy(alpha = .10f), RoundedCornerShape(50))) {
                                                Box(Modifier.fillMaxWidth(animatedSpend).fillMaxHeight().background(Brush.horizontalGradient(listOf(Violet, Blue, Mint)), RoundedCornerShape(50)))
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("NÆSTE LØN", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .5.sp)
                                                    Text(if (daysToPay == 0) "I dag" else "Om $daysToPay dage", color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("LØN PR. GANG", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .5.sp)
                                                    Text(money(payAmount), color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                    QuickAction("Ny post", Icons.Default.AddCircle, { dialog = "post" }, Modifier.weight(1f))
                                    QuickAction("Regning", Icons.Default.ReceiptLong, { dialog = "bill" }, Modifier.weight(1f))
                                    QuickAction("Budget", Icons.Default.Tune, { tab = "Budget" }, Modifier.weight(1f))
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text("Månedens overblik", color = White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.35).sp)
                                        Text("Indtægter og udgifter indtil nu", color = Muted, fontSize = 12.sp)
                                    }
                                    Surface(color = PanelRaised, shape = RoundedCornerShape(10.dp)) {
                                        Text("${LocalDate.now().monthValue}/${LocalDate.now().year}", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    DashboardMetric("Indtægter", money(monthIncome), Icons.Default.ArrowDownward, Mint, Modifier.weight(1f))
                                    DashboardMetric("Udgifter", money(monthExpenses), Icons.Default.ArrowUpward, Violet, Modifier.weight(1f))
                                }
                            }
                            item { MonthlyFlowCard(monthIncome = monthIncome, monthExpenses = monthExpenses) }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text("Kommende regninger", color = White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                        Text("Hold styr på det næste, der skal betales", color = Muted, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { tab = "Regninger" }) { Text("Se alle", color = Blue) }
                                }
                            }
                            if (bills.none { !it.optBoolean("paid", false) }) item {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Color(0x2639B982), shape = RoundedCornerShape(14.dp), modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, null, tint = Mint) } }
                                        Spacer(Modifier.width(12.dp))
                                        Column { Text("Alt er betalt", color = White, fontWeight = FontWeight.SemiBold); Text("Du har ingen ubetalte regninger lige nu.", color = Muted, fontSize = 11.sp) }
                                    }
                                }
                            }
                            items(bills.filter { !it.optBoolean("paid", false) }.sortedBy { it.s("date") }.take(3), key = { it.s("id") }) { b ->
                                UpcomingBillCard(b.s("name"), b.s("date"), money(b.n("amount"))) { updatePaid(bills, b, ::store) }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text("Seneste aktivitet", color = White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                        Text("Dine senest registrerede poster", color = Muted, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { tab = "Poster" }) { Text("Alle poster", color = Blue) }
                                }
                            }
                            items(tx.sortedByDescending { it.s("date") }.take(4), key = { "recent-${it.s("id")}" }) { x ->
                                RecordRow(x.s("name"), "${x.s("date")} · ${x.s("category")} · ${x.s("owner", "Mig")}", money(x.n("amount")), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) })
                            }
                        }
                        "Poster" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Indtægter og udgifter", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.45).sp)
                                    Text("Alle dine bevægelser samlet ét sted", color = Muted, fontSize = 11.sp)
                                }
                                FilledTonalButton(onClick = { dialog = "post" }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Ny post")
                                }
                            }
                            OutlinedTextField(
                                value = transactionSearch,
                                onValueChange = { transactionSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Søg efter navn, kategori eller dato") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = BorderSubtle, focusedLabelColor = Violet, unfocusedLabelColor = Muted)
                            )
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Alle", "Indtægt", "Udgift").forEach { filter ->
                                    FilterChip(selected = transactionTypeFilter == filter, onClick = { transactionTypeFilter = filter }, label = { Text(filter) }, leadingIcon = if (transactionTypeFilter == filter) ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }) else null)
                                }
                            }
                            val filteredTransactions = tx.filter { (transactionTypeFilter == "Alle" || it.s("type") == transactionTypeFilter) && (transactionSearch.isBlank() || listOf(it.s("name"), it.s("category"), it.s("date"), it.s("owner"), it.s("type")).any { field -> field.contains(transactionSearch, true) }) }.sortedByDescending { it.s("date") }
                            if (filteredTransactions.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(28.dp))
                                        Text("Ingen poster fundet", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Prøv en anden søgning eller opret en ny post.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                items(filteredTransactions, key = { it.s("id") }) { x -> RecordRow(x.s("name"), "${x.s("date")} · ${x.s("category")} · ${x.s("owner", "Mig")}", money(x.n("amount")), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }) }
                            }
                        }
                        "Regninger" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Regninger", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.45).sp)
                                    Text("Forfald, betalinger og faste udgifter", color = Muted, fontSize = 11.sp)
                                }
                                FilledTonalButton(onClick = { dialog = "bill" }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("Ny regning")
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(onClick = { dialog = "ocr" }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Violet)) { Icon(Icons.Default.DocumentScanner, null); Spacer(Modifier.width(6.dp)); Text("Scan regning") }
                                FilledTonalButton(onClick = { tab = "Kalender" }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Blue)) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(6.dp)); Text("Kalender") }
                            }
                            val unpaidBills = bills.filter { !it.optBoolean("paid", false) }
                            val paidBills = bills.filter { it.optBoolean("paid", false) }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                DashboardMetric("Ubetalte", money(unpaidBills.sumOf { it.n("amount") }), Icons.Default.Schedule, Violet, Modifier.weight(1f))
                                DashboardMetric("Betalte", paidBills.size.toString(), Icons.Default.CheckCircle, Mint, Modifier.weight(1f))
                            }
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                items(bills.sortedWith(compareBy<JSONObject> { it.optBoolean("paid", false) }.thenBy { it.s("date") }), key = { it.s("id") }) { b ->
                                    RecordRow(b.s("name"), "${b.s("date")} · ${if (b.optBoolean("paid")) "Betalt" else "Ubetalt"} · ${b.s("repeat", "Engangsbetaling")}", money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) })
                                }
                            }
                        }
                        "Budget" -> Column(Modifier.fillMaxSize()) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Dine budgetter", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                                    Text("${LocalDate.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() }} · registreret forbrug", color = Muted, fontSize = 11.sp)
                                }
                                FilledTonalButton(onClick = { dialog = "budget" }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Nyt budget")
                                }
                            }
                            val budgetItems = list("budgets").objects()
                            val totalLimit = budgetItems.sumOf { it.n("limit") }
                            val totalSpent = budgetItems.sumOf { b -> tx.filter { it.s("type") == "Udgift" && it.s("category").equals(b.s("category"), true) && it.s("owner", "Mig").equals(b.s("owner", "Husstand"), true) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> d.year == LocalDate.now().year && d.month == LocalDate.now().month } == true }.sumOf { it.n("amount") } }
                            val totalRatio = if (totalLimit > 0) (totalSpent / totalLimit).toFloat().coerceIn(0f, 1f) else 0f
                            Surface(color = Color.Transparent, shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                                Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFF20372D), Color(0xFF14221C)))).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("SAMLET BUDGETSTATUS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(money((totalLimit - totalSpent).coerceAtLeast(0.0)), color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.7).sp)
                                            Text("tilbage af ${money(totalLimit)}", color = Muted, fontSize = 11.sp)
                                        }
                                        Text("${(totalRatio * 100).toInt()}% brugt", color = if (totalRatio >= 1f) Color(0xFFFF91A9) else Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White.copy(alpha = .08f), RoundedCornerShape(50))) {
                                        Box(Modifier.fillMaxWidth(totalRatio).fillMaxHeight().background(Brush.horizontalGradient(listOf(Violet, Blue, Mint)), RoundedCornerShape(50)))
                                    }
                                }
                            }
                            if (budgetItems.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Tune, null, tint = Violet, modifier = Modifier.size(32.dp))
                                        Text("Lav dit første budget", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Sæt en månedlig grænse for en kategori, og følg forbruget her.", color = Muted, fontSize = 12.sp)
                                        FilledTonalButton(onClick = { dialog = "budget" }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) { Text("Opret budget") }
                                    }
                                }
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                    items(budgetItems, key = { it.s("id") }) { b ->
                                        val spent = tx.filter { it.s("type") == "Udgift" && it.s("category").equals(b.s("category"), true) && it.s("owner", "Mig").equals(b.s("owner", "Husstand"), true) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> d.year == LocalDate.now().year && d.month == LocalDate.now().month } == true }.sumOf { it.n("amount") }
                                        val limit = b.n("limit")
                                        val ratio = if (limit > 0) (spent / limit).toFloat().coerceAtLeast(0f) else 0f
                                        val animatedRatio by animateFloatAsState(ratio.coerceIn(0f, 1f), animationSpec = tween(750, easing = FastOutSlowInEasing), label = "budget-${b.s("id")}")
                                        val over = ratio >= 1f
                                        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Surface(color = if (over) Color(0x22FF7798) else Color(0x263F6B4E), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(40.dp)) {
                                                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PieChart, null, tint = if (over) Color(0xFFFF91A9) else Violet, modifier = Modifier.size(20.dp)) }
                                                    }
                                                    Spacer(Modifier.width(11.dp))
                                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                        Text(b.s("category"), color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                                        Text(b.s("owner", "Husstand"), color = Muted, fontSize = 10.sp)
                                                    }
                                                    Surface(color = if (over) Color(0x24FF7798) else Color(0x1F3CE0B0), shape = RoundedCornerShape(9.dp)) {
                                                        Text(if (over) "Overskredet" else "${((1f - ratio.coerceIn(0f, 1f)) * 100).toInt()}% tilbage", color = if (over) Color(0xFFFF91A9) else Mint, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                                                    }
                                                }
                                                Row(verticalAlignment = Alignment.Bottom) {
                                                    Text(money(spent), color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text("af ${money(limit)}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                                                }
                                                Box(Modifier.fillMaxWidth().height(7.dp).background(Color.White.copy(alpha = .07f), RoundedCornerShape(50))) {
                                                    Box(Modifier.fillMaxWidth(animatedRatio).fillMaxHeight().background(Brush.horizontalGradient(if (over) listOf(Color(0xFFFF7798), Color(0xFFFFB07C)) else listOf(Violet, Blue)), RoundedCornerShape(50)))
                                                }
                                                Text(if (over) "Budget overskredet med ${money(spent - limit)}" else "Tilbage: ${money(limit - spent)}", color = if (over) Color(0xFFFF91A9) else Muted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "Mere" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                            item {
                                Column(Modifier.padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Flere værktøjer", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                                    Text("Alt det ekstra til at holde styr på økonomien.", color = Muted, fontSize = 12.sp)
                                }
                            }
                            items(moreTabs) { t ->
                                val icon = when (t) {
                                    "Opsparing" -> Icons.Default.AccountBalanceWallet
                                    "Gæld" -> Icons.Default.AccountBalance
                                    "Bil" -> Icons.Default.DirectionsCar
                                    "Abonnementer" -> Icons.Default.Sync
                                    "Kalender" -> Icons.Default.CalendarMonth
                                    "Prognoser" -> Icons.Default.TrendingUp
                                    "Rapporter" -> Icons.Default.Insights
                                    else -> Icons.Default.Settings
                                }
                                val subtitle = when (t) {
                                    "Opsparing" -> "Følg dine mål og fremskridt"
                                    "Gæld" -> "Restgæld, renter og afdrag"
                                    "Bil" -> "Tankninger og brændstofforbrug"
                                    "Abonnementer" -> "Faste betalinger og årlige omkostninger"
                                    "Kalender" -> "Se regninger efter forfaldsdato"
                                    "Prognoser" -> "Et estimat for de kommende måneder"
                                    "Rapporter" -> "Opsummeringer og eksport af data"
                                    else -> "Sikkerhed, backup og onlinekonto"
                                }
                                Surface(onClick = { tab = t }, color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Color(0x263F6B4E), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(44.dp)) {
                                            Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Violet, modifier = Modifier.size(21.dp)) }
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(t, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                            Text(subtitle, color = Muted, fontSize = 10.sp)
                                        }
                                        Icon(Icons.Default.ArrowForward, null, tint = Blue, modifier = Modifier.size(17.dp))
                                    }
                                }
                            }
                        }
                        "Opsparing" -> ManagedList("Opsparingsmål", list("goals").objects(), { dialog = "goal" }, { g -> RecordRow(g.s("name"), "Mål ${money(g.n("target"))} · ${g.s("date")}", "Sparet ${money(g.n("saved"))}", true, { delete("goals", g.s("id")) }) })
                        "Gæld" -> { val debts = list("debts").objects(); Column(Modifier.fillMaxSize()) { Metric("Samlet restgæld", money(debts.sumOf { it.n("balance") }), Modifier.fillMaxWidth(), positive = false); Metric("Samlede månedlige afdrag", money(debts.sumOf { it.n("payment") }), Modifier.fillMaxWidth()); val monthlyInterest = debts.sumOf { it.n("balance") * it.n("rate") / 1200.0 }; Metric("Anslåede renter pr. måned", money(monthlyInterest), Modifier.fillMaxWidth(), positive = false); ManagedList("Gæld og afdragsplan", debts, { dialog = "debt" }) { d -> val balance = d.n("balance"); val payment = d.n("payment"); val rate = d.n("rate") / 1200.0; val months = if (payment <= balance * rate || payment <= 0) null else if (rate > 0) ceil(ln(payment / (payment - balance * rate)) / ln(1 + rate)).toInt() else ceil(balance / payment).toInt(); RecordRow(d.s("name"), "Rente ${d.n("rate")}% · ${months?.let { "$it mdr. tilbage" } ?: "Afdrag dækker ikke renten"}", money(balance), false, { delete("debts", d.s("id")) }) } } }
                        "Bil" -> { val fuel = list("fuel").objects().sortedBy { it.n("km") }; val totalLiters = fuel.sumOf { it.n("liters") }; val totalCost = fuel.sumOf { it.n("cost") }; val kmSpan = if (fuel.size >= 2) fuel.last().n("km") - fuel.first().n("km") else 0.0; val consumption = if (kmSpan > 0) totalLiters * 100 / kmSpan else 0.0; Column(Modifier.fillMaxSize()) { Text("Brændstof og biløkonomi", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Metric("Samlet brændstof", String.format(Locale("da", "DK"), "%.1f liter", totalLiters), Modifier.weight(1f)); Metric("Samlet pris", money(totalCost), Modifier.weight(1f), positive = false) }; Metric("Gennemsnitligt forbrug", if (consumption > 0) String.format(Locale("da", "DK"), "%.1f l/100 km", consumption) else "Registrér mindst 2 tankninger med km-stand", Modifier.fillMaxWidth()); Text("Beregningen bruger forskellen mellem laveste og højeste registrerede kilometertal. Registrér km-stand ved hver tankning.", color = Muted, fontSize = 11.sp); ManagedList("Tankninger", fuel, { dialog = "fuel" }) { f -> val pricePerLiter = if (f.n("liters") > 0) f.n("cost") / f.n("liters") else 0.0; RecordRow(f.s("date"), "${f.n("liters")} liter · ${f.n("km")} km · ${money(pricePerLiter)}/liter", money(f.n("cost")), true, { delete("fuel", f.s("id")) }) } } }
                        "Abonnementer" -> ManagedList("Abonnementer", list("subs").objects(), { dialog = "sub" }, { s -> RecordRow(s.s("name"), "Årligt ${money(s.n("monthly") * 12)}", "${money(s.n("monthly"))}/md.", false, { delete("subs", s.s("id")) }) })
                        "Kalender" -> LazyColumn { item { Text("Regningskalender", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("date"), b.s("name"), money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) } }
                        "Prognoser" -> {
                            val monthlyIncome = (prefs.getFloat("pay_amount", 10000f).toDouble() * 26.0 / 12.0)
                            val cutoff = LocalDate.now().minusDays(90)
                            val recentExpenses = tx.filter { it.s("type") == "Udgift" && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(cutoff) } == true }.sumOf { it.n("amount") }
                            val monthlyExpenses = recentExpenses / 3.0
                            val unpaidDueSoon = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(90)) } == true }.sumOf { it.n("amount") }
                            val netMonthly = monthlyIncome - monthlyExpenses
                            val forecastItems = listOf(30 to 1.0, 60 to 2.0, 90 to 3.0)
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Økonomisk prognose", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("Et vejledende estimat baseret på din lønindstilling, registrerede udgifter og ubetalte regninger.", color = Muted, fontSize = 12.sp)
                                Metric("Forventet løn pr. måned", money(monthlyIncome), Modifier.fillMaxWidth(), positive = true)
                                Metric("Gennemsnitlige månedlige udgifter (seneste 90 dage)", money(monthlyExpenses), Modifier.fillMaxWidth(), positive = false)
                                Metric("Ubetalte regninger med forfald inden 90 dage", money(unpaidDueSoon), Modifier.fillMaxWidth(), positive = false)
                                forecastItems.forEach { (days, months) ->
                                    val dueInPeriod = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(days.toLong())) } == true }.sumOf { it.n("amount") }
                                    val projection = netMonthly * months - dueInPeriod
                                    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) { Text("Næste $days dage", color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); Text("Forventet ændring i saldo", color = Muted, fontSize = 12.sp) }
                                            Text(money(projection), color = if (projection >= 0) Mint else Color(0xFFFF7F9D), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        }
                                    }
                                }
                                Text("Bemærk: Prognosen er et estimat, ikke en bankbalance. Den bruger lønindstillingen, gennemsnittet af registrerede udgifter de seneste 90 dage og ubetalte regninger med forfald i perioden. Manglende poster gør prognosen mindre præcis.", color = Muted, fontSize = 11.sp)
                            }
                        }
                        "Rapporter" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) { val currentMonthTx = tx.filter { runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> d.year == LocalDate.now().year && d.month == LocalDate.now().month } == true }; val monthIncome = currentMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }; val monthExpenses = currentMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }; val categories = currentMonthTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse") }.mapValues { entry -> entry.value.sumOf { it.n("amount") } }.toList().sortedByDescending { it.second }; Text("Rapporter", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Denne måned", color = Muted, fontSize = 13.sp); Metric("Indtægter denne måned", money(monthIncome), Modifier.fillMaxWidth(), positive = true); Metric("Udgifter denne måned", money(monthExpenses), Modifier.fillMaxWidth(), positive = false); Metric("Månedens netto", money(monthIncome - monthExpenses), Modifier.fillMaxWidth(), positive = monthIncome >= monthExpenses); Text("Udvikling – seneste 6 måneder", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); val monthTrend = (0..5).map { offset -> val month = LocalDate.now().withDayOfMonth(1).minusMonths((5 - offset).toLong()); val monthEntries = tx.filter { runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> d.year == month.year && d.month == month.month } == true }; Triple(month, monthEntries.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }, monthEntries.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }) }; monthTrend.forEach { (month, trendIncome, trendExpenses) -> Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Text("${month.monthValue}/${month.year}", color = White, fontWeight = FontWeight.SemiBold); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Indtægt", color = Muted, fontSize = 12.sp); Text(money(trendIncome), color = Mint, fontSize = 12.sp) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Udgift", color = Muted, fontSize = 12.sp); Text(money(trendExpenses), color = Color(0xFFFF7F9D), fontSize = 12.sp) }; HorizontalDivider(color = Muted.copy(alpha = .2f)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Netto", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text(money(trendIncome - trendExpenses), color = if (trendIncome >= trendExpenses) Mint else Color(0xFFFF7F9D), fontSize = 12.sp, fontWeight = FontWeight.Bold) } } } }; Text("Største udgiftskategorier", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); if (categories.isEmpty()) Text("Ingen udgifter registreret i denne måned endnu.", color = Muted) else categories.take(5).forEach { (category, total) -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(category, Modifier.weight(1f), color = White); Text(money(total), color = Violet, fontWeight = FontWeight.SemiBold) } }; HorizontalDivider(color = Muted.copy(alpha = .25f)); Metric("Samlede indtægter (alle poster)", money(income), Modifier.fillMaxWidth(), positive = true); Metric("Samlede udgifter (alle poster)", money(expenses), Modifier.fillMaxWidth(), positive = false); Metric("Netto (alle poster)", money(income - expenses), Modifier.fillMaxWidth()); Metric("Abonnementer pr. år", money(list("subs").objects().sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth()); Button(onClick = { shareCsv(context, tx, bills) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér CSV") }; Button(onClick = { shareBackup(context, data.toString()) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") } }
                        "Indstillinger" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Indstillinger", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            SettingsAction("Løn og næste løndato", "Tilpas løn og lønrytme", Icons.Default.CalendarMonth) { dialog = "payday" }
                            SettingsAction("Opret / ændr PIN", "Beskyt appen med en PIN-kode", Icons.Default.Lock) { dialog = "pin" }
                            SettingsAction("Biometrisk oplåsning", "Brug fingeraftryk eller ansigt", Icons.Default.Fingerprint) { val activity = context as? FragmentActivity; if (activity != null) startBiometric(activity, context) { prefs.edit().putBoolean("biometric_enabled", true).apply(); Toast.makeText(context, "Biometrisk oplåsning aktiveret.", Toast.LENGTH_SHORT).show() } else Toast.makeText(context, "Biometrisk oplåsning er ikke tilgængelig her.", Toast.LENGTH_LONG).show() }
                            SettingsAction("Eksportér sikkerhedskopi", "Gem en kopi af dine data", Icons.Default.CloudUpload) { shareBackup(context, data.toString()) }
                            SettingsAction("Gendan sikkerhedskopi", "Gendan fra en tidligere kopi", Icons.Default.Restore) { dialog = "backup" }
                            SettingsAction("Eksportér PDF-rapport", "Lav en rapport over din økonomi", Icons.Default.PictureAsPdf) { sharePdfReport(context, tx, bills, income, expenses) }
                            SettingsAction("Gem lokale data online", "Sikkerhedskopiér til din onlinekonto", Icons.Default.CloudUpload, enabled = !cloudBusy, trailing = if (cloudBusy) Icons.Default.Sync else Icons.Default.ArrowForward) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før synkronisering."
                                else { cloudBusy = true; cloudStatus = "Gemmer online…"; scope.launch {
                                    val result = withContext(Dispatchers.IO) { runCatching { syncCloud(token, data) } }
                                    cloudBusy = false
                                    result.onSuccess { cloudStatus = "Lokale data er gemt online." }.onFailure { cloudStatus = "Synkronisering fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            SettingsAction("Hent data fra onlinekonto", "Hent din seneste online sikkerhedskopi", Icons.Default.CloudDownload, enabled = !cloudBusy) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før hentning."
                                else { cloudBusy = true; cloudStatus = "Henter online data…"; scope.launch {
                                    val result = withContext(Dispatchers.IO) { runCatching { fetchCloud(token) } }
                                    cloudBusy = false
                                    result.onSuccess { cloudData -> if (cloudData == null) cloudStatus = "Der er ingen online backup endnu." else { data = cloudData; prefs.edit().putString("data", cloudData.toString()).apply(); cloudStatus = "Online data hentet og gemt lokalt." } }.onFailure { cloudStatus = "Hentning fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) { Text(cloudStatus, color = Blue, fontSize = 12.sp, modifier = Modifier.padding(14.dp)) }
                            SettingsAction("Notifikationer og regninger", "Kontrollér kommende forfald", Icons.Default.NotificationsActive) { if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS) else scheduleDueBillNotification(context, bills) }
                            SettingsAction("Log ud", "Afslut online-sessionen", Icons.Default.Logout, danger = true) { prefs.edit().remove("online_access_token").remove("online_refresh_token").apply(); accountUnlocked = false; loginMode = false; loginPassword = ""; loginConfirm = "" }
                            Text("Online-login og online-synkronisering kræver Supabase-konfiguration og SQL-adgangsreglerne i ONLINE-LOGIN.md. Synkronisering er manuel; slå ikke automatisk bankbetaling til.", color = Muted, fontSize = 12.sp)
                        }
                    }
                    }
                }
            }
        }
        if (dialog.isNotEmpty()) {
            DataDialog(dialog, onDismiss = { dialog = "" }, onSave = { kind, obj ->
                when (kind) {
                    "post" -> add("transactions", obj)
                    "bill" -> {
                        val duplicate = list("bills").objects().any { it.s("name").equals(obj.s("name"), true) && it.s("date") == obj.s("date") && kotlin.math.abs(it.n("amount") - obj.n("amount")) < 0.01 }
                        if (duplicate) Toast.makeText(context, "Mulig dublet: regningen findes allerede", Toast.LENGTH_LONG).show() else add("bills", obj)
                    }
                    "budget" -> add("budgets", obj)
                    "goal" -> add("goals", obj)
                    "debt" -> add("debts", obj)
                    "fuel" -> add("fuel", obj)
                    "sub" -> add("subs", obj)
                    "payday" -> prefs.edit().putFloat("pay_amount", obj.n("pay").toFloat()).putString("payday", obj.s("date")).apply()
                    "pin" -> { prefs.edit().putString("pin", obj.s("pin")).apply(); unlocked = true }
                    "backup" -> { prefs.edit().putString("data", obj.s("json")).apply(); data = JSONObject(obj.s("json")) }
                }
                dialog = ""
            })
        }
    }
}

class BillReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return runCatching {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
            val prefs = applicationContext.getSharedPreferences("saldo_data_v4", Context.MODE_PRIVATE)
            val data = JSONObject(prefs.getString("data", "{}") ?: "{}")
            val bills = (data.optJSONArray("bills") ?: JSONArray()).objects()
            val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
            if (due.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = due.take(5).joinToString("\n") { "${it.s("name")}: ${money(it.n("amount"))} · ${it.s("date")}" }
                val n = NotificationCompat.Builder(applicationContext, "saldo_bills").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(351, n)
            }
        }.fold({ Result.success() }, { Result.retry() })
    }
}

private fun cloudRequest(path: String, token: String, method: String = "GET", body: JSONObject? = null, prefer: String? = null): String {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL mangler eller er ikke HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val c = (URL("$base$path").openConnection() as HttpURLConnection).apply {
        requestMethod = method; connectTimeout = 15000; readTimeout = 20000; doInput = true
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        setRequestProperty("Authorization", "Bearer $token")
        setRequestProperty("Content-Type", "application/json")
        if (prefer != null) setRequestProperty("Prefer", prefer)
        if (body != null) doOutput = true
    }
    try {
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("Supabase HTTP $code: ${runCatching { JSONObject(text).optString("message") }.getOrDefault(text).take(240)}")
        return text
    } finally { c.disconnect() }
}

private fun currentCloudUserId(token: String): String {
    val user = JSONObject(cloudRequest("/auth/v1/user", token))
    return user.optString("id").takeIf { it.isNotBlank() } ?: throw IllegalStateException("Kunne ikke identificere onlinekontoen.")
}

private fun syncCloud(token: String, data: JSONObject) {
    val userId = currentCloudUserId(token)
    val body = JSONObject().put("user_id", userId).put("data", data).put("updated_at", java.time.Instant.now().toString())
    cloudRequest("/rest/v1/saldo_user_data?on_conflict=user_id", token, "POST", body, "resolution=merge-duplicates,return=minimal")
}

private fun fetchCloud(token: String): JSONObject? {
    val userId = currentCloudUserId(token)
    val rows = JSONArray(cloudRequest("/rest/v1/saldo_user_data?select=data&user_id=eq.$userId&limit=1", token))
    return if (rows.length() == 0) null else rows.optJSONObject(0)?.optJSONObject("data")
}

private fun startBiometric(activity: FragmentActivity, context: Context, onSuccess: () -> Unit = {}) {
    val manager = BiometricManager.from(context)
    if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
        Toast.makeText(context, "Ingen biometrisk oplåsning er sat op på telefonen.", Toast.LENGTH_LONG).show(); return
    }
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            Toast.makeText(context, "Biometrisk kontrol lykkedes.", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
        override fun onAuthenticationFailed() { Toast.makeText(context, "Fingeraftryk blev ikke genkendt.", Toast.LENGTH_SHORT).show() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { Toast.makeText(context, errString, Toast.LENGTH_SHORT).show() }
    })
    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Lås Saldo op").setSubtitle("Bekræft din identitet").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Annuller").build())
}

private fun scheduleDueBillNotification(context: Context, bills: List<JSONObject>) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Tillad notifikationer i Android-indstillinger for at modtage påmindelser.", Toast.LENGTH_LONG).show(); return
    }
    val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
    if (due.isEmpty()) { Toast.makeText(context, "Ingen ubetalte regninger med forfald inden for 3 dage.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
    val details = due.take(4).joinToString("\n") { "${it.s("name")}: ${money(it.n("amount"))} · ${it.s("date")}" }
    val notification = NotificationCompat.Builder(context, "saldo_bills").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(details)).setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(351, notification)
    Toast.makeText(context, "Påmindelse sendt for ${due.size} regning(er). Dette er en manuel kontrol, ikke en daglig baggrundsalarm.", Toast.LENGTH_LONG).show()
}

private fun sharePdfReport(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>, income: Double, expenses: Double) {
    runCatching {
        val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val canvas = page.canvas
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(30, 38, 52); textSize = 24f; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        canvas.drawText("Saldo – økonomirapport", 40f, 55f, paint)
        paint.textSize = 12f; paint.typeface = android.graphics.Typeface.DEFAULT
        canvas.drawText("Dato: ${LocalDate.now()}", 40f, 82f, paint)
        canvas.drawText("Indtægter registreret: ${money(income)}", 40f, 120f, paint)
        canvas.drawText("Udgifter registreret: ${money(expenses)}", 40f, 145f, paint)
        canvas.drawText("Netto: ${money(income - expenses)}", 40f, 170f, paint)
        canvas.drawText("Poster: ${transactions.size}", 40f, 195f, paint)
        canvas.drawText("Regninger: ${bills.size} · Ubetalte: ${bills.count { !it.optBoolean("paid") }}", 40f, 220f, paint)
        paint.textSize = 10f
        var y = 260f
        canvas.drawText("Seneste poster", 40f, y, paint); y += 18f
        transactions.sortedByDescending { it.s("date") }.take(22).forEach { t ->
            if (y > 790f) return@forEach
            val line = "${t.s("date")}  ${t.s("name").take(35)}  ${money(t.n("amount"))}  ${t.s("type")}".take(100)
            canvas.drawText(line, 40f, y, paint); y += 20f
        }
        doc.finishPage(page)
        val file = File(context.cacheDir, "Saldo-rapport-${LocalDate.now()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }; doc.close()
        val uri: Uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_SUBJECT, "Saldo-økonomirapport").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Del PDF-rapport"))
    }.onFailure { Toast.makeText(context, "Kunne ikke oprette PDF: ${it.message}", Toast.LENGTH_LONG).show() }
}

private fun supabaseAuth(email: String, password: String, signUp: Boolean): JSONObject {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    val endpoint = if (signUp) "$base/auth/v1/signup" else "$base/auth/v1/token?grant_type=password"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
    }
    try {
        val body = JSONObject().put("email", email).put("password", password).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
        if (status !in 200..299) {
            val message = json.optString("msg").ifBlank { json.optString("message") }.ifBlank { json.optString("error_description") }.ifBlank { json.optString("error") }.ifBlank { "Online-login fejlede (HTTP $status)." }
            throw IllegalStateException(message)
        }
        return json
    } finally { connection.disconnect() }
}

private fun passwordHash(password: String): String = MessageDigest.getInstance("SHA-256").digest(password.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

private fun updatePaid(bills: List<JSONObject>, target: JSONObject, store: (String, JSONArray) -> Unit) { val arr = JSONArray(); bills.forEach { b -> arr.put(if (b.s("id") == target.s("id")) JSONObject(b.toString()).put("paid", !b.optBoolean("paid")) else b) }; store("bills", arr) }

@Composable private fun MonthlyFlowCard(monthIncome: Double, monthExpenses: Double) {
    val ratio = if (monthIncome > 0.0) (monthExpenses / monthIncome).toFloat().coerceIn(0f, 1f) else if (monthExpenses > 0.0) 1f else 0f
    val animatedRatio by animateFloatAsState(
        targetValue = ratio,
        animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing),
        label = "monthly-expense-progress"
    )
    Surface(
        color = Panel,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Månedens pengestrøm", color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("Forbrug sammenholdt med indtægter", color = Muted, fontSize = 11.sp)
                }
                Surface(color = if (monthIncome >= monthExpenses) Color(0x243ED7A5) else Color(0x24FF7798), shape = RoundedCornerShape(10.dp)) {
                    Text(if (monthIncome >= monthExpenses) "Positiv" else "Underskud", color = if (monthIncome >= monthExpenses) Mint else Color(0xFFFF91A9), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
            Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White.copy(alpha = .07f), RoundedCornerShape(50))) {
                Box(Modifier.fillMaxWidth(animatedRatio).fillMaxHeight().background(Brush.horizontalGradient(listOf(Violet, Blue, Mint)), RoundedCornerShape(50)))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Forbrug", color = Muted, fontSize = 10.sp)
                    Text(money(monthExpenses), color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Tilbage af indtægter", color = Muted, fontSize = 10.sp)
                    Text(money(monthIncome - monthExpenses), color = if (monthIncome >= monthExpenses) Mint else Color(0xFFFF91A9), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable private fun SettingsAction(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    danger: Boolean = false,
    trailing: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.ChevronRight,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = if (danger) Color(0x24FF7798) else Color(0x263F6B4E), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = if (danger) Color(0xFFFF91A9) else Violet, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = if (danger) Color(0xFFFF91A9) else White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
            Icon(trailing, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable private fun Metric(label: String, value: String, modifier: Modifier = Modifier, positive: Boolean? = null) {
    Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(20.dp), tonalElevation = 0.dp, border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.size(7.dp).background(when (positive) { true -> Mint; false -> Violet; else -> Blue }, RoundedCornerShape(50)))
                Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = .05.sp, maxLines = 1)
            }
            Text(value, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.25).sp, maxLines = 1)
        }
    }
}
@Composable private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        color = Color(0xFF15221C),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A4035)),
        modifier = modifier
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Surface(color = Color(0xFF2B4436), shape = RoundedCornerShape(15.dp), modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Violet, modifier = Modifier.size(22.dp)) }
            }
            Text(label, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable private fun DashboardMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = accent.copy(alpha = .13f), shape = RoundedCornerShape(11.dp), modifier = Modifier.size(34.dp)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp)) } }
                Spacer(Modifier.width(8.dp))
                Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
            Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp, maxLines = 1)
            Box(Modifier.fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = .07f), RoundedCornerShape(50))) {
                Box(Modifier.fillMaxWidth(.72f).fillMaxHeight().background(Brush.horizontalGradient(listOf(accent.copy(alpha = .55f), accent)), RoundedCornerShape(50)))
            }
        }
    }
}

@Composable private fun UpcomingBillCard(title: String, date: String, amount: String, onPaid: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0x263F6B4E), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ReceiptLong, null, tint = Violet, modifier = Modifier.size(21.dp)) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("Forfalder $date", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(amount, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onPaid, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("Markér betalt", color = Mint, fontSize = 10.sp) }
            }
        }
    }
}

@Composable private fun RecordRow(title: String, detail: String, amount: String, positive: Boolean, onDelete: () -> Unit, onToggle: (() -> Unit)? = null) {
    Surface(Modifier.fillMaxWidth().animateContentSize().padding(vertical = 3.dp), color = Panel, shape = RoundedCornerShape(19.dp), border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = if (positive) Color(0x2639B982) else Color(0x263F6B4E), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(if (positive) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (positive) Mint else Violet, modifier = Modifier.size(19.dp)) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                Text(detail, color = Muted, fontSize = 10.sp, maxLines = 2)
            }
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(amount, color = if (positive) Mint else White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                Row {
                    if (onToggle != null) TextButton(onClick = onToggle, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) { Text("Betalt", color = Mint, fontSize = 9.sp) }
                    TextButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) { Text("Slet", color = Color(0xFFFF91A9), fontSize = 9.sp) }
                }
            }
        }
    }
}
@Composable private fun ManagedList(title: String, records: List<JSONObject>, onAdd: () -> Unit, row: @Composable (JSONObject) -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp); Button(onClick = onAdd, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Tilføj") } }; if (records.isEmpty()) { Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(8.dp)); Text("Her er tomt endnu", color = White, fontWeight = FontWeight.SemiBold); Text("Tilføj din første post for at komme i gang.", color = Muted, fontSize = 12.sp) } } }; LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) { items(records, key = { it.s("id") }) { row(it) } } } }

@Composable private fun DataDialog(kind: String, onDismiss: () -> Unit, onSave: (String, JSONObject) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Diverse") }; var date by remember { mutableStateOf(LocalDate.now().toString()) }; var type by remember { mutableStateOf("Udgift") }; var owner by remember { mutableStateOf("Mig") }; var extra by remember { mutableStateOf("") }; var extra2 by remember { mutableStateOf("") }; var extra3 by remember { mutableStateOf("") }; var json by remember { mutableStateOf("") }; var ocrText by remember { mutableStateOf("") }; var ocrBusy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching { InputImage.fromFilePath(context, uri) }.onSuccess { image ->
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text
                        val parsed = parseBillText(result.text)
                        if (name.isBlank()) name = parsed.first
                        if (amount.isBlank()) amount = parsed.second
                        if (parsed.third.isNotBlank()) date = parsed.third
                        ocrBusy = false
                    }
                    .addOnFailureListener { ocrText = "Kunne ikke læse billedet. Prøv et skarpere og mere tydeligt skærmbillede."; ocrBusy = false }
            }.onFailure { ocrText = "Filen kunne ikke åbnes som et billede. Vælg et almindeligt PNG/JPG-skærmbillede."; ocrBusy = false }
        }
    }
    val title = when (kind) { "post" -> "Ny post"; "bill" -> "Ny regning"; "budget" -> "Budgetgrænse"; "goal" -> "Opsparingsmål"; "debt" -> "Ny gæld"; "fuel" -> "Ny tankning"; "sub" -> "Abonnement"; "payday" -> "Lønindstillinger"; "pin" -> "PIN-kode"; "backup" -> "Backup / gendannelse"; "ocr" -> "Importér regning"; else -> "Saldo" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (kind) {
                "post" -> { Field("Beskrivelse", name, { name = it }); Field("Beløb i kr.", amount, { amount = it }, true); Field("Kategori", category, { category = it }); Field("Dato (ÅÅÅÅ-MM-DD)", date, { date = it }); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Udgift", "Indtægt").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
                }
                "bill" -> { Field("Regning / modtager", name, { name = it }); Field("Beløb", amount, { amount = it }, true); Field("Forfaldsdato", date, { date = it }); Field("Gentagelse (fx månedlig)", extra, { extra = it }); Field("Kategori", category, { category = it }); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "budget" -> { Field("Kategori", name, { name = it }); Field("Månedlig grænse", amount, { amount = it }, true); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "goal" -> { Field("Opsparingsmål", name, { name = it }); Field("Målsum", amount, { amount = it }, true); Field("Allerede sparet", extra, { extra = it }, true); Field("Måldato", date, { date = it }) }
                "debt" -> { Field("Kreditor", name, { name = it }); Field("Restgæld", amount, { amount = it }, true); Field("Årlig rente (%)", extra, { extra = it }, true); Field("Månedligt afdrag", extra2, { extra2 = it }, true) }
                "fuel" -> { Field("Dato", date, { date = it }); Field("Liter", amount, { amount = it }, true); Field("Samlet pris", extra, { extra = it }, true); Field("Kilometerstand", extra2, { extra2 = it }, true) }
                "sub" -> { Field("Abonnement", name, { name = it }); Field("Pris pr. måned", amount, { amount = it }, true) }
                "payday" -> { Field("Løn hver 14. dag", amount, { amount = it }, true); Field("Næste løndato", date, { date = it }) }
                "pin" -> Field("PIN (4-8 cifre)", amount, { amount = it }, true, true)
                "backup" -> { Field("Indsæt backup-JSON for at gendanne", json, { json = it }); Text("Kopiér backup-JSON fra appdata via eksport eller gem det sikkert eksternt.", color = Muted, fontSize = 11.sp) }
                "ocr" -> {
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), enabled = !ocrBusy) { Text(if (ocrBusy) "Læser skærmbillede…" else "Vælg skærmbillede af regningen") }
                    Text(if (ocrText.isBlank()) "Vælg et skærmbillede fra dit galleri. Saldo forsøger at finde afsender, beløb og dato. Kontrollér altid felterne før gemning." else "Tekst genkendt – kontrollér oplysningerne nedenfor:", color = Muted)
                    if (ocrBusy) CircularProgressIndicator(color = Violet)
                    if (ocrText.isNotBlank()) {
                        Field("Afsender / regning", name, { name = it })
                        Field("Beløb i kr.", amount, { amount = it }, true)
                        Field("Forfaldsdato (ÅÅÅÅ-MM-DD)", date, { date = it })
                        Text("Genkendt tekst", color = White, fontWeight = FontWeight.SemiBold)
                        Text(ocrText.take(1800), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = {
        val a = amount.replace(",", ".").toDoubleOrNull() ?: 0.0; val id = System.currentTimeMillis().toString()
        val obj = when (kind) {
            "post" -> record("id" to id, "name" to name, "amount" to a, "category" to category, "date" to date, "type" to type, "owner" to owner)
            "bill" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to extra, "category" to category, "owner" to owner, "paid" to false)
            "budget" -> record("id" to id, "category" to name, "limit" to a, "owner" to owner)
            "goal" -> record("id" to id, "name" to name, "target" to a, "saved" to (extra.toDoubleOrNull() ?: 0.0), "date" to date)
            "debt" -> record("id" to id, "name" to name, "balance" to a, "rate" to (extra.toDoubleOrNull() ?: 0.0), "payment" to (extra2.toDoubleOrNull() ?: 0.0))
            "fuel" -> record("id" to id, "date" to date, "liters" to a, "cost" to (extra.toDoubleOrNull() ?: 0.0), "km" to (extra2.toDoubleOrNull() ?: 0.0))
            "sub" -> record("id" to id, "name" to name, "monthly" to a)
            "payday" -> record("pay" to a, "date" to date)
            "pin" -> record("pin" to amount)
            "backup" -> record("json" to json)
            "ocr" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to "Engangsbetaling", "category" to category, "owner" to owner, "paid" to false, "source" to "OCR-skærmbillede")
            else -> JSONObject()
        }
        if (kind == "pin" && !amount.matches(Regex("\\d{4,8}"))) return@TextButton
        if (kind == "backup" && runCatching { JSONObject(json) }.isFailure) return@TextButton
        if (kind == "ocr") {
            if (ocrText.isBlank() || name.isBlank() || a <= 0.0 || runCatching { LocalDate.parse(date) }.isFailure) {
                Toast.makeText(context, "Kontrollér afsender, beløb og dato før gemning", Toast.LENGTH_LONG).show()
                return@TextButton
            }
            onSave("bill", obj)
        } else onSave(kind, obj)
    }) { Text(if (kind == "ocr") "Opret regning" else "Gem", color = Blue) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } })
}

@Composable private fun Field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false, password: Boolean = false) { OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = Muted, focusedLabelColor = Violet, unfocusedLabelColor = Muted)) }

private fun parseBillText(text: String): Triple<String, String, String> {
    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
    val vendor = lines.firstOrNull { line ->
        line.length in 3..70 && line.any { it.isLetter() } &&
            !line.contains("faktura", true) && !line.contains("invoice", true) &&
            !line.contains("betalingsoversigt", true)
    }?.take(70).orEmpty()

    val datePatterns = listOf(
        Regex("(?<!\\d)(20\\d{2})[-./](0?[1-9]|1[0-2])[-./]([0-2]?\\d|3[01])(?!\\d)"),
        Regex("(?<!\\d)([0-3]?\\d)[./-](0?[1-9]|1[0-2])[./-](20\\d{2})(?!\\d)")
    )
    var date = ""
    for ((index, pattern) in datePatterns.withIndex()) {
        val match = pattern.find(text) ?: continue
        date = if (index == 0) {
            runCatching { LocalDate.of(match.groupValues[1].toInt(), match.groupValues[2].toInt(), match.groupValues[3].toInt()).toString() }.getOrDefault("")
        } else {
            runCatching { LocalDate.of(match.groupValues[3].toInt(), match.groupValues[2].toInt(), match.groupValues[1].toInt()).toString() }.getOrDefault("")
        }
        if (date.isNotBlank()) break
    }

    val moneyRegex = Regex("(?i)(?:i alt|total|at betale|beløb|amount|kr\\.?)[^\\d]{0,18}([0-9][0-9 .]*[,\\.][0-9]{2})")
    val match = moneyRegex.find(text) ?: Regex("(?<!\\d)([0-9]{1,3}(?:[ .][0-9]{3})*(?:[,\\.][0-9]{2}))(?!\\d)").find(text)
    val amount = match?.groupValues?.lastOrNull()?.replace(" ", "")?.replace(".", "")?.replace(",", ".")?.toDoubleOrNull()?.takeIf { it > 0 }?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
    return Triple(vendor, amount, date)
}

private fun shareCsv(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>) { val lines = mutableListOf("type;navn;beløb;kategori;dato;status;ejer"); transactions.forEach { lines += "post;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${it.s("type")};${it.s("owner")}" }; bills.forEach { lines += "regning;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${if (it.optBoolean("paid")) "betalt" else "ubetalt"};${it.s("owner")}" }; val intent = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_SUBJECT, "Saldo CSV-eksport").putExtra(Intent.EXTRA_TEXT, lines.joinToString("\n")); context.startActivity(Intent.createChooser(intent, "Eksportér Saldo-data")) }

private fun shareBackup(context: Context, json: String) {
    val intent = Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_SUBJECT, "Saldo sikkerhedskopi").putExtra(Intent.EXTRA_TEXT, json)
    context.startActivity(Intent.createChooser(intent, "Gem eller del sikkerhedskopi"))
}
