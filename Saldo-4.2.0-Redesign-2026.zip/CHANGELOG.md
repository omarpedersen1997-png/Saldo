# Changelog

## 4.2.0 — Saldo 2026 Redesign
- Replaced the dark green interface with a light, premium fintech visual system: soft canvas, ink typography, violet and emerald accents, white cards, subtle borders and elevation.
- Updated system bars and bottom navigation for the light interface; the Saldo logo image remains byte-for-byte unchanged.
- Reworked the cash-flow component to show monthly net balance and separate animated income/expense comparison bars.
- Refined quick actions, budget status, transaction/bill rows, and card hierarchy across the main screens.
- Kept the existing data model, Partner naming (with migration of older local records), Supabase authentication/sync, PIN/biometric lock, reminders, and PDF/backup exports.
- Retained the GitHub Actions build workflow; APK compilation still needs to be confirmed by a real Android SDK build.


## 4.1.0 — Saldo 2026 UI-redesign
- Redesignet overblik med et stort, gradientbaseret rådighedsbeløbskort, animeret forbrugsindikator og hurtige handlinger.
- Opdateret budgetskærm med samlet status, animerede budgetbjælker og tydeligere kategorikort.
- Redesignet Poster- og Regninger-skærme med forbedret søgning, statusoversigter og mere kompakte handlinger.
- Redesignet Mere-menuen med ikonbaserede værktøjskort og korte forklaringer.
- Opdateret fælles postrækker, knapfarver, typografisk hierarki og kortstile.
- Beholdt eksisterende Saldo-logo, datalagring, budgetberegninger, PIN/biometri, PDF/backup og Supabase-funktioner.
- Brugerrettet ejerbetegnelse er Partner; ældre lokale ejerfelter med Kæreste migreres til Partner ved indlæsning.

## 4.0.0
- Tidligere opdateringer af online-login, lokal sikkerhed og UI-komponenter.
