## 4.2.3 — Finpudsning af pålidelighed
- Android targetSdk opdateret til API 36; systembjælker håndteres med edge-to-edge og sikre indholdsinsets på login- og PIN-skærme.
- Manuel cloud-synkronisering medtager nu lønindstilling, løndato og eventuel aktuel saldo; ældre cloud-data kan fortsat hentes.
- Samlet normalisering af ældre ejerbetegnelser ved lokal indlæsning og gendannelse.
- Understøttelse af månedlige, kvartalsvise og årlige gentagelser med stabil oprindelig forfaldsdag.
- Forhindrer dubletter ved generering af næste regning efter længere tid uden at åbne appen.
- Strammere kontrol af JSON-backupens struktur før gendannelse.
- Eksporter får unikke filnavne med millisekunder.
- Versionskode hævet til 20.

# Changelog

## 4.2.2 — Finish polish and reliability
- Added password-recovery email from the second login step while preserving the two-step swipe transition.
- Completed the password-reset flow: the recovery email links back into Saldo, where the user sets and confirms a new password. Requires a working Supabase Auth configuration and the approved `dk.saldo.app://auth-callback` redirect.
- PINs are now stored as salted PBKDF2-HMAC-SHA256 hashes; existing plaintext PINs are upgraded after a successful unlock. Added PIN confirmation, a numeric password keyboard and a 5-attempt cooldown.
- Automatic local recovery keeps the previous saved state instead of simply copying the latest state; restoring local/cloud backups preserves the replaced state as a recovery point.
- Monthly recurring bills now generate their next occurrence when marked paid, without waiting for an app restart, and avoid leaving recurrence permanently broken after long idle periods.
- Added stronger validation for required names, amounts, Danish decimal formats, dates, PIN confirmation, fuel entries and imported backup shape.
- CSV export now produces a real UTF-8 file with Danish Excel-friendly delimiters; JSON backup exports are real files and restore supports choosing a file.
- Disabled Android auto-backup of local finance data and session tokens; explicit in-app export/restore remains available.
- Incremented Android version metadata to 4.2.2 (versionCode 19).
- APK compilation and on-device testing still need to be confirmed through GitHub Actions.

## 4.2.0 — Saldo 2026 Redesign
- Replaced the dark green interface with a light, premium fintech visual system: soft canvas, ink typography, violet and emerald accents, white cards, subtle borders and elevation.
- Updated system bars and bottom navigation for the light interface; the Saldo logo image remains byte-for-byte unchanged.
- Reworked the cash-flow component to show monthly net balance and separate animated income/expense comparison bars.
- Refined quick actions, budget status, transaction/bill rows, and card hierarchy across the main screens.
- Kept the existing data model, Partner naming (with migration of older local records), Supabase authentication/sync, PIN/biometric lock, reminders, and PDF/backup exports.
- Retained the GitHub Actions build workflow; APK compilation still needs to be confirmed by a real Android SDK build.


## 4.1.0 — Saldo 2026 UI-redesign
- Redesignet overblik med et stort, gradientbaseret rådighedsbeløbskort, animeret forbrugsindikator og hurtige handlinger.
- Opdateret budgetskærm med samlet status, animerede budgetbjælker og tydeligere kategorikort.
- Redesignet Poster- og Regninger-skærme med forbedret søgning, statusoversigter og mere kompakte handlinger.
- Redesignet Mere-menuen med ikonbaserede værktøjskort og korte forklaringer.
- Opdateret fælles postrækker, knapfarver, typografisk hierarki og kortstile.
- Beholdt eksisterende Saldo-logo, datalagring, budgetberegninger, PIN/biometri, PDF/backup og Supabase-funktioner.
- Brugerrettet ejerbetegnelse er Partner; ældre lokale ejerfelter med Kæreste migreres til Partner ved indlæsning.

## 4.0.0
- Tidligere opdateringer af online-login, lokal sikkerhed og UI-komponenter.


### Login-flow — to sider
- Login starter nu med e-mail alene.
- Når en gyldig e-mail er indtastet, glider kortet vandret til adgangskode-siden.
- Adgangskode-siden viser e-mailen med en tydelig Ret-handling og en Tilbage-knap.
- Kontooprettelse bevarer bekræftelse af adgangskoden.
- Eksisterende Supabase-login og session-lagring er bevaret.

## 4.2.1 — samlet funktionsudvidelse
- Added current-account-balance input and an estimated daily spending allowance through the next payday after upcoming bills.
- Added a separate monthly spend summary for Mig, Partner and Fælles.
- Added budget threshold warnings on the dashboard and daily local notifications, plus upcoming subscription renewal reminders when a renewal date is entered.
- Added automatic local recovery snapshots on data saves and a restore action in settings.
- Added renewal date and cancellation note fields to subscriptions, with monthly/yearly totals.
- Added an interactive scenario calculator for extra spending and savings.
- Existing screenshot OCR, recurring bills, reminders, savings goals, debt estimates, reports, CSV/PDF export, PIN/biometric lock and manual Supabase sync remain in the project.
- APK build and on-device interaction tests still require a real Android SDK build via GitHub Actions.
- Added daily low-cashflow alerts when a manually entered available balance leaves less than 150 kr/day or a negative amount after upcoming bills, plus separate cancellation-deadline reminders for subscriptions.


## 4.2.4
- Added persistent Light/Dark theme switching, including theme-aware login surfaces and Android system bars.
- Added per-section home dashboard customization (show/hide seven dashboard sections).
- Added three native Android home-screen widgets: available balance, monthly overview, and upcoming bills.
- Widget content refreshes when local app data/settings are saved and widgets open Saldo when tapped.
