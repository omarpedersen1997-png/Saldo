# Ændringslog

## 4.2.5 — Stabilitet og sikkerhed
- Samlet budgetstatus tæller hver registreret udgift én gang, også hvis ældre data indeholder dublerede budgetrækker.
- Appen forhindrer oprettelse af et ekstra budget med samme kategori og ejer.
- Sletning af en post eller regning kræver nu en ekstra bekræftelse.
- Onlinegendannelse kontrollerer struktur og relevante indstillinger, før lokale data erstattes.
- Onlinebackup afviser ugyldige lokale datastrukturer i stedet for at uploade dem.
- Versionsnummeret er opdateret til 4.2.5. Saldo-logoets filer og appens identitet er bevaret.

## 4.2.4 — Widgets, startside og tema
- Lys og mørk tilstand gemmes på telefonen.
- Startsiden kan tilpasses med vis/skjul-kontroller for de syv kortsektioner.
- Tre Android-startskærmswidgets viser rådighedsbeløb, månedens overblik og kommende regninger.

## 4.2.3 — Datakvalitet og backup
- Gentagende regninger understøtter måned, kvartal og år.
- JSON-backup valideres før gendannelse.
- Eksportfiler får unikke tidsstemplede filnavne.
- Ældre ejerbetegnelsen "Kæreste" normaliseres til "Partner".

## 4.2.2 — Konto og oplåsning
- Glemt adgangskode via Supabase Auth.
- PIN gemmes som saltet PBKDF2-HMAC-SHA256-hash.
- Backuprotation og validering af formularer.
