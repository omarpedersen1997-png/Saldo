# Saldo – online-login (Supabase)

Saldo bruger nu Supabase Auth via HTTPS til oprettelse og login med e-mail/adgangskode. Der er ikke længere en lokal adgangskodekonto som fallback.

## Opsætning før login kan bruges
1. Opret et projekt på https://supabase.com/.
2. Find projektets **Project URL** og **publishable/anon key** under projektets API-indstillinger. Brug aldrig service-role key i appen.
3. I GitHub-repositoryet: **Settings → Secrets and variables → Actions → New repository secret**. Opret:
   - `SUPABASE_URL` = projektets URL, fx `https://dit-projekt.supabase.co`
   - `SUPABASE_ANON_KEY` = Supabase publishable/anon key
4. Kør **Actions → Build Saldo Android APK → Run workflow** igen.
5. Indstil e-mailbekræftelse i Supabase efter eget behov. Hvis den er slået til, skal brugeren bekræfte sin e-mail før login.

## Online backup/synkronisering
1. Åbn `SUPABASE-SCHEMA.sql` og kør hele filen i Supabase Dashboard → SQL Editor.
2. Byg appen igen med `SUPABASE_URL` og `SUPABASE_ANON_KEY` som GitHub Actions Secrets.
3. I appen: Indstillinger → **Gem lokale data online** for at uploade den lokale backup, eller **Hent data fra onlinekonto** for at erstatte de lokale data med backup fra kontoen.
4. Gem lokale data online efter ændringer; synkroniseringen er manuel og bruger sidste handling som valgt, den fletter ikke ændringer fra flere enheder.

## Vigtigt
- Login/oprettelse kontrolleres online af Supabase. Uden de to GitHub Secrets viser appen en konfigurationsfejl i loginvinduet.
- Denne ændring giver **ikke** automatisk synkronisering af budgetter mellem telefoner. Saldo-poster og budgetdata ligger fortsat lokalt på enheden; cloud-datasynkronisering kræver tabellen og RLS-politikkerne i `SUPABASE-SCHEMA.sql`; appen tilbyder manuel upload/hentning af registrerede data samt lønindstilling, løndato og eventuel aktuel saldo. Ældre cloud-backups uden indstillingsdata kan stadig hentes. PIN og login-session deles ikke som backupdata.
- Appen gemmer adgangstokens lokalt for at bevare login-sessionen. Brug ikke dette som en færdig sikkerhedsgodkendelse til følsomme finansielle data uden yderligere sikkerhedsgennemgang.
- APK-build er ikke kørt i dette miljø; bekræft resultatet i GitHub Actions.


## Nulstilling af adgangskode
På adgangskodesiden findes nu **Glemt adgangskode?**. Tilføj `dk.saldo.app://auth-callback` under Supabase Authentication → URL Configuration → Redirect URLs. Supabase skal have en korrekt Site URL og den godkendte app-redirect for nulstillingslinket. Kontroller også skabelonen for password recovery under Supabase Authentication → Email Templates. Appen viser en generisk kvittering, så den ikke afslører, om en bestemt e-mailadresse har en konto.

- Androids automatiske enhedsbackup er slået fra for at undgå, at lokale økonomidata og login-sessioner kopieres automatisk. Brug appens eksplicitte JSON-backup og gem filen et sikkert sted. Den manuelle JSON-backup omfatter data samt lønindstilling, løndato og eventuel aktuel saldo, men indeholder ikke PIN-kode eller login-session.
