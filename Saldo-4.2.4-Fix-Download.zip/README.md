# Saldo — Android

Saldo er en privatøkonomi-app til Android bygget med Kotlin og Jetpack Compose.

## Version 4.2.4 — Saldo 2026 Redesign + widgets og tema
Brugerfladen er omlagt til et lyst, moderne fintech-design med blød baggrund, tydelig typografi, lilla og smaragdgrønne accenter, hvide kort og en ny bundnavigation. Dashboardets pengestrøm viser månedens netto samt separate animerede bjælker for indtægter og udgifter. Poster, regninger, budgetter og værktøjer har fået et mere konsekvent visuelt hierarki. Saldo-logoets billedfil er bevaret byte-for-byte uændret.

## Nye muligheder i 4.2.4
- Lys og mørk tilstand, huskes på telefonen.
- Tilpas startsiden ved at vise/skjule rådighedsbeløb, hurtige handlinger, budgetadvarsler, månedens tal, pengestrøm, regninger og seneste aktivitet.
- Tre Android-startskærmswidgets: rådighedsbeløb, månedens overblik og kommende regninger. Widgets åbner appen ved tryk og opdateres ved ændringer i lokale data.

## Byg appen
- JDK 17
- Android SDK 36 (compile/target API 36)
- Gradle 8.14.3 eller en kompatibel Gradle-installation
- Byg debug-APK med `gradle assembleDebug` fra projektroden.

GitHub Actions-workflowet i `.github/workflows/android-build.yml` bygger projektet direkte fra repositoryets rod (hvor `settings.gradle.kts` og `app/build.gradle.kts` ligger) og installerer eksplicit Android SDK Platform 36 samt Build Tools 36.0.0. Det bruger ikke den forældede SDK-pakke `tools`. GitHub Secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY` bruges ved build. Brug kun en Supabase publishable/anon key i mobilappen — aldrig en secret/service-role key.

Online-login og cloud-backup kræver opsætningen beskrevet i `ONLINE-LOGIN.md` og SQL-skemaet i `SUPABASE-SCHEMA.sql`.


## Saldo 4.2.4 — samlet funktionsopdatering

This source package includes a modern 2026 interface, persistent light/dark theme selection, configurable dashboard sections, and three native Android home-screen widgets. Existing local data structure and app workflows are retained.

### Build APK with GitHub Actions
1. Upload the contents of this project folder to the root of a GitHub repository (including `.github/workflows/android-build.yml`).
2. In GitHub, open **Actions** and run **Build Saldo Android APK**, or push to `main`.
3. Download the `Saldo-2026-Android-APK` artifact from the completed workflow run.
4. For online login/sync, configure repository secrets `SUPABASE_URL` and `SUPABASE_ANON_KEY`.

The APK has not been built in this environment because an Android SDK is not installed here. The GitHub workflow is included to build it on a hosted Android-capable runner.


## Login i to trin
Login-flowet viser først e-mailadressen og glider derefter vandret til adgangskode-siden. Brugeren kan gå tilbage og rette e-mailadressen. Supabase-autentificeringen og konto-oprettelsen bruger fortsat de eksisterende funktioner.

## Samlet funktionsudvidelse (4.2.1)
Udvidelserne omfatter dagligt vejledende rådighedsbeløb frem til næste løn (med mulighed for at indtaste aktuel kontosaldo), udgiftsoversigt for Mig/Partner/Fælles, advarsler ved budgetgrænser, automatiske lokale gendannelsespunkter, abonnementers fornyelsesdato/opsigelsesnote og en interaktiv "Hvad nu hvis?"-beregner. Påmindelser om abonnementsfornyelse kræver, at en dato indtastes. Løn- og forbrugsprognoser er estimater og erstatter ikke en live bankbalance. Den automatiske backup er lokal; online-synkronisering er stadig manuel.
Der kan også komme en daglig advarsel ved lavt beregnet rådighedsbeløb eller kommende opsigelsesfrist på et abonnement. Disse advarsler bygger kun på de oplysninger, du selv har registreret.


## Finish polish (4.2.3)
Login-flowet har nu en glemt-adgangskode-handling på adgangskodesiden. PIN-koder gemmes med saltet PBKDF2-HMAC-SHA256, og eksisterende PIN-koder opgraderes ved korrekt oplåsning. PIN skal bekræftes ved oprettelse. Automatisk gendannelsespunkt bevarer forrige tilstand ved ændringer og restore. Månedlige, kvartalsvise og årlige gentagende regninger opretter næste forekomst direkte, når de markeres betalt; den oprindelige forfaldsdag bevares, og dubletter forebygges. Skærmformularer validerer påkrævede værdier og datoformater. Eksportfiler får tidsstempler, så flere eksporter samme dag ikke overskriver hinanden.


## Ekstra stabilitets- og sikkerhedsfinpudsning (4.2.3)
- Glemt adgangskode kan gennemføres via et app-deep-link tilbage til Saldo; Supabase skal tillade `dk.saldo.app://auth-callback`.
- PIN-koder gemmes som saltede PBKDF2-hashes og kan ikke prøves ubegrænset hurtigt.
- Formularer accepterer dansk decimalkomma og validerer påkrævede datoer/værdier.
- CSV og JSON eksporteres som vedhæftede filer med unikke filnavne; JSON-gendannelse understøtter også filvalg og validerer dataformatet før gendannelse.
- Androids automatiske enhedsbackup er slået fra for lokale økonomidata; brug den eksplicitte Saldo-backup.


## Google Play / Android 16
Appen er sat til `targetSdk = 36` for Android 16. Edge-to-edge er aktiveret med sikre indholdsinsets på login- og PIN-skærme. Test visuelt på en Android 16-enhed efter GitHub-build, før APK/AAB udgives.
