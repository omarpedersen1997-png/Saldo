# Kom i gang med Saldo 3.5.0

## GitHub Actions
1. Upload `Saldo-3.5.0-udvidede-funktioner.zip` til roden af dit GitHub-repository.
2. Kopiér workflow-filen fra ZIP'ens `.github/workflows/android-build.yml` til samme sti i selve GitHub-repositoryet.
3. Under repository → Settings → Secrets and variables → Actions skal du have `SUPABASE_URL` og `SUPABASE_ANON_KEY`.
4. I Supabase SQL Editor skal du køre `SUPABASE-SCHEMA.sql` fra ZIP-filen.
5. Gå til Actions → Build Saldo Android APK → Run workflow.
6. Når workflow lykkes, hentes APK'en under Artifacts med navnet `Saldo-Android-debug-APK`.

## Nye funktioner
- Manuel upload/hentning af backup online fra Indstillinger.
- PDF-rapport fra Indstillinger.
- Biometrisk oplåsning kan aktiveres i Indstillinger; den bruges ved næste app-start og på låseskærmen.
- Daglige baggrundskontroller af ubetalte regninger, der forfalder inden for tre dage (tillad notifikationer i Android).
- Månedlige, kvartalsvise og årlige regninger kan oprette næste forekomst, når den nuværende er markeret betalt; den oprindelige forfaldsdag bevares.

## Begrænsninger
APK-build og enhedstest skal stadig udføres via GitHub Actions og på en Android-telefon. Cloud backup er manuel og erstatter hele datasættet ved hentning; der er ikke konfliktfletning. OCR læser billeder og kræver manuel kontrol. Ingen bankbetalinger eller automatisk banksynkronisering.

Appen målretter nu API 36. Efter build bør du teste login, PIN-skærm, bundnavigation og regningsdialoger på Android 16 på grund af edge-to-edge-systembjælkerne.


## Lys/mørk tilstand og startskærmswidgets (4.2.4)
1. Åbn Saldo → Mere → Indstillinger.
2. Vælg **Lys** eller **Mørk** under Udseende. Dit valg gemmes automatisk.
3. Under **Tilpas startside** kan du vise eller skjule de enkelte kort på Overblik. Mindst ét kort skal være synligt.
4. Under **Widgets på telefonens startskærm** trykker du på den ønskede widget. Hvis startprogrammet ikke viser en bekræftelsesdialog, så hold fingeren på telefonens startskærm og vælg Widgets → Saldo.
5. Widgets opdateres, når Saldo gemmer ændringer i de lokale data. De viser det, appen kender lokalt, og erstatter ikke en bankkonto eller bankintegration.
