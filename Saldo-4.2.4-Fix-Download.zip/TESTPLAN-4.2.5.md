# Saldo 4.2.5 — testplan før installation og udgivelse

Denne liste er en praktisk testplan. Den er ikke dokumentation for, at testene allerede er gennemført.

## Bygning
- [ ] GitHub Actions afsluttes med grønt resultat.
- [ ] Artefaktet `Saldo-4.2.5-Android-APK` indeholder en APK.
- [ ] APK installeres og åbner på den tilsigtede Android-telefon.

## Første brug og beskyttelse
- [ ] Appen åbner på login-skærmen og viser det korrekte Saldo-logo.
- [ ] Konto-oprettelse, login og glemt adgangskode testes med en korrekt konfigureret Supabase-instans.
- [ ] PIN-lås, forkert PIN og biometrisk oplåsning testes, hvis funktionerne er aktiveret.
- [ ] Log ud fører til login, og økonomidata forsvinder ikke ved almindelig log ud.

## Budget og poster
- [ ] Opret en indtægt og en udgift med dansk decimalkomma.
- [ ] Søg og filtrér poster, og kontrollér månedens summer.
- [ ] Opret budgetter for Mig, Partner og Fælles.
- [ ] Forsøg at oprette samme kategori/ejer-budget to gange; dubletten skal afvises.
- [ ] Kontrollér samlet budgetstatus med flere kategorier og en dublet i ældre testdata.
- [ ] Tryk Slet, og kontrollér at posten først fjernes efter bekræftelse.

## Regninger og påmindelser
- [ ] Opret en engangsregning og en månedlig, kvartalsvis eller årlig regning.
- [ ] Markér en gentagen regning betalt, og kontrollér at næste forekomst oprettes én gang.
- [ ] Kontrollér OCR med et tydeligt skærmbillede; kontrollér selv afsender, beløb og dato før gemning.
- [ ] Giv notifikationstilladelse og test regnings- og budgetpåmindelser.

## Backup, konto og widgets
- [ ] Eksportér JSON-backup, og gendan den i en testinstallation.
- [ ] Prøv en ugyldig backup; eksisterende data skal bevares.
- [ ] Med Supabase sat op: upload data, hent data og verificér både transaktioner og løn-/saldoindstillinger.
- [ ] Prøv en ugyldig cloud-datapost; lokale data skal ikke overskrives.
- [ ] Tilføj alle tre widgets fra Android-startskærmen, og kontrollér deres beløb efter dataændringer.
- [ ] Skift mellem lyst og mørkt tema, luk appen og åbn igen.

## Øvrige værktøjer og visning
- [ ] Test opsparing, gæld, bil/brændstof, abonnementer, kalender, prognoser og rapporter.
- [ ] Kontrollér skærme på telefonens normale tekststørrelse og med større systemskrift.
- [ ] Test rotation, tilbageknap, tastatur og edge-to-edge på målversionen af Android.
