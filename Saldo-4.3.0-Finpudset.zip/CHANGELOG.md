# Ændringslog — Saldo 4.3.0

## Ny funktion: Økonomitjek
- Samler forfaldne, ubetalte regninger.
- Finder budgetter, der har nået eller overskredet grænsen i indeværende måned.
- Finder mulige dubletter blandt transaktioner ud fra dato, type, navn, kategori, beløb og ejer. Dubletter slettes aldrig automatisk.
- Viser status og alder for lokal backup samt genvej til at eksportere en sikkerhedskopi.
- Tilføjet som selvstændigt værktøj under Mere.

## Sikkerhed og begrænsninger
- Ingen nye tilladelser, serverkald eller tredjepartstjenester til økonomitjekket.
- Alle kontroller foretages lokalt på de data, der allerede findes i Saldo.
- Mulige dubletter er kun forslag og kræver manuel gennemgang.
- Version 4.3.0 bruger versionCode 27.
