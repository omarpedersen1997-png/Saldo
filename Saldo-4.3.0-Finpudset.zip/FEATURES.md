# Saldo – funktionsoversigt

## Budget og overblik
- Registrering af indtægter og udgifter med kategori, dato og ejer.
- Søgning i poster.
- Budgetgrænser pr. kategori og ejer med advarsel ved 80 % og overskridelse.
- Overblik over forfaldne og kommende regninger.
- Prognoser for 30, 60 og 90 dage baseret på registrerede data.

## Regninger
- Opret, markér betalt og slet regninger.
- Gentagne månedlige, kvartalsvise og årlige regninger med kontrol for dubletter og bevarelse af den oprindelige forfaldsdag.
- Skærmbillede-OCR til forslag om afsender, beløb og dato; brugeren skal kontrollere før gemning.
- Lokale påmindelser via Android WorkManager, afhængigt af tilladelser og systemets batteristyring.

## Økonomiværktøjer
- Opsparingsmål.
- Gæld med rente, afdrag og estimeret tilbagebetalingstid.
- Bil/brændstofregistrering med liter, pris og kilometertal samt vejledende forbrugsestimat.
- Abonnementer med månedlig og årlig pris.
- Rapporter for indeværende måned, kategorier og samlet økonomi.
- CSV-eksport, PDF-rapport og lokal JSON-backup/gendannelse. Den manuelle backup indeholder også lønindstilling, næste løndato og eventuel kontosaldo; sikkerheds-PIN og login-session udelades med vilje.

## Konto og data
- Online-login via Supabase, når URL, nøgle og projekt er konfigureret.
- Manuel upload/hentning af appdata via Supabase, inkl. lønindstilling, løndato og eventuel aktuel saldo. PIN og login-session medtages ikke i backupdata.
- PIN og valgfri biometrisk oplåsning.

## Begrænsninger
- Automatisk bankintegration/betaling er ikke implementeret.
- Automatisk live-synkronisering mellem enheder er ikke implementeret; synkronisering er manuel.
- OCR læser billeder, ikke direkte PDF-dokumenter.
- Forbrugsberegning for bil er vejledende og afhænger af korrekte kilometertal og tankningsdata.
- Funktionen er ikke verificeret med en lokal Android-build i dette miljø; kør GitHub Actions og test på en fysisk enhed.


## Nyt i 3.7.0
- Rapport over de seneste seks måneders indtægter, udgifter og nettoresultat pr. måned.


### Brugerflade og arbejdsgang (3.9.1)
- Animerede overgange mellem faner.
- Filtrering af poster efter indtægt/udgift.
- Månedskorrekte summer på overblikket.
- Animerede ændringer i postkort.

## Udvidelser i denne samlede funktionsopdatering
- Rådighedsbeløb frem til næste løn: kan bruge en manuelt indtastet nuværende saldo og fratrækker ubetalte regninger, der forfalder inden næste lønudbetaling. Viser også et vejledende beløb pr. dag. Uden en indtastet saldo anvendes et estimat ud fra månedens registrerede poster.
- Samlet overblik over månedens udgifter for Mig, Partner og Fælles.
- Budgetadvarsler ved 80 % af en budgetgrænse og ved overskridelse, både på overblikket og som notifikationer via den daglige baggrundskontrol.
- Automatisk lokal gendannelseskopi opdateres, når appens post-/regnings-/budgetdata gemmes, og kan gendannes fra Indstillinger.
- Abonnementer understøtter nu valgfri næste fornyelsesdato og opsigelsesnote; kommende fornyelser inden for 7 dage kan give en notifikation.
- Interaktiv "Hvad nu hvis?"-beregner til at afprøve ekstra månedligt forbrug og opsparing uden at ændre de registrerede budgetdata.
- Løn-, saldo- og fremtidsestimater er vejledende, da appen ikke henter live bankdata.
- Når en nuværende saldo er indtastet, kan den daglige baggrundskontrol også advare, hvis de registrerede regninger efterlader under 150 kr. pr. dag eller et negativt beløb frem til løn.
- Abonnementer har separate felter for fornyelsesdato, dato for seneste opsigelse og note; både fornyelses- og opsigelsesdatoer kan udløse en påmindelse inden for 7 dage.


## Finish polish (4.2.2)
- Glemt adgangskode via Supabase Auth recovery endpoint; kræver en korrekt konfigureret Site URL/redirect i Supabase.
- PIN-hashning med salt og PBKDF2-HMAC-SHA256 samt sikker opgradering af ældre lokale PIN-værdier efter korrekt oplåsning.
- PIN-bekræftelse, bedre numerisk tastatur og validering af påkrævede formularfelter/datoer.
- Backuprotation, så den tidligere gemte datatilstand bevares inden restore eller synkronisering erstatter lokalt indhold.
- Gentagne månedlige, kvartalsvise og årlige regninger opretter næste forekomst, når en betaling markeres som betalt; forfaldsdagen bevares for lange måneder, og dubletter ved opstart forhindres.
- PIN-oplåsning har 5-forsøgsgrænse med kort pause efter gentagne forkerte koder; PIN gemmes som saltet PBKDF2-hash.
- CSV og JSON-backup eksporteres som rigtige filer via Androids delingsmenu; CSV bruger semikolon, citat-escaping og UTF-8 BOM til dansk Excel.
- JSON-backup kan også vælges direkte via Filer/Downloads under gendannelse.


## Sidste finpudsning (4.2.3)
- Kvartals- og årsbetalinger understøttes på samme måde som månedlige gentagelser.
- Import af JSON-backup afviser ugyldige eller forkert typede samlingsfelter før data erstattes.
- Eksport af PDF, CSV og JSON får unikke tidsstemplede filnavne.

- Gamle poster med ejerbetegnelsen `Kæreste` normaliseres til `Partner` ved lokal indlæsning, backupgendannelse og cloudgendannelse.


## Saldo 4.2.4 — Widgets, startside og tema
- Lys/mørk temaindstilling gemmes lokalt og anvendes på appens hovedskærme, login og systembjælker.
- Startsiden kan tilpasses med individuelle vis/skjul-kontroller for syv kortsektioner. Der kan ikke skjules alle sektioner samtidigt.
- Tre Android App Widgets kan fastgøres fra Indstillinger: rådighedsbeløb frem til næste løn, månedens indtægter/udgifter/netto og kommende ubetalte regninger.
- Widgets læser kun den lokale Saldo-lagring; ingen bankforbindelse eller tredjepartsdata bruges. De opdateres, når appdata gemmes, og har en periodisk systemopdatering.
- Widgetopsætning er tilføjet i AndroidManifest, provider-metadata, RemoteViews-layouts og ressourcebeskrivelser.


## 4.2.5 — Stabilitet og sikkerhed
- Samlet budgetforbrug tæller hver transaktion én gang, selv hvis data indeholder dublerede budgetrækker.
- Dublerede budgetter for samme kategori og ejer afvises ved oprettelse.
- Sletning af poster og regninger kræver bekræftelse.
- Cloudgendannelse validerer økonomidata og løn-/saldoindstillinger før lokale data erstattes.
- Ugyldige lokale datastrukturer uploades ikke til cloudbackup.


## 4.2.6 — Datagendannelse, privatliv og konto-isolering
- Krypteret lokal præferencelagring med kontrolleret én-gangs-migrering fra tidligere data.
- Sikrere opstart, der bevarer fejlbehæftede data og forsøger at gendanne fra verificeret lokal kopi.
- Cloudgendannelse afviser ugyldige eller tomme datasæt, som ellers kunne erstatte lokale data.
- Lokal data og indstillinger adskilles pr. onlinekonto.
- Budgetoversigt deduplikerer gamle kategorier pr. ejer og viser overforbrug korrekt; budgetter kan redigeres og slettes efter bekræftelse.


## 4.2.7 — Finpudsning
- Automatisk forsøg på at forny en udløbet Supabase-session under manuel cloud-upload/hentning.
- Regningsdubletkontrol og gentagelser skelner mellem Mig, Partner og Fælles.
- Ældre poster med manglende eller dublerede ID'er normaliseres, så betaling og sletning kun påvirker den valgte række.
- Adgangskodefelter har valgfri vis/skjul-funktion, og adgangskodeværdier ryddes efter vellykket login.
- Budgetstatus viser reel procent ved overforbrug, og ukrypteret HTTP er eksplicit deaktiveret.


## Ny funktion i 4.3.0: Økonomitjek
Saldo samler nu lokale advarsler om forfaldne regninger, budgetter på/over grænsen, mulige dubletter og backupstatus. Mulige dubletter skal gennemgås manuelt; intet slettes automatisk.
