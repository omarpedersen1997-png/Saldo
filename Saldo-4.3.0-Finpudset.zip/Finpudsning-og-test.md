# Saldo 4.3.0 — implementering og teststatus

## Implementeret
- Nyt lokalt værktøj: **Økonomitjek**.
- Viser ubetalte regninger med forfaldsdato før i dag.
- Beregner budgetforbrug for indeværende måned og viser budgetter på/over grænsen.
- Marker potentielle dubletter med identisk dato, type, navn, kategori, beløb og ejer. Ingen automatisk sletning.
- Viser seneste lokale backup og dens alder; giver genvej til backup-eksport.
- Ingen nye netværkskald, tilladelser eller eksterne afhængigheder til funktionen.

## Kontrolstatus
- Projektstruktur og versionskonfiguration kontrolleres af `scripts/validate-saldo-source.py`.
- XML-manifest og ressourcer kontrolleres ved parsing.
- Workflow-YAML parses lokalt.
- Android-build og enhedstest er ikke udført i dette miljø; de skal køres i GitHub Actions og på Android-telefonen.

## Forbehold
Økonomitjekket bruger registrerede data. Manglende poster, fejlindtastninger og gentagne legitime betalinger kan påvirke resultaterne. Det erstatter ikke bankens saldo eller professionel økonomisk rådgivning.
