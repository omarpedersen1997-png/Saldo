# Saldo 4.3.0

Saldo er en Android-app til lokal styring af privatøkonomi med indtægter/udgifter, budgetter, regninger, opsparing, gæld, brændstof, abonnementer, prognoser, eksport og valgfri onlinekonto.

## Nyt i 4.3.0 — Økonomitjek
Åbn **Mere → Økonomitjek** for at få et lokalt overblik over:
- Ubetalte regninger med forfald før i dag.
- Budgetter, der har nået eller overskredet grænsen i den aktuelle måned.
- Mulige dubletter baseret på dato, type, navn, kategori, beløb og ejer.
- Status og alder på den lokale backup samt hurtig adgang til at eksportere en kopi.

Dubletkontrollen er vejledende. Saldo sletter eller ændrer ikke poster automatisk. Alle resultater afhænger af de data, brugeren har registreret.

## Byg APK via GitHub Actions
1. Upload projektfilerne til repositoryet, eller upload ZIP-filen `Saldo-4.3.0-Finpudset.zip` til repositoryets rod.
2. Kontrollér at workflowet ligger på `.github/workflows/build-saldo-4-3-0.yml`.
3. Åbn fanen **Actions**, og kør **Build Saldo 4.3.0 APK**.
4. Hent artefaktet `Saldo-4.3.0-Android-APK`, hvis bygningen lykkes.

Workflowet bruger Java 17 og Android SDK 36. Onlinefunktioner kræver de relevante `SUPABASE_URL` og `SUPABASE_ANON_KEY` secrets, hvis de skal bruges.

## Kontroller og sikkerhed
- `applicationId`: `dk.saldo.app`
- `versionName`: `4.3.0`
- `versionCode`: `27`
- Lokal datalagring benytter krypterede præferencer.
- Android backup og cleartext HTTP er slået fra i manifestet.
- Logoet er bevaret.
- Kildekontrol: `python3 scripts/validate-saldo-source.py`.

Fuld Android-kompilering og test på fysisk enhed er ikke bekræftet i denne arbejdsomgang. Se `TESTPLAN-4.3.0.md` før installation eller udgivelse.
