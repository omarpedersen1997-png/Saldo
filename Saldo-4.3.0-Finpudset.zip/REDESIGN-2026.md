# Saldo 4.2.0 — UI-redesign 2026

## Hvad er ændret i brugerfladen?
- Nyt lyst designsystem med lys canvas, mørk tekst, lilla hovedaccent og smaragdgrøn for positive beløb.
- Opdateret top- og bundnavigation, herunder aktivt faneblad, kortkanter, afrundinger og skygger.
- Rådighedsbeløbet er fortsat det vigtigste fokuspunkt, men får nu en dyb lilla kontrastflade, så saldoen står tydeligt frem.
- Månedens pengestrøm er bygget om til et nettobeløb samt separate animerede bjælker for indtægter og udgifter, skaleret mod månedens største værdi.
- Post- og regningsrækker bruger tydeligere ikoner, bedre beløbsfarver og kompakte ikonhandlinger.
- Budgetkort, hurtige handlinger og indstillingskort bruger samme visuelle system.

## Bevarede funktioner
Dataformatet, lokal lagring, ejerfelter med migrering fra `Kæreste` til `Partner`, Supabase-login/synkronisering, PIN, biometrisk oplåsning, regningspåmindelser, PDF-rapport, backup/restore og andre værktøjer er ikke tilsigtet ændret.

## Kontrolstatus
- Saldo-logoets billedfiler er hash-kontrolleret mod udgangspunktet og er byte-for-byte identiske.
- Appens Gradle-konfiguration, manifest, Supabase SQL og filprovider-konfiguration er uændrede. Build-workflowet installerer nu eksplicit Android SDK Platform 36, Build Tools 36.0.0 og Platform Tools.
- Kotlin-kilden er kontrolleret for parserfejl; en fuld Android-build er ikke udført, fordi dette miljø ikke har Android SDK eller Gradle-cache installeret.


## Baggrundsjustering

Den lyse baggrund er ændret fra næsten ensartet hvid til en rolig pastelgradient: lavendel øverst, diskret violet gennem midten og svag mint nederst. Kortene forbliver hvide for at bevare kontrast og læsbarhed. Systemets status- og navigationsbjælker er tilpasset den lidt varmere lavendelbaggrund.
