# Saldo 4.2.7 — finpudsning

## Ændringer i kildekoden

1. **Sessioner:** Synkronisering og hentning prøver at forny Supabase-sessionen én gang, hvis adgangstokenet er udløbet (HTTP 401). Den nye session kontrolleres mod den aktive bruger, før den gemmes i krypterede præferencer. Andre fejl bliver stadig vist i stedet for at blive skjult.
2. **Regninger:** Identiske regninger for forskellige ejere regnes ikke længere som dubletter. Oprettelse og tilbagevendende forekomster skelner mellem Mig, Partner og Fælles.
3. **Gendannelse:** Hvis den aktive datafil mangler, undersøger appen et gyldigt, ikke-tomt kontosnapshot eller lokalt gendannelsespunkt, før den starter tomt.
4. **Netværk:** Manifestet forbyder eksplicit ukrypteret HTTP-trafik.
5. **Udgivelse:** Versionsnummer 4.2.7 og et versionstilpasset GitHub Actions-workflow. Saldo-logoet og eksisterende JSON-dataformat er bevaret.

## Kontrolstatus
- ZIP/filstruktur og XML kan kontrolleres lokalt.
- YAML syntaks kontrolleres hvis PyYAML er tilgængelig; GitHub Actions skal stadig køre.
- Android-kompilering er ikke udført i dette miljø, fordi Android SDK/Gradle ikke er installeret, og distributionsserveren ikke er tilgængelig her.
- Praktisk test kræves på Android-enhed for login, tokenfornyelse, kontoskift, regningsdubletter, backup og widgets.
6. **Brugeroplevelse:** Adgangskode- og PIN-felter har vis/skjul-knap, og loginfelternes adgangskodeværdier ryddes efter succes. Budgetoversigten viser over 100 % korrekt ved overforbrug.
7. **Datakonsistens og lås:** Manglende eller dublerede række-ID'er i ældre backupdata gendannes til unikke ID'er; logout fjerner vist konto-e-mail og genaktiverer den lokale lås, når PIN/biometri er konfigureret.
8. **Byggemiljø:** Kotlin-gradle-plugin er opdateret til 2.4.21 og Compose BOM til 2026.09.00. Refresh-endpointet sender kun projektets API-nøgle, ikke en publishable key som Bearer-token.
