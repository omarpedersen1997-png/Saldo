# Start her — Saldo 4.3.0

1. Pak hele projektet ud i en mappe.
2. Upload projektfilerne til dit GitHub-repository.
3. Sørg for, at `.github/workflows/build-saldo-4-3-0.yml` ligger i repositoryet.
4. Kør workflowet under fanen **Actions**.
5. Hent APK-artefaktet, hvis workflowet lykkes.
6. Tag en sikkerhedskopi af dine økonomidata før installation og test.

Ny funktion: Åbn **Mere → Økonomitjek** for at se forfaldne regninger, overskredne budgetter, mulige dubletter og backupstatus. Dubletter slettes ikke automatisk.

Bemærk: Denne pakke er statisk kontrolleret, men APK-kompilering og test på fysisk Android-enhed skal stadig gennemføres i GitHub Actions og på telefonen.
