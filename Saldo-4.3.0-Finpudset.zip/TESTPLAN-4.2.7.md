# Saldo 4.2.8 — testplan

## Login og session
- Log ind med en eksisterende konto og udfør cloud-upload og cloud-hentning.
- Test med udløbet access token og gyldigt refresh token: operationen skal forny sessionen og fortsætte én gang.
- Test ugyldigt refresh token eller HTTP 403: fejl skal vises tydeligt uden at rydde lokale data.
- Skift mellem to testkonti: hver konto skal beholde sine egne poster, lønindstillinger og saldo.

## Regninger
- Opret to regninger med samme navn, dato og beløb, men forskellige ejere. Begge skal kunne gemmes.
- Opret en dublet med samme ejer: appen skal advare.
- Markér en månedlig, kvartalsvis og årlig regning som betalt; kontrollér at næste forekomst oprettes én gang for samme ejer.

## Backup og datagendannelse
- Lav JSON-backup, gendan i testsæt og bekræft poster, regninger, budgetter, opsparing, gæld, abonnementer, brændstof og indstillinger.
- Simulér manglende `data`-nøgle med gyldig konto-backup; appen skal gendanne og vise en advarsel.
- Brug en ugyldig backup: appen skal afvise den uden at erstatte aktive data.

## Brugerflade og Android
- Skift lys/mørk tilstand, navigér gennem alle faner og skift app baggrund/forgrund.
- Test notifikationstilladelse på Android 13+ og bekræft at de tre widgets opdateres.
- Test OCR med mindst tre forskellige Betalingsservice-billeder; kontrollér alle felter før gemning.
- Kontrollér at budgetter tælles for den rigtige ejer, og at rådighedsbeløb tydeligt står som estimat, når saldo ikke er indtastet.

## Release
- GitHub Actions skal gennemføre `assembleDebug`, uploade artefaktet, og APK'en skal kunne installeres.
- Før Google Play: lav signeret release/AAB og test på en fysisk enhed.
- Test vis/skjul på adgangskode- og PIN-felter, samt at adgangskodefeltet ryddes efter vellykket login.
- Registrér et budget, brug mere end grænsen, og kontrollér at status viser den faktiske procent (over 100 %) samtidig med at bjælken ikke flyder ud over kortet.
- Importér en ældre backup med manglende/dublerede `id`-felter, og kontrollér at redigering, betaling og sletning kun rammer den valgte post.
- Konfigurér PIN/biometri, log ud og ind igen; appen skal bede om den lokale oplåsning efter login.
- Kontrollér, at GitHub Actions kan hente Kotlin 2.4.21 og Compose BOM 2026.09.00, og gennemføre build uden afhængigheds- eller Kotlin-pluginfejl.

## Extra migration check before release
- Install over a previous version containing local records, bills, settings, PIN and theme choice. Confirm the encrypted preference migration succeeds, old data is not lost, and widgets/reminders still read the migrated preferences.
- Repeat with storage nearly full and after a forced app stop during first launch; ensure the app reports an error rather than silently clearing the only usable copy.


## Buildkontrol 4.2.8
Kontrollér også, at APK-pakken viser `dk.saldo.app`, versionsnavn `4.2.8` og versionCode `25`, og at `SHA256SUMS.txt` følger med artefaktet.
