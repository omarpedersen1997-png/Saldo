# Testplan — Saldo 4.3.0

## Automatiske kontroller udført lokalt
- [x] Kildekontrolscript: 24/24 kontroller bestået.
- [x] Android XML-filer kan parses.
- [x] GitHub Actions-workflow kan parses som YAML.
- [x] Kotlin-kilder er kontrolleret for parser-/syntaksfejl med lokal Kotlin-compiler; fuld typekontrol er ikke mulig uden Android/Compose-afhængigheder.
- [x] Saldo-logoets SHA-256 matcher den bevarede reference.
- [x] Version er `4.3.0`, versionCode `27`, applicationId `dk.saldo.app`.

## Funktionstest, der skal køres efter APK-bygning
1. Opret to regninger med forfald i fortiden, hvoraf én er betalt; kun den ubetalte skal vises som forfalden.
2. Opret et budget med udgifter under grænsen, derefter på grænsen og over grænsen; økonomitjekket skal opdatere status.
3. Opret to ens transaktioner; økonomitjekket skal markere mulige dubletter uden at slette nogen.
4. Bekræft, at legitime gentagne betalinger også kan markeres, og at brugeren får besked om manuel kontrol.
5. Eksportér en sikkerhedskopi fra økonomitjekket, og kontrollér at delingsdialogen åbnes.
6. Test tomme data, danske tegn, store beløb, dark/light mode og små skærme.
7. Kontrollér, at ændring af konto ikke blander økonomidata.
8. Test eksisterende OCR-import, PIN/biometri, online synkronisering og widgets.

## Ikke bekræftet endnu
- Fuld Gradle `assembleDebug`-bygning.
- Installation eller interaktion på en fysisk Android-enhed.
- Integrationstest af Supabase/onlinekonto med gyldige secrets.
