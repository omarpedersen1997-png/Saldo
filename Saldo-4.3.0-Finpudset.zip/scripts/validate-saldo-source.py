#!/usr/bin/env python3
"""Dependency-free static preflight for Saldo 4.3.0 source packages."""
from pathlib import Path
import hashlib
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_LOGO_SHA256 = "b799edbf3a636fb0dcd28ce09320bb51de3d168df4c6766c80281c133221e1ca"
ANDROID = "http://schemas.android.com/apk/res/android"
errors = []
checks = []
def check(label, condition, detail=""):
    checks.append((label, bool(condition)))
    if not condition:
        errors.append(f"{label}: {detail or 'kontrollen fejlede'}")

for rel in ("settings.gradle.kts", "build.gradle.kts", "gradle.properties", "app/build.gradle.kts", "app/src/main/AndroidManifest.xml", "app/src/main/java/dk/saldo/app/MainActivity.kt"):
    check(f"Projektfil: {rel}", (ROOT / rel).is_file())

build_file = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
check("versionName 4.3.0", 'versionName = "4.3.0"' in build_file)
check("versionCode 27", re.search(r"versionCode\s*=\s*27\b", build_file) is not None)
check("App-ID dk.saldo.app", 'applicationId = "dk.saldo.app"' in build_file)

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
try:
    manifest = ET.parse(manifest_path).getroot()
    app = manifest.find("application")
    check("Manifest kan parses", True)
    check("Android-backup slået fra", app is not None and app.get(f"{{{ANDROID}}}allowBackup") == "false")
    check("Cleartext HTTP slået fra", app is not None and app.get(f"{{{ANDROID}}}usesCleartextTraffic") == "false")
except Exception as exc:
    check("Manifest kan parses", False, str(exc))

logo = ROOT / "app/src/main/res/drawable/ic_saldo_logo.png"
logo_actual = hashlib.sha256(logo.read_bytes()).hexdigest() if logo.is_file() else "missing"
check("Saldo-logo uændret", logo_actual == EXPECTED_LOGO_SHA256, f"forventede {EXPECTED_LOGO_SHA256}, fandt {logo_actual}")
source = (ROOT / "app/src/main/java/dk/saldo/app/MainActivity.kt").read_text(encoding="utf-8")
for label, fragment in [
    ("Kontoafgrænset lokal data", "localAccountDataKey"),
    ("Backupvalidering", "parseSaldoBackup"),
    ("OCR-import", "TextRecognition"),
    ("Partner-ejer", '"Partner"'),
    ("Budgetredigering bruger række-ID", 'item.s("id") == budgetId'),
    ("Budgetredigering afviser manglende ID", 'budgetId.isBlank()'),
    ("Budgetsletning bruger kun valgt ID", 'filterNot { it.s("id") == budgetId }'),
    ("Økonomitjek-funktion tilføjet", '"Økonomitjek" -> {'),
    ("Dubletkontrol er kun vejledende", 'Mulige dubletter'),
    ("Backupstatus i økonomitjek", 'Backupstatus'),
]:
    check(label, fragment in source)
check("Ingen falsk fast 72-procentsbjælke", 'fillMaxWidth(.72f)' not in source)
print(f"Saldo 4.3.0 kildekontrol: {sum(ok for _, ok in checks)}/{len(checks)} bestået")
for label, ok in checks:
    print(("PASS" if ok else "FEJL") + " — " + label)
if errors:
    print("\nFejl:")
    print("\n".join("- " + e for e in errors))
    sys.exit(1)
