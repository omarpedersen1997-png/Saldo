# Saldo 4.3.2 — tjekliste før offentlig udgivelse

## Kilde og build
- [ ] Kør `.github/workflows/build-saldo-4-3-2.yml`; kildekontrollen skal passere, APK skal kompilere, og versionen skal være `dk.saldo.app` / `4.3.2` / `29`.
- [ ] Tilføj GitHub Secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY` (kun den publicerbare anon/publishable key, aldrig service-role key).
- [ ] Opret en privat upload-keystore og læg kun dens Base64-indhold, adgangskoder og alias i GitHub Actions Secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`.
- [ ] Konfigurer Supabase Auth, fungerende SMTP/e-mailbekræftelse/redirects og gennemgå `SUPABASE-SCHEMA.sql` / Row Level Security.
- [ ] Deploy Edge Function `supabase/functions/delete-account/index.ts` som `delete-account`. Test den med en testkonto; service-role-nøglen må aldrig indgå i Android-appen eller hjemmesiden.

## Privatliv og kontosletning — obligatorisk før Play-udgivelse
- [ ] Udfyld udviklernavn og supportmail i `docs/privacy/index.html`.
- [ ] Udfyld `docs/account-deletion/config.js` med Supabase Project URL og publicerbar anon/publishable key. Brug aldrig service-role key.
- [ ] I GitHub → Settings → Pages vælges **GitHub Actions** som source; kør `.github/workflows/publish-saldo-pages.yml`, og bekræft at privatlivspolitik og kontosletningsside virker uden at installere appen.
- [ ] Tilføj den eksterne kontosletnings-URL til Supabase Auth → URL Configuration → Redirect URLs.
- [ ] Test sletning fra appen og fra hjemmesiden med en testkonto. Bekræft både at Supabase Auth-brugeren og `saldo_user_data`-rækken bliver slettet.
- [ ] Udfyld Play Console **Data safety** og **Data deletion** ud fra den endelige build og faktiske Supabase-konfiguration.

## Manuel Android-test
- [ ] Test login, oprettelse, glemt adgangskode, udløbet session, logout, kontoskift og kontosletning.
- [ ] Test budgetter, løn hver 14. dag, rådighedsbeløb, tilbagevendende regninger og notifikationer.
- [ ] Test at en fejlet backup-/gendannelsesoperation ikke overskriver eksisterende data.
- [ ] Test OCR-import med korrekt og dårligt billede; kontrollér alle forslag før gemning.
- [ ] Test PDF-rapport med tomt datasæt og flere sider; CSV/JSON-backup og gendannelse.
- [ ] Test PIN/biometri, temaer, widgets, TalkBack, store skrifttyper og små skærme.
- [ ] Installér signeret AAB via Play Console intern testspor og test på mindst én fysisk Android-enhed.

## Google Play
- [ ] Upload 512×512 PNG-appikon og 1024×500 JPEG-feature graphic fra `store-assets/`.
- [ ] Upload mindst to aktuelle screenshots, der viser den faktiske app uden fejlagtige/fiktive funktioner.
- [ ] Indsæt titel og dansk beskrivelse fra `STORE_LISTING_DA.md` efter kontrol af maksimale tegnlængder.
- [ ] Indsæt den offentlige privatlivspolitik og eksterne kontosletnings-URL.
- [ ] Gennemgå appadgang, annoncer, målgruppe, indholdsbedømmelse, data safety og release notes.

**Status:** Kilde- og konfigurationskontroller er kørt lokalt; fuld Android-build, signing, enhedstest, fungerende Supabase-sletning og Play Console-godkendelse skal stadig bekræftes før udgivelse.
