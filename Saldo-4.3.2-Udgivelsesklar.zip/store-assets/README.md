# Saldo — visuelle Google Play-aktiver

- `app-icon-512.png`: 512 × 512 px RGBA PNG til Google Play og appens nye visuelle identitet.
- `feature-graphic-1024x500.jpg`: 1024 × 500 px JPEG til Google Play.
- `saldo-s-mark-transparent.png`: fritstående, transparent S-symbol i 1024 × 1024 px.
- `saldo-wordmark-light.png` og `saldo-wordmark-dark.png`: transparente ordmærker til henholdsvis lyse og mørke baggrunde.
- `screenshots/`: syv kategoribilleder i 1080 × 2160 px. Statuslinjen med klokken og Androids systemnavigationsknapper er fjernet; appens egen fanemenu er bevaret, fordi den er en del af appens faktiske brugerflade. Økonomibeløb i billederne er generiske, illustrative eksempeldata.

Kontrollér billederne i Play Console før indsendelse. Brug kun skærmbilleder, der svarer til den endelige build.
