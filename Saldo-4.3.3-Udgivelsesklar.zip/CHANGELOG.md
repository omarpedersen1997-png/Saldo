# Saldo 4.3.2 — komplet finpudsning

- Nyt samlet S-logo med cyan/blå/lilla/magenta-farver, tilpasset den eksisterende lilla/mint-brugerflade.
- Adaptive launcher-ikoner til Android 8+ med monokromt ikon til tematiske ikoner på understøttede enheder.
- Branded notifikationsikon; økonomiske detaljer er sat til privat visning på låseskærmen.
- Lokal gendannelse er skærpet, så en indlogget konto aldrig bruger en global ældre backup, der kan høre til en anden konto.
- Rådighedsoversigten forklarer nu, at 14-dages perioden starter efter løn, når løndatoen er i dag.
- Opdateret build-workflow, versionering og release-kontrol til version 4.3.2 / versionCode 29.
- Kildekontrol udvidet til nye logoressourcer, kontoisolering og notifikationsprivatliv.

# Ændringslog — Saldo 4.3.2

## Udgivelsesfinpudsning
- Nyt højopløseligt S-logo i cyan, blå, violet og magenta, genbrugt i appens logoressource.
- Rettet Compose-afhængigheder, så appen ikke trækker Compose 1.12.1 ind under AGP 8.13.2 og SDK 36.
- Migreret Kotlin JVM-target fra den forældede `kotlinOptions`-blok til typed `compilerOptions`.
- Kontrolleret `targetSdk = 36` og gjort kompatibiliteten med Compose/AGP eksplicit i preflight-kontrollen.
- PDF-rapporten understøtter nu flere sider, alle nyere transaktioner (op til 1.000), ubetalte regninger og en privatlivspåmindelse.
- Tilføjet kontosletning i appen og ekstern e-mailverificeret sletningsside, inklusive server-side Supabase Edge Function.
- Opdateret kildekontrol, versionering og GitHub Actions-workflows.

## Eksisterende funktioner bevaret
- Økonomitjek, budgetter, regninger, opsparing, gæld, brændstof, abonnementer, prognoser, PDF/CSV og JSON-backup.
- Lokal krypteret datalagring, PIN/biometri, widgets, notifikationer og Supabase-login med manuel cloudbackup.

## Versionsnummer
- `versionName`: 4.3.2
- `versionCode`: 28

## 4.3.3 – Finpudsning
- Transparent brand-logo gennem launcher, app-UI og butiksgrafik.
- Robuste decimal- og tusindtalsseparatorer ved CSV-import.
- Importskabelon, dokumentation og op til 20 regningsbilleder pr. batch.
- Ryddet gentagne overskrifter og hjælpetekstens placering.
- Opsparingsmålsredigering og validering dokumenteret til udgivelsestest.
