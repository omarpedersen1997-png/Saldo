# Release-tjekliste – Saldo 4.3.3

- [ ] Upload `Saldo-4.3.3-Udgivelsesklar.zip` til repositoryets rod.
- [ ] Upload `.github/workflows/build-saldo-4-3-3.yml` til `.github/workflows/`.
- [ ] Kør GitHub Actions-workflowet og hent APK under Artifacts.
- [ ] Installer APK på en fysisk Android-telefon og gennemfør `TESTPLAN-4.3.3.md`.
- [ ] Konfigurér Supabase URL/anon key og test login/synkronisering.
- [ ] Konfigurér service-side kontosletning og offentliggør privatlivs- og sletningssider.
- [ ] Brug privat upload-keystore via GitHub Secrets til release AAB; del aldrig keystore/password.
- [ ] Kontrollér Google Play Data safety, appadgang, målgruppe, annoncer, indholdsrating og kontaktinfo.
- [ ] Upload 512×512 ikon, 1024×500 feature graphic og skærmbilleder fra `store-assets/`.
- [ ] Gennemfør intern test og kontrollér alle nøgleflows før produktion.
