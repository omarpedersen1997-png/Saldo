# CSV-import i Saldo

Saldo kan importere en almindelig bank-CSV som poster eller en CSV eksporteret fra Saldo med type, navn, beløb, kategori, dato, status og ejer. Importen overskriver ikke eksisterende data. Den viser en forhåndsvisning, springer oplagte dubletter over og viser ugyldige/oversprungne rækker.

## Almindelige bankfiler
- Filen skal indeholde kolonner til dato, beskrivelse/navn og beløb.
- Positive beløb importeres som indtægter; negative beløb importeres som udgifter.
- Datoer genkendes i almindelige ISO- og danske datoformater.
- Både komma-, semikolon- og tabulatorseparerede filer understøttes.
- Gem først en eksport med et par linjer som CSV, og kontrollér forhåndsvisningen, før du importerer resten.

## Saldo-format
Se `Saldo-CSV-skabelon.csv` for et eksempel på poster, regninger, budgetter og opsparingsmål. Eksempelbeløb er kun testdata.

## Regninger fra billeder
Vælg `Scan flere`, markér flere billeder/skærmbilleder, kontrollér hvert fund i gennemgangsdialogen og gem først derefter. Maksimalt 20 billeder behandles pr. omgang. OCR kan læse forkert; kontrollér altid afsender, beløb og forfaldsdato. PDF-filer kan ikke vælges i billedscannerens masseimport.
