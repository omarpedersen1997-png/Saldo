#!/usr/bin/env python3
"""Dependency-free release preflight for Saldo 4.3.3."""
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "http://schemas.android.com/apk/res/android"
checks = []
errors = []
def check(label, condition, detail=""):
    checks.append((label, bool(condition)))
    if not condition:
        errors.append(f"{label}: {detail or 'kontrollen fejlede'}")

required = (
    "settings.gradle.kts", "build.gradle.kts", "gradle.properties",
    "app/build.gradle.kts", "app/src/main/AndroidManifest.xml",
    "app/src/main/java/dk/saldo/app/MainActivity.kt",
    "app/src/main/java/dk/saldo/app/SaldoWidgets.kt", "scripts/validate-saldo-source.py",
    ".github/workflows/build-saldo-4-3-3.yml",
    ".github/workflows/publish-saldo-pages.yml",
    "supabase/functions/delete-account/index.ts",
    "docs/account-deletion/index.html",
    "docs/account-deletion/config.js",
    "docs/privacy/index.html",
    "RELEASE_CHECKLIST.md",
    "RELEASE_AUDIT_4.3.3.md",
    "RELEASE_NOTES_4.3.3.md",
    "STORE_LISTING_DA.md", "docs/import/CSV-IMPORT.md", "docs/import/Saldo-CSV-skabelon.csv",
)
for rel in required:
    check(f"Projektfil: {rel}", (ROOT / rel).is_file())

build_path = ROOT / "app/build.gradle.kts"
build = build_path.read_text(encoding="utf-8") if build_path.is_file() else ""
for label, fragment in [
    ("versionName 4.3.3", 'versionName = "4.3.3"'),
    ("versionCode 30", 'versionCode = 30'),
    ("App-ID dk.saldo.app", 'applicationId = "dk.saldo.app"'),
    ("compileSdk 36", 'compileSdk = 36'),
    ("targetSdk 36", 'targetSdk = 36'),
    ("Compose BOM kompatibel med API 36", 'compose-bom:2025.10.01'),
    ("Typed Kotlin JVM-target", 'jvmTarget.set(JvmTarget.JVM_17)'),
]:
    check(label, fragment in build)
check("Forældet kotlinOptions fjernet", "kotlinOptions" not in build)
check("Forældet Compose BOM fjernet", "2026.09.00" not in build)

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
try:
    manifest = ET.parse(manifest_path).getroot()
    app = manifest.find("application")
    check("Manifest kan parses", True)
    check("Android backup slået fra", app is not None and app.get(f"{{{ANDROID}}}allowBackup") == "false")
    check("Cleartext HTTP slået fra", app is not None and app.get(f"{{{ANDROID}}}usesCleartextTraffic") == "false")
    check("App bruger launcher-mipmap", app is not None and app.get(f"{{{ANDROID}}}icon") == "@mipmap/ic_launcher")
    check("Appnavn kommer fra strings", app is not None and app.get(f"{{{ANDROID}}}label") == "@string/app_name")
except Exception as exc:
    check("Manifest kan parses", False, str(exc))

logo = ROOT / "app/src/main/res/drawable-nodpi/ic_saldo_logo.png"
try:
    png = logo.read_bytes()
    valid_png = png[:8] == b"\x89PNG\r\n\x1a\n" and len(png) >= 24
    dimensions = struct.unpack(">II", png[16:24]) if valid_png else (0, 0)
    check("App-logo er 512 × 512 PNG", valid_png and dimensions == (512, 512), f"fundet {dimensions}")
except OSError as exc:
    check("App-logo er 512 × 512 PNG", False, str(exc))
old_logo = ROOT / "app/src/main/res/drawable/ic_saldo_logo_reference.png"
check("Gammelt indrammet logo er fjernet", not old_logo.exists())
adaptive_icon = ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"
try:
    adaptive_root = ET.parse(adaptive_icon).getroot()
    check("Adaptive launcher-ikon kan parses", adaptive_root.tag == "adaptive-icon")
    android_ns = "{http://schemas.android.com/apk/res/android}"
    check("Adaptive ikon har forgrund, baggrund og monochrome", all(adaptive_root.find(name) is not None for name in ("background", "foreground", "monochrome")))
except Exception as exc:
    check("Adaptive launcher-ikon kan parses", False, str(exc))
for rel in ["app/src/main/res/drawable-xxxhdpi/ic_launcher_foreground.png", "app/src/main/res/drawable-xxxhdpi/ic_launcher_monochrome.png", "app/src/main/res/drawable-nodpi/ic_saldo_notification.png"]:
    try:
        b = (ROOT / rel).read_bytes()
        check(f"Brandressource findes: {rel}", b[:8] == b"\x89PNG\r\n\x1a\n")
    except OSError as exc:
        check(f"Brandressource findes: {rel}", False, str(exc))
launcher_sizes = {"mipmap-mdpi": 48, "mipmap-hdpi": 72, "mipmap-xhdpi": 96, "mipmap-xxhdpi": 144, "mipmap-xxxhdpi": 192}
for folder, size in launcher_sizes.items():
    launcher = ROOT / f"app/src/main/res/{folder}/ic_launcher.png"
    try:
        b = launcher.read_bytes()
        dims = struct.unpack(">II", b[16:24]) if b[:8] == b"\x89PNG\r\n\x1a\n" and len(b) >= 24 else (0, 0)
        check(f"Launcher-ikon {folder} {size}×{size}", dims == (size, size), f"fundet {dims}")
    except OSError as exc:
        check(f"Launcher-ikon {folder}", False, str(exc))
store_icon = ROOT / "store-assets/app-icon-512.png"
try:
    png = store_icon.read_bytes()
    dimensions = struct.unpack(">II", png[16:24]) if png[:8] == b"\x89PNG\r\n\x1a\n" and len(png) >= 24 else (0, 0)
    check("Google Play-ikon er 512 × 512 PNG", dimensions == (512, 512), f"fundet {dimensions}")
    check("Google Play-ikon under 1 MB", len(png) <= 1024 * 1024, f"filstørrelse {len(png)} bytes")
except OSError as exc:
    check("Google Play-ikon findes", False, str(exc))
feature = ROOT / "store-assets/feature-graphic-1024x500.jpg"
try:
    feature_bytes = feature.read_bytes()
    check("Google Play-feature graphic er JPEG", feature_bytes[:2] == b"\xff\xd8" and feature_bytes[-2:] == b"\xff\xd9")
except OSError as exc:
    check("Google Play-feature graphic findes", False, str(exc))
expected_screenshots = {
    "01_Overblik.jpg", "02_Poster.jpg", "03_Regninger.jpg", "04_Budget.jpg",
    "05_Okonomitjek.jpg", "06_Abonnementer.jpg", "07_Hvad_nu_hvis.jpg",
}
screenshot_dir = ROOT / "store-assets/screenshots"
actual_screenshots = {p.name for p in screenshot_dir.glob("*.jpg")} if screenshot_dir.is_dir() else set()
check("Syv Google Play-kategoribilleder findes", actual_screenshots == expected_screenshots)
for image_name in sorted(expected_screenshots):
    image_path = screenshot_dir / image_name
    try:
        image_data = image_path.read_bytes()
        check(f"Screenshot {image_name} er en JPEG", image_data[:2] == b"\xff\xd8" and image_data[-2:] == b"\xff\xd9" and len(image_data) > 10000)
    except OSError as exc:
        check(f"Screenshot {image_name}", False, str(exc))

source_path = ROOT / "app/src/main/java/dk/saldo/app/MainActivity.kt"
source = source_path.read_text(encoding="utf-8") if source_path.is_file() else ""
for label, fragment in [
    ("Kontoafgrænset lokal data", "localAccountDataKey"),
    ("Recovery bruger global backup kun uden aktiv konto", "Global recovery points are allowed only before any online account is attached."),
    ("Rådighedsbeløb er tydeligt på lønningsdagen", "Efter løn · ca. 14 dage"),
    ("Notifikationer skjuler økonomidetaljer på låseskærm", "NotificationCompat.VISIBILITY_PRIVATE"),
    ("Notifikationer bruger Saldo-ikon", "setSmallIcon(R.drawable.ic_saldo_notification)"),
    ("Backupvalidering", "parseSaldoBackup"),
    ("OCR-import", "TextRecognition"),
    ("Partner-ejer", '"Partner"'),
    ("Budgetredigering bruger række-ID", 'item.s("id") == budgetId'),
    ("Budgetredigering afviser manglende ID", 'budgetId.isBlank()'),
    ("Budgetsletning bruger kun valgt ID", 'filterNot { it.s("id") == budgetId }'),
    ("Økonomitjek-funktion tilføjet", '"Økonomitjek" -> {'),
    ("Dubletkontrol er kun vejledende", "Mulige dubletter"),
    ("Backupstatus i økonomitjek", "Backupstatus"),
    ("PDF rapport understøtter flere sider", "fun ensureSpace(height: Float = 18f)"),
    ("PDF rapport dækker ubetalte regninger", "drawSection(\"Ubetalte regninger\")"),
    ("In-app kontosletning har bekræftet serverkald", "supabaseDeleteAccount(token)"),
    ("In-app kontosletning rydder lokal kontodata", "remove(localAccountDataKey(accountId))"),
    ("Login-skærm linker til privatliv og sletning", "SALDO_ACCOUNT_DELETION_URL"),
]:
    check(label, fragment in source)
check("CSV-filvælger og import-preview", "OpenDocument()" in source and "parseSaldoCsv(raw)" in source and "pendingCsvImport" in source)
check("CSV-parser understøtter quoted fields", "parseCsvMatrix" in source and "!quoted" in source)
check("Masseimport af regningsbilleder begrænset til 20", "OpenMultipleDocuments()" in source and "uris.take(20)" in source)
check("Opsparingsmål kan redigeres", "GoalEditDialog" in source and "onEdit = { editingGoal" in source)
check("Forældet slogan og kicker fjernet fra hovedskærm", "Mere styr på pengene." not in source and "DIN ØKONOMI · ENKELT" not in source)
check("Økonomitjek har tydelig underoverskrift", 'Text("Status lige nu"' in source)
check("CSV-parser har robust separator-/decimalhåndtering", "The rightmost separator is the decimal separator" in source)
check("Ingen hårdkodet falsk 72-procentsbjælke", 'fillMaxWidth(.72f)' not in source)
edge_delete = (ROOT / "supabase/functions/delete-account/index.ts").read_text(encoding="utf-8") if (ROOT / "supabase/functions/delete-account/index.ts").is_file() else ""
check("Server-side sletning verificerer session", "auth.getUser(accessToken)" in edge_delete and "auth.admin.deleteUser(user.id)" in edge_delete)
android_source_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in (ROOT / "app/src/main").rglob("*.kt"))
check("Service-role-nøgle ligger kun i Edge Function", "SUPABASE_SERVICE_ROLE_KEY" in edge_delete and "SUPABASE_SERVICE_ROLE_KEY" not in android_source_text)
check("Kontosletningsside håndterer e-mailverificeret login", "signInWithOtp" in (ROOT / "docs/account-deletion/index.html").read_text(encoding="utf-8"))
workflow = (ROOT / ".github/workflows/build-saldo-4-3-3.yml").read_text(encoding="utf-8") if (ROOT / ".github/workflows/build-saldo-4-3-3.yml").is_file() else ""
for label, fragment in [
    ("Workflow henter udgivelsespakken", "Saldo-4.3.3-Udgivelsesklar.zip"),
    ("Workflow kontrollerer APK-versionen", "versionCode='30' versionName='4.3.3'"),
    ("Workflow tilbyder valgfri signeret AAB", "bundleRelease"),
]:
    check(label, fragment in workflow)
check("Workflow bruger aktuelle Node 24-actions", "actions/checkout@v7" in workflow and "actions/setup-java@v6" in workflow)
check("Workflow installerer kun understøttede SDK-pakker", '"platforms;android-36"' in workflow and '"platform-tools"' in workflow and '"tools"' not in workflow)
pages_workflow = (ROOT / ".github/workflows/publish-saldo-pages.yml").read_text(encoding="utf-8") if (ROOT / ".github/workflows/publish-saldo-pages.yml").is_file() else ""
check("GitHub Pages-workflow bruger aktuelle deploy-actions", "actions/checkout@v7" in pages_workflow and "actions/configure-pages@v5" in pages_workflow and "actions/upload-pages-artifact@v3" in pages_workflow and "actions/deploy-pages@v4" in pages_workflow)

print(f"Saldo 4.3.3 kildekontrol: {sum(ok for _, ok in checks)}/{len(checks)} bestået")
for label, ok in checks:
    print(("PASS" if ok else "FEJL") + " — " + label)
if errors:
    print("\nFejl:\n" + "\n".join("- " + e for e in errors))
    sys.exit(1)
