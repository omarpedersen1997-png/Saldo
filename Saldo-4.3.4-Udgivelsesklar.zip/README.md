# Saldo 4.3.4 — udgivelsesfinpudset kildepakke

Saldo er en Android-app til manuel styring af privatøkonomi med indtægter/udgifter, budgetter, regninger, opsparing, gæld, brændstof, abonnementer, prognoser og eksport. Den nuværende appversion kræver Supabase-login for at åbne hoveddelen; lokal økonomilagring og cloudbackup er forskellige funktioner, og cloudbackup er manuel.

## Udgivelsesfinpudsning i 4.3.4
- Nyt S-logo i samme cyan/blå/violette farvesprog som appen, adaptive launcher-ikoner samt ensartede Play- og privatlivsassets.
- Compose-afhængighederne er låst til en version, der er kompatibel med Android Gradle Plugin 8.13.2 og compile SDK 36; den tidligere konflikt med Compose 1.12.1 er afhjulpet ved at pinne Compose BOM til 2025.10.01.
- Kotlin JVM-target bruger typed `compilerOptions`.
- Notifikationer bruger Saldo-ikon og privat låseskærmsvisning.
- Gendannelse på en aktiv onlinekonto bruger kun den kontos egen backup.
- Rådighedsvisningen forklarer nu tydeligt perioden efter en lønudbetaling på selve løndagen.
- `targetSdk = 36` er kontrolleret og bevaret.
- PDF-rapporten er sideopdelt og inkluderer transaktioner, ubetalte regninger samt privatlivspåmindelse.
- GitHub Actions kontrollerer version, manifest, logo, Kotlin DSL og bygger debug-APK. Signeret AAB bygges, hvis keystore-secrets er konfigureret.

## Funktioner
- Lokale poster, budgetter og rådighedsbeløb frem til næste løn.
- Regningskalender, påmindelser, gentagelser og skærmbillede/OCR-import.
- Opsparing, gæld, bil/brændstof, abonnementer og scenarier/prognoser.
- Økonomitjek med forfald, overskredne budgetter og vejledende dubletkontrol.
- CSV, JSON-backup/-gendannelse, PDF-rapport, PIN/biometri og widgets.
- E-mail/password login via Supabase (påkrævet i den nuværende appversion); onlinebackup og gendannelse er manuelle handlinger.

## Byg via GitHub Actions
1. Upload `Saldo-4.3.4-Udgivelsesklar.zip` til repositoryets rod.
2. Kopiér workflow-filen `build-saldo-4-3-4.yml` til `.github/workflows/` (eller erstat indholdet af den gamle `build-saldo-4-3-4.yml`).
3. Upload også `publish-saldo-pages.yml` til `.github/workflows/`, og vælg GitHub Actions under Repository → Settings → Pages.
4. Åbn **Actions** og kør **Build Saldo 4.3.4**.
5. Hent `Saldo-4.3.4-Android` fra workflowets **Artifacts**.

### Signeret AAB til Google Play
For at få workflowet til også at bygge en signeret `bundleRelease`, skal der i GitHub Repository → Settings → Secrets and variables → Actions oprettes disse secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` og `ANDROID_KEY_PASSWORD`. Brug kun en privat upload-keystore, som du selv kontrollerer; læg aldrig keystore eller passwords i ZIP-filen eller i kildekoden. Uden disse secrets produceres debug-APK, ikke en signeret AAB.

Appen kræver `SUPABASE_URL` og `SUPABASE_ANON_KEY` som GitHub Actions secrets for at kunne logge ind; uden dem kan brugeren ikke komme forbi login-skærmen. Konfigurér også fungerende e-mailudsendelse/SMTP og redirects i Supabase Auth. Kontrollér Supabase Row Level Security og politikker før offentlig lancering.

## Privatliv og kontosletning
- Google Play kræver en tydelig sletningsvej i appen og en ekstern sletningsside, fordi appen kan oprette konti. Pakken indeholder en in-app slettefunktion, Supabase Edge Function og side i `docs/account-deletion/`.
- Udfyld kontaktmailen i `docs/privacy/index.html`, konfigurer `docs/account-deletion/config.js`, deploy `supabase/functions/delete-account` og publicér GitHub Pages. Test begge sletteveje før Play-udgivelse.
- `SUPABASE_SERVICE_ROLE_KEY` må kun ligge i Supabase Edge Function-miljøet; aldrig i Android-appen, HTML, GitHub commit eller almindelige Actions logs.

## Kontroller og begrænsninger
- `applicationId`: `dk.saldo.app`
- `versionName`: `4.3.4`
- `versionCode`: `31`
- `minSdk`: 26 · `targetSdk`: 36 · `compileSdk`: 36
- Lokal app-backup via Android Auto Backup er slået fra; Saldo har sin egen krypterede lokale lagring og manuel eksport.

Denne arbejdsomgang kan kontrollere kilde, XML og konfiguration statisk, men kan ikke bekræfte en fuld Android-build eller test på fysisk enhed i det lokale miljø. Se `TESTPLAN-4.3.4.md`. Google Play-godkendelse kræver desuden endelig signering, privacy policy, Data safety-oplysninger og test i Play Console.

## 4.3.4 – Fuld finpudsning
- CSV-importen genkender underskrifter, debet/kredit og retningstyper, foreslår kategori ud fra tekst og viser en kontrolforhåndsvisning inden import.
- CSV-importdialogen kan rulles på små skærme.
- Launcher-ikonet er skaleret ned til en sikker zone; logoet inde i appen beholder sit fritstående udtryk.
- Rådighedsbeløbsteksten er gjort mere naturlig, og statiske UI-afledninger er cachet for at reducere unødvendigt arbejde ved recomposition.
Se `START-HER.md`, `RELEASE_CHECKLIST.md`, `RELEASE_AUDIT_4.3.4.md` og `TESTPLAN-4.3.4.md`. CSV-importskabelonen ligger i `docs/import/`.
