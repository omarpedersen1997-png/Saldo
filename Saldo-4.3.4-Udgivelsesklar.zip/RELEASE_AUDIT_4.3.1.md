# Saldo 4.3.1 — release audit

## Status

- Kildekontrol: **73/73 bestået** (ingen fejl).
- Android XML: **10 filer parsede**.
- GitHub Actions-workflows: **2 YAML-filer parsede**.
- Store assets: **4 brandingfiler** og **7 kategoriskærmbilleder** er kontrolleret for format/størrelse.
- Kotlin: no syntax diagnostics; standalone type-check skipped because Android/Compose classpath is unavailable.
- Fuld Android Gradle-build: **not run locally: Gradle and/or Android SDK are not installed in this working environment**. Det skal bekræftes i GitHub Actions.

## Vigtigste ændringer

1. Nyt S-logo i appens hovedlogo og launcher-ikoner i alle fem Android-tætheder. Google Play-ikonet er 512 × 512 PNG; feature graphic er 1024 × 500 JPEG.
2. Skærmbillederne er adskilt efter kategori og viser den faktiske appstruktur uden statuslinjen med klokken og uden Android-systemknapper nederst. Appens egen fanemenu er bevaret. Økonomital i disse marketingbilleder er generiske, illustrative eksempler, ikke private budgettal.
3. Compose BOM er fastlåst til `2025.10.01`, så Compose 1.12.1 ikke længere bliver trukket ind sammen med AGP 8.13.2 / SDK 36.
4. Kotlin `jvmTarget` er flyttet fra den forældede `kotlinOptions`-blok til typed `compilerOptions`.
5. `targetSdk = 36` er kontrolleret og bevaret; `versionName = 4.3.1` og `versionCode = 28`.
6. PDF-rapporten understøtter nu flere sider, transaktionsliste, ubetalte regninger og en privatlivspåmindelse.
7. Tilføjet in-app-kontosletning, server-side Supabase Edge Function og e-mailverificeret ekstern sletningsside. Service-role-nøglen er ikke indsat i app-koden eller hjemmesiden.
8. Tilføjet GitHub Actions-workflow for APK og valgfri signeret AAB samt workflow til at publicere `docs/` via GitHub Pages.

## Ikke bekræftet endnu — skal gøres før offentlig lancering

- Kør `Build Saldo 4.3.1` i GitHub Actions, og test APK'en/AAB'en på en fysisk Android-enhed. En statisk kildekontrol er ikke det samme som en vellykket Android-build.
- Tilføj GitHub Actions-secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY`; denne appversion kræver Supabase-login for at komme ind i hoveddelen. Uden dem er appen ikke brugbar. Konfigurér også SMTP/e-mail og redirect-URL'er i Supabase Auth.
- Deploy `supabase/functions/delete-account/index.ts`, publicér GitHub Pages, erstat placeholders i `docs/account-deletion/config.js`, og udfyld udviklernavn/supportmail i `docs/privacy/index.html`. Test sletning fra både app og web.
- Tilføj upload-keystore som GitHub Secrets for at få en signeret Google Play AAB: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` og `ANDROID_KEY_PASSWORD`. Gem aldrig service-role-nøglen eller keystore i kildekoden.
- Udfyld Play Console Data safety, App access og erklæringer ud fra den endelige build; kontrollér at app-ID `dk.saldo.app` er tilgængeligt/korrekt i din Play Console.

## Visuelle assets

- `app-icon-512.png` — 512 × 512 PNG. 253.702 bytes.
- `feature-graphic-1024x500.jpg` — 1024 × 500 JPEG. 75.052 bytes.
- `saldo-wordmark-light.png` — 1500 × 420 PNG. 129.862 bytes.
- `saldo-wordmark-dark.png` — 1500 × 420 PNG. 129.149 bytes.
- `screenshots/01_Overblik.jpg` — 1080 × 2160 JPEG. 243.681 bytes.
- `screenshots/02_Poster.jpg` — 1080 × 2160 JPEG. 197.555 bytes.
- `screenshots/03_Regninger.jpg` — 1080 × 2160 JPEG. 201.337 bytes.
- `screenshots/04_Budget.jpg` — 1080 × 2160 JPEG. 198.579 bytes.
- `screenshots/05_Okonomitjek.jpg` — 1080 × 2160 JPEG. 242.306 bytes.
- `screenshots/06_Abonnementer.jpg` — 1080 × 2160 JPEG. 183.063 bytes.
- `screenshots/07_Hvad_nu_hvis.jpg` — 1080 × 2160 JPEG. 248.569 bytes.

## Officielle krav, der skal kontrolleres i Play Console

- Google Play kræver en ekstern webressource til kontosletning for apps, der tillader kontooprettelse, samt en tydelig sletningsvej i appen.
- Appikon og feature graphic følger størrelserne i Play Console-specifikationen.
- `targetSdk = 36` er valgt til Android 16/API 36.

Se `RELEASE_CHECKLIST.md`, `TESTPLAN-4.3.1.md` og `ONLINE-LOGIN.md` for den konkrete checkliste.
