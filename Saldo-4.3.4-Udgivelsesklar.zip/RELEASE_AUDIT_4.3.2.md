# Saldo 4.3.2 — finpudsning og kontrolrapport

## Udførte ændringer
- Opdateret visuel identitet med et konsistent S-logo i appskærme, Android-launcherikoner og Google Play-assets.
- Tilføjet adaptive launcher-ikoner med monokromt lag til understøttede Android-versioner.
- Skiftet notifikationsikon til Saldo-branding og sat synlighed til `VISIBILITY_PRIVATE`, så detaljer ikke vises på låseskærmen som fuldt indhold.
- Afklaret labels i rådighedsoversigten: hvis lønudbetalingen er i dag, står der nu “Efter løn · ca. 14 dage” frem for at sige både “I dag” og “Til næste løn”.
- Skærpet datagendannelse: når en onlinekonto er aktiv, genoprettes data kun fra denne kontos egne lokale snapshot-/backupnøgler. Den globale ældre backup anvendes kun, før en onlinekonto er tilknyttet.
- Version bumpet til 4.3.2 (versionCode 29), og build-workflow og statisk preflight er tilpasset.

## Kontroller kørt lokalt
- **84/84 statiske kildekontroller bestået** via `python3 scripts/validate-saldo-source.py`.
- YAML-parsing af begge GitHub Actions-workflows.
- XML-parsing af AndroidManifest og alle 11 Android-resource-XML-filer.
- Selvstændig Kotlin-syntaksscan uden parserdiagnostik; dette er ikke en kompileringskontrol, da Android/Compose-klasser mangler i miljøet.
- PNG/JPEG-signaturer, størrelser og tilstedeværelse kontrolleret for ikoner og Google Play-assets.
- ZIP-arkiver verificeret med CRC-test efter pakning.

## Ikke verificeret i dette miljø
- Fuld Gradle/Android-kompilering kunne ikke køres, fordi miljøet ikke har Android SDK eller Gradle-distribution, og netværks-DNS til at hente værktøjerne ikke er tilgængelig.
- Ingen APK/AAB eller fysisk enhedstest er derfor bekræftet af denne rapport. Kør workflowet i GitHub Actions før udgivelse.
- Publicering kræver stadig Supabase-konfiguration, fungerende Edge Function og udfyldte, sande kontaktoplysninger i privatlivspolitikken. Dette kan ikke udfyldes uden udgiverens egne oplysninger.

## Før Google Play
Se `RELEASE_CHECKLIST.md`. Brug ikke debug-APK som produktionsudgivelse; brug en AAB bygget med privat upload-keystore.
