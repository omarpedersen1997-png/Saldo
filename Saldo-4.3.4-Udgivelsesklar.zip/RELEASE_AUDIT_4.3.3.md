# Saldo 4.3.3 – kontrolrapport

Dato: 29. oktober 2026

## Kontrolleret
- Statisk preflight: 93/93 kontroller bestået (`scripts/validate-saldo-source.py`).
- AndroidManifest.xml og adaptive launcher-icon XML kan parses.
- PNG/JPEG-signaturer, mål og krævede assets er kontrolleret.
- Projektets release-version er 4.3.3 / versionCode 30.
- CSV-import, masseimport af regningsbilleder, målredigering, notifikationsprivatliv, kontoafgrænsning og kontosletningskode er kontrolleret statisk.
- Syv butiksskærmbilleder er visuelt gennemgået; Android-statuslinje/systemnavigation er fjernet, og appens egen navigation er bevaret.
- Logo-assets har en gennemsigtig S-markør uden tile i appens brugerflade.
- ZIP-arkiverne kontrolleres med `unzip -t`.

## Ikke bekræftet
- Android Gradle build og installérbar APK/AAB. Dette runtime har ikke Android SDK/Gradle installeret.
- Test på fysisk Android-enhed.
- Supabase-login, onlinekonto, e-mailflow og server-side kontosletning mod et rigtigt konfigureret projekt.
- Upload-keystore og underskrevet AAB.

**Status:** kilde-releasekandidat – ikke erklæret endeligt udgivelsesklar før grøn GitHub Actions-build og enhedstest.
