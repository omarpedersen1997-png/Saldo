# Saldo 4.3.4 – kontrolrapport

## Ændringer
- CSV-import understøtter separate debet-/kreditkolonner og tydelige retningstyper.
- Automatisk kategorisering af generiske/tomme kategorier ud fra beskrivelsen.
- Importdialogen viser summer og eksempler på type/kategori før bekræftelse.
- Launcher-ikonet bruger samme S-logo med mere luft omkring symbolet; in-app-logoet er uændret.
- Rådighedsbeløbsteksten er gjort mere naturlig.
- Føjet JUnit-regressionstests for CSV til build-workflowet.

## Verifikation
- Kildekontrol skal køres med `python3 scripts/validate-saldo-source.py`.
- Build-workflowet kører `testDebugUnitTest` og `assembleDebug`.
- Lokal Android-build kan ikke anses for bestået, før GitHub Actions har kørt succesfuldt.
- Test på fysisk Android-enhed og signed AAB skal udføres før offentlig lancering.


## Lokal kontrolstatus
- Den statiske kildekontrol blev kørt: 100/100 kontroller bestået.
- Den isolerede Kotlin-smoketest af produktionsparseren bestod: 3/3 scenarier.
- De fire JUnit-regressionstests er inkluderet i projektet og køres af GitHub Actions; de er ikke kørt lokalt, fordi Gradle/Android SDK ikke er tilgængelige i dette miljø.
- Fuld Android-build, APK-installation og fysisk enhedstest er ikke bekræftet.
