# Release-tjekliste – Saldo 4.3.4

- [ ] Upload `Saldo-4.3.4-Udgivelsesklar.zip` til repositoryets rod.
- [ ] Upload `.github/workflows/build-saldo-4-3-4.yml` til `.github/workflows/`.
- [ ] Kontrollér, at GitHub Actions består `testDebugUnitTest` og `assembleDebug`.
- [ ] Download APK fra Actions-artifact, og installér den på en fysisk Android-telefon.
- [ ] Gennemfør `TESTPLAN-4.3.4.md`, især import af flere bank-CSV-formater.
- [ ] Kontrollér Supabase-login, kontoafgrænsning, backup og kontosletning.
- [ ] Til Google Play: konfigurér upload-keystore-secrets og verificér signeret AAB.
- [ ] Gennemgå privatlivspolitik, Data safety-formular og kontaktoplysninger.

Ingen release markeres som endeligt godkendt, før build og enhedstest er bestået.
