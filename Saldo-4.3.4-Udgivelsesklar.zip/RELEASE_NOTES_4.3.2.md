# Saldo 4.3.2 — release notes

Denne version fokuserer på finish og robusthed før udgivelse:
- Ensartet S-logo på appskærme, Android-launcherikoner og Google Play-assets.
- Adaptive ikoner med monokrom version til understøttede Android-launchere.
- Privat notifikationsvisning på låseskærmen og et branded notifikationsikon.
- Sikrere lokal datagendannelse på tværs af onlinekonti.
- Opdateret build-workflow, kildekontrol og version 4.3.2 / versionCode 29.

Dette er en release-kandidat, ikke en bekræftet Google Play-godkendelse. Se `RELEASE_AUDIT_4.3.2.md` og `RELEASE_CHECKLIST.md` for åbne kontrolpunkter.
