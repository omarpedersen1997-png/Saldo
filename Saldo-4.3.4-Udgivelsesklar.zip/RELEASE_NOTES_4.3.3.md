# Saldo 4.3.3 – ændringer

- App-logoet er skiftet til en gennemsigtig cyan/blå/lilla/magenta S-markør uden tile i appens UI.
- Launcher-ikon, adaptiv forgrund, monokromt ikon og notifikationsikon er regenereret fra samme S-symbol.
- CSV-importen håndterer almindelige danske og internationale tusindtals-/decimal-separatorer bedre.
- CSV-skabelon og dansk importvejledning er tilføjet.
- Masseimport af regningsbilleder behandler op til 20 billeder pr. omgang og viser eksplicit advarsel, hvis brugeren vælger flere.
- Økonomitjek bruger nu underoverskriften “Status lige nu” i stedet for en gentaget titel.
- Regningsimportens hjælpetekst står under handlingsknapperne, ikke i samme række.
- UI- og Google Play-billeder er opdateret; det gamle slogan/kicker og indrammede logo er fjernet fra kategori-billederne.
- Versionen er bumpet til 4.3.3 / versionCode 30.

Dette er en kilde-releasekandidat. Der er ikke gennemført en Android Gradle-build i dette miljø; CI-build og device-test er fortsat påkrævet.
