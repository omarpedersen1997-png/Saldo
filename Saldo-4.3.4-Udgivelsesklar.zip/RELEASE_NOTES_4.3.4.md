# Saldo 4.3.4 – forbedringer

- CSV-import kan nu læse separate debet-/kreditkolonner og tydeligere retningstyper.
- CSV-import foreslår kategorier fra transaktionsbeskrivelsen, når kategorien mangler eller er generisk.
- Importforhåndsvisningen viser indtægter/udgifter, beløbsfordeling og eksempler på foreslåede kategorier før bekræftelse.
- Appikonet har fået større luft omkring S-symbolet; appens logo i selve brugerfladen er bevaret.
- Teksten for dagsbeløb og lønperiode er gjort mere naturlig.
- Hovedsidens undertekst forklarer nu værdien af overblikket mere konkret.
- Føjet automatiske CSV-regressionstests til projektet.

## Kontrolstatus

Kilde- og ressourcekontroller køres lokalt. Fuld Android/Gradle-build og test på fysisk enhed skal bekræftes af GitHub Actions og en Android-enhed; denne pakke må ikke beskrives som fuldt verificeret, før det er sket.
