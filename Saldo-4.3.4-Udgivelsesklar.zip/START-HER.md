# Start her – Saldo 4.3.4

## På Android-telefonen
1. Download `Saldo_Finpudsning_4.3.4_Samlet.zip`.
2. Åbn **Filer → Downloads**, tryk på ZIP-filen, og vælg **Udpak**.
3. Upload `Saldo-4.3.4-Udgivelsesklar.zip` til roden af GitHub-repositoryet (ikke den udpakkede projektmappe).
4. Upload `build-saldo-4-3-4.yml` til `.github/workflows/build-saldo-4-3-4.yml`.
5. Åbn fanen **Actions** og kør **Build Saldo 4.3.4**.
6. Når kørslen er grøn, åbn den og download `Saldo-4.3.4-Android` fra Artifacts.

## Vigtigt
En grøn build bekræfter kompilering, men ikke at appen er klar til alle brugere. Test login, CSV-import, flere regningsbilleder, redigering af opsparingsmål, backup/gendannelse og kontosletning på telefonen. For Google Play skal der genereres en signeret AAB med din egen upload-keystore og konfigureret Supabase.
