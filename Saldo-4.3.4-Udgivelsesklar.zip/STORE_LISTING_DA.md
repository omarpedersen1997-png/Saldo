# Google Play-butikstekst — Saldo

## Appnavn
Saldo – Budget og regninger

## Kort beskrivelse
Få overblik over budgetter, regninger, opsparing og rådighedsbeløb.

## Fuld beskrivelse
Saml din privatøkonomi i Saldo, og få et tydeligt overblik over indtægter, udgifter og planlagte betalinger.

**Funktioner**
- Registrér indtægter og udgifter manuelt.
- Hold styr på budgetter for dig, din partner og fælles udgifter.
- Se kommende regninger, forfald og gentagne betalinger.
- Beregn et vejledende rådighedsbeløb frem til næste løn.
- Følg opsparingsmål og gæld.
- Få overblik over abonnementer, bil/brændstof og mulige scenarier.
- Brug økonomitjek til at få øje på forfaldne regninger, budgetter nær grænsen og mulige dubletter.
- Eksportér CSV, PDF og JSON-sikkerhedskopier.
- Beskyt appen med PIN-kode eller biometrisk oplåsning, og brug Saldo-widgets på startskærmen.

Saldo opretter ikke forbindelse til din bank og foretager ikke betalinger. Beløb og prognoser afhænger af de data, du selv registrerer, og er vejledende.

En konto med e-mail og adgangskode kræves for at bruge appens hoveddel. Onlinebackup er en manuel handling; ændringer flettes ikke automatisk mellem flere enheder. Læs privatlivspolitikken for oplysninger om lokal lagring, Supabase-login, cloud-backup og kontosletning.

## Før brug
Kontrollér, at Supabase-login, online backup og kontosletning er konfigureret og testet i den endelige build, før denne tekst offentliggøres.
