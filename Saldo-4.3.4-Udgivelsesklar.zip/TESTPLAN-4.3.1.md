# Testplan — Saldo 4.3.1

## Kontroller, der køres af workflowet
- Projektstruktur, app-ID, versionCode/versionName og target/compile SDK.
- AndroidManifest.xml parses, Android backup er slået fra, og cleartext HTTP er slået fra.
- Logoet er en 512 × 512 PNG.
- Compose BOM er pinna til en API 36 / AGP 8.13-kompatibel version.
- Kotlin bruger `compilerOptions` og ikke den gamle `kotlinOptions`-blok.
- Eksisterende databeskyttelses-, backup-, OCR-, budgetredigerings- og økonomitjek-markører bevares.
- Debug-APK bygges, og package name/version kontrolleres i APK'en.
- Hvis gyldig upload-keystore er konfigureret som GitHub Secrets, bygges også en signeret release AAB.

## Manuelle test før offentlig lancering
1. Installer APK på mindst én fysisk Android-enhed med API 26+.
2. Første start viser et tomt datasæt uden personlige eksempeldata.
3. Opret, redigér og slet indtægter/udgifter; totalsummer, kategorier og rådighedsbeløb opdateres korrekt.
4. Test danske decimaler, tusindtalsseparatorer, nul, negative tal, lange navne og store beløb.
5. Gentagende regninger oprettes præcis én gang pr. forfaldsdato; markering som betalt og historik kontrolleres.
6. Økonomitjek: forfaldne regninger, budgetter under/på/over grænsen og mulige dubletter. Dubletter må aldrig slettes automatisk.
7. JSON-backup: eksportér, gendan gyldig fil, afvis ugyldig/for stor fil og bekræft at eksisterende data bevares ved fejl.
8. PDF-rapport: test tomt datasæt, mange transaktioner (over én side), lange danske navne og ubetalte regninger; delingsdialogen skal åbne.
9. CSV-eksport skal bevare danske tegn og håndtere komma/anførselstegn korrekt.
10. Test PIN/biometri, logout/login, kontoskift og at ingen kontodata blandes mellem brugere.
11. Test online-login/synkronisering med rigtige secrets, Supabase RLS/policies og fejlsituationer uden netværk.
12. Test OCR med en regning med tydelig tekst og en dårlig/uklar skærm; intet må gemmes uden brugerens bekræftelse.
13. Test dark/light mode, skærmstørrelser, stor skrift, TalkBack, systemnavigation og tilladelser.
14. Kontrollér widgets, notifikationer efter genstart og batteribegrænsninger.
15. Google Play: signeret AAB, privatlivspolitik på offentlig HTTPS, korrekt Data safety, målgruppe/indholdsbedømmelse og intern/lukket test.

## Teststatus
- Udførte statiske checks registreres i `scripts/validate-saldo-source.py`.
- Fuld Android Gradle-build og test på fysisk enhed skal gennemføres i GitHub Actions/Android før offentlig udgivelse.
- Play Console kan afvise en app, selv om AAB'en kan bygges; gennemgå alle erklæringer ud fra den endelige build.
