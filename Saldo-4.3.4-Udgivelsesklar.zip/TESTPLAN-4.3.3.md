# Testplan Saldo 4.3.3

## Automatiske preflight-kontroller
- Versionsnumre og applicationId
- Manifest- og adaptive-icon XML
- PNG/JPEG-signaturer og størrelser
- Påkrævede CSV, masse-OCR, målredigering og privatlivskode findes
- Gammelt slogan/kicker og boxed-logo reference er ikke aktivt
- Build-workflow peger på 4.3.3 og understøttede Android SDK-pakker

## Test på Android-enhed (skal udføres efter CI-build)
1. Importér en CSV med semikolon, komma og tabulator; kontrollér forhåndsvisning, dubletkontrol og beløb med danske separatorer.
2. Importér en bank-CSV med positive/negative beløb; kontrollér indtægt/udgift og datoer.
3. Vælg flere regningsbilleder, ret OCR-fejl, fravælg et billede og gem; kontrollér dubletadvarsel og samlede beløb.
4. Opret, redigér og slet et opsparingsmål; kontrollér, at indbetalinger ikke utilsigtet ændres.
5. Skift mellem hovedfaner, mørkt/lyst tema og skærmstørrelser; kontrollér nederste navigation og labels.
6. Test login/logud, brugerisolering, backup, gendannelse, PIN/biometri og kontosletning med testkonto.
7. Kontrollér notifikationernes låseskærm-visning.
8. Test rotation, appens genstart, ingen data, store lister og fejlbehæftede filer.

## Ikke bekræftet i dette miljø
Android Gradle-build, APK-installation, AAB-signering, Supabase end-to-end og fysisk enhedstest.
