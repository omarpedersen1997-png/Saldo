# Testplan – Saldo 4.3.4

## Automatiske CSV-tests
1. Positiv løn klassificeres som indtægt og kategorien Løn.
2. Negative køb klassificeres som udgifter og kategoriseres efter beskrivelse.
3. Separate Debet/Kredit-kolonner bliver læst korrekt, også uden en samlet beløbskolonne.
4. Retning fra bankens retningstype skal overstyre et positivt beløb, hvis der findes en eksplicit type.
5. Dansk talformat med tusindtalsseparator og decimal-komma læses korrekt.
6. Datoformater med punktum og skråstreg accepteres.

## Manuelle test på Android
- Importér en rigtig bank-CSV og kontrollér alle forslag i forhåndsvisningen.
- Importér samme fil to gange og bekræft, at dubletkontrollen virker.
- Kontrollér ikonets størrelse i launcher og på startsiden, i lyst og mørkt tema.
- Skift mellem hovedfaner med store lister, og kontrollér rulning og animationer.
- Kontrollér lønningsdagen og en dato midt i lønperioden.
- Test CSV, masseimport af regningsbilleder, opsparingsmål, backup, login og kontosletning.

## Ikke bekræftet før CI
Fuld Android/Gradle-build, APK-installation, signeret AAB og fysisk enhedstest.

- Kontrollér manuelt positive bankbeløb uden debet/kredit- eller retningstype; parseren er bevidst konservativ og foreslår kun indtægt for genkendelige indkomstbeskrivelser.
