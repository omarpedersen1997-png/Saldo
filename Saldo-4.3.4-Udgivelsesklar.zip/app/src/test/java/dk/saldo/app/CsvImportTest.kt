package dk.saldo.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CsvImportTest {
    private fun transactions(csv: String) = parseSaldoCsv(csv)
        .recordsByCollection["transactions"]
        .orEmpty()

    @Test
    fun signedAmountsUseDirectionAndSuggestCategories() {
        val csv = """Dato;Beskrivelse;Beløb;Kategori
2026-10-24;Løn fra arbejdsgiver;10.000,00;Importeret
2026-10-25;Netto;−562,50;Importeret
2026-10-26;OK Benzin;-375,00;
""".replace("−", "-")
        val result = transactions(csv)
        assertEquals(3, result.size)
        val salary = result.single { it.getString("name").startsWith("Løn") }
        assertEquals("Indtægt", salary.getString("type"))
        assertEquals("Løn", salary.getString("category"))
        assertEquals(10000.0, salary.getDouble("amount"), 0.001)
        val groceries = result.single { it.getString("name") == "Netto" }
        assertEquals("Udgift", groceries.getString("type"))
        assertEquals("Mad", groceries.getString("category"))
        val fuel = result.single { it.getString("name") == "OK Benzin" }
        assertEquals("Transport", fuel.getString("category"))
    }

    @Test
    fun separateDebitAndCreditColumnsWorkWithoutSingleAmountColumn() {
        val csv = """Dato;Beskrivelse;Debet;Kredit
2026-10-24;Løn fra arbejdsgiver;;10000,00
2026-10-25;Netto;562,50;
2026-10-26;Codan forsikring;293,00;
"""
        val result = transactions(csv)
        assertEquals(3, result.size)
        val salary = result.single { it.getString("name").startsWith("Løn") }
        assertEquals("Indtægt", salary.getString("type"))
        assertEquals("Løn", salary.getString("category"))
        val groceries = result.single { it.getString("name") == "Netto" }
        assertEquals("Udgift", groceries.getString("type"))
        assertEquals("Mad", groceries.getString("category"))
        val insurance = result.single { it.getString("name") == "Codan forsikring" }
        assertEquals("Regninger", insurance.getString("category"))
    }

    @Test
    fun explicitDirectionColumnOverridesPositiveAmount() {
        val csv = """Dato;Beskrivelse;Beløb;Retning
2026-10-24;Overførsel fra arbejdsgiver;1500,00;Indbetaling
2026-10-25;MobilePay køb;75,00;Udgift
"""
        val result = transactions(csv)
        assertEquals(2, result.size)
        val incoming = result.single { it.getString("name").contains("arbejdsgiver") }
        assertEquals("Indtægt", incoming.getString("type"))
        val outgoing = result.single { it.getString("name").contains("MobilePay") }
        assertEquals("Udgift", outgoing.getString("type"))
    }

    @Test
    fun importPreviewDataIncludesTypeAndCategoryFields() {
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Løn;10000
2026-10-25;Netflix;-99
""")
        assertTrue(result.all { it.has("type") && it.has("category") })
        assertEquals("Abonnementer", result.single { it.getString("name") == "Netflix" }.getString("category"))
    }
}
