/*
 * Udfyld før publicering på GitHub Pages.
 * Brug kun din Supabase Project URL og publishable/anon key.
 * Indsæt ALDRIG SUPABASE_SERVICE_ROLE_KEY her.
 */
window.SALDO_CONFIG = {
  supabaseUrl: "INDSAET_SUPABASE_PROJECT_URL",
  supabaseAnonKey: "INDSAET_SUPABASE_PUBLISHABLE_ELLER_ANON_KEY"
};
