# CSV-import i Saldo

Saldo kan importere poster fra almindelige bank-CSV-filer og fra Saldo-eksport. Filen vælges under **Indstillinger → Importér CSV-fil**. Saldo viser en forhåndsvisning, før noget bliver gemt.

## Kolonner, der genkendes

Mindst dato og beskrivelse skal være med. For beløb accepteres enten én beløbskolonne (fx `Beløb`, `Amount` eller `Value`) eller separate kolonner for debet/udbetaling og kredit/indbetaling. Datoer som `2026-10-29`, `29.10.2026` og `29/10/2026` understøttes. Semikolon, komma og tabulator accepteres som kolonneseparator.

## Indtægt eller udgift

Saldo bruger i denne rækkefølge separate debet-/kreditkolonner, en tydelig retningstype, beløbets fortegn og kendte indkomstord i beskrivelsen. Hvis en bankfil indeholder positive beløb uden retning, kan nogle rækker være tvetydige; kontrollér derfor altid typen i forhåndsvisningen, før importen bekræftes. Saldo ændrer ikke de eksisterende poster ved import, og mulige dubletter springes over.

## Automatisk kategorisering

Når kategorien mangler eller er generisk, foreslår Saldo en kategori ud fra beskrivelsen, fx løn, dagligvarer, benzin, husleje, forsikringer, abonnementer, sundhed eller shopping. En eksisterende, ikke-generisk kategori i filen bevares. Kategoriseringen er lokal og regelbaseret – ingen bankforbindelse eller dataupload er nødvendig. Kontrollér forslagene før import.

## Saldo CSV-skabelon

Skabelonen `Saldo-CSV-skabelon.csv` bruger Saldo-formatet: `type;navn;beløb;kategori;dato;status;ejer`. For en række med `type=post` angiver `status` retningen (`Indtægt` eller `Udgift`), og `beløb` er det absolutte beløb. Andre CSV-formater kan bruge negative beløb til udgifter og positive beløb til indtægter.
