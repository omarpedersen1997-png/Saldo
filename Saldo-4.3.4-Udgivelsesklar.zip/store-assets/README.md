# Saldo – brand og Google Play-assets (4.3.4)

- `app-icon-512.png`: komplet Google Play-ikon (512×512).
- `saldo-s-mark-transparent.png`: fritstående logo uden baggrund; brug på appens lyse eller mørke flader.
- `saldo-wordmark-dark.png` / `saldo-wordmark-light.png`: logo + Saldo-ordmærke med gennemsigtig baggrund.
- `feature-graphic-1024x500.jpg`: Google Play-feature graphic, 1024×500.
- `screenshots/`: syv kategoribilleder baseret på appens faktiske layout, 1080×2160.

Skærmbilledernes tal er illustrative testdata, ikke en rigtig brugers økonomi. Android-statuslinjen og systemnavigationsknapperne er fjernet; appens egen navigation er bevaret.
