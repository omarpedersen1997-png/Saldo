import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

function jsonResponse(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: corsHeaders });
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return jsonResponse({ error: "Kun POST understøttes." }, 405);

  const authorization = request.headers.get("Authorization") ?? "";
  const accessToken = authorization.replace(/^Bearer\s+/i, "").trim();
  if (!accessToken) return jsonResponse({ error: "Log ind for at slette kontoen." }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !anonKey || !serviceRoleKey) {
    console.error("delete-account mangler Supabase-miljøvariabler.");
    return jsonResponse({ error: "Kontosletning er ikke konfigureret på serveren." }, 500);
  }

  // Validate the caller with their own session before using admin privileges.
  const userClient = createClient(supabaseUrl, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: userResult, error: authError } = await userClient.auth.getUser(accessToken);
  const user = userResult.user;
  if (authError || !user) return jsonResponse({ error: "Sessionen er udløbet. Log ind igen." }, 401);

  // The service-role key stays server-side. It is never compiled into the Android app or page.
  const adminClient = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // The schema uses ON DELETE CASCADE for this row. Deleting the auth user removes its cloud backup.
  const { error: deleteError } = await adminClient.auth.admin.deleteUser(user.id);
  if (deleteError) {
    console.error("Supabase account deletion failed for authenticated user.", deleteError.message);
    return jsonResponse({ error: "Supabase kunne ikke slette kontoen. Prøv igen senere." }, 500);
  }

  return jsonResponse({ ok: true, message: "Konto og tilknyttet clouddata er slettet." });
});
