## 4.3.5 – Design 2026
- Nyt mørkt standardtema med dyb navy/sort baggrund, lilla gradienter, diskrete glødende kanter og afrundede kort.
- Animerede budgetbjælker, glidende beløb, nyt søjlediagram i Rapporter og kategoribjælker i stedet for tekstlister.
- Flydende bundnavigation med animeret markering, tilbageknap på undersider og Android-tilbage-tast til Mere/Overblik.
- Hurtige skærmovergange, trykanimationer på kort og knapper, animerede listeændringer og en kort succesanimation ved gemning.
- Logo, ikoner og brandingfiler er uændrede. Dataformat, Supabase-login, synkronisering, PIN, biometri, PDF, backup og notifikationer er bevaret.

# Ændringslog — Saldo

## 4.3.5 — Smartere import, ydeevne og UX
- CSV-kategorisering tager højde for detaljeret tekst, brugerens eksisterende kategorier, kendte transaktioner, beløbsnærhed og tidligere rettelser.
- Usikre retninger/kategorier markeres til review; type og kategori kan ændres i importens forhåndsvisning.
- CSV-dubletkontrol er ændret til set-baserede fingerprints, og kategoriændringer alene skaber ikke dublettransaktioner.
- CSV læses/analyseres på IO-dispatcheren, og preview bruger `LazyColumn`.
- Cache af månedsindeks og kategori-/ejer-summer samt debounced widgetopdatering reducerer gentaget arbejde.
- Indstillinger er sektioneret, og eksisterende lette animationer bevares.
- Launcher-ikonet har forbedret indre margen; overskriftstekster er strammet op.
- Version: `4.3.5`, versionCode `32`.

## 4.3.4 og tidligere
Se historikken i `RELEASE_NOTES_4.3.4.md`, `RELEASE_NOTES_4.3.3.md` og tidligere test-/auditfiler.
