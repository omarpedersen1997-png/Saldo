# Ændringslog — Saldo

## 4.3.5 – Design 2026
- Skånsomt for øjnene: blødere mørkt tema med lysere navy, dæmpet champagneguld, lysegrå i stedet for kridhvid tekst, afdæmpet grøn/rød, næsten ingen glød. Logo og widgets følger samme bløde toner. Kontrast er stadig 6,8–13,8:1.
- Rettelser efter test på telefon: rådighedskortets undertekst har sin egen linje, trendlinjen skjules uden historik og klippes ikke længere i kanten, ikonfelter/valgt fane/valgte chips er lysere navy i stedet for brunlige, Økonomitjek-overskrifter skæres ikke af, mere luft på Budget, ingen markør uden budget, og skyderne i "Hvad nu hvis?" er glatte uden prikker.
- Budgettempo: hver budgetbjælke har en markør for, hvor langt måneden er, og viser en prognose for månedens forbrug, hvis tempoet er for højt.
- Opsparingsmål vises med fremskridtsring, procent og hvor meget der skal spares pr. måned for at nå målet til måldatoen.
- Ny indsigt på Overblik: forbrug sammenlignet med samme tidspunkt sidste måned.
- Beløb vises som i en bankapp: altid to decimaler, og i store beløb er øre og "kr." sat mindre end kronebeløbet.
- Poster vises med en rund forbogstavsavatar og et lille ind/ud-mærke i stedet for generiske pile.
- Overblik har tappbare indsigter: forfaldne regninger, andel af indtægten brugt, regninger før løn og største udgiftskategori.
- Bundmenuen bruger konturikoner, der bliver udfyldt ved valg; let haptisk feedback ved faneskift og når noget gemmes.
- Ny farveprofil: navy og guld. Appen (mørkt og lyst tema), logo, launcher-/notifikationsikoner, widgets og butiksgrafik bruger samme navy-baggrund og guldgradient. Advarsler er nu orange, så de ikke forveksles med guldaccenten.
- Roligere udtryk: mindre glød og blødere kanter.
- Bedre læsbarhed: beløb vises med + / − ved siden af grøn/rød (farveblind-venligt), ingen tekst under 10 pt, og grøn/orange har nu tilstrækkelig kontrast i lyst tema.
- Rettet: brændstofforbrug (l/100 km) talte literne fra den første tankning med og viste derfor for højt forbrug.
- Rettet: widgets kunne crashe på startskærmen, hvis den krypterede lagring ikke kunne læses.
- Optimeret: beløbsformatering genbruges i stedet for at blive oprettet ved hvert kald (også i animationer og widgets), masseimport af regninger gemmer én gang i stedet for op til 20 gange, og regningsgrupper/dubletsøgning caches.
- Skrifttypen Inter (OFL-1.1, se INTER-FONT-LICENSE.txt) bruges i hele appen, med tabeltal i animerede beløb.
- Primære knapper, plusknappen og den valgte fane i bundmenuen bruger logoets gradient; kontoknap i toppen åbner Indstillinger.
- Rådighedskortet viser en animeret trendlinje for netto de seneste 6 måneder.
- Nyt logo: minimalistisk, geometrisk S med guldgradient på dyb navy. Launcher-, adaptive-, monochrome-, notifikations- og butiksikoner samt feature graphic er gentegnet (kilde: store-assets/render-logo.js).
- Ny struktur: personlig hilsen og 2×2-nøgletal på Overblik, poster grupperet pr. dag med faste datooverskrifter, regninger grupperet i Forfaldne/Kommende/Betalt, og Mere som et adaptivt gitter.
- Layoutet centreres og begrænses i bredden på tablets og foldbare telefoner.
- Nyt mørkt standardtema med dyb navy/sort baggrund, lilla gradienter, diskrete glødende kanter og afrundede kort.
- Animerede budgetbjælker, glidende beløb, nyt søjlediagram i Rapporter og kategoribjælker i stedet for tekstlister.
- Flydende bundnavigation med animeret markering, tilbageknap på undersider og Android-tilbage-tast til Mere/Overblik.
- Hurtige skærmovergange, trykanimationer på kort og knapper, animerede listeændringer og en kort succesanimation ved gemning.
- Logo, ikoner og brandingfiler er uændrede. Dataformat, Supabase-login, synkronisering, PIN, biometri, PDF, backup og notifikationer er bevaret.

## 4.3.5 — Smartere import, ydeevne og UX
- CSV-kategorisering tager højde for detaljeret tekst, brugerens eksisterende kategorier, kendte transaktioner, beløbsnærhed og tidligere rettelser.
- Usikre retninger/kategorier markeres til review; type og kategori kan ændres i importens forhåndsvisning.
- CSV-dubletkontrol er ændret til set-baserede fingerprints, og kategoriændringer alene skaber ikke dublettransaktioner.
- CSV læses/analyseres på IO-dispatcheren, og preview bruger `LazyColumn`.
- Cache af månedsindeks og kategori-/ejer-summer samt debounced widgetopdatering reducerer gentaget arbejde.
- Indstillinger er sektioneret, og eksisterende lette animationer bevares.
- Launcher-ikonet har forbedret indre margen; overskriftstekster er strammet op.
- Version: `4.3.5`, versionCode `32`.

## 4.3.4 og tidligere
Se historikken i `RELEASE_NOTES_4.3.4.md`, `RELEASE_NOTES_4.3.3.md` og tidligere test-/auditfiler.
