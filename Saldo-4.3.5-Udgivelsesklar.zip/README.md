# Saldo 4.3.5 — smarter CSV, hurtigere oversigter og finpudset UX

Saldo er en Android-app til manuel styring af privatøkonomi med indtægter, udgifter, budgetter, regninger, opsparing, gæld, brændstof, abonnementer, prognoser, eksport og sikkerhedskopiering.

## Forbedringer i 4.3.5

- CSV-importen genkender danske og engelske kolonneoverskrifter, semikolon/komma/tabulator, citerede felter, danske/engelske beløbsformater samt separate debet- og kreditkolonner.
- Kategoriforslag anvender transaktionstekst, eksplicit kategori, brugerens eksisterende kategorier, tidligere transaktioner, brugerens tidligere rettelser og beløbslighed som supplerende signal.
- Usikre forslag fremhæves i en rulbar forhåndsvisning, hvor retning og kategori kan ændres før import. Rettelser gemmes lokalt og afgrænses til den aktive konto.
- Dubletkontrol bruger et sæt af forretningsfelter i stedet for en gentagen lineær sammenligning. Kategoriændringer alene gør ikke den samme transaktion til en ny post.
- Månedlige data og kategori-/ejer-summer beregnes én gang pr. datasnapshot og genbruges i oversigter.
- Widgetopdateringer samles i en kort debounced kø for at undgå gentaget arbejde ved flere ændringer.
- Indstillinger er opdelt i forståelige sektioner, og lister/kort har afdæmpet størrelsesanimation.
- Launcher-ikonet har en større sikker margen omkring S-symbolet; logoet i selve appen bevarer den gennemsigtige baggrund.
- Rådighedsteksten bruger "TIL RÅDIGHED PR. DAG" og "Ny lønperiode · ca. 14 dage" på lønningsdagen.

## Teknologi og dataprivatliv

- Native Android/Kotlin med Jetpack Compose, SDK 36 og minSdk 26.
- Lokal JSON-/SharedPreferences-lagring samt Supabase-login og manuel synkronisering.
- CSV-filer analyseres på IO-dispatcheren. Ingen bankforbindelse tilføjes.
- Kategorisering er regelbaseret, ikke en ekstern AI-tjeneste; den uploader ikke beskrivelser til en tredjepart.
- Brugerens kategorirettelser gemmes lokalt i præferencer under nøgle, der er afgrænset pr. onlinekonto.

## Byg via GitHub Actions fra Android-telefon

1. Upload `Saldo-4.3.5-Udgivelsesklar.zip` til roden af dit GitHub-repository.
2. Upload `.github/workflows/build-saldo-4-3-5.yml` til samme sti i repositoryet. Filen ligger også i dette projekt.
3. Sørg for, at `publish-saldo-pages.yml` fortsat ligger i `.github/workflows/`, hvis du bruger GitHub Pages til privatlivs-/kontosletningssider.
4. Åbn **Actions** og kør **Build Saldo 4.3.5**.
5. Hent `Saldo-4.3.5-Android` fra workflowets **Artifacts**, når jobbet er grønt.

Workflowet kører `testDebugUnitTest` og `assembleDebug`. En signeret AAB bygges kun, hvis de fire upload-keystore-secrets er konfigureret: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` og `ANDROID_KEY_PASSWORD`.

`SUPABASE_URL` og `SUPABASE_ANON_KEY` skal være konfigureret i GitHub Secrets for at login kan virke. Konfigurér også Supabase Auth-email/redirects, Row Level Security, privatlivspolitik og kontosletning inden offentlig udgivelse.

## Kontrolstatus

Den lokale preflight validator kontrollerer kildefiler, version, ressourcer, workflow, tests, CSV-flow, kontoafgrænsning og branding. Det lokale miljø har ikke Android SDK/Gradle installeret, så fuld APK/AAB-kompilering og UI-test på en rigtig telefon skal verificeres i GitHub Actions og på enheden. Se `RELEASE_AUDIT_4.3.5.md`, `TESTPLAN-4.3.5.md` og `RELEASE_CHECKLIST.md`.
