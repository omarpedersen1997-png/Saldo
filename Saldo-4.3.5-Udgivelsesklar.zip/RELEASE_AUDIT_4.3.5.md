# Releaseaudit — Saldo 4.3.5

## Omfang
Gennemgået den eksisterende Kotlin/Jetpack Compose-appstruktur før ændringer. Appen er en native Android-app med en stor Compose-baseret `MainActivity.kt`, `SaldoWidgets.kt`, lokal JSON/SharedPreferences-lagring, Supabase-login/-synkronisering, ML Kit OCR og Gradle-baseret build.

## Implementerede ændringer
- CSV-importen bruger nu beskrivelse, beløbstype, eksisterende kategorier, kendt transaktionshistorik og kontoafgrænsede tidligere brugerrettelser.
- Tydelige regler foreslår specifikke kategorier. Ukendte/tvetydige resultater markeres til gennemgang.
- CSV-dialogens lister er virtualiserede via `LazyColumn`; type og kategori kan redigeres før bekræftelse.
- CSV-tekst læses og parses på `Dispatchers.IO`.
- Dubletkontrol bruger fingerprints i `MutableSet` frem for O(n²)-sammenligninger. Fingerprint på poster ignorerer id, importmetadata og kategori for ikke at genimportere samme transaktion som ny alene pga. kategoriretning.
- Månedlige transaktioner grupperes efter `YearMonth`; summer efter kategori/ejer cachelagres.
- Widgetopdateringer samles i en debounced single-thread-kø.
- Indstillinger har sektionstitler; kort/handlingsrækker bruger `animateContentSize`, eksisterende budget/progress-animationer bevares.
- Appikonets S-symbol får mere luft, appens indre logo bevarer transparent baggrund.

## Kontrol
Den inkluderede `scripts/validate-saldo-source.py` foretager statiske kontroller af versionering, XML, asset-dimensioner, CSV-flow, kontoafgrænsning og workflow. GitHub Actions udfører de rigtige JUnit-tests og `assembleDebug`.

## Ikke bekræftet lokalt
- Komplet Android/Gradle-kompilering, fordi dette miljø ikke har Android SDK/Gradle installeret.
- Ydeevnemålinger på fysisk telefon, adaptive ikonvisninger på OEM-launchere eller TalkBack-test.
- Endelig Play Console-godkendelse og signed AAB, som kræver udviklerens upload-keystore og korrekt Supabase-konfiguration.

**Status:** Kildeopdatering og release preflight er klar til CI; dette dokument påstår ikke at en fuld build allerede er lykkedes.
