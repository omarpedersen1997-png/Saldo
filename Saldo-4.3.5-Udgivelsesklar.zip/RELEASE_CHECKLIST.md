# Release-tjekliste — Saldo 4.3.5

## GitHub build
- [ ] Upload `Saldo-4.3.5-Udgivelsesklar.zip` til repositoryets rod.
- [ ] Upload `.github/workflows/build-saldo-4-3-5.yml` til samme sti i repositoryet.
- [ ] Sørg for at `publish-saldo-pages.yml` forbliver i `.github/workflows/`, hvis Pages bruges.
- [ ] Tilføj GitHub Secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY`.
- [ ] Kør **Build Saldo 4.3.5** og kontrollér at `testDebugUnitTest` og `assembleDebug` passerer.
- [ ] Kontrollér pakken `dk.saldo.app`, versionName `4.3.5` og versionCode `32`.

## Funktionstest
- [ ] CSV med semikolon, komma, citerede felter, danske talformater, signerede beløb og debet/kredit.
- [ ] Review af usikre kategorier og retning, manuel redigering før import og dubletkontrol.
- [ ] Kategori-hukommelse skal være lokal og kontoafgrænset.
- [ ] Regnings-OCR og masseimport, opsparingsmålsredigering, budgets, rapporter, widgets.
- [ ] Login/logout/kontoskift, sikkerhedskopi, gendannelse og kontosletning.
- [ ] Smal skærm, større tekststørrelse, systemnavigationsindstillinger og TalkBack.

## Google Play
- [ ] Konfigurér og test Supabase Auth e-mail/redirects, RLS og kontosletnings-Edge Function.
- [ ] Udfyld kontaktmail i privatlivspolitikken, deploy GitHub Pages, test sletningsflow.
- [ ] Tilføj `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD` som secrets.
- [ ] Byg og kontroller signeret AAB, upload til intern test og test på rigtig enhed.
- [ ] Udfyld Data safety, appadgang, indholdsbedømmelse og butiksfortegnelse i Play Console.

## Status
Kildekontroller kan køres lokalt. Fuld Android-build, fysisk device-test og Play Console-udgivelse skal udføres før offentlig lancering.
