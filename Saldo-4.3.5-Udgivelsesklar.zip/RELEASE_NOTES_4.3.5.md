# Saldo 4.3.5 — release notes

## CSV-import
- Udvidet klassificering efter tekst, brugerdefinerede kategorier, kendte afsendere og tidligere rettelser.
- Beløbsnærhed anvendes kun som ekstra signal sammen med kendt afsender og type — ikke som selvstændigt bevis.
- Støtte for separate debet-/kreditkolonner og flere danske/engelske overskrifter.
- Rulbar forhåndsvisning med redigering af retning og kategori, sikkerhedsniveau og begrundelse.
- Rettelser gemmes lokalt og adskilt pr. konto. Parsermetadata fjernes, før poster gemmes.
- Hurtig dubletkontrol, som ignorerer genereret ID, midlertidige importfelter og kategoritekst ved genkendelse af samme transaktion.

## Ydeevne og UX
- Månedlige transaktioner indekseres efter måned.
- Månedlige kategori- og ejerbeløb caches og bruges til budgetadvarsler og budgetoversigter.
- Widgetopdateringer samles i en debounced kø.
- Indstillinger præsenteres med sektioner, og kort/handlinger bruger diskrete animationer.
- Rådighedstekst er præciseret, og launcherikonet har en større indre margen.

## Tekniske valg
- Ingen netværksbaseret kategorisering; heuristikker og kategori-hukommelse forbliver lokale.
- Usikre forslag markeres til brugerreview. Retningstvivl under 80 % og kategoritvivl under 72 % vises som review.
- Projektets applicationId og minimum-/target-SDK bevares; versionen er `4.3.5` / versionCode `32`.
- Fuld Android-build og praktisk UI-test afventer en GitHub Actions-kørsel og test på en fysisk enhed.
