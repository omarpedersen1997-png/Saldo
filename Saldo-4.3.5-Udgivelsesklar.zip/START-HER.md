# Start her — Saldo 4.3.5

## Brug fra Android-telefon
1. Download `Saldo-4.3.5-Udgivelsesklar.zip` og pak den ud i appen Filer, hvis du vil undersøge projektet lokalt.
2. På GitHub, åbn repositoryet `Saldo`.
3. Upload ZIP-filen `Saldo-4.3.5-Udgivelsesklar.zip` til roden af repositoryet.
4. Upload workflow-filen `build-saldo-4-3-5.yml` til `.github/workflows/build-saldo-4-3-5.yml`.
5. Åbn **Actions**, vælg **Build Saldo 4.3.5**, og tryk på **Run workflow**.
6. Når jobbet er grønt, åbn kørslen og hent artefaktet `Saldo-4.3.5-Android` under **Artifacts**.

## Før udgivelse
- Se efter den nye debug-APK og kontrollér, at `versionName` er `4.3.5`, `versionCode` er `32`, og pakken er `dk.saldo.app`.
- Test CSV-import med en lille bankfil: indtægt, udgift, debet/kredit, ukendt beskrivelse, kategoriforslag og manuel ændring af forslag.
- Test regninger, opsparingsmål, backup/gendannelse, login, logout/konto-skift, privatliv og kontosletning.
- Hvis du vil udgive i Google Play, skal du konfigurere din private upload-keystore og relevante GitHub Secrets og bygge en signeret AAB. Del aldrig din keystore eller adgangskoder.

**Bemærk:** Kildekoden og statiske kontroller er opdateret; den fulde Android-build skal stadig bekræftes i GitHub Actions. En grøn build er nødvendig, men erstatter ikke praktisk test på telefon.
