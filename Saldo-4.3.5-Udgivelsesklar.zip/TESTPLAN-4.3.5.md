# Testplan — Saldo 4.3.5

## Automatiske regressionstests
- [ ] Signerede beløb og specifikke kategorier: løn, dagligvarer, brændstof, forsikring.
- [ ] Debet-/kreditkolonner uden samlet beløbskolonne.
- [ ] Eksplicit retning prioriteres, og tvetydig eller modstridende retning markeres.
- [ ] Ukendt transaktion får lav tillid og review-markering.
- [ ] Brugerrettelse pr. afsender huskes i den aktive konto.
- [ ] Kendte transaktioner og beløbsnærhed bidrager til kategoriforslag.
- [ ] Brugerens egne kategorier genkendes i beskrivelser.
- [ ] CSV med komma-separator og citeret komma i beskrivelse parses.
- [ ] Forhåndsvisning indeholder retning og kategori.
- [ ] Dubletfingerprint ignorerer ID, importmetadata og kategoritekst.
- [ ] Nyttige, specifikke kategorier foreslås for daginstitution og husleje.

## Manuel test på Android
- [ ] Tryk CSV-import, mens filen læses: knappen/feedback viser ventestatus og appen fryser ikke.
- [ ] Importér fil med kendt bankformat, ukendt description og blandede fortegn.
- [ ] Ændr type og kategori i forhåndsvisningen; kontrollér at ændringer vises før import.
- [ ] Importér samme CSV to gange; dubletter springes over uden at genoprette samme poster.
- [ ] Kontrollér at brugerrettelser ikke deles mellem onlinekonti.
- [ ] Kontrollér budgetadvarsler og månedsrapporter efter import.
- [ ] Gennemgå indstillinger på smal skærm og med stor skrift/skærmzoom.
- [ ] Test navigation, tryk, animationer, login/logout og gendannelse.
- [ ] Test på mindst én fysisk Android-enhed samt én anden skærmstørrelse/emulator.

## Kendte begrænsninger
- Kategorisering er regelbaseret. Unikke merchant-navne eller meget korte banktekster kan være tvetydige og skal kontrolleres.
- Fuld Gradle/Android-build er ikke kørt i det lokale miljø; CI skal bekræfte kompilering og JUnit-tests.
