package dk.saldo.app

import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.ln

// Saldo 4.3.5 — smarter CSV categorisation, responsive settings, cached monthly aggregates and smoother updates.
// Observable palette: all components that use these tokens update immediately when the user switches theme.
private const val SALDO_PREFERENCES_NAME = "saldo_data_v4"
private const val SALDO_ENCRYPTED_PREFERENCES_NAME = "saldo_data_v4_encrypted"
private const val SALDO_ENCRYPTION_MIGRATION_MARKER = "_saldo_encrypted_migration_v1"
private const val SALDO_PRIVACY_POLICY_URL = "https://omarpedersen1997-png.github.io/Saldo/privacy/"
private const val SALDO_ACCOUNT_DELETION_URL = "https://omarpedersen1997-png.github.io/Saldo/account-deletion/"
private val saldoPreferencesLock = Any()
@Volatile private var cachedSaldoPreferences: SharedPreferences? = null

/** Encrypted preferences shared by the activity, reminder worker and home-screen widgets. */
fun saldoPreferences(context: Context): SharedPreferences = synchronized(saldoPreferencesLock) {
    cachedSaldoPreferences?.let { return@synchronized it }
    val legacy = context.applicationContext.getSharedPreferences(SALDO_PREFERENCES_NAME, Context.MODE_PRIVATE)
    val masterKey = MasterKey.Builder(context.applicationContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    val encrypted = EncryptedSharedPreferences.create(
        context.applicationContext,
        SALDO_ENCRYPTED_PREFERENCES_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    if (!encrypted.getBoolean(SALDO_ENCRYPTION_MIGRATION_MARKER, false)) {
        val values = legacy.all
        val editor = encrypted.edit()
        values.forEach { (key, value) ->
            if (key != SALDO_ENCRYPTION_MIGRATION_MARKER) {
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
            }
        }
        editor.putBoolean(SALDO_ENCRYPTION_MIGRATION_MARKER, true)
        check(editor.commit()) { "Saldo kunne ikke gemme de krypterede data. De oprindelige data er bevaret." }
    }
    // Do not leave a second, plaintext copy behind after migration or a previously interrupted run.
    if (legacy.all.isNotEmpty()) {
        check(legacy.edit().clear().commit()) { "Saldo kunne ikke rydde den gamle ukrypterede datakopi. Genstart appen, og kontrollér lagerpladsen." }
    }
    cachedSaldoPreferences = encrypted
    encrypted
}

// Navy & gold palette. Initial values are the dark theme; setSaldoPalette() applies the saved choice.
internal var Night by mutableStateOf(Color(0xFF060A1C))
internal var Panel by mutableStateOf(Color(0xFF0E1533))
internal var PanelRaised by mutableStateOf(Color(0xFF18214A))
internal var Violet by mutableStateOf(Color(0xFFF5C66B))
internal var Blue by mutableStateOf(Color(0xFF93A8F4))
internal var Mint by mutableStateOf(Color(0xFF6EE7B7))
internal var Muted by mutableStateOf(Color(0xFFA3ADCF))
internal var White by mutableStateOf(Color(0xFFF3F5FF))
internal var BorderSubtle by mutableStateOf(Color(0x1AFFFFFF))

private fun setSaldoPalette(dark: Boolean) {
    if (dark) {
        Night = Color(0xFF060A1C)
        Panel = Color(0xFF0E1533)
        PanelRaised = Color(0xFF18214A)
        Violet = Color(0xFFF5C66B)
        Blue = Color(0xFF93A8F4)
        Mint = Color(0xFF6EE7B7)
        Muted = Color(0xFFA3ADCF)
        White = Color(0xFFF3F5FF)
        BorderSubtle = Color(0x1AFFFFFF)
    } else {
        Night = Color(0xFFF6F4EE)
        Panel = Color(0xFFFFFFFF)
        PanelRaised = Color(0xFFF2ECDD)
        Violet = Color(0xFF8A5A00)
        Blue = Color(0xFF1E3A8A)
        Mint = Color(0xFF047857)
        Muted = Color(0xFF5E6385)
        White = Color(0xFF0E1533)
        BorderSubtle = Color(0x1A0E1533)
    }
}

private fun saldoBackgroundBrush(dark: Boolean): Brush = if (dark) {
    Brush.verticalGradient(listOf(Color(0xFF16204A), Color(0xFF0B1230), Night, Color(0xFF04060F)))
} else {
    Brush.verticalGradient(listOf(Color(0xFFFBF7EC), Color(0xFFF6F4EE), Color(0xFFF4F4F7), Color(0xFFEEF1F8)))
}

private val homeSectionOptions = listOf(
    Triple("balance", "Rådighedsbeløb", "Saldo, dagligt beløb og næste løn"),
    Triple("quick", "Hurtige handlinger", "Tilføj post, regning og budget"),
    Triple("warnings", "Budgetadvarsler", "Vis budgetter, der nærmer sig grænsen"),
    Triple("summary", "Månedens tal", "Indtægter og udgifter"),
    Triple("cashflow", "Pengestrøm", "Sammenlign månedens indtægter og udgifter"),
    Triple("bills", "Kommende regninger", "Vis de næste ubetalte regninger"),
    Triple("activity", "Seneste aktivitet", "Vis de seneste poster")
)
private val defaultHomeSections = homeSectionOptions.map { it.first }
// NumberFormat is expensive to create and not thread-safe: cache one per thread. money() runs on
// every recomposition and every frame of an animated amount.
private val saldoMoneyFormat = object : ThreadLocal<NumberFormat>() {
    override fun initialValue(): NumberFormat = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { minimumFractionDigits = 2; maximumFractionDigits = 2 }
}
internal fun money(v: Double): String = saldoMoneyFormat.get()!!.format(if (v.isFinite()) v else 0.0) + " kr."
private fun parseDanishAmount(raw: String): Double? {
    val cleaned = raw.trim().replace(" ", "").replace("\u00A0", "").replace("\u202F", "")
    if (cleaned.isBlank()) return null
    val normalized = if (cleaned.contains(',')) cleaned.replace(".", "").replace(',', '.')
        else if (Regex("^-?\\d{1,3}(?:\\.\\d{3})+$").matches(cleaned)) cleaned.replace(".", "")
        else cleaned
    return normalized.toDoubleOrNull()?.takeIf { it.isFinite() && kotlin.math.abs(it) <= 1_000_000_000_000.0 }
}
private fun JSONObject.s(k: String, d: String = "") = optString(k, d).let { if (it == "null") d else it }
private fun JSONObject.n(k: String, d: Double = 0.0) = optDouble(k, d)
private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
private fun record(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }

private val saldoCollectionKeys = listOf("transactions", "bills", "budgets", "goals", "debts", "subs", "fuel")

/** Coalesces widget refreshes and runs RemoteViews work off the UI thread. */
private object SaldoWidgetRefreshQueue {
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "SaldoWidgetRefresh").apply { isDaemon = true }
    }
    @Volatile private var pending: ScheduledFuture<*>? = null

    @Synchronized
    fun request(context: Context) {
        pending?.cancel(false)
        val appContext = context.applicationContext
        pending = executor.schedule({
            runCatching { SaldoWidgetUpdater.updateAll(appContext) }
        }, 120, TimeUnit.MILLISECONDS)
    }
}

private fun emptySaldoData(): JSONObject = JSONObject().apply {
    saldoCollectionKeys.forEach { put(it, JSONArray()) }
}

private fun isEmptySaldoDataObject(data: JSONObject): Boolean = saldoCollectionKeys.all { key ->
    (data.optJSONArray(key)?.length() ?: 0) == 0
}

private fun hasAnySaldoRecords(data: JSONObject): Boolean = saldoCollectionKeys.any { key ->
    (data.optJSONArray(key)?.length() ?: 0) > 0
}

private fun persistSaldoSettingsForActiveAccount(prefs: android.content.SharedPreferences) {
    val userId = prefs.getString("active_account_user_id", null).orEmpty()
    if (userId.isNotBlank()) prefs.edit().putString(localAccountSettingsKey(userId), saldoSettingsJson(prefs).toString()).apply()
}

private fun normalizeSaldoData(source: JSONObject): JSONObject = JSONObject(source.toString()).apply {
    // Older versions did not always include every collection. Missing collections are safe to
    // initialize, but malformed collections are rejected by validation before normalization.
    saldoCollectionKeys.forEach { key -> if (!has(key)) put(key, JSONArray()) }
    listOf("transactions", "bills", "budgets", "subs").forEach { key ->
        optJSONArray(key)?.objects()?.forEach { item ->
            val owner = item.s("owner").trim()
            when {
                owner.equals("Kæreste", ignoreCase = true) -> item.put("owner", "Partner")
                owner.isNotBlank() -> item.put("owner", owner)
            }
        }
    }
    // LazyColumn keys and deletion actions rely on unique IDs. Repair IDs in older/malformed
    // backups once, before the normalized snapshot is persisted, to avoid deleting multiple rows.
    saldoCollectionKeys.forEach { key ->
        val array = optJSONArray(key) ?: return@forEach
        val seenIds = mutableSetOf<String>()
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val existingId = item.s("id").trim()
            if (existingId.isBlank() || !seenIds.add(existingId)) {
                var replacement: String
                do {
                    replacement = "migrated-$key-${java.util.UUID.randomUUID()}"
                } while (!seenIds.add(replacement))
                item.put("id", replacement)
            }
        }
    }
}

private data class LoadedSaldoData(val data: JSONObject, val recoveryNotice: String?)

private fun localAccountDataKey(userId: String) = "saldo_account_data_$userId"
private fun localAccountBackupKey(userId: String) = "saldo_account_backup_$userId"
private fun localAccountSettingsKey(userId: String) = "saldo_account_settings_$userId"

private fun findValidLocalRecoveryData(prefs: android.content.SharedPreferences): JSONObject? {
    val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
    val candidates = buildList {
        if (activeUserId.isNotBlank()) {
            // Once an online account is active, recover only from that account's scoped copies.
            // Never fall back to a legacy global backup that may belong to a different user.
            prefs.getString(localAccountDataKey(activeUserId), null)?.let(::add)
            prefs.getString(localAccountBackupKey(activeUserId), null)?.let(::add)
        } else {
            // Global recovery points are allowed only before any online account is attached.
            prefs.getString("auto_backup_data", null)?.let(::add)
        }
    }
    return candidates.firstNotNullOfOrNull { rawCandidate ->
        val candidate = runCatching { JSONObject(rawCandidate) }.getOrNull() ?: return@firstNotNullOfOrNull null
        candidate.takeIf { isValidSaldoDataObject(it) && hasAnySaldoRecords(it) }
    }
}

/** Load local data without ever turning a parse/validation failure into an unprotected empty overwrite. */
private fun loadSaldoDataSafely(prefs: android.content.SharedPreferences): LoadedSaldoData {
    val raw = prefs.getString("data", null)
    if (raw == null) {
        val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
        val scopedData = activeUserId.takeIf { it.isNotBlank() }
            ?.let { prefs.getString(localAccountDataKey(it), null) }
            ?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (scopedData != null && isValidSaldoDataObject(scopedData) && hasAnySaldoRecords(scopedData)) {
            val restored = normalizeSaldoData(scopedData)
            check(prefs.edit().putString("data", restored.toString()).commit()) {
                "Saldo kunne ikke gemme de gendannede data. Den oprindelige kontokopi er bevaret."
            }
            return LoadedSaldoData(restored, "Saldo gendannede de lokale data fra kontoens gemte kopi. Kontrollér dine poster.")
        }
        // A missing active cache can happen after an interrupted update. Prefer a validated,
        // non-empty recovery point over silently starting with an empty financial overview.
        val recovery = findValidLocalRecoveryData(prefs)
        if (recovery != null) {
            val restored = normalizeSaldoData(recovery)
            check(prefs.edit().putString("data", restored.toString()).commit()) {
                "Saldo kunne ikke gemme de gendannede data. Den oprindelige backup er bevaret."
            }
            return LoadedSaldoData(restored, "Saldo gendannede et lokalt gendannelsespunkt, fordi den aktive datafil manglede. Kontrollér dine poster.")
        }
        return LoadedSaldoData(emptySaldoData(), null)
    }
    val parsed = runCatching { JSONObject(raw) }.getOrNull()
    if (parsed != null && parsed.length() > 0 && isValidSaldoDataObject(parsed)) {
        return LoadedSaldoData(normalizeSaldoData(parsed), null)
    }
    val recoveryCandidate = findValidLocalRecoveryData(prefs)
    if (parsed != null && parsed.length() == 0 && recoveryCandidate == null) {
        // Empty JSON was used by older versions for a fresh install; don't warn on that case.
        return LoadedSaldoData(emptySaldoData(), null)
    }

    // Preserve the damaged input for diagnostics/recovery instead of silently destroying it.
    prefs.edit().putString("corrupt_data_backup", raw).apply()
    if (recoveryCandidate != null) {
        val restored = normalizeSaldoData(recoveryCandidate)
        prefs.edit().putString("data", restored.toString()).apply()
        val message = if (parsed?.length() == 0) {
            "Saldo fandt tomme lokale data, men der var en gyldig backup. Backupen er gendannet; kontrollér dine poster."
        } else {
            "Saldo fandt ugyldige lokale data og gendannede den seneste gyldige lokale kopi. Kontrollér dine poster."
        }
        return LoadedSaldoData(restored, message)
    }
    val empty = emptySaldoData()
    prefs.edit().putString("data", empty.toString()).apply()
    return LoadedSaldoData(empty, "Saldo kunne ikke læse de lokale data. De oprindelige data er bevaret internt som gendannelsesmateriale, og appen er startet med et tomt datasæt. Gendan en kendt backup hurtigst muligt.")
}

/** Keep local data separated when multiple online accounts use the same device. */
private fun switchToAccountData(
    prefs: android.content.SharedPreferences,
    currentData: JSONObject,
    newUserId: String
): JSONObject {
    require(newUserId.isNotBlank()) { "Onlinekontoen kunne ikke identificeres." }
    val oldUserId = prefs.getString("active_account_user_id", null).orEmpty()
    val currentSnapshot = normalizeSaldoData(currentData).toString()
    val editor = prefs.edit()

    if (oldUserId.isNotBlank() && oldUserId != newUserId) {
        // Every regular data/settings change already updates the scoped snapshot. After logout,
        // the shared active cache is intentionally empty; never copy that empty cache over the
        // previous account's real snapshot or settings during the next account's login.
        val hasSavedProfileSnapshot = prefs.contains(localAccountDataKey(oldUserId))
        val shouldCommitCurrentData = hasAnySaldoRecords(currentData) || !hasSavedProfileSnapshot
        if (shouldCommitCurrentData) {
            editor.putString(localAccountDataKey(oldUserId), currentSnapshot)
                .putString(localAccountSettingsKey(oldUserId), saldoSettingsJson(prefs).toString())
        } else if (!prefs.contains(localAccountSettingsKey(oldUserId))) {
            editor.putString(localAccountSettingsKey(oldUserId), saldoSettingsJson(prefs).toString())
        }
        prefs.getString("auto_backup_data", null)?.let { editor.putString(localAccountBackupKey(oldUserId), it) }
    }

    val switchingToDifferentAccount = oldUserId.isNotBlank() && oldUserId != newUserId
    val candidateRaw = prefs.getString(localAccountDataKey(newUserId), null)
    val candidate = candidateRaw?.let { runCatching { JSONObject(it) }.getOrNull() }
    val selected = when {
        switchingToDifferentAccount && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        switchingToDifferentAccount -> emptySaldoData()
        oldUserId.isBlank() && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        oldUserId == newUserId && isEmptySaldoDataObject(currentData) && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        else -> normalizeSaldoData(currentData)
    }
    val selectedSnapshot = selected.toString()
    editor.putString("active_account_user_id", newUserId)
        .putString("data", selectedSnapshot)
        .putString(localAccountDataKey(newUserId), selectedSnapshot)

    val settingsRaw = prefs.getString(localAccountSettingsKey(newUserId), null)
    val savedSettings = settingsRaw?.let { runCatching { JSONObject(it) }.getOrNull() }
    if (switchingToDifferentAccount) {
        // Reset settings first so malformed/missing settings from the next account
        // can never inherit the previous account's salary, payday, or cash balance.
        editor.putFloat("pay_amount", 10000f).remove("payday").remove("cash_balance")
        if (savedSettings != null) applySaldoSettings(savedSettings, editor)
    } else if (savedSettings != null && ((oldUserId.isBlank() && candidate != null && isValidSaldoDataObject(candidate)) ||
            (oldUserId == newUserId && isEmptySaldoDataObject(currentData) && candidate != null && isValidSaldoDataObject(candidate)))) {
        applySaldoSettings(savedSettings, editor)
    } else {
        editor.putString(localAccountSettingsKey(newUserId), saldoSettingsJson(prefs).toString())
    }

    val backupRaw = prefs.getString(localAccountBackupKey(newUserId), null)
    if (switchingToDifferentAccount) {
        if (backupRaw == null) editor.remove("auto_backup_data") else editor.putString("auto_backup_data", backupRaw)
    } else if (((oldUserId.isBlank() || (oldUserId == newUserId && isEmptySaldoDataObject(currentData))) && candidate != null && isValidSaldoDataObject(candidate)) && backupRaw != null) {
        editor.putString("auto_backup_data", backupRaw)
    } else {
        val existingBackup = prefs.getString("auto_backup_data", null)
        if (existingBackup != null) editor.putString(localAccountBackupKey(newUserId), existingBackup)
    }
    editor.putLong("auto_backup_time", System.currentTimeMillis()).apply()
    return selected
}

class MainActivity : FragmentActivity() {
    private val passwordRecoveryToken = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15/16 edge-to-edge: draw backgrounds behind transparent system bars,
        // while each screen applies safe insets to keep interactive content clear.
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        saldoPreferences(this).let { designPrefs ->
            if (!designPrefs.getBoolean("design_2026_dark_applied", false)) {
                designPrefs.edit().putBoolean("dark_mode", true).putBoolean("design_2026_dark_applied", true).apply()
            }
        }
        setSaldoPalette(saldoPreferences(this).getBoolean("dark_mode", true))
        val initialDarkMode = saldoPreferences(this).getBoolean("dark_mode", true)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !initialDarkMode
            isAppearanceLightNavigationBars = !initialDarkMode
        }
        handlePasswordRecoveryIntent(intent)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("saldo-bill-reminders", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<BillReminderWorker>(24, TimeUnit.HOURS).build())
        setContent { SaldoApp(passwordRecoveryToken.value) { passwordRecoveryToken.value = null } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePasswordRecoveryIntent(intent)
    }

    private fun handlePasswordRecoveryIntent(source: Intent?) {
        val uri = source?.data
        val fragmentValues = uri?.fragment?.let { Uri.parse("https://saldo-recovery.invalid/?$it") }
        val type = uri?.getQueryParameter("type") ?: fragmentValues?.getQueryParameter("type")
        val token = uri?.getQueryParameter("access_token") ?: fragmentValues?.getQueryParameter("access_token")
        val prefs = saldoPreferences(this)
        if (type == "recovery" && !token.isNullOrBlank()) {
            prefs.edit().putString("password_recovery_token", token).apply()
            // Do not retain the access token inside the activity's original deep-link Intent.
            setIntent(Intent(this, MainActivity::class.java))
        }
        passwordRecoveryToken.value = prefs.getString("password_recovery_token", null)
    }
}

private val mainTabs = listOf("Overblik", "Poster", "Regninger", "Budget", "Mere")
private val moreTabs = listOf("Økonomitjek", "Opsparing", "Gæld", "Bil", "Abonnementer", "Kalender", "Prognoser", "Hvad nu hvis?", "Rapporter", "Indstillinger")

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable private fun SaldoApp(passwordRecoveryToken: String? = null, onRecoveryComplete: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { saldoPreferences(context) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var visibleHomeSections by remember {
        mutableStateOf(prefs.getString("home_visible_sections", defaultHomeSections.joinToString("|"))
            .orEmpty().split("|").filter { item -> defaultHomeSections.contains(item) }.ifEmpty { defaultHomeSections })
    }
    fun updateHomeSection(section: String, enabled: Boolean) {
        val updated = if (enabled) (visibleHomeSections + section).distinct() else visibleHomeSections.filterNot { it == section }
        visibleHomeSections = updated
        prefs.edit().putString("home_visible_sections", updated.joinToString("|")).apply()
    }
    LaunchedEffect(darkMode) {
        setSaldoPalette(darkMode)
        prefs.edit().putBoolean("dark_mode", darkMode).apply()
        (context as? android.app.Activity)?.window?.let { appWindow ->
            WindowInsetsControllerCompat(appWindow, appWindow.decorView).apply {
                isAppearanceLightStatusBars = !darkMode
                isAppearanceLightNavigationBars = !darkMode
            }
        }
        SaldoWidgetRefreshQueue.request(context)
    }
    val initialDataLoad = remember { loadSaldoDataSafely(prefs) }
    var data by remember { mutableStateOf(initialDataLoad.data) }
    var dataRecoveryNotice by remember { mutableStateOf(initialDataLoad.recoveryNotice) }
    val csvCategoryContext = remember(data) { buildCsvCategoryContext(data, prefs) }
    LaunchedEffect(Unit) {
        SaldoWidgetRefreshQueue.request(context)
        val snapshot = data.toString()
        val editor = prefs.edit().putString("data", snapshot)
        if (!prefs.contains("auto_backup_data")) editor.putString("auto_backup_data", snapshot).putLong("auto_backup_time", System.currentTimeMillis())
        val activeUserId = prefs.getString("active_account_user_id", null)
        if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), snapshot)
        editor.apply()
        dataRecoveryNotice?.let { message ->
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            dataRecoveryNotice = null
        }
    }
    fun list(key: String) = data.optJSONArray(key) ?: JSONArray()
    fun store(key: String, arr: JSONArray) {
        data.put(key, arr)
        val snapshot = data.toString()
        // Preserve the previously committed data as the recovery point before replacing it.
        val previousSnapshot = prefs.getString("data", "{}") ?: "{}"
        val editor = prefs.edit().putString("data", snapshot)
        val activeUserId = prefs.getString("active_account_user_id", null)
        if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), snapshot)
        if (previousSnapshot != snapshot) {
            editor.putString("auto_backup_data", previousSnapshot)
                .putLong("auto_backup_time", System.currentTimeMillis())
            if (!activeUserId.isNullOrBlank()) editor.putString(localAccountBackupKey(activeUserId), previousSnapshot)
        } else if (!prefs.contains("auto_backup_data")) {
            editor.putString("auto_backup_data", previousSnapshot)
                .putLong("auto_backup_time", System.currentTimeMillis())
        }
        editor.apply()
        data = JSONObject(snapshot)
        SaldoWidgetRefreshQueue.request(context)
    }
    fun add(key: String, obj: JSONObject) { val arr = list(key); arr.put(obj); store(key, arr) }
    fun delete(key: String, id: String) { val arr = JSONArray(); list(key).objects().filterNot { it.s("id") == id }.forEach { arr.put(it) }; store(key, arr) }
    var tab by remember { mutableStateOf("Overblik") }
    var dialog by remember { mutableStateOf("") }
    var transactionSearch by remember { mutableStateOf("") }
    var transactionTypeFilter by remember { mutableStateOf("Alle") }
    var pin by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginConfirm by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loginMode by remember { mutableStateOf(false) }
    var loginStep by remember { mutableStateOf(0) }
    // Old sessions without an account binding must re-authenticate once after this update.
    var accountUnlocked by remember { mutableStateOf(
        prefs.getString("online_access_token", null) != null && prefs.getString("active_account_user_id", null) != null
    ) }
    var loginLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var pendingCsvImport by remember { mutableStateOf<CsvImportPlan?>(null) }
    var csvImportBusy by remember { mutableStateOf(false) }
    var csvImportError by remember { mutableStateOf("") }
    var multiBillProcessing by remember { mutableStateOf(false) }
    var multiBillDrafts by remember { mutableStateOf<List<BillImportDraft>>(emptyList()) }
    var showMultiBillDialog by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<JSONObject?>(null) }
    var saveSuccess by remember { mutableStateOf<String?>(null) }

    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            csvImportBusy = true
            csvImportError = ""
            // Snapshot local categories, merchant history and previous corrections before doing IO.
            val categoryContext = csvCategoryContext
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val raw = readTextFromUri(context, uri, 10 * 1024 * 1024)
                        parseSaldoCsv(raw, categoryContext)
                    }
                }
                csvImportBusy = false
                result.onSuccess { plan -> pendingCsvImport = plan }
                    .onFailure { error ->
                        csvImportError = error.message ?: "CSV-filen kunne ikke læses."
                        Toast.makeText(context, csvImportError, Toast.LENGTH_LONG).show()
                    }
            }
        }
    }

    val multiBillPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            multiBillProcessing = true
            scope.launch {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val drafts = mutableListOf<BillImportDraft>()
                try {
                    uris.take(20).forEachIndexed { index, uri ->
                        val result = runCatching {
                            val image = withContext(Dispatchers.IO) { InputImage.fromFilePath(context, uri) }
                            recognizer.process(image).saldoAwait().text
                        }
                        result.onSuccess { text ->
                            val parsed = parseBillText(text)
                            drafts += BillImportDraft(
                                id = "multi-${System.currentTimeMillis()}-$index",
                                name = parsed.first,
                                amount = parsed.second,
                                date = parsed.third,
                                selected = parsed.first.isNotBlank() || parsed.second.isNotBlank() || parsed.third.isNotBlank(),
                                rawText = text.take(420)
                            )
                        }.onFailure { error ->
                            drafts += BillImportDraft(
                                id = "multi-${System.currentTimeMillis()}-$index",
                                name = "",
                                amount = "",
                                date = "",
                                selected = false,
                                rawText = "Kunne ikke læse dette billede: ${error.message ?: "ukendt fejl"}"
                            )
                        }
                    }
                } finally {
                    recognizer.close()
                }
                multiBillDrafts = drafts
                if (uris.size > 20) Toast.makeText(context, "Der blev valgt ${uris.size} billeder. De første 20 er læst; importér resten bagefter.", Toast.LENGTH_LONG).show()
                showMultiBillDialog = drafts.isNotEmpty()
                multiBillProcessing = false
                if (drafts.isEmpty()) Toast.makeText(context, "Ingen billeder kunne importeres.", Toast.LENGTH_LONG).show()
            }
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            scheduleDueBillNotification(context, list("bills").objects())
            scheduleBudgetWarningNotification(context, data)
            scheduleSubscriptionRenewalNotification(context, data)
        }
        else Toast.makeText(context, "Notifikationer er slået fra. Aktivér dem i Android-indstillinger.", Toast.LENGTH_LONG).show()
    }
    var cloudStatus by remember { mutableStateOf("Ikke synkroniseret") }
    var cloudBusy by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deleteAccountBusy by remember { mutableStateOf(false) }
    var deleteAccountError by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(prefs.getString("pin_hash", null) == null && prefs.getString("pin", null) == null && !prefs.getBoolean("biometric_enabled", false)) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(180); splash = false }
    val today = LocalDate.now()
    // Cache derived lists by the immutable data snapshot. This avoids re-filtering and
    // re-sorting every transaction/bill on unrelated UI recompositions.
    val tx = remember(data) { list("transactions").objects() }
    val bills = remember(data) { list("bills").objects() }
    // Parse dates once per data snapshot. Monthly dashboards and reports share this index.
    val transactionsByMonth = remember(tx) {
        tx.mapNotNull { item ->
            runCatching { YearMonth.from(LocalDate.parse(item.s("date"))) }.getOrNull()?.let { month -> month to item }
        }.groupBy({ it.first }, { it.second })
    }
    val thisMonthTx = remember(transactionsByMonth, today) { transactionsByMonth[YearMonth.from(today)].orEmpty() }
    val monthSpendByCategoryOwner = remember(thisMonthTx) {
        thisMonthTx.asSequence()
            .filter { it.s("type") == "Udgift" }
            .groupBy { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }
            .mapValues { (_, rows) -> rows.sumOf { it.n("amount") } }
    }
    val income = remember(tx) { tx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") } }
    val expenses = remember(tx) { tx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") } }
    val monthIncome = remember(thisMonthTx) { thisMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") } }
    val monthExpenses = remember(thisMonthTx) { thisMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") } }
    val unpaidBills = remember(bills) { bills.filter { !it.optBoolean("paid", false) } }
    val unpaid = remember(unpaidBills) { unpaidBills.sumOf { it.n("amount") } }
    val payday = runCatching { LocalDate.parse(prefs.getString("payday", today.toString())) }.getOrElse { today }
    val payAmount = prefs.getFloat("pay_amount", 10000f).toDouble()
    val daysToPay = ChronoUnit.DAYS.between(today, payday).toInt().let { ((it % 14) + 14) % 14 }
    val daysUntilNextPay = if (daysToPay == 0) 14 else daysToPay
    val payPeriodEnd = today.plusDays(daysUntilNextPay.toLong())
    val billsDueBeforePayday = remember(bills, today, payPeriodEnd) { bills.filter { bill ->
        !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due ->
            !due.isBefore(today) && !due.isAfter(payPeriodEnd)
        } == true
    }.sumOf { it.n("amount") } }
    val hasCurrentBalance = prefs.contains("cash_balance")
    val currentBalance = prefs.getFloat("cash_balance", 0f).toDouble()
    val estimatedAvailableToPayday = if (hasCurrentBalance) currentBalance - billsDueBeforePayday else monthIncome - monthExpenses - billsDueBeforePayday
    val dailyAllowance = estimatedAvailableToPayday / daysUntilNextPay.coerceAtLeast(1)
    val backupTimestamp = prefs.getLong("auto_backup_time", 0L)
    val backupDescription = if (backupTimestamp > 0L) {
        "Forrige datatilstand · ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("da", "DK")).format(java.util.Date(backupTimestamp))}"
    } else "Der er endnu ikke oprettet et gendannelsespunkt."
    LaunchedEffect(Unit) {
        val existing = (data.optJSONArray("bills") ?: JSONArray()).objects()
        val today = LocalDate.now()
        val knownOccurrences = existing.map { billOccurrenceKey(it) }.toMutableSet()
        val additions = existing.filter { it.optBoolean("paid", false) && isRecurringRepeat(it.s("repeat")) }.mapNotNull { bill ->
            val oldDate = runCatching { LocalDate.parse(bill.s("date")) }.getOrNull() ?: return@mapNotNull null
            val anchorDay = bill.optInt("recurrenceDay", oldDate.dayOfMonth).coerceIn(1, 31)
            val next = nextRecurringOccurrence(oldDate, today, bill.s("repeat"), anchorDay) ?: return@mapNotNull null
            val newBill = JSONObject(bill.toString()).put("id", "rec-${bill.s("id")}-${next}").put("date", next.toString()).put("recurrenceDay", anchorDay).put("paid", false)
            if (knownOccurrences.add(billOccurrenceKey(newBill))) newBill else null
        }
        if (additions.isNotEmpty()) { val arr = JSONArray(); (existing + additions).forEach { arr.put(it) }; store("bills", arr) }
    }
    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(
            primary = Violet,
            onPrimary = Color(0xFF0E1533),
            secondary = Mint,
            onSecondary = Color(0xFF082A1D),
            tertiary = Blue,
            background = Night,
            surface = Panel,
            surfaceVariant = PanelRaised,
            onSurface = White,
            onBackground = White,
            outline = BorderSubtle
        ) else lightColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            secondary = Mint,
            onSecondary = Color.White,
            tertiary = Blue,
            background = Night,
            surface = Panel,
            surfaceVariant = PanelRaised,
            onSurface = White,
            onBackground = White,
            outline = BorderSubtle
        ),
        typography = saldoTypography(),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(26.dp)
        )
    ) {
        if (!passwordRecoveryToken.isNullOrBlank()) {
            var newPassword by remember { mutableStateOf("") }
            var confirmNewPassword by remember { mutableStateOf("") }
            var recoveryError by remember { mutableStateOf("") }
            Box(
                Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode))
                    .statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.Center
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(76.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Nulstil adgangskode", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("Vælg en ny adgangskode til din Saldo-konto.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    Surface(color = Panel.copy(alpha = .98f), shape = RoundedCornerShape(26.dp), border = saldoCardBorder(), shadowElevation = 10.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Field("Ny adgangskode (mindst 8 tegn)", newPassword, { newPassword = it; recoveryError = "" }, password = true)
                            Field("Gentag ny adgangskode", confirmNewPassword, { confirmNewPassword = it; recoveryError = "" }, password = true)
                            if (recoveryError.isNotBlank()) Text(recoveryError, color = SaldoDanger, fontSize = 12.sp)
                            Button(
                                onClick = {
                                    when {
                                        newPassword.length < 8 -> recoveryError = "Adgangskoden skal være mindst 8 tegn."
                                        newPassword != confirmNewPassword -> recoveryError = "Adgangskoderne er ikke ens."
                                        else -> {
                                            loginLoading = true
                                            recoveryError = ""
                                            scope.launch {
                                                val result = withContext(Dispatchers.IO) { runCatching { supabaseUpdatePassword(passwordRecoveryToken, newPassword) } }
                                                loginLoading = false
                                                result.onSuccess {
                                                    prefs.edit().remove("password_recovery_token").remove("online_access_token").remove("online_refresh_token").apply()
                                                    accountUnlocked = false
                                                    loginStep = 0
                                                    loginPassword = ""
                                                    newPassword = ""
                                                    confirmNewPassword = ""
                                                    onRecoveryComplete()
                                                    Toast.makeText(context, "Adgangskoden er ændret. Log ind med din nye adgangskode.", Toast.LENGTH_LONG).show()
                                                }.onFailure {
                                                    recoveryError = "Linket kan være udløbet. Bed om en ny nulstillingsmail, og prøv igen."
                                                }
                                            }
                                        }
                                    }
                                },
                                enabled = !loginLoading,
                                modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color(0xFF0E1533), disabledContainerColor = Color.Transparent, disabledContentColor = Color(0xFF0E1533).copy(alpha = .55f)),
                                shape = RoundedCornerShape(17.dp)
                            ) { Text(if (loginLoading) "Opdaterer…" else "Gem ny adgangskode", fontWeight = FontWeight.Bold) }
                            TextButton(onClick = {
                                prefs.edit().remove("password_recovery_token").apply()
                                onRecoveryComplete()
                            }, enabled = !loginLoading, modifier = Modifier.fillMaxWidth()) {
                                Text("Tilbage til login", color = Violet, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        } else if (splash) {
            Box(Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(145.dp))
                    Spacer(Modifier.height(22.dp)); Text("SALDO", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = 4.sp)
                    Spacer(Modifier.height(7.dp)); Text("Dit overblik. Din økonomi.", color = Muted)
                    Spacer(Modifier.height(35.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf(Violet, Blue, Mint).forEach { Box(Modifier.size(6.dp).background(it, RoundedCornerShape(50))) } }
                }
            }
        } else if (!accountUnlocked) {
            Box(
                Modifier.fillMaxSize().background(
                    saldoBackgroundBrush(darkMode)
                ).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.size(78.dp),
                        contentAlignment = Alignment.Center
                    ) { Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(76.dp)) }
                    Spacer(Modifier.height(17.dp))
                    Text("SALDO", color = White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Din økonomi.\nDit overblik.", color = White, fontSize = 31.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(9.dp))
                    Text("En enklere vej til økonomisk ro.", color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(27.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Panel.copy(alpha = 0.97f),
                        shape = RoundedCornerShape(28.dp),
                        border = saldoCardBorder(),
                        shadowElevation = 10.dp
                    ) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Two-step sign-in: email first, then a horizontal page transition to password.
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                repeat(2) { index ->
                                    Box(
                                        Modifier
                                            .padding(horizontal = 4.dp)
                                            .width(if (loginStep == index) 25.dp else 7.dp)
                                            .height(7.dp)
                                            .background(if (loginStep == index) Violet else PanelRaised, RoundedCornerShape(50))
                                    )
                                }
                            }
                            AnimatedContent(
                                targetState = loginStep,
                                transitionSpec = {
                                    if (targetState > initialState) {
                                        (slideInHorizontally(tween(320)) { it } + fadeIn(tween(220))) togetherWith
                                            (slideOutHorizontally(tween(320)) { -it } + fadeOut(tween(160)))
                                    } else {
                                        (slideInHorizontally(tween(320)) { -it } + fadeIn(tween(220))) togetherWith
                                            (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(160)))
                                    }
                                },
                                label = "login-two-step"
                            ) { step ->
                                Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                                    if (step == 0) {
                                        Text("TRIN 1 AF 2", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                                        Text(if (loginMode) "Hvad er din e-mail?" else "Velkommen tilbage", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (loginMode) "Vi starter med din e-mail og gør resten klar på næste side."
                                            else "Skriv din e-mail, så gør vi klar til dit personlige overblik.",
                                            color = Muted, fontSize = 13.sp
                                        )
                                        Field("E-mailadresse", loginEmail, {
                                            if (loginEmail.trim().lowercase(Locale.ROOT) != it.trim().lowercase(Locale.ROOT)) {
                                                loginPassword = ""
                                                loginConfirm = ""
                                            }
                                            loginEmail = it
                                            loginError = ""
                                        }, email = true)
                                        if (loginError.isNotBlank()) Text(loginError, color = SaldoDanger, fontSize = 12.sp)
                                        Button(
                                            onClick = {
                                                val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                if (email.contains("@") && email.substringAfter("@").contains(".") && !email.endsWith(".")) {
                                                    loginEmail = email
                                                    loginError = ""
                                                    loginStep = 1
                                                } else {
                                                    loginError = "Indtast en gyldig e-mailadresse."
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color(0xFF0E1533), disabledContainerColor = Color.Transparent, disabledContentColor = Color(0xFF0E1533).copy(alpha = .55f)),
                                            shape = RoundedCornerShape(17.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                                Text("Fortsæt", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.width(8.dp))
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    } else {
                                        Text("TRIN 2 AF 2", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                                        Text(if (loginMode) "Vælg en adgangskode" else "Din adgangskode", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                        Text(if (loginMode) "Opret en sikker adgangskode på mindst 8 tegn." else "Indtast adgangskoden til din Saldo-konto.", color = Muted, fontSize = 13.sp)
                                        Surface(
                                            color = PanelRaised,
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                                            ) {
                                                Icon(Icons.Default.Email, contentDescription = null, tint = Violet, modifier = Modifier.size(18.dp))
                                                Text(loginEmail, color = White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                                TextButton(onClick = { loginStep = 0; loginError = ""; loginPassword = ""; loginConfirm = "" }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                                                    Text("Ret", color = Violet, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                        Field("Adgangskode", loginPassword, { loginPassword = it; loginError = "" }, password = true)
                                        if (loginMode) Field("Gentag adgangskode", loginConfirm, { loginConfirm = it; loginError = "" }, password = true)
                                        if (loginError.isNotBlank()) Text(loginError, color = SaldoDanger, fontSize = 12.sp)
                                        Button(
                                            onClick = {
                                                val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                when {
                                                    BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_ANON_KEY.isBlank() -> loginError = "Online-login er ikke tilgængeligt i denne version af appen."
                                                    loginPassword.isBlank() -> loginError = "Indtast din adgangskode."
                                                    loginMode && loginPassword.length < 8 -> loginError = "Ved oprettelse skal adgangskoden være mindst 8 tegn."
                                                    loginMode && loginPassword != loginConfirm -> loginError = "Adgangskoderne er ikke ens."
                                                    else -> {
                                                        loginLoading = true
                                                        loginError = ""
                                                        scope.launch {
                                                            val result = withContext(Dispatchers.IO) {
                                                                runCatching {
                                                                    supabaseAuth(email, loginPassword, loginMode).apply {
                                                                        val sessionToken = optString("access_token")
                                                                        if (sessionToken.isNotBlank()) put("_saldoUserId", currentCloudUserId(sessionToken))
                                                                    }
                                                                }
                                                            }
                                                            loginLoading = false
                                                            result.onSuccess { response ->
                                                                val token = response.optString("access_token")
                                                                if (loginMode && token.isBlank()) {
                                                                    loginError = "Kontoen er oprettet. Tjek din e-mail for bekræftelse, og log derefter ind."
                                                                    loginMode = false
                                                                    loginStep = 0
                                                                    loginPassword = ""
                                                                    loginConfirm = ""
                                                                } else if (token.isBlank()) {
                                                                    loginError = "Serveren returnerede ingen login-session."
                                                                } else {
                                                                    val userId = response.optString("_saldoUserId")
                                                                    if (userId.isBlank()) {
                                                                        loginError = "Login lykkedes ikke helt, fordi kontoen ikke kunne identificeres sikkert. Prøv igen."
                                                                    } else {
                                                                        data = switchToAccountData(prefs, data, userId)
                                                                        prefs.edit().putString("online_access_token", token).putString("online_refresh_token", response.optString("refresh_token")).putString("account_email", email).apply()
                                                                        SaldoWidgetRefreshQueue.request(context)
                                                                        // Release credential strings from Compose state after a successful login.
                                                                        loginPassword = ""
                                                                        loginConfirm = ""
                                                                        loginError = ""
                                                                        unlocked = prefs.getString("pin_hash", null) == null &&
                                                                            prefs.getString("pin", null) == null &&
                                                                            !prefs.getBoolean("biometric_enabled", false)
                                                                        accountUnlocked = true
                                                                    }
                                                                }
                                                            }.onFailure { e -> loginError = e.message ?: "Kunne ikke oprette forbindelse. Kontrollér internet og konto." }
                                                        }
                                                    }
                                                }
                                            },
                                            enabled = !loginLoading,
                                            modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color(0xFF0E1533), disabledContainerColor = Color.Transparent, disabledContentColor = Color(0xFF0E1533).copy(alpha = .55f)),
                                            shape = RoundedCornerShape(17.dp)
                                        ) {
                                            Text(
                                                if (loginLoading) "Forbinder…" else if (loginMode) "Opret konto" else "Log sikkert ind",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        if (!loginMode) {
                                            TextButton(
                                                onClick = {
                                                    val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                    when {
                                                        email.isBlank() || !email.contains("@") || !email.substringAfter("@").contains(".") -> loginError = "Indtast din e-mail på første side først."
                                                        BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_ANON_KEY.isBlank() -> loginError = "Online-login er ikke konfigureret endnu."
                                                        else -> {
                                                            loginLoading = true
                                                            loginError = ""
                                                            scope.launch {
                                                                val result = withContext(Dispatchers.IO) { runCatching { supabasePasswordRecovery(email) } }
                                                                loginLoading = false
                                                                result.onSuccess {
                                                                    Toast.makeText(context, "Hvis e-mailadressen er tilknyttet en konto, modtager du en nulstillingsmail.", Toast.LENGTH_LONG).show()
                                                                }.onFailure {
                                                                    loginError = "Kunne ikke sende nulstillingsmail. Kontrollér internetforbindelsen og Supabase-opsætningen."
                                                                }
                                                            }
                                                        }
                                                    }
                                                },
                                                enabled = !loginLoading,
                                                modifier = Modifier.fillMaxWidth()
                                            ) { Text("Glemt adgangskode?", color = Violet, fontWeight = FontWeight.SemiBold) }
                                        }
                                        TextButton(
                                            onClick = { loginStep = 0; loginError = ""; loginPassword = ""; loginConfirm = "" },
                                            enabled = !loginLoading,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Tilbage til e-mail", color = Violet, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = BorderSubtle)
                            TextButton(
                                onClick = {
                                    loginMode = !loginMode
                                    loginStep = 0
                                    loginError = ""
                                    loginPassword = ""
                                    loginConfirm = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (loginMode) "Har du allerede en konto? Log ind" else "Ny hos Saldo? Opret en konto", color = Violet, fontWeight = FontWeight.SemiBold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Mint, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Din adgangskode gemmes ikke på telefonen", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Violet, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Privat · Sikkert · Dit overblik", color = Muted, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { openSaldoExternalPage(context, SALDO_PRIVACY_POLICY_URL) }) {
                            Text("Privatlivspolitik", color = Muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { openSaldoExternalPage(context, SALDO_ACCOUNT_DELETION_URL) }) {
                            Text("Slet konto", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        } else if (!unlocked) {
            Column(Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode)).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(36.dp))
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(90.dp))
                Spacer(Modifier.height(18.dp))
                Text("Saldo er låst", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.5).sp)
                Spacer(Modifier.height(6.dp))
                Text("Bekræft at det er dig for at se dit overblik.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), contentPadding = PaddingValues(22.dp)) {
                Field("PIN-kode", pin, { pin = it }, numeric = true, password = true)
                Button(modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color(0xFF0E1533), disabledContainerColor = Color.Transparent, disabledContentColor = Color(0xFF0E1533).copy(alpha = .55f)), shape = RoundedCornerShape(17.dp), onClick = {
                    val now = System.currentTimeMillis()
                    val lockedUntil = prefs.getLong("pin_locked_until", 0L)
                    if (lockedUntil > now) {
                        val seconds = ((lockedUntil - now + 999) / 1000).coerceAtLeast(1)
                        Toast.makeText(context, "For mange forsøg. Prøv igen om $seconds sek.", Toast.LENGTH_LONG).show()
                    } else if (verifyAndUpgradePin(prefs, pin)) {
                        prefs.edit().remove("pin_failed_attempts").remove("pin_locked_until").apply()
                        unlocked = true
                    } else {
                        pin = ""
                        val attempts = prefs.getInt("pin_failed_attempts", 0) + 1
                        if (attempts >= 5) {
                            prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_locked_until", now + 30_000L).apply()
                            Toast.makeText(context, "Fem forkerte forsøg. PIN-oplåsning er sat på pause i 30 sekunder.", Toast.LENGTH_LONG).show()
                        } else {
                            prefs.edit().putInt("pin_failed_attempts", attempts).apply()
                            Toast.makeText(context, "Forkert PIN-kode. Forsøg ${attempts} af 5.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Icon(Icons.Default.Lock, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Lås op med PIN", fontWeight = FontWeight.Bold) }
                if (prefs.getBoolean("biometric_enabled", false)) FilledTonalButton(onClick = { val activity = context as? FragmentActivity; if (activity != null) startBiometric(activity, context) { unlocked = true } }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Violet)) { Icon(Icons.Default.Fingerprint, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text("Lås op med fingeraftryk", fontWeight = FontWeight.SemiBold) }
                }
            }
        } else {
            val navTab = if (tab in mainTabs) tab else "Mere"
            androidx.activity.compose.BackHandler(enabled = tab != "Overblik") {
                tab = if (tab in moreTabs) "Mere" else "Overblik"
            }
            Scaffold(modifier = Modifier.background(saldoBackgroundBrush(darkMode)), containerColor = Color.Transparent, bottomBar = {
                SaldoBottomBar(
                    items = mainTabs.map { t ->
                        when (t) {
                            "Overblik" -> SaldoNavItem(t, Icons.Outlined.OutlinedHome, Icons.Default.Home)
                            "Poster" -> SaldoNavItem(t, Icons.AutoMirrored.Outlined.OutlinedReceiptLong, Icons.AutoMirrored.Filled.ReceiptLong)
                            "Regninger" -> SaldoNavItem(t, Icons.Outlined.OutlinedCalendarMonth, Icons.Default.CalendarMonth)
                            "Budget" -> SaldoNavItem(t, Icons.Outlined.OutlinedPieChart, Icons.Default.PieChart)
                            else -> SaldoNavItem(t, Icons.Outlined.OutlinedGridView, Icons.Default.GridView)
                        }
                    },
                    selectedKey = navTab,
                    onSelect = { selected -> tab = selected }
                )
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).wrapContentWidth(Alignment.CenterHorizontally).widthIn(max = 760.dp).padding(horizontal = 20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = tab in moreTabs,
                            enter = fadeIn(tween(SaldoMotion.MEDIUM)) + androidx.compose.animation.expandHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)),
                            exit = fadeOut(tween(SaldoMotion.SHORT)) + androidx.compose.animation.shrinkHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(onClick = { tab = "Mere" }, shape = RoundedCornerShape(14.dp), color = Panel, border = saldoCardBorder(), modifier = Modifier.size(44.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Tilbage til Mere", tint = White, modifier = Modifier.size(20.dp)) }
                                }
                                Spacer(Modifier.width(10.dp))
                            }
                        }
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(44.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text("SALDO", color = Violet, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.5.sp)
                            AnimatedContent(
                                targetState = tab,
                                transitionSpec = {
                                    (fadeIn(tween(SaldoMotion.MEDIUM)) + androidx.compose.animation.slideInVertically(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { it / 2 }) togetherWith
                                        (fadeOut(tween(SaldoMotion.SHORT)) + androidx.compose.animation.slideOutVertically(tween(SaldoMotion.SHORT)) { -it / 2 })
                                },
                                label = "Saldo-title"
                            ) { title ->
                                Text(title, color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            }
                        }
                        val accountInitial = prefs.getString("account_email", "").orEmpty().trim().firstOrNull()?.uppercaseChar()?.toString() ?: "S"
                        Surface(onClick = { tab = "Indstillinger" }, shape = RoundedCornerShape(50), color = PanelRaised, border = saldoCardBorder(), modifier = Modifier.size(42.dp)) {
                            Box(contentAlignment = Alignment.Center) { Text(accountInitial, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                        }
                        Spacer(Modifier.width(10.dp))
                        val addSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                        val addScale by rememberPressScale(addSource, .9f)
                        Surface(onClick = { dialog = "post" }, interactionSource = addSource, shape = RoundedCornerShape(16.dp), color = Color.Transparent, shadowElevation = 8.dp, modifier = Modifier.size(46.dp).graphicsLayer { scaleX = addScale; scaleY = addScale }) {
                            Box(Modifier.fillMaxSize().background(saldoBrandBrush()), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Add, "Tilføj post", tint = Color(0xFF0E1533), modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                    fun tabOrder(t: String): Int = mainTabs.indexOf(t).takeIf { it >= 0 } ?: (mainTabs.size + moreTabs.indexOf(t))
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            val direction = if (tabOrder(targetState) >= tabOrder(initialState)) 1 else -1
                            (fadeIn(tween(SaldoMotion.MEDIUM, delayMillis = 40)) + slideInHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { direction * it / 8 } +
                                androidx.compose.animation.scaleIn(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized), initialScale = .985f)) togetherWith
                                (fadeOut(tween(SaldoMotion.SHORT)) + slideOutHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { -direction * it / 10 })
                        },
                        label = "Saldo-tab-transition"
                    ) { activeTab ->
                    when (activeTab) {
                        "Overblik" -> LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                            contentPadding = PaddingValues(bottom = 22.dp)
                        ) {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(saldoGreeting(), color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.6).sp)
                                    Text(saldoDayLabel(LocalDate.now().toString(), LocalDate.now().minusDays(7)) + " · dit økonomiske overblik", color = Muted, fontSize = 12.sp)
                                }
                            }
                            if ("balance" in visibleHomeSections) item {
                                val available = estimatedAvailableToPayday
                                val spendRatio = if (monthIncome > 0) (monthExpenses / monthIncome).toFloat().coerceIn(0f, 1f) else 0f
                                val animatedSpend by animateFloatAsState(spendRatio, animationSpec = tween(900, easing = FastOutSlowInEasing), label = "hero-spend")
                                Surface(
                                    shape = RoundedCornerShape(26.dp),
                                    color = Color.Transparent,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(Modifier.background(saldoHeroBrush()).drawBehind {
                                        drawCircle(Brush.radialGradient(listOf(Color(0x2EF5C66B), Color.Transparent), center = Offset(size.width * .92f, 0f), radius = size.width * .65f), radius = size.width * .65f, center = Offset(size.width * .92f, 0f))
                                        drawCircle(Brush.radialGradient(listOf(Color(0x2293A8F4), Color.Transparent), center = Offset(0f, size.height), radius = size.width * .55f), radius = size.width * .55f, center = Offset(0f, size.height))
                                    }) {
                                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(color = Color.White.copy(alpha = .13f), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) {
                                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountBalanceWallet, null, tint = Color(0xFFFDE7B0), modifier = Modifier.size(22.dp)) }
                                                }
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    Text("RÅDIGHEDSBELØB", color = Color.White.copy(alpha = .78f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.35.sp)
                                                    Text(if (hasCurrentBalance) "Saldo nu minus regninger før løn" else "Estimat fra månedens poster og regninger før løn", color = Color(0xFFD5DAEE), fontSize = 10.sp)
                                                }
                                                Surface(color = if (available >= 0) Color(0x263CE0B0) else Color(0x26FF7798), shape = RoundedCornerShape(50)) {
                                                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                                        Box(Modifier.size(6.dp).background(if (available >= 0) Mint else Color(0xFFFFA8BA), RoundedCornerShape(50)))
                                                        Text(if (available >= 0) "På sporet" else "Underskud", color = if (available >= 0) Color(0xFFB9F7DE) else Color(0xFFFFA8BA), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                                    }
                                                }
                                            }
                                            AnimatedMoney(available, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.25).sp)
                                            val heroTrend = remember(transactionsByMonth) {
                                                (0..5).map { offset ->
                                                    val month = YearMonth.from(LocalDate.now()).minusMonths((5 - offset).toLong())
                                                    transactionsByMonth[month].orEmpty().sumOf { if (it.s("type") == "Indtægt") it.n("amount") else -it.n("amount") }
                                                }
                                            }
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                SaldoSparkline(heroTrend, Modifier.fillMaxWidth().height(48.dp))
                                                Text("Netto pr. måned · seneste 6 måneder", color = Color.White.copy(alpha = .62f), fontSize = 10.sp, letterSpacing = .3.sp)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("FORBRUG AF INDTÆGTER", color = Color(0xFFD5DAEE), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .6.sp)
                                                    Text("${(spendRatio * 100).toInt()}% brugt", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(58.dp)) {
                                                    CircularProgressIndicator(progress = { animatedSpend }, modifier = Modifier.fillMaxSize(), color = Color(0xFFFDE7B0), trackColor = Color.White.copy(alpha = .12f), strokeWidth = 5.dp)
                                                    Icon(if (spendRatio < .8f) Icons.Default.TrendingUp else Icons.Default.TrendingDown, null, tint = if (spendRatio < .8f) Mint else Color(0xFFFFC078), modifier = Modifier.size(20.dp))
                                                }
                                            }
                                            SaldoProgressBar(spendRatio, height = 9.dp, colors = listOf(Color(0xFFFDE7B0), Color(0xFFA9F2D4)), track = Color.White.copy(alpha = .10f))
                                            Surface(color = Color.White.copy(alpha = .10f), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                                                Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Speed, null, tint = if (dailyAllowance >= 0) Color(0xFFA9F2D4) else Color(0xFFFFA8BA), modifier = Modifier.size(18.dp))
                                                    Spacer(Modifier.width(8.dp))
                                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                        Text("TIL RÅDIGHED PR. DAG", color = Color(0xFFD5DAEE), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
                                                        Text(
                                                            if (daysToPay == 0) "Ny lønperiode · ca. 14 dage" else "Næste løn om ca. $daysUntilNextPay dage",
                                                            color = Color.White.copy(alpha = .85f),
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                    AnimatedMoney(dailyAllowance, color = if (dailyAllowance >= 0) Color(0xFFA9F2D4) else Color(0xFFFFA8BA), fontSize = 13.sp)
                                                }
                                            }
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("NÆSTE LØN", color = Color(0xFFD5DAEE), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .5.sp)
                                                    Text(if (daysToPay == 0) "I dag" else "Om $daysToPay dage", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text("LØN PR. GANG", color = Color(0xFFD5DAEE), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = .5.sp)
                                                    Text(money(payAmount), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if ("balance" in visibleHomeSections) item {
                                val topCategory = remember(thisMonthTx) {
                                    thisMonthTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }
                                        .mapValues { entry -> entry.value.sumOf { it.n("amount") } }.maxByOrNull { it.value }
                                }
                                val billsBeforePayCount = remember(bills, today, payPeriodEnd) {
                                    bills.count { bill ->
                                        !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due -> !due.isBefore(today) && !due.isAfter(payPeriodEnd) } == true
                                    }
                                }
                                val overdueCount = remember(bills, today) {
                                    bills.count { bill -> !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.isBefore(today) == true }
                                }
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (overdueCount > 0) SaldoInsightChip(Icons.Default.WarningAmber, "$overdueCount forfaldne regninger", SaldoDanger) { tab = "Regninger" }
                                    if (monthIncome > 0) SaldoInsightChip(Icons.Default.DonutLarge, "${((monthExpenses / monthIncome) * 100).toInt()} % af indtægten brugt") { tab = "Budget" }
                                    if (billsBeforePayCount > 0) SaldoInsightChip(Icons.Default.Event, "$billsBeforePayCount ${if (billsBeforePayCount == 1) "regning" else "regninger"} før løn · ${money(billsDueBeforePayday)}") { tab = "Regninger" }
                                    else SaldoInsightChip(Icons.Default.CheckCircle, "Ingen regninger før næste løn", Mint) { tab = "Regninger" }
                                    topCategory?.let { (category, total) -> SaldoInsightChip(Icons.Default.Insights, "Største udgift: $category · ${money(total)}") { tab = "Rapporter" } }
                                }
                            }
                            if ("quick" in visibleHomeSections) item {
                                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                                    QuickAction("Ny post", Icons.Default.AddCircle, { dialog = "post" }, Modifier.weight(1f))
                                    QuickAction("Regning", Icons.AutoMirrored.Filled.ReceiptLong, { dialog = "bill" }, Modifier.weight(1f))
                                    QuickAction("Scan", Icons.Default.DocumentScanner, { dialog = "ocr" }, Modifier.weight(1f))
                                    QuickAction("Budget", Icons.Default.Tune, { tab = "Budget" }, Modifier.weight(1f))
                                }
                            }
                            if ("warnings" in visibleHomeSections) item {
                                val budgetChecks = list("budgets").objects().map { budget ->
                                    val spendKey = "${budget.s("category").trim().lowercase(Locale.ROOT)}|${budget.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"
                                    val spentForBudget = monthSpendByCategoryOwner[spendKey] ?: 0.0
                                    Triple(budget.s("category"), budget.n("limit"), spentForBudget)
                                }
                                val criticalBudgets = budgetChecks.filter { it.second > 0 && it.third >= it.second * .8 }
                                if (criticalBudgets.isNotEmpty()) {
                                    Surface(onClick = { tab = "Budget" }, color = if (darkMode) Color(0x22FF6B8B) else Color(0xFFFFF1F0), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (darkMode) Color(0x55FF6B8B) else Color(0xFFFFD8D5)), modifier = Modifier.fillMaxWidth().animateContentSize()) {
                                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.NotificationsActive, null, tint = if (darkMode) SaldoDanger else Color(0xFFB93848), modifier = Modifier.size(19.dp))
                                                Spacer(Modifier.width(7.dp))
                                                Text("Budgetadvarsel", color = if (darkMode) Color(0xFFFFC2CF) else Color(0xFF842C39), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                            criticalBudgets.take(3).forEach { (category, limit, spent) ->
                                                Text("$category: ${if (spent >= limit) "overskredet med ${money(spent - limit)}" else "${money(limit - spent)} tilbage"}", color = if (darkMode) Color(0xFFFFC2CF) else Color(0xFF842C39), fontSize = 11.sp)
                                            }
                                            Text("Tryk for at se alle budgetter", color = if (darkMode) Color(0xFFE7A3B3) else Color(0xFF9B5260), fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                            if ("summary" in visibleHomeSections) item {
                                SaldoSectionHeader("Denne måned", LocalDate.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() } + " ${LocalDate.now().year} · indtil nu", "Rapporter") { tab = "Rapporter" }
                            }
                            if ("summary" in visibleHomeSections) item {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        DashboardMetric("Indtægter", money(monthIncome), Icons.Default.ArrowDownward, Mint, Modifier.weight(1f), amount = monthIncome)
                                        DashboardMetric("Udgifter", money(monthExpenses), Icons.Default.ArrowUpward, Violet, Modifier.weight(1f), amount = monthExpenses)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        DashboardMetric("Ubetalt", money(unpaid), Icons.Default.Schedule, SaldoWarning, Modifier.weight(1f), amount = unpaid)
                                        DashboardMetric("Pr. dag", money(dailyAllowance), Icons.Default.Speed, Blue, Modifier.weight(1f), amount = dailyAllowance)
                                    }
                                }
                            }
                            if ("cashflow" in visibleHomeSections) item { MonthlyFlowCard(monthIncome = monthIncome, monthExpenses = monthExpenses) }
                            if ("bills" in visibleHomeSections) item {
                                SaldoSectionHeader("Kommende regninger", "Det næste, der skal betales", "Se alle") { tab = "Regninger" }
                            }
                            if ("bills" in visibleHomeSections && unpaidBills.isEmpty()) item {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Mint.copy(alpha = .12f), shape = RoundedCornerShape(14.dp), modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, null, tint = Mint) } }
                                        Spacer(Modifier.width(12.dp))
                                        Column { Text("Alt er betalt", color = White, fontWeight = FontWeight.SemiBold); Text("Du har ingen ubetalte regninger lige nu.", color = Muted, fontSize = 11.sp) }
                                    }
                                }
                            }
                            if ("bills" in visibleHomeSections) items(unpaidBills.sortedBy { it.s("date") }.take(3), key = { "home-bill-${it.s("id")}" }) { b ->
                                UpcomingBillCard(b.s("name"), b.s("date"), money(b.n("amount")), Modifier.animateItem()) { updatePaid(bills, b, ::store) }
                            }
                            if ("activity" in visibleHomeSections) item {
                                SaldoSectionHeader("Seneste aktivitet", "Dine senest registrerede poster", "Alle poster") { tab = "Poster" }
                            }
                            if ("activity" in visibleHomeSections) items(tx.sortedByDescending { it.s("date") }.take(4), key = { "recent-${it.s("id")}" }) { x ->
                                RecordRow(x.s("name"), "${saldoDayLabel(x.s("date"))} · ${x.s("category")} · ${x.s("owner", "Mig")}", signedMoney(x.n("amount"), x.s("type") == "Indtægt"), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }, modifier = Modifier.animateItem())
                            }
                        }
                        "Poster" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Ind", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        AnimatedMoney(monthIncome, color = Mint, fontSize = 14.sp)
                                    }
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Ud", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        AnimatedMoney(monthExpenses, color = White, fontSize = 14.sp)
                                    }
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Netto i måneden", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        AnimatedMoney(monthIncome - monthExpenses, color = if (monthIncome >= monthExpenses) Mint else SaldoDanger, fontSize = 14.sp, format = ::netMoney)
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = transactionSearch,
                                onValueChange = { transactionSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Søg efter navn, kategori eller dato") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = BorderSubtle, focusedLabelColor = Violet, unfocusedLabelColor = Muted)
                            )
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Alle", "Indtægt", "Udgift").forEach { filter ->
                                    FilterChip(selected = transactionTypeFilter == filter, onClick = { transactionTypeFilter = filter }, label = { Text(filter) }, leadingIcon = if (transactionTypeFilter == filter) ({ Icon(Icons.Default.Check, null, modifier = Modifier.size(16.dp)) }) else null)
                                }
                            }
                            val filteredTransactions = remember(tx, transactionTypeFilter, transactionSearch) { tx.filter { (transactionTypeFilter == "Alle" || it.s("type") == transactionTypeFilter) && (transactionSearch.isBlank() || listOf(it.s("name"), it.s("category"), it.s("date"), it.s("owner"), it.s("type")).any { field -> field.contains(transactionSearch, true) }) }.sortedByDescending { it.s("date") } }
                            if (filteredTransactions.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(28.dp))
                                        Text("Ingen poster fundet", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Prøv en anden søgning eller opret en ny post.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            } else {
                                val transactionsByDay = remember(filteredTransactions) { filteredTransactions.sortedByDescending { it.s("date") }.groupBy { it.s("date") } }
                                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                    transactionsByDay.forEach { (day, rows) ->
                                        val dayNet = rows.sumOf { if (it.s("type") == "Indtægt") it.n("amount") else -it.n("amount") }
                                        stickyHeader(key = "day-header-$day") {
                                            SaldoGroupHeader(saldoDayLabel(day), netMoney(dayNet), if (dayNet >= 0) Mint else Violet)
                                        }
                                        items(rows, key = { it.s("id") }) { x ->
                                            RecordRow(x.s("name"), "${x.s("category")} · ${x.s("owner", "Mig")}", signedMoney(x.n("amount"), x.s("type") == "Indtægt"), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }, modifier = Modifier.animateItem())
                                        }
                                    }
                                }
                            }
                        }
                        "Regninger" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            val (overdueBills, upcomingBills, settledBills) = remember(bills, today) {
                                val (overdue, upcoming) = bills.filter { !it.optBoolean("paid", false) }
                                    .partition { bill -> runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.isBefore(today) == true }
                                Triple(overdue.sortedBy { it.s("date") }, upcoming.sortedBy { it.s("date") }, bills.filter { it.optBoolean("paid", false) }.sortedByDescending { it.s("date") })
                            }
                            Surface(color = Color.Transparent, shape = RoundedCornerShape(24.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.background(if (darkMode) saldoHeroBrush() else Brush.linearGradient(listOf(Color(0xFFFFF4DC), Color(0xFFF3F5FF)))).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text("UBETALT I ALT", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                            AnimatedMoney(unpaid, color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.7).sp)
                                        }
                                        Surface(onClick = { dialog = "bill" }, color = Violet.copy(alpha = .18f), shape = RoundedCornerShape(50)) {
                                            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Add, null, tint = Violet, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Ny regning", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }
                                    Text("${overdueBills.size} forfaldne · ${upcomingBills.size} kommende · ${settledBills.size} betalt", color = Muted, fontSize = 11.sp)
                                    SaldoProgressBar(if (bills.isEmpty()) 0f else settledBills.size.toFloat() / bills.size, height = 9.dp, colors = listOf(Mint, Blue), track = Mint.copy(alpha = .14f))
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilledTonalButton(onClick = { dialog = "ocr" }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Violet)) { Icon(Icons.Default.DocumentScanner, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Scan én", fontSize = 10.sp, maxLines = 1) }
                                FilledTonalButton(onClick = { multiBillPicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f), enabled = !multiBillProcessing, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 10.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Violet)) { Icon(Icons.Default.DocumentScanner, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(if (multiBillProcessing) "Læser…" else "Scan flere", fontSize = 10.sp, maxLines = 1) }
                                FilledTonalButton(onClick = { tab = "Kalender" }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = Panel, contentColor = Blue)) { Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Kalender", fontSize = 10.sp, maxLines = 1) }
                            }
                            if (multiBillProcessing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Violet)
                            Text("Du kan vælge op til 20 billeder ad gangen. Kontrollér altid OCR-beløb og datoer før gemning.", color = Muted, fontSize = 11.sp)
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                if (bills.isEmpty()) item {
                                    SaldoCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                            SaldoIconTile(Icons.AutoMirrored.Filled.ReceiptLong, Violet)
                                            Text("Ingen regninger endnu", color = White, fontWeight = FontWeight.SemiBold)
                                            Text("Tilføj en regning eller scan et billede af den.", color = Muted, fontSize = 11.sp)
                                        }
                                    }
                                }
                                listOf(
                                    Triple("Forfaldne", overdueBills, SaldoDanger),
                                    Triple("Kommende", upcomingBills, Violet),
                                    Triple("Betalt", settledBills, Mint)
                                ).filter { it.second.isNotEmpty() }.forEach { (groupTitle, groupBills, accent) ->
                                    stickyHeader(key = "bill-group-$groupTitle") {
                                        SaldoGroupHeader("$groupTitle · ${groupBills.size}", money(groupBills.sumOf { it.n("amount") }), accent)
                                    }
                                    items(groupBills, key = { it.s("id") }) { b ->
                                        RecordRow(b.s("name"), "${saldoDayLabel(b.s("date"))} · ${b.s("repeat", "Engangsbetaling")}", money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }, modifier = Modifier.animateItem())
                                    }
                                }
                            }
                        }
                        "Budget" -> Column(Modifier.fillMaxSize()) {
                            var editingBudget by remember { mutableStateOf<JSONObject?>(null) }
                            var deletingBudget by remember { mutableStateOf<JSONObject?>(null) }
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Dine budgetter", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                                    Text("${LocalDate.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() }} · registreret forbrug", color = Muted, fontSize = 11.sp)
                                }
                                FilledTonalButton(onClick = { dialog = "budget" }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Nyt budget")
                                }
                            }
                            val budgetItems = list("budgets").objects()
                            // A legacy backup might contain duplicate owner/category rows. Count one
                            // effective monthly limit per owner/category so totals remain meaningful.
                            val effectiveBudgetItems = budgetItems.groupBy {
                                "${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}|${it.s("category").trim().lowercase(Locale.ROOT)}"
                            }.values.map { group -> group.maxBy { it.n("limit") } }
                            val totalLimit = effectiveBudgetItems.sumOf { it.n("limit") }
                            val currentMonthSpendingByOwner = remember(monthSpendByCategoryOwner) {
                                monthSpendByCategoryOwner.entries.groupBy { entry -> entry.key.substringAfter('|') }
                                    .mapValues { (_, entries) -> entries.sumOf { it.value } }
                            }
                            // Each transaction must count once in the aggregate, even if an old backup
                            // contains duplicate budget rows for the same owner/category.
                            val budgetKeys = effectiveBudgetItems.map {
                                "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"
                            }.toSet()
                            val totalSpent = budgetKeys.sumOf { monthSpendByCategoryOwner[it] ?: 0.0 }
                            val totalUsedRatio = if (totalLimit > 0) (totalSpent / totalLimit).coerceAtLeast(0.0) else 0.0
                            val totalRatio = totalUsedRatio.toFloat().coerceIn(0f, 1f) // Progress bars are capped; the label below is not.
                            val totalUsedPercent = (totalUsedRatio * 100.0).toInt()
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                OwnerSummaryCard("Mig", currentMonthSpendingByOwner["mig"] ?: 0.0, Modifier.weight(1f), Violet)
                                OwnerSummaryCard("Partner", currentMonthSpendingByOwner["partner"] ?: 0.0, Modifier.weight(1f), Blue)
                                OwnerSummaryCard("Fælles", currentMonthSpendingByOwner["fælles"] ?: 0.0, Modifier.weight(1f), Mint)
                            }
                            Surface(color = Color.Transparent, shape = RoundedCornerShape(24.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                                Column(Modifier.background(if (darkMode) saldoHeroBrush() else Brush.linearGradient(listOf(Color(0xFFFFF4DC), Color(0xFFF3F5FF)))).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("SAMLET BUDGETSTATUS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            val totalRemaining = totalLimit - totalSpent
                                            AnimatedMoney(kotlin.math.abs(totalRemaining), color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.7).sp)
                                            Text(if (totalRemaining < 0) "overskredet med ${money(kotlin.math.abs(totalRemaining))}" else "tilbage af ${money(totalLimit)}", color = if (totalRemaining < 0) SaldoDanger else Muted, fontSize = 11.sp)
                                        }
                                        Text("${totalUsedPercent}% brugt", color = if (totalUsedRatio >= 1.0) SaldoDanger else Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    SaldoProgressBar(totalRatio, height = 11.dp, colors = if (totalUsedRatio >= 1.0) listOf(SaldoDanger, SaldoWarning) else listOf(Violet, Blue, Mint), track = Violet.copy(alpha = .16f))
                                }
                            }
                            if (effectiveBudgetItems.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Tune, null, tint = Violet, modifier = Modifier.size(32.dp))
                                        Text("Lav dit første budget", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Sæt en månedlig grænse for en kategori, og følg forbruget her.", color = Muted, fontSize = 12.sp)
                                        FilledTonalButton(onClick = { dialog = "budget" }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) { Text("Opret budget") }
                                    }
                                }
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                    items(effectiveBudgetItems, key = { it.s("id") }) { b ->
                                        val spent = monthSpendByCategoryOwner["${b.s("category").trim().lowercase(Locale.ROOT)}|${b.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"] ?: 0.0
                                        val limit = b.n("limit")
                                        val ratio = if (limit > 0) (spent / limit).toFloat().coerceAtLeast(0f) else 0f
                                        val over = ratio >= 1f
                                        SaldoCard(Modifier.fillMaxWidth().animateItem(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(16.dp)) {
                                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    SaldoIconTile(Icons.Default.PieChart, if (over) SaldoDanger else Violet, size = 40.dp, iconSize = 20.dp)
                                                    Spacer(Modifier.width(11.dp))
                                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                        Text(b.s("category"), color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                                        Text(b.s("owner", "Husstand"), color = Muted, fontSize = 10.sp)
                                                    }
                                                    Surface(color = if (over) Color(0x16E54865) else Mint.copy(alpha = .10f), shape = RoundedCornerShape(9.dp)) {
                                                        Text(if (over) "Overskredet" else "${((1f - ratio.coerceIn(0f, 1f)) * 100).toInt()}% tilbage", color = if (over) SaldoDanger else Mint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                                                    }
                                                    IconButton(onClick = { editingBudget = JSONObject(b.toString()) }, modifier = Modifier.size(30.dp)) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Rediger budget", tint = Blue, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(onClick = { deletingBudget = JSONObject(b.toString()) }, modifier = Modifier.size(30.dp)) {
                                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Slet budget", tint = SaldoDanger, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                Row(verticalAlignment = Alignment.Bottom) {
                                                    AnimatedMoney(spent, color = White, fontSize = 20.sp, letterSpacing = (-.4).sp)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text("af ${money(limit)}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                                                }
                                                SaldoProgressBar(ratio, height = 10.dp, colors = if (over) listOf(SaldoDanger, SaldoWarning) else if (ratio >= .8f) listOf(Violet, SaldoWarning) else listOf(Violet, Blue))
                                                Text(if (over) "Budget overskredet med ${money(spent - limit)}" else "Tilbage: ${money(limit - spent)}", color = if (over) SaldoDanger else Muted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                            editingBudget?.let { target ->
                                BudgetEditDialog(
                                    budget = target,
                                    onDismiss = { editingBudget = null },
                                    onSave = { updated ->
                                        val budgetId = target.s("id").trim()
                                        val newCategory = updated.s("category").trim()
                                        val newOwner = updated.s("owner", "Mig").trim()
                                        val duplicateElsewhere = list("budgets").objects().any { item ->
                                            item.s("id") != budgetId &&
                                                item.s("category").trim().equals(newCategory, true) &&
                                                item.s("owner", "Mig").trim().equals(newOwner, true)
                                        }
                                        if (budgetId.isBlank()) {
                                            Toast.makeText(context, "Budgettet mangler et sikkert ID. Luk og åbn budgettet igen, og prøv derefter.", Toast.LENGTH_LONG).show()
                                        } else if (duplicateElsewhere) {
                                            Toast.makeText(context, "Der findes allerede et budget for den valgte kategori og ejer.", Toast.LENGTH_LONG).show()
                                        } else {
                                            val updatedBudgets = JSONArray()
                                            var replaced = false
                                            list("budgets").objects().forEach { item ->
                                                if (item.s("id") == budgetId && !replaced) {
                                                    updatedBudgets.put(JSONObject(updated.toString()).put("id", budgetId))
                                                    replaced = true
                                                } else updatedBudgets.put(item)
                                            }
                                            if (replaced) {
                                                store("budgets", updatedBudgets)
                                                editingBudget = null
                                                saveSuccess = "Budgettet er opdateret"
                                            } else {
                                                Toast.makeText(context, "Budgettet blev ændret et andet sted. Åbn det igen, før du gemmer.", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            }
                            deletingBudget?.let { target ->
                                AlertDialog(
                                    onDismissRequest = { deletingBudget = null },
                                    title = { Text("Slet budget?") },
                                    text = { Text("Budgettet for ${target.s("category")} (${target.s("owner", "Mig")}) slettes. Dette sletter ikke dine registrerede poster.") },
                                    confirmButton = {
                                        TextButton(onClick = {
                                            val budgetId = target.s("id").trim()
                                            if (budgetId.isBlank()) {
                                                Toast.makeText(context, "Budgettet mangler et ID og blev ikke slettet.", Toast.LENGTH_LONG).show()
                                            } else {
                                                val updatedBudgets = JSONArray()
                                                list("budgets").objects().filterNot { it.s("id") == budgetId }.forEach { updatedBudgets.put(it) }
                                                store("budgets", updatedBudgets)
                                            }
                                            deletingBudget = null
                                        }) { Text("Slet", color = SaldoDanger) }
                                    },
                                    dismissButton = { TextButton(onClick = { deletingBudget = null }) { Text("Annuller") } }
                                )
                            }
                        }
                        "Mere" -> androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                            columns = androidx.compose.foundation.lazy.grid.GridCells.Adaptive(150.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 18.dp)
                        ) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                Column(Modifier.padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Flere værktøjer", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                                    Text("Alt det ekstra til at holde styr på økonomien.", color = Muted, fontSize = 12.sp)
                                }
                            }
                            items(moreTabs) { t ->
                                val icon = when (t) {
                                    "Opsparing" -> Icons.Default.AccountBalanceWallet
                                    "Gæld" -> Icons.Default.AccountBalance
                                    "Bil" -> Icons.Default.DirectionsCar
                                    "Abonnementer" -> Icons.Default.Sync
                                    "Kalender" -> Icons.Default.CalendarMonth
                                    "Prognoser" -> Icons.AutoMirrored.Filled.TrendingUp
                                    "Hvad nu hvis?" -> Icons.Default.Science
                                    "Rapporter" -> Icons.Default.Insights
                                    "Økonomitjek" -> Icons.AutoMirrored.Filled.FactCheck
                                    else -> Icons.Default.Settings
                                }
                                val subtitle = when (t) {
                                    "Opsparing" -> "Følg dine mål og fremskridt"
                                    "Gæld" -> "Restgæld, renter og afdrag"
                                    "Bil" -> "Tankninger og brændstofforbrug"
                                    "Abonnementer" -> "Faste betalinger og årlige omkostninger"
                                    "Kalender" -> "Se regninger efter forfaldsdato"
                                    "Prognoser" -> "Et estimat for de kommende måneder"
                                    "Hvad nu hvis?" -> "Afprøv ekstra forbrug og opsparing"
                                    "Rapporter" -> "Opsummeringer og eksport af data"
                                    "Økonomitjek" -> "Find forfaldne regninger, budgetoverskridelser og mulige dubletter"
                                    else -> "Sikkerhed, backup og onlinekonto"
                                }
                                SaldoCard(Modifier.fillMaxWidth().heightIn(min = 148.dp), onClick = { tab = t }, shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.Top) {
                                        SaldoIconTile(icon, if (t == "Indstillinger") Blue else if (t == "Økonomitjek") Mint else Violet, size = 46.dp, iconSize = 22.dp)
                                        Spacer(Modifier.weight(1f))
                                        Icon(Icons.Default.NorthEast, null, tint = Muted, modifier = Modifier.size(18.dp))
                                    }
                                    Text(t, color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text(subtitle, color = Muted, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 3)
                                }
                            }
                        }
                        "Opsparing" -> ManagedList("Opsparingsmål", list("goals").objects(), { dialog = "goal" }, { g -> RecordRow(g.s("name"), "Mål ${money(g.n("target"))} · ${g.s("date").ifBlank { "Ingen måldato" }}", "Sparet ${money(g.n("saved"))}", true, { delete("goals", g.s("id")) }, onEdit = { editingGoal = JSONObject(g.toString()) }) })
                        "Gæld" -> { val debts = list("debts").objects(); Column(Modifier.fillMaxSize()) { Metric("Samlet restgæld", money(debts.sumOf { it.n("balance") }), Modifier.fillMaxWidth(), positive = false); Metric("Samlede månedlige afdrag", money(debts.sumOf { it.n("payment") }), Modifier.fillMaxWidth()); val monthlyInterest = debts.sumOf { it.n("balance") * it.n("rate") / 1200.0 }; Metric("Anslåede renter pr. måned", money(monthlyInterest), Modifier.fillMaxWidth(), positive = false); ManagedList("Gæld og afdragsplan", debts, { dialog = "debt" }) { d -> val balance = d.n("balance"); val payment = d.n("payment"); val rate = d.n("rate") / 1200.0; val months = if (payment <= balance * rate || payment <= 0) null else if (rate > 0) ceil(ln(payment / (payment - balance * rate)) / ln(1 + rate)).toInt() else ceil(balance / payment).toInt(); RecordRow(d.s("name"), "Rente ${d.n("rate")}% · ${months?.let { "$it mdr. tilbage" } ?: "Afdrag dækker ikke renten"}", money(balance), false, { delete("debts", d.s("id")) }) } } }
                        "Bil" -> { val fuel = list("fuel").objects().sortedBy { it.n("km") }; val totalLiters = fuel.sumOf { it.n("liters") }; val totalCost = fuel.sumOf { it.n("cost") }; val kmSpan = if (fuel.size >= 2) fuel.last().n("km") - fuel.first().n("km") else 0.0; val consumption = if (kmSpan > 0) (totalLiters - fuel.first().n("liters")) * 100 / kmSpan else 0.0; Column(Modifier.fillMaxSize()) { Text("Brændstof og biløkonomi", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Metric("Samlet brændstof", String.format(Locale("da", "DK"), "%.1f liter", totalLiters), Modifier.weight(1f)); Metric("Samlet pris", money(totalCost), Modifier.weight(1f), positive = false) }; Metric("Gennemsnitligt forbrug", if (consumption > 0) String.format(Locale("da", "DK"), "%.1f l/100 km", consumption) else "Registrér mindst 2 tankninger med km-stand", Modifier.fillMaxWidth()); Text("Beregningen bruger forskellen mellem laveste og højeste registrerede kilometertal. Registrér km-stand ved hver tankning.", color = Muted, fontSize = 11.sp); ManagedList("Tankninger", fuel, { dialog = "fuel" }) { f -> val pricePerLiter = if (f.n("liters") > 0) f.n("cost") / f.n("liters") else 0.0; RecordRow(f.s("date"), "${f.n("liters")} liter · ${f.n("km")} km · ${money(pricePerLiter)}/liter", money(f.n("cost")), true, { delete("fuel", f.s("id")) }) } } }
                        "Abonnementer" -> {
                            val subscriptions = list("subs").objects().filter { it.optBoolean("active", true) }
                            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Metric("Abonnementer pr. måned", money(subscriptions.sumOf { it.n("monthly") }), Modifier.fillMaxWidth())
                                Metric("Abonnementer pr. år", money(subscriptions.sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth())
                                Text("Fornyelsesdato og opsigelsesnote vises på hvert abonnement, hvis du har indtastet dem.", color = Muted, fontSize = 11.sp)
                                ManagedList("Abonnementer", subscriptions, { dialog = "sub" }) { sub ->
                                    val renewal = sub.s("renewalDate").takeIf { it.isNotBlank() }?.let { "Fornyes $it" } ?: "Fornyelsesdato ikke angivet"
                                    val cancelBy = sub.s("cancelByDate").takeIf { it.isNotBlank() }?.let { " · Opsig senest $it" }.orEmpty()
                                    val note = sub.s("cancelNote").takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
                                    RecordRow(sub.s("name"), "$renewal$cancelBy$note · Årligt ${money(sub.n("monthly") * 12)}", "${money(sub.n("monthly"))}/md.", false, { delete("subs", sub.s("id")) })
                                }
                            }
                        }
                        "Kalender" -> LazyColumn { item { Text("Regningskalender", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("date"), b.s("name"), money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }, modifier = Modifier.animateItem()) } }
                        "Prognoser" -> {
                            val monthlyIncome = (prefs.getFloat("pay_amount", 10000f).toDouble() * 26.0 / 12.0)
                            val cutoff = LocalDate.now().minusDays(90)
                            val recentExpenses = tx.filter { it.s("type") == "Udgift" && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(cutoff) } == true }.sumOf { it.n("amount") }
                            val monthlyExpenses = recentExpenses / 3.0
                            val unpaidDueSoon = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(90)) } == true }.sumOf { it.n("amount") }
                            val netMonthly = monthlyIncome - monthlyExpenses
                            val forecastItems = listOf(30 to 1.0, 60 to 2.0, 90 to 3.0)
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Økonomisk prognose", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("Et vejledende estimat baseret på din lønindstilling, registrerede udgifter og ubetalte regninger.", color = Muted, fontSize = 12.sp)
                                Metric("Forventet løn pr. måned", money(monthlyIncome), Modifier.fillMaxWidth(), positive = true)
                                Metric("Gennemsnitlige månedlige udgifter (seneste 90 dage)", money(monthlyExpenses), Modifier.fillMaxWidth(), positive = false)
                                Metric("Ubetalte regninger med forfald inden 90 dage", money(unpaidDueSoon), Modifier.fillMaxWidth(), positive = false)
                                forecastItems.forEach { (days, months) ->
                                    val dueInPeriod = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(days.toLong())) } == true }.sumOf { it.n("amount") }
                                    val projection = netMonthly * months - dueInPeriod
                                    SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            SaldoIconTile(if (projection >= 0) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown, if (projection >= 0) Mint else SaldoDanger, size = 40.dp, iconSize = 20.dp)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) { Text("Næste $days dage", color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp); Text("Forventet ændring i saldo", color = Muted, fontSize = 12.sp) }
                                            AnimatedMoney(projection, color = if (projection >= 0) Mint else SaldoDanger, fontSize = 16.sp, format = ::netMoney)
                                        }
                                    }
                                }
                                Text("Bemærk: Prognosen er et estimat, ikke en bankbalance. Den bruger lønindstillingen, gennemsnittet af registrerede udgifter de seneste 90 dage og ubetalte regninger med forfald i perioden. Manglende poster gør prognosen mindre præcis.", color = Muted, fontSize = 11.sp)
                            }
                        }
                        "Hvad nu hvis?" -> {
                            var extraSpend by remember { mutableFloatStateOf(500f) }
                            var monthlySave by remember { mutableFloatStateOf(1000f) }
                            val today = LocalDate.now()
                            val recentExpenses = tx.filter { it.s("type") == "Udgift" && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(today.minusDays(90)) && !d.isAfter(today) } == true }.sumOf { it.n("amount") } / 3.0
                            val recurringSubscriptions = list("subs").objects().sumOf { it.n("monthly") }
                            val debtPayments = list("debts").objects().sumOf { it.n("payment") }
                            val estimatedMonthlyIncome = payAmount * 26.0 / 12.0
                            val estimatedBaseline = estimatedMonthlyIncome - recentExpenses - recurringSubscriptions - debtPayments
                            val scenarioMonthlyRemainder = estimatedBaseline - extraSpend.toDouble() - monthlySave.toDouble()
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Hvad nu hvis?", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("Prøv ændringer af uden at ændre dine rigtige budgetdata.", color = Muted, fontSize = 12.sp)
                                Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ShoppingCart, null, tint = Violet); Spacer(Modifier.width(8.dp)); Text("Ekstra forbrug pr. måned", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(money(extraSpend.toDouble()), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                        Slider(value = extraSpend, onValueChange = { extraSpend = it }, valueRange = 0f..5000f, steps = 19)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("0 kr.", color = Muted, fontSize = 10.sp); Text("5.000 kr.", color = Muted, fontSize = 10.sp) }
                                        HorizontalDivider(color = BorderSubtle)
                                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Savings, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text("Ekstra opsparing pr. måned", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(money(monthlySave.toDouble()), color = Mint, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                        Slider(value = monthlySave, onValueChange = { monthlySave = it }, valueRange = 0f..5000f, steps = 19)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("0 kr.", color = Muted, fontSize = 10.sp); Text("5.000 kr.", color = Muted, fontSize = 10.sp) }
                                    }
                                }
                                Surface(color = Color.Transparent, shape = RoundedCornerShape(22.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.background(if (darkMode) saldoHeroBrush() else Brush.linearGradient(listOf(Color(0xFFFFF4DC), Color(0xFFEEF1F8)))).padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                                        Text("RESULTAT AF SCENARIET", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                        AnimatedMoney(scenarioMonthlyRemainder, color = if (scenarioMonthlyRemainder >= 0) Mint else SaldoDanger, fontSize = 28.sp, format = ::netMoney)
                                        Text("Anslået tilbage pr. måned efter ændringer", color = Muted, fontSize = 11.sp)
                                        HorizontalDivider(color = if (darkMode) Color(0x25FFFFFF) else Color(0x251B1B2C))
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Ekstra forbrug på et år", color = White, fontSize = 12.sp); Text(money(extraSpend.toDouble() * 12), color = SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Mulig ekstra opsparing på et år", color = White, fontSize = 12.sp); Text(money(monthlySave.toDouble() * 12), color = Mint, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Effekt på rådighedsbeløb pr. måned", color = White, fontSize = 11.sp); Text(money((-extraSpend - monthlySave).toDouble()), color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 11.sp) }
                                    }
                                }
                                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                                    Text("Grundlaget er lønindstillingen omregnet til gennemsnit pr. måned minus registrerede udgifter de seneste 90 dage, abonnementer og gældsafdrag. Beløbet er et overslag, ikke en bankbalance; undgå at tælle abonnementer eller afdrag dobbelt, hvis de også er registreret som almindelige udgifter.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(14.dp))
                                }
                            }
                        }
                        "Økonomitjek" -> {
                            val today = LocalDate.now()
                            val overdueBills = bills.filter { bill ->
                                !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.isBefore(today) == true
                            }
                            val currentMonthTransactions = thisMonthTx
                            val overBudget = list("budgets").objects().mapNotNull { budget ->
                                val limit = budget.n("limit")
                                val key = "${budget.s("category").trim().lowercase(Locale.ROOT)}|${budget.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"
                                val spent = monthSpendByCategoryOwner[key] ?: 0.0
                                if (limit > 0 && spent >= limit) Triple(budget, spent, limit) else null
                            }
                            val possibleDuplicates = remember(tx) { tx.groupBy { item ->
                                listOf(
                                    item.s("date").trim(), item.s("type").trim().lowercase(Locale.ROOT),
                                    item.s("name").trim().lowercase(Locale.ROOT), item.s("category").trim().lowercase(Locale.ROOT),
                                    item.n("amount").toBigDecimal().stripTrailingZeros().toPlainString(),
                                    item.s("owner", "Mig").trim().lowercase(Locale.ROOT)
                                ).joinToString("¦")
                            }.values.filter { it.size > 1 } }
                            val backupTimestamp = prefs.getLong("auto_backup_time", 0L)
                            val backupExists = !prefs.getString("auto_backup_data", null).isNullOrBlank()
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Status lige nu", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("Et lokalt tjek af data, der kan kræve din opmærksomhed. Saldo ændrer eller sletter ikke poster automatisk.", color = Muted, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DashboardMetric("Forfaldne", overdueBills.size.toString(), Icons.Default.WarningAmber, if (overdueBills.isEmpty()) Mint else SaldoDanger, Modifier.weight(1f))
                                    DashboardMetric("Over budget", overBudget.size.toString(), Icons.Default.PieChart, if (overBudget.isEmpty()) Mint else SaldoDanger, Modifier.weight(1f))
                                    DashboardMetric("Mulige dubletter", possibleDuplicates.size.toString(), Icons.Default.ContentCopy, if (possibleDuplicates.isEmpty()) Mint else Violet, Modifier.weight(1f))
                                }
                                Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(if (overdueBills.isEmpty() && overBudget.isEmpty() && possibleDuplicates.isEmpty()) Icons.Default.CheckCircle else Icons.Default.FactCheck, null, tint = if (overdueBills.isEmpty() && overBudget.isEmpty() && possibleDuplicates.isEmpty()) Mint else Violet)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Kontrolresultater", color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                        }
                                        if (overdueBills.isEmpty()) Text("✓ Ingen ubetalte regninger med en forfaldsdato før i dag.", color = Mint, fontSize = 12.sp)
                                        else {
                                            Text("${overdueBills.size} regning(er) er forfaldne · ${money(overdueBills.sumOf { it.n("amount") })}", color = SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            overdueBills.take(5).forEach { bill -> Text("• ${bill.s("name")} · ${bill.s("date")} · ${money(bill.n("amount"))}", color = Muted, fontSize = 12.sp) }
                                            TextButton(onClick = { tab = "Regninger" }) { Text("Gennemgå regninger") }
                                        }
                                        HorizontalDivider(color = BorderSubtle)
                                        if (overBudget.isEmpty()) Text("✓ Ingen budgetter er overskredet i denne måned.", color = Mint, fontSize = 12.sp)
                                        else {
                                            Text("${overBudget.size} budget(ter) har nået eller overskredet grænsen.", color = SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            overBudget.take(5).forEach { (budget, spent, limit) -> Text("• ${budget.s("category")} (${budget.s("owner", "Mig")}) · ${money(spent)} / ${money(limit)}", color = Muted, fontSize = 12.sp) }
                                            TextButton(onClick = { tab = "Budget" }) { Text("Gennemgå budgetter") }
                                        }
                                        HorizontalDivider(color = BorderSubtle)
                                        if (possibleDuplicates.isEmpty()) Text("✓ Ingen oplagte dubletter fundet blandt posterne.", color = Mint, fontSize = 12.sp)
                                        else {
                                            Text("Mulige dubletter: ${possibleDuplicates.sumOf { it.size - 1 }} ekstra række(r) i ${possibleDuplicates.size} gruppe(r).", color = Violet, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text("Ens dato, type, navn, kategori, beløb og ejer kan også være legitime gentagelser. Kontrollér manuelt før du sletter noget.", color = Muted, fontSize = 11.sp)
                                            possibleDuplicates.take(3).forEach { group ->
                                                val sample = group.first()
                                                Text("• ${sample.s("date")} · ${sample.s("name")} · ${money(sample.n("amount"))} (${group.size} gange)", color = Muted, fontSize = 12.sp)
                                            }
                                            TextButton(onClick = { tab = "Poster" }) { Text("Gennemgå poster") }
                                        }
                                    }
                                }
                                Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Backupstatus", color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                        if (backupExists && backupTimestamp > 0L) {
                                            val backupAgeDays = ((System.currentTimeMillis() - backupTimestamp).coerceAtLeast(0L) / 86_400_000L)
                                            Text("Seneste lokale backup: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("da", "DK")).format(java.util.Date(backupTimestamp))}", color = Muted, fontSize = 12.sp)
                                            Text(if (backupAgeDays >= 7) "Backupen er mindst 7 dage gammel. Overvej at eksportere en ny kopi." else "Der findes en lokal backup. Eksportér også en kopi uden for telefonen.", color = if (backupAgeDays >= 7) Violet else Mint, fontSize = 12.sp)
                                        } else {
                                            Text("Der er ikke registreret en tidsstemplet lokal backup endnu. Opret og gem en sikkerhedskopi.", color = SaldoDanger, fontSize = 12.sp)
                                        }
                                        Button(onClick = { shareBackup(context, buildBackupJson(data, prefs)) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Eksportér sikkerhedskopi") }
                                        Text("Dette tjek er vejledende. Mulige dubletter er kun forslag, og datoer/registreringer kan være ufuldstændige.", color = Muted, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                        "Rapporter" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) { val currentMonthTx = thisMonthTx; val monthIncome = currentMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }; val monthExpenses = currentMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }; val categories = currentMonthTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse") }.mapValues { entry -> entry.value.sumOf { it.n("amount") } }.toList().sortedByDescending { it.second }; Text("Rapporter", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Denne måned", color = Muted, fontSize = 13.sp); Metric("Indtægter denne måned", money(monthIncome), Modifier.fillMaxWidth(), positive = true); Metric("Udgifter denne måned", money(monthExpenses), Modifier.fillMaxWidth(), positive = false); Metric("Månedens netto", money(monthIncome - monthExpenses), Modifier.fillMaxWidth(), positive = monthIncome >= monthExpenses); Text("Udvikling – seneste 6 måneder", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); val monthTrend = (0..5).map { offset -> val month = LocalDate.now().withDayOfMonth(1).minusMonths((5 - offset).toLong()); val monthEntries = transactionsByMonth[YearMonth.from(month)].orEmpty(); Triple(month, monthEntries.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }, monthEntries.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }) }; SaldoCard(Modifier.fillMaxWidth()) { SaldoTrendChart(monthTrend.map { (month, trendIncome, trendExpenses) -> Triple(month.month.getDisplayName(java.time.format.TextStyle.SHORT, Locale("da", "DK")).trimEnd('.').replaceFirstChar { it.uppercase() }, trendIncome, trendExpenses) }); HorizontalDivider(color = BorderSubtle); monthTrend.takeLast(3).forEach { (month, trendIncome, trendExpenses) -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("${month.monthValue}/${month.year}", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("Netto ", color = Muted, fontSize = 12.sp); Text(netMoney(trendIncome - trendExpenses), color = if (trendIncome >= trendExpenses) Mint else SaldoDanger, fontSize = 13.sp, fontWeight = FontWeight.Bold) } } }; Text("Største udgiftskategorier", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); if (categories.isEmpty()) Text("Ingen udgifter registreret i denne måned endnu.", color = Muted) else SaldoCard(Modifier.fillMaxWidth()) { val topCategoryTotal = categories.firstOrNull()?.second?.takeIf { it > 0 } ?: 1.0; categories.take(5).forEach { (category, total) -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(category, Modifier.weight(1f), color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(money(total), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp) }; SaldoProgressBar((total / topCategoryTotal).toFloat(), height = 7.dp) } } }; HorizontalDivider(color = Muted.copy(alpha = .25f)); Metric("Samlede indtægter (alle poster)", money(income), Modifier.fillMaxWidth(), positive = true); Metric("Samlede udgifter (alle poster)", money(expenses), Modifier.fillMaxWidth(), positive = false); Metric("Netto (alle poster)", money(income - expenses), Modifier.fillMaxWidth()); Metric("Abonnementer pr. år", money(list("subs").objects().sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth()); Button(onClick = { csvPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !csvImportBusy) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(8.dp)); Text(if (csvImportBusy) "Indlæser CSV…" else "Importér CSV-fil") }; Button(onClick = { shareCsv(context, data) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér CSV") }; Button(onClick = { shareBackup(context, buildBackupJson(data, prefs)) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") } }
                        "Indstillinger" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Indstillinger", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Udseende", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Vælg dit tema", color = White, fontWeight = FontWeight.SemiBold)
                                    Text("Dit valg gemmes og bruges næste gang, du åbner Saldo.", color = Muted, fontSize = 12.sp)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        FilterChip(selected = !darkMode, onClick = { darkMode = false }, label = { Text("Lys") }, leadingIcon = { Icon(Icons.Default.LightMode, null) }, modifier = Modifier.weight(1f))
                                        FilterChip(selected = darkMode, onClick = { darkMode = true }, label = { Text("Mørk") }, leadingIcon = { Icon(Icons.Default.DarkMode, null) }, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                            Text("Tilpas startside", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Vælg de kort, du vil se på dit overblik. Ændringerne gemmes med det samme.", color = Muted, fontSize = 12.sp)
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                                    homeSectionOptions.forEachIndexed { index, option ->
                                        val (key, title, description) = option
                                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                Text(description, color = Muted, fontSize = 11.sp)
                                            }
                                            Checkbox(checked = key in visibleHomeSections, onCheckedChange = { enabled ->
                                                if (!enabled && visibleHomeSections.size == 1) Toast.makeText(context, "Behold mindst ét kort på startsiden.", Toast.LENGTH_SHORT).show()
                                                else updateHomeSection(key, enabled)
                                            })
                                        }
                                        if (index < homeSectionOptions.lastIndex) HorizontalDivider(color = BorderSubtle)
                                    }
                                }
                            }
                            Text("Widgets på telefonens startskærm", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Tilføj Saldo-kort uden at åbne appen. Widgets kan vise økonomiske beløb på startskærmen. Hvis din launcher ikke understøtter hurtig tilføjelse, kan du holde fingeren på telefonens startskærm og vælge Widgets → Saldo.", color = Muted, fontSize = 12.sp)
                            SettingsAction("Widget · Rådighedsbeløb", "Vis estimeret rådighed frem til næste løn", Icons.Default.AccountBalanceWallet) { requestSaldoWidget(context, SaldoBalanceWidgetProvider::class.java) }
                            SettingsAction("Widget · Månedens overblik", "Vis månedens indtægter og udgifter", Icons.Default.PieChart) { requestSaldoWidget(context, SaldoMonthlyWidgetProvider::class.java) }
                            SettingsAction("Widget · Kommende regninger", "Vis de næste ubetalte regninger", Icons.Default.CalendarMonth) { requestSaldoWidget(context, SaldoBillsWidgetProvider::class.java) }
                            SettingsAction("Løn og næste løndato", "Tilpas løn og lønrytme", Icons.Default.CalendarMonth) { dialog = "payday" }
                            SettingsAction("Nuværende saldo", if (hasCurrentBalance) "Registreret saldo: ${money(currentBalance)}" else "Indtast saldoen på dine konti for en bedre rådighedsberegning", Icons.Default.AccountBalanceWallet) { dialog = "cashbalance" }
                            SettingsSectionHeader("Sikkerhed og gendannelse", "Lokal backup, PIN og biometrisk oplåsning")
                            SettingsAction("Gendan automatisk lokal backup", backupDescription, Icons.Default.Restore) {
                                val backup = prefs.getString("auto_backup_data", null)
                                if (backup.isNullOrBlank()) Toast.makeText(context, "Der er endnu ingen automatisk backup.", Toast.LENGTH_LONG).show()
                                else runCatching {
                                    val restored = JSONObject(backup)
                                    require(isValidSaldoDataObject(restored)) { "Den lokale backup er tom eller ugyldig." }
                                    normalizeSaldoData(restored)
                                }.onSuccess { restored ->
                                    val currentSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                                    val restoredSnapshot = restored.toString()
                                    val editor = prefs.edit().putString("auto_backup_data", currentSnapshot)
                                        .putLong("auto_backup_time", System.currentTimeMillis())
                                        .putString("data", restoredSnapshot)
                                    val activeUserId = prefs.getString("active_account_user_id", null)
                                    if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), restoredSnapshot).putString(localAccountBackupKey(activeUserId), currentSnapshot)
                                    editor.apply()
                                    data = restored
                                    SaldoWidgetRefreshQueue.request(context)
                                    Toast.makeText(context, "Gendannet. Den tidligere version er bevaret som næste gendannelsespunkt.", Toast.LENGTH_LONG).show()
                                }.onFailure { Toast.makeText(context, it.message ?: "Den lokale backup kunne ikke læses.", Toast.LENGTH_LONG).show() }
                            }
                            SettingsAction("Opret / ændr PIN", "Beskyt appen med en PIN-kode", Icons.Default.Lock) { dialog = "pin" }
                            SettingsAction("Biometrisk oplåsning", "Brug fingeraftryk eller ansigt", Icons.Default.Fingerprint) { val activity = context as? FragmentActivity; if (activity != null) startBiometric(activity, context) { prefs.edit().putBoolean("biometric_enabled", true).apply(); Toast.makeText(context, "Biometrisk oplåsning aktiveret.", Toast.LENGTH_SHORT).show() } else Toast.makeText(context, "Biometrisk oplåsning er ikke tilgængelig her.", Toast.LENGTH_LONG).show() }
                            SettingsSectionHeader("Import og eksport", "Flyt dine økonomidata ind og ud af Saldo")
                            SettingsAction("Importer CSV-fil", "Importer poster med foreslået retning og kategori", Icons.Default.FileOpen, enabled = !csvImportBusy) { csvPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "application/octet-stream", "*/*")) }
                            if (csvImportBusy) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Violet)
                                Text("Analyserer beskrivelser, beløb og dine eksisterende kategorier…", color = Muted, fontSize = 11.sp)
                            }
                            if (csvImportError.isNotBlank()) Text(csvImportError, color = SaldoDanger, fontSize = 11.sp)
                            SettingsAction("Eksportér CSV", "Del poster, regninger og øvrige registreringer som CSV", Icons.Default.FileDownload) { shareCsv(context, data) }
                            SettingsAction("Eksportér sikkerhedskopi", "Gem en kopi af dine data", Icons.Default.CloudUpload) { shareBackup(context, buildBackupJson(data, prefs)) }
                            SettingsAction("Gendan sikkerhedskopi", "Gendan fra en tidligere kopi", Icons.Default.Restore) { dialog = "backup" }
                            SettingsAction("Eksportér PDF-rapport", "Lav en rapport over din økonomi", Icons.Default.PictureAsPdf) { sharePdfReport(context, tx, bills, income, expenses) }
                            SettingsSectionHeader("Onlinekonto og synkronisering", "Manuel synkronisering mellem dine enheder")
                            SettingsAction("Gem lokale data online", "Sikkerhedskopiér til din onlinekonto", Icons.Default.CloudUpload, enabled = !cloudBusy, trailing = if (cloudBusy) Icons.Default.Sync else Icons.Default.ArrowForward) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før synkronisering."
                                else { cloudBusy = true; cloudStatus = "Gemmer online…"; scope.launch {
                                    val uploadSnapshot = JSONObject(data.toString())
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { withRefreshedCloudSession(prefs, token) { freshToken -> syncCloud(freshToken, uploadSnapshot, prefs) } }
                                    }
                                    cloudBusy = false
                                    result.onSuccess { cloudStatus = "Lokale data er gemt online." }.onFailure { cloudStatus = "Synkronisering fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            SettingsAction("Hent data fra onlinekonto", "Hent din seneste online sikkerhedskopi", Icons.Default.CloudDownload, enabled = !cloudBusy) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før hentning."
                                else { cloudBusy = true; cloudStatus = "Henter online data…"; scope.launch {
                                    val expectedUserId = prefs.getString("active_account_user_id", null)
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { withRefreshedCloudSession(prefs, token) { freshToken -> fetchCloud(freshToken, expectedUserId) } }
                                    }
                                    cloudBusy = false
                                    result.onSuccess { cloudData -> if (cloudData == null) cloudStatus = "Der er ingen online backup endnu." else {
                                        val previousSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                                        val cloudSettings = cloudData.optJSONObject("_saldoSettings")
                                        val cloudBusinessData = JSONObject(cloudData.toString()).apply { remove("_saldoSettings") }
                                        val normalizedCloudData = normalizeSaldoData(cloudBusinessData)
                                        val downloadedSnapshot = normalizedCloudData.toString()
                                        val restoreEditor = prefs.edit()
                                            .putString("auto_backup_data", previousSnapshot)
                                            .putLong("auto_backup_time", System.currentTimeMillis())
                                            .putString("data", downloadedSnapshot)
                                        val activeUserId = prefs.getString("active_account_user_id", null)
                                        if (!activeUserId.isNullOrBlank()) restoreEditor.putString(localAccountDataKey(activeUserId), downloadedSnapshot).putString(localAccountBackupKey(activeUserId), previousSnapshot)
                                        cloudSettings?.let { settings ->
                                            applySaldoSettings(settings, restoreEditor)
                                            if (!activeUserId.isNullOrBlank()) restoreEditor.putString(localAccountSettingsKey(activeUserId), settings.toString())
                                        }
                                        restoreEditor.apply()
                                        data = normalizedCloudData
                                        SaldoWidgetRefreshQueue.request(context)
                                        cloudStatus = "Online data hentet og gemt lokalt. Den tidligere lokale version er bevaret som gendannelsespunkt."
                                    } }.onFailure { cloudStatus = "Hentning fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) { Text(cloudStatus, color = Blue, fontSize = 12.sp, modifier = Modifier.padding(14.dp)) }
                            SettingsSectionHeader("Notifikationer og privatliv", "Påmindelser, kontoadgang og dine data")
                            SettingsAction("Notifikationer og budgetadvarsler", "Kontrollér regninger og budgetgrænser", Icons.Default.NotificationsActive) {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                else { scheduleDueBillNotification(context, bills); scheduleBudgetWarningNotification(context, data); scheduleSubscriptionRenewalNotification(context, data) }
                            }
                            SettingsAction("Privatlivspolitik", "Se hvordan Saldo behandler dine oplysninger", Icons.Default.Policy) {
                                openSaldoExternalPage(context, SALDO_PRIVACY_POLICY_URL)
                            }
                            SettingsAction("Anmod om kontosletning", "Åbn den eksterne sletningsside", Icons.Default.DeleteOutline, danger = true) {
                                openSaldoExternalPage(context, SALDO_ACCOUNT_DELETION_URL)
                            }
                            if (!prefs.getString("online_access_token", null).isNullOrBlank() && !prefs.getString("active_account_user_id", null).isNullOrBlank()) {
                                SettingsAction("Slet onlinekonto og clouddata", "Permanent sletning af konto og tilknyttede online data", Icons.Default.DeleteForever, enabled = !deleteAccountBusy, danger = true) {
                                    deleteAccountError = ""
                                    showDeleteAccountDialog = true
                                }
                            }
                            SettingsAction("Log ud", "Afslut online-sessionen", Icons.Default.Logout, danger = true) {
                                val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
                                val editor = prefs.edit().remove("online_access_token").remove("online_refresh_token").remove("account_email")
                                if (activeUserId.isNotBlank()) {
                                    editor.putString(localAccountDataKey(activeUserId), data.toString())
                                        .putString(localAccountSettingsKey(activeUserId), saldoSettingsJson(prefs).toString())
                                    prefs.getString("auto_backup_data", null)?.let { editor.putString(localAccountBackupKey(activeUserId), it) }
                                }
                                val blank = emptySaldoData()
                                editor.putString("data", blank.toString()).remove("auto_backup_data")
                                    .remove("cash_balance").remove("payday").apply()
                                data = blank
                                SaldoWidgetRefreshQueue.request(context)
                                accountUnlocked = false
                                unlocked = prefs.getString("pin_hash", null) == null &&
                                    prefs.getString("pin", null) == null &&
                                    !prefs.getBoolean("biometric_enabled", false)
                                loginMode = false
                                loginPassword = ""
                                loginConfirm = ""
                            }
                        }
                    }
                    }
                }
            }
        }
        SaldoSuccessOverlay(saveSuccess) { saveSuccess = null }
        if (dialog.isNotEmpty()) {
            DataDialog(dialog, onDismiss = { dialog = "" }, onSave = { kind, obj ->
                when (kind) {
                    "post" -> { add("transactions", obj); saveSuccess = if (obj.s("type") == "Indtægt") "Indtægten er gemt" else "Posten er gemt" }
                    "bill" -> {
                        val duplicate = list("bills").objects().any {
                            it.s("name").trim().equals(obj.s("name").trim(), true) &&
                                it.s("date") == obj.s("date") &&
                                kotlin.math.abs(it.n("amount") - obj.n("amount")) < 0.01 &&
                                normalizedOwner(it.s("owner", "Mig")) == normalizedOwner(obj.s("owner", "Mig"))
                        }
                        if (duplicate) Toast.makeText(context, "Mulig dublet: regningen findes allerede", Toast.LENGTH_LONG).show() else { add("bills", obj); saveSuccess = "Regningen er gemt" }
                    }
                    "budget" -> {
                        val duplicate = list("budgets").objects().any {
                            it.s("category").trim().equals(obj.s("category").trim(), ignoreCase = true) &&
                                it.s("owner", "Mig").trim().equals(obj.s("owner", "Mig").trim(), ignoreCase = true)
                        }
                        if (duplicate) {
                            Toast.makeText(context, "Der findes allerede et budget for denne kategori og ejer. Brug det eksisterende budget i stedet.", Toast.LENGTH_LONG).show()
                        } else { add("budgets", obj); saveSuccess = "Budgettet er gemt" }
                    }
                    "goal" -> { add("goals", obj); saveSuccess = "Opsparingsmålet er gemt" }
                    "debt" -> { add("debts", obj); saveSuccess = "Gælden er gemt" }
                    "fuel" -> { add("fuel", obj); saveSuccess = "Tankningen er gemt" }
                    "sub" -> { add("subs", obj); saveSuccess = "Abonnementet er gemt" }
                    "payday" -> {
                        prefs.edit().putFloat("pay_amount", obj.n("pay").toFloat()).putString("payday", obj.s("date")).apply()
                        persistSaldoSettingsForActiveAccount(prefs)
                        saveSuccess = "Lønindstillingen er gemt"
                    }
                    "pin" -> {
                        val salt = newPinSalt()
                        val hash = hashPin(obj.s("pin"), salt)
                        prefs.edit().putString("pin_salt", salt).putString("pin_hash", hash)
                            .remove("pin").apply()
                        unlocked = true
                    }
                    "backup" -> {
                        val importedBackup = parseSaldoBackup(obj.s("json"))
                            ?: throw IllegalArgumentException("Backupfilen kunne ikke valideres.")
                        val restored = normalizeSaldoData(importedBackup.data)
                        val snapshot = restored.toString()
                        val previousSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                        val editor = prefs.edit()
                            .putString("auto_backup_data", previousSnapshot)
                            .putLong("auto_backup_time", System.currentTimeMillis())
                            .putString("data", snapshot)
                        importedBackup.settings?.let { settings ->
                            applySaldoSettings(settings, editor)
                            prefs.getString("active_account_user_id", null)?.takeIf { it.isNotBlank() }?.let { editor.putString(localAccountSettingsKey(it), settings.toString()) }
                        }
                        editor.apply()
                        data = restored
                    }
                    "cashbalance" -> {
                        prefs.edit().putFloat("cash_balance", obj.n("balance").toFloat()).apply()
                        persistSaldoSettingsForActiveAccount(prefs)
                        saveSuccess = "Saldoen er opdateret"
                    }
                }
                SaldoWidgetRefreshQueue.request(context)
                dialog = ""
            })
        }
        pendingCsvImport?.let { plan ->
            val totalImportedRows = plan.recordsByCollection.values.sumOf { it.size }
            val summary = listOf(
                "Poster" to (plan.recordsByCollection["transactions"]?.size ?: 0),
                "Regninger" to (plan.recordsByCollection["bills"]?.size ?: 0),
                "Budgetter" to (plan.recordsByCollection["budgets"]?.size ?: 0),
                "Opsparingsmål" to (plan.recordsByCollection["goals"]?.size ?: 0),
                "Gæld" to (plan.recordsByCollection["debts"]?.size ?: 0),
                "Abonnementer" to (plan.recordsByCollection["subs"]?.size ?: 0),
                "Tankninger" to (plan.recordsByCollection["fuel"]?.size ?: 0)
            ).filter { it.second > 0 }
            val transactionPreview = plan.recordsByCollection["transactions"].orEmpty()
            val categoryContext = csvCategoryContext
            val categoryOptions = csvCategoryOptions(plan, categoryContext)
            val needsReviewCount = transactionPreview.count {
                it.optBoolean("_saldoCsvNeedsReview", it.optInt("_saldoCsvConfidence", 0) < 72) ||
                    it.optInt("_saldoCsvDirectionConfidence", 0) < 80
            }
            AlertDialog(
                onDismissRequest = { pendingCsvImport = null },
                containerColor = Panel,
                title = { Text("Kontrollér CSV-import", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 500.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 6.dp)
                    ) {
                        item {
                            Text("Saldo har læst ${plan.rowsRead} datarække(r). Intet ændres, før du bekræfter importen.", color = Muted, fontSize = 13.sp)
                        }
                        if (summary.isNotEmpty()) item {
                            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    summary.forEach { (label, count) ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, color = White, fontSize = 13.sp)
                                            Text(count.toString(), color = Violet, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                        if (transactionPreview.isNotEmpty()) {
                            item {
                                val incomeRows = transactionPreview.filter { it.s("type") == "Indtægt" }
                                val expenseRows = transactionPreview.filter { it.s("type") == "Udgift" }
                                Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text("Gennemgå og ret forslag", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text("${incomeRows.size} indtægter · ${money(incomeRows.sumOf { it.n("amount") })}   ${expenseRows.size} udgifter · ${money(expenseRows.sumOf { it.n("amount") })}", color = Muted, fontSize = 11.sp)
                                        Text(if (needsReviewCount == 0) "Alle forslag har høj sikkerhed. Kontrollér stadig beløb og retning." else "$needsReviewCount post(er) bør kontrolleres. Du kan ændre både retning og kategori før import.", color = if (needsReviewCount == 0) Mint else Color(0xFFE4B866), fontSize = 11.sp)
                                    }
                                }
                            }
                            items(transactionPreview, key = { it.s("id") }) { transaction ->
                                CsvTransactionPreviewRow(
                                    transaction = transaction,
                                    categories = categoryOptions,
                                    onTypeChange = { selectedType ->
                                        pendingCsvImport = updateCsvPlanTransaction(plan = pendingCsvImport ?: plan, id = transaction.s("id"), newType = selectedType, context = categoryContext)
                                    },
                                    onCategoryChange = { selectedCategory ->
                                        pendingCsvImport = updateCsvPlanTransaction(plan = pendingCsvImport ?: plan, id = transaction.s("id"), newCategory = selectedCategory, context = categoryContext)
                                    }
                                )
                            }
                        }
                        if (plan.skippedRows > 0) item { Text("Sprunget over som dublet eller ukendt posttype: ${plan.skippedRows}.", color = Muted, fontSize = 11.sp) }
                        if (plan.invalidRows > 0) item { Text("Rækker med manglende eller ugyldige felter: ${plan.invalidRows}.", color = SaldoDanger, fontSize = 11.sp) }
                        item {
                            Text("Importerede poster lægges oven i dine eksisterende data. De erstatter ikke din økonomi.", color = Mint, fontSize = 11.sp)
                            Text("Retningen afgøres først og fremmest af CSV-filens retning, debet/kredit eller beløbets fortegn. Beløbsstørrelse bruges kun som ekstra støtte ved genkendelse af tidligere transaktioner.", color = Muted, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        var imported = 0
                        var duplicates = 0
                        plan.recordsByCollection.forEach { (collection, incoming) ->
                            val merged = list(collection).objects().toMutableList()
                            val fingerprints = merged.mapTo(mutableSetOf()) { csvRecordFingerprint(collection, it) }
                            incoming.forEach { candidate ->
                                val cleanCandidate = JSONObject(candidate.toString())
                                val learnCorrection = collection == "transactions" && candidate.optBoolean("_saldoCsvUserChangedCategory", false)
                                val correctionName = cleanCandidate.s("name")
                                val correctionType = cleanCandidate.s("type")
                                val correctionCategory = cleanCandidate.s("category")
                                csvTransientFields.forEach(cleanCandidate::remove)
                                if (!fingerprints.add(csvRecordFingerprint(collection, cleanCandidate))) {
                                    duplicates++
                                } else {
                                    merged += cleanCandidate
                                    imported++
                                    if (learnCorrection) persistCsvCategoryCorrection(prefs, correctionName, correctionType, correctionCategory)
                                }
                            }
                            if (merged.size > list(collection).length()) {
                                store(collection, JSONArray().apply { merged.forEach { put(it) } })
                            }
                        }
                        pendingCsvImport = null
                        csvImportError = ""
                        Toast.makeText(context, "CSV-import færdig: $imported tilføjet, $duplicates dubletter sprunget over.", Toast.LENGTH_LONG).show()
                    }, enabled = totalImportedRows > 0) { Text("Importér $totalImportedRows", color = Blue) }
                },
                dismissButton = { TextButton(onClick = { pendingCsvImport = null }) { Text("Annuller", color = Muted) } }
            )
        }

        if (showMultiBillDialog) {
            MultiBillImportDialog(
                drafts = multiBillDrafts,
                onDraftsChanged = { multiBillDrafts = it },
                onDismiss = { showMultiBillDialog = false; multiBillDrafts = emptyList() },
                onImport = { drafts ->
                    var added = 0
                    var duplicates = 0
                    val existingBillsForImport = list("bills").objects()
                    val importedBills = mutableListOf<JSONObject>()
                    var invalid = 0
                    drafts.filter { it.selected }.forEach { draft ->
                        val parsedAmount = parseDanishAmount(draft.amount)
                        val validDate = runCatching { LocalDate.parse(draft.date) }.isSuccess
                        if (draft.name.isBlank() || parsedAmount == null || parsedAmount <= 0.0 || !validDate) {
                            invalid++
                        } else {
                            val candidate = record(
                                "id" to draft.id,
                                "name" to draft.name.trim(),
                                "amount" to parsedAmount,
                                "date" to draft.date,
                                "repeat" to "Engangsbetaling",
                                "category" to "Regning",
                                "owner" to "Mig",
                                "paid" to false,
                                "source" to "Masseimport af billeder"
                            )
                            val exists = (existingBillsForImport + importedBills).any { existing -> csvRecordsEquivalent("bills", existing, candidate) }
                            if (exists) duplicates++ else { importedBills += candidate; added++ }
                        }
                    }
                    if (importedBills.isNotEmpty()) {
                        val updatedBills = list("bills")
                        importedBills.forEach { updatedBills.put(it) }
                        store("bills", updatedBills)
                    }
                    showMultiBillDialog = false
                    multiBillDrafts = emptyList()
                    Toast.makeText(context, "Regningsimport: $added tilføjet, $duplicates dubletter, $invalid ugyldige/skippede.", Toast.LENGTH_LONG).show()
                }
            )
        }

        editingGoal?.let { goal ->
            GoalEditDialog(
                goal = goal,
                onDismiss = { editingGoal = null },
                onSave = { updated ->
                    val goalId = goal.s("id")
                    val updatedGoals = JSONArray()
                    list("goals").objects().forEach { current ->
                        updatedGoals.put(if (current.s("id") == goalId) updated else current)
                    }
                    store("goals", updatedGoals)
                    editingGoal = null
                    Toast.makeText(context, "Opsparingsmålet er opdateret.", Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (showDeleteAccountDialog) {
            AlertDialog(
                onDismissRequest = { if (!deleteAccountBusy) showDeleteAccountDialog = false },
                containerColor = Panel,
                title = { Text("Slet onlinekonto?", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Dette sletter din Supabase-konto og dens online backup permanent. Saldo fjerner også denne kontos lokale data fra telefonen. Handlingen kan ikke fortrydes.", color = Muted)
                        Text("Eksportér først en JSON-sikkerhedskopi, hvis du vil gemme dine oplysninger.", color = White, fontWeight = FontWeight.SemiBold)
                        if (deleteAccountError.isNotBlank()) Text(deleteAccountError, color = SaldoDanger, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !deleteAccountBusy,
                        onClick = {
                            val token = prefs.getString("online_access_token", "").orEmpty()
                            val accountId = prefs.getString("active_account_user_id", "").orEmpty()
                            if (token.isBlank() || accountId.isBlank()) {
                                deleteAccountError = "Du skal være logget ind på den konto, der skal slettes."
                            } else {
                                deleteAccountBusy = true
                                deleteAccountError = ""
                                scope.launch {
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { supabaseDeleteAccount(token) }
                                    }
                                    deleteAccountBusy = false
                                    result.onSuccess {
                                        val blank = emptySaldoData()
                                        prefs.edit()
                                            .remove("online_access_token")
                                            .remove("online_refresh_token")
                                            .remove("account_email")
                                            .remove("active_account_user_id")
                                            .remove(localAccountDataKey(accountId))
                                            .remove(localAccountBackupKey(accountId))
                                            .remove(localAccountSettingsKey(accountId))
                                            .remove("auto_backup_data")
                                            .remove("auto_backup_time")
                                            .remove("corrupt_data_backup")
                                            .remove("cash_balance")
                                            .remove("payday")
                                            .putFloat("pay_amount", 10000f)
                                            .putString("data", blank.toString())
                                            .apply()
                                        data = blank
                                        loginEmail = ""
                                        loginPassword = ""
                                        loginConfirm = ""
                                        pin = ""
                                        accountUnlocked = false
                                        showDeleteAccountDialog = false
                                        deleteAccountError = ""
                                        SaldoWidgetRefreshQueue.request(context)
                                        Toast.makeText(context, "Onlinekonto og tilknyttede data er slettet.", Toast.LENGTH_LONG).show()
                                    }.onFailure { error ->
                                        deleteAccountError = error.message ?: "Kontoen kunne ikke slettes. Prøv igen, eller brug sletningssiden."
                                    }
                                }
                            }
                        }
                    ) { Text(if (deleteAccountBusy) "Sletter…" else "Slet konto permanent", color = SaldoDanger) }
                },
                dismissButton = {
                    TextButton(enabled = !deleteAccountBusy, onClick = { showDeleteAccountDialog = false }) {
                        Text("Annuller", color = Muted)
                    }
                }
            )
        }
    }
}

class BillReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return runCatching {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
            val prefs = saldoPreferences(applicationContext)
            val data = JSONObject(prefs.getString("data", "{}") ?: "{}")
            val bills = (data.optJSONArray("bills") ?: JSONArray()).objects()
            val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
            if (due.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = due.take(5).joinToString("\n") { "${it.s("name")}: ${money(it.n("amount"))} · ${it.s("date")}" }
                val n = NotificationCompat.Builder(applicationContext, "saldo_bills").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(351, n)
            }
            val subscriptions = (data.optJSONArray("subs") ?: JSONArray()).objects()
            val todayForRenewal = LocalDate.now()
            val renewals = subscriptions.filter { sub ->
                val renewal = runCatching { LocalDate.parse(sub.s("renewalDate")) }.getOrNull()
                val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
                listOfNotNull(renewal, cancelBy).any { !it.isBefore(todayForRenewal) && !it.isAfter(todayForRenewal.plusDays(7)) } && sub.optBoolean("active", true)
            }
            if (renewals.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_subscriptions", "Abonnementer og fornyelser", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = renewals.take(5).joinToString("\n") { sub ->
                    val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
                    val actionDate = if (cancelBy != null && !cancelBy.isBefore(todayForRenewal) && !cancelBy.isAfter(todayForRenewal.plusDays(7))) "Opsig senest ${sub.s("cancelByDate")}" else "Fornyes ${sub.s("renewalDate")}" 
                    "${sub.s("name")}: $actionDate · ${money(sub.n("monthly"))}/md."
                }
                val n = NotificationCompat.Builder(applicationContext, "saldo_subscriptions").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: abonnement fornyes snart").setContentText("${renewals.size} abonnement(er) fornyes inden for 7 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(353, n)
            }
            val budgets = (data.optJSONArray("budgets") ?: JSONArray()).objects()
            val transactions = (data.optJSONArray("transactions") ?: JSONArray()).objects()
            val now = LocalDate.now()
            val critical = budgets.mapNotNull { budget ->
                val limit = budget.n("limit")
                if (limit <= 0) return@mapNotNull null
                val spent = transactions.filter { tx -> tx.s("type") == "Udgift" && tx.s("category").equals(budget.s("category"), true) && tx.s("owner", "Mig").equals(budget.s("owner", "Mig"), true) && runCatching { LocalDate.parse(tx.s("date")) }.getOrNull()?.let { it.year == now.year && it.month == now.month } == true }.sumOf { it.n("amount") }
                if (spent >= limit * .8) "${budget.s("category")}: ${money(spent)} af ${money(limit)}${if (spent >= limit) " (overskredet)" else " (over 80 %)"}" else null
            }
            if (critical.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_budgets", "Budgetadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = critical.take(5).joinToString("\n")
                val n = NotificationCompat.Builder(applicationContext, "saldo_budgets").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: tjek dine budgetter").setContentText("${critical.size} budget(ter) nærmer sig eller har overskredet grænsen").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(352, n)
            }
            if (prefs.contains("cash_balance")) {
                val configuredPayday = runCatching { LocalDate.parse(prefs.getString("payday", now.toString())) }.getOrElse { now }
                val untilPayday = ChronoUnit.DAYS.between(now, configuredPayday).toInt().let { ((it % 14) + 14) % 14 }.let { if (it == 0) 14 else it }
                val periodEnd = now.plusDays(untilPayday.toLong())
                val nextBills = bills.filter { bill ->
                    !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { d -> !d.isBefore(now) && !d.isAfter(periodEnd) } == true
                }.sumOf { it.n("amount") }
                val daily = (prefs.getFloat("cash_balance", 0f).toDouble() - nextBills) / untilPayday.coerceAtLeast(1)
                if (daily < 150.0) {
                    val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_cashflow", "Rådighedsadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
                    val detail = "Efter registrerede regninger: ${money(prefs.getFloat("cash_balance", 0f).toDouble() - nextBills)} tilbage. Vejledende ${money(daily)} pr. dag frem til næste løn. Kontrollér, at saldo og regninger er opdateret."
                    val n = NotificationCompat.Builder(applicationContext, "saldo_cashflow").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle(if (daily < 0) "Saldo: regninger overstiger registreret saldo" else "Saldo: lavt rådighedsbeløb frem til løn").setContentText(detail).setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                    NotificationManagerCompat.from(applicationContext).notify(354, n)
                }
            }
        }.fold({ Result.success() }, { Result.retry() })
    }
}

private fun openSaldoExternalPage(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "Siden kunne ikke åbnes. Kontrollér internetforbindelsen.", Toast.LENGTH_LONG).show() }
}

private class SupabaseHttpException(val statusCode: Int, message: String) : IllegalStateException(message)

private fun supabaseDeleteAccount(accessToken: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL mangler eller er ikke HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val connection = (URL("$base/functions/v1/delete-account").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 20000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        setRequestProperty("Authorization", "Bearer $accessToken")
    }
    try {
        connection.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (status !in 200..299) {
            val message = runCatching { JSONObject(body).optString("error").takeIf { it.isNotBlank() } }.getOrNull()
            throw IllegalStateException(message ?: "Kontosletning fejlede (HTTP $status). Kontrollér, at delete-account-funktionen er installeret.")
        }
    } finally {
        connection.disconnect()
    }
}

private fun cloudRequest(path: String, token: String, method: String = "GET", body: JSONObject? = null, prefer: String? = null): String {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL mangler eller er ikke HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val c = (URL("$base$path").openConnection() as HttpURLConnection).apply {
        requestMethod = method; connectTimeout = 15000; readTimeout = 20000; doInput = true
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        // Refresh requests authenticate with the project API key. Avoid sending a publishable
        // key as a Bearer JWT; every user-scoped request still uses its access token below.
        if (!path.startsWith("/auth/v1/token?grant_type=refresh_token")) {
            setRequestProperty("Authorization", "Bearer $token")
        }
        setRequestProperty("Content-Type", "application/json")
        if (prefer != null) setRequestProperty("Prefer", prefer)
        if (body != null) doOutput = true
    }
    try {
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val message = runCatching { JSONObject(text).optString("message").ifBlank { JSONObject(text).optString("msg") } }
                .getOrDefault(text).ifBlank { "Serveren afviste forespørgslen." }.take(240)
            throw SupabaseHttpException(code, "Supabase HTTP $code: $message")
        }
        return text
    } finally { c.disconnect() }
}

private fun currentCloudUserId(token: String): String {
    val user = JSONObject(cloudRequest("/auth/v1/user", token))
    return user.optString("id").takeIf { it.isNotBlank() } ?: throw IllegalStateException("Kunne ikke identificere onlinekontoen.")
}

/** Refresh an expired Supabase access token using the encrypted local refresh token. */
private fun refreshSupabaseSession(prefs: android.content.SharedPreferences): String {
    val refreshToken = prefs.getString("online_refresh_token", null).orEmpty()
    require(refreshToken.isNotBlank()) { "Din session er udløbet. Log ind igen for at fortsætte." }
    val response = JSONObject(
        cloudRequest(
            "/auth/v1/token?grant_type=refresh_token",
            BuildConfig.SUPABASE_ANON_KEY,
            "POST",
            JSONObject().put("refresh_token", refreshToken)
        )
    )
    val accessToken = response.optString("access_token")
    require(accessToken.isNotBlank()) { "Supabase returnerede ingen ny session. Log ind igen." }
    val refreshedUserId = currentCloudUserId(accessToken)
    val expectedUserId = prefs.getString("active_account_user_id", null).orEmpty()
    require(expectedUserId.isBlank() || expectedUserId == refreshedUserId) {
        "Den fornyede session tilhører en anden konto. Log ind igen, så kontodata ikke blandes."
    }
    val editor = prefs.edit().putString("online_access_token", accessToken)
    response.optString("refresh_token").takeIf { it.isNotBlank() }?.let { editor.putString("online_refresh_token", it) }
    response.optString("email").takeIf { it.isNotBlank() }?.let { editor.putString("account_email", it) }
    check(editor.commit()) { "Den fornyede session kunne ikke gemmes sikkert. Log ind igen." }
    return accessToken
}

/** Retry exactly once after a 401; all other server errors remain visible to the user. */
private fun <T> withRefreshedCloudSession(
    prefs: android.content.SharedPreferences,
    token: String,
    action: (String) -> T
): T = try {
    action(token)
} catch (error: SupabaseHttpException) {
    if (error.statusCode != 401) throw error
    action(refreshSupabaseSession(prefs))
}

private fun syncCloud(token: String, data: JSONObject, prefs: android.content.SharedPreferences) {
    require(isValidSaldoDataObject(data) && hasAnySaldoRecords(data)) {
        "De lokale økonomidata er tomme eller ugyldige og blev ikke uploadet, så en eksisterende online backup ikke risikerer at blive overskrevet."
    }
    val userId = currentCloudUserId(token)
    val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
    require(activeUserId.isBlank() || activeUserId == userId) {
        "Den lokale dataejer matcher ikke den onlinekonto, der er logget ind. Log ind på den rigtige konto først."
    }
    if (activeUserId.isBlank()) {
        prefs.edit().putString("active_account_user_id", userId).putString(localAccountDataKey(userId), data.toString()).apply()
    }
    // Store settings alongside the JSON data without mixing them into the app's transaction collections.
    val cloudPayload = JSONObject(data.toString()).put("_saldoSettings", saldoSettingsJson(prefs))
    val body = JSONObject().put("user_id", userId).put("data", cloudPayload).put("updated_at", java.time.Instant.now().toString())
    cloudRequest("/rest/v1/saldo_user_data?on_conflict=user_id", token, "POST", body, "resolution=merge-duplicates,return=minimal")
}

private fun fetchCloud(token: String, expectedUserId: String? = null): JSONObject? {
    val userId = currentCloudUserId(token)
    require(expectedUserId.isNullOrBlank() || expectedUserId == userId) {
        "Den lokale dataejer matcher ikke den onlinekonto, der er logget ind. Dine lokale data er ikke ændret."
    }
    val rows = JSONArray(cloudRequest("/rest/v1/saldo_user_data?select=data&user_id=eq.$userId&limit=1", token))
    val cloudData = if (rows.length() == 0) null else rows.optJSONObject(0)?.optJSONObject("data")
    if (cloudData != null) {
        // Never let malformed cloud JSON replace the working local budget.
        val businessData = JSONObject(cloudData.toString()).apply { remove("_saldoSettings") }
        require(isValidSaldoDataObject(businessData) && hasAnySaldoRecords(businessData)) {
            "Onlinekopien er tom eller indeholder ugyldige/ufuldstændige økonomidata. Dine lokale data er ikke ændret."
        }
        cloudData.optJSONObject("_saldoSettings")?.let { settings ->
            val salary = settings.optDouble("payAmount", 10000.0)
            require(salary.isFinite() && salary > 0.0 && salary <= 1_000_000_000_000.0) {
                "Onlinekopiens lønindstilling er ugyldig. Dine lokale data er ikke ændret."
            }
            if (settings.optBoolean("hasPayday", false)) {
                require(runCatching { LocalDate.parse(settings.optString("payday")) }.isSuccess) {
                    "Onlinekopiens løndato er ugyldig. Dine lokale data er ikke ændret."
                }
            }
            if (settings.optBoolean("hasCashBalance", false)) {
                val balance = settings.optDouble("cashBalance", Double.NaN)
                require(balance.isFinite() && kotlin.math.abs(balance) <= 1_000_000_000_000.0) {
                    "Onlinekopiens kontosaldo er ugyldig. Dine lokale data er ikke ændret."
                }
            }
        }
    }
    return cloudData
}

private fun startBiometric(activity: FragmentActivity, context: Context, onSuccess: () -> Unit = {}) {
    val manager = BiometricManager.from(context)
    if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
        Toast.makeText(context, "Ingen biometrisk oplåsning er sat op på telefonen.", Toast.LENGTH_LONG).show(); return
    }
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            Toast.makeText(context, "Biometrisk kontrol lykkedes.", Toast.LENGTH_SHORT).show()
            onSuccess()
        }
        override fun onAuthenticationFailed() { Toast.makeText(context, "Fingeraftryk blev ikke genkendt.", Toast.LENGTH_SHORT).show() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { Toast.makeText(context, errString, Toast.LENGTH_SHORT).show() }
    })
    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Lås Saldo op").setSubtitle("Bekræft din identitet").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Annuller").build())
}

private fun scheduleDueBillNotification(context: Context, bills: List<JSONObject>) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Tillad notifikationer i Android-indstillinger for at modtage påmindelser.", Toast.LENGTH_LONG).show(); return
    }
    val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
    if (due.isEmpty()) { Toast.makeText(context, "Ingen ubetalte regninger med forfald inden for 3 dage.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
    val details = due.take(4).joinToString("\n") { "${it.s("name")}: ${money(it.n("amount"))} · ${it.s("date")}" }
    val notification = NotificationCompat.Builder(context, "saldo_bills").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(details)).setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(351, notification)
    Toast.makeText(context, "Påmindelse sendt for ${due.size} regning(er). Dette er en manuel kontrol, ikke en daglig baggrundsalarm.", Toast.LENGTH_LONG).show()
}

private fun scheduleSubscriptionRenewalNotification(context: Context, data: JSONObject) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val today = LocalDate.now()
    val renewals = (data.optJSONArray("subs") ?: JSONArray()).objects().filter { sub ->
        val renewal = runCatching { LocalDate.parse(sub.s("renewalDate")) }.getOrNull()
        val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
        val relevantDates = listOfNotNull(renewal, cancelBy)
        sub.optBoolean("active", true) && relevantDates.any { !it.isBefore(today) && !it.isAfter(today.plusDays(7)) }
    }
    if (renewals.isEmpty()) { Toast.makeText(context, "Ingen registrerede abonnementsfornyelser inden for 7 dage.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_subscriptions", "Abonnementer og fornyelser", NotificationManager.IMPORTANCE_DEFAULT))
    val detail = renewals.take(5).joinToString("\n") { sub ->
        val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
        val actionDate = if (cancelBy != null && !cancelBy.isBefore(today) && !cancelBy.isAfter(today.plusDays(7))) "Opsig senest ${sub.s("cancelByDate")}" else "Fornyes ${sub.s("renewalDate")}" 
        "${sub.s("name")}: $actionDate · ${money(sub.n("monthly"))}/md."
    }
    val notification = NotificationCompat.Builder(context, "saldo_subscriptions").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: abonnement fornyes snart").setContentText("${renewals.size} abonnement(er) fornyes inden for 7 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(353, notification)
    Toast.makeText(context, "Påmindelse sendt for ${renewals.size} abonnement(er).", Toast.LENGTH_LONG).show()
}

private fun scheduleBudgetWarningNotification(context: Context, data: JSONObject) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Tillad notifikationer i Android-indstillinger for at modtage budgetadvarsler.", Toast.LENGTH_LONG).show(); return
    }
    val now = LocalDate.now()
    val transactions = (data.optJSONArray("transactions") ?: JSONArray()).objects()
    val budgets = (data.optJSONArray("budgets") ?: JSONArray()).objects()
    val critical = budgets.mapNotNull { budget ->
        val limit = budget.n("limit")
        if (limit <= 0) return@mapNotNull null
        val spent = transactions.filter { tx -> tx.s("type") == "Udgift" && tx.s("category").equals(budget.s("category"), true) && tx.s("owner", "Mig").equals(budget.s("owner", "Mig"), true) && runCatching { LocalDate.parse(tx.s("date")) }.getOrNull()?.let { it.year == now.year && it.month == now.month } == true }.sumOf { it.n("amount") }
        if (spent >= limit * .8) "${budget.s("category")}: ${money(spent)} af ${money(limit)}${if (spent >= limit) " (overskredet)" else " (over 80 %)"}" else null
    }
    if (critical.isEmpty()) { Toast.makeText(context, "Ingen budgetter over 80 % af grænsen.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_budgets", "Budgetadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
    val detail = critical.take(5).joinToString("\n")
    val notification = NotificationCompat.Builder(context, "saldo_budgets").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: tjek dine budgetter").setContentText("${critical.size} budget(ter) nærmer sig eller har overskredet grænsen").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(352, notification)
    Toast.makeText(context, "Budgetadvarsel sendt for ${critical.size} kategori(er).", Toast.LENGTH_LONG).show()
}

private fun sharePdfReport(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>, income: Double, expenses: Double) {
    runCatching {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val left = 40f
        val maxTextWidth = 515f
        val ink = android.graphics.Color.rgb(31, 29, 55)
        val muted = android.graphics.Color.rgb(112, 112, 134)
        val purple = android.graphics.Color.rgb(105, 83, 224)
        val green = android.graphics.Color.rgb(35, 135, 107)
        val red = android.graphics.Color.rgb(205, 65, 83)
        val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 23f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val sectionPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = purple; textSize = 13f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val bodyPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 10.5f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        val smallPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 9f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        var currentPage: PdfDocument.Page? = null
        var currentCanvas: android.graphics.Canvas? = null
        var y = 0f
        var pageNumber = 0

        fun startPage() {
            currentPage?.let { document.finishPage(it) }
            pageNumber += 1
            val newPage = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            currentPage = newPage
            currentCanvas = newPage.canvas
            val canvas = newPage.canvas
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.drawText("Saldo · Økonomirapport", left, 42f, titlePaint)
            canvas.drawText("Udarbejdet ${LocalDate.now()} · Privat økonomi", left, 62f, smallPaint)
            val rulePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(225, 222, 240); strokeWidth = 1f
            }
            canvas.drawLine(left, 77f, 555f, 77f, rulePaint)
            y = 99f
        }

        fun ensureSpace(height: Float = 18f) {
            if (y + height > 778f) startPage()
        }

        fun drawTextLine(text: String, paint: android.graphics.Paint = bodyPaint, lineHeight: Float = 16f) {
            ensureSpace(lineHeight)
            currentCanvas?.drawText(text, left, y, paint)
            y += lineHeight
        }

        fun drawWrapped(text: String, paint: android.graphics.Paint = bodyPaint, lineHeight: Float = 14f) {
            val words = text.replace('\n', ' ').trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            var line = ""
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) <= maxTextWidth) {
                    line = candidate
                } else {
                    if (line.isNotEmpty()) drawTextLine(line, paint, lineHeight)
                    line = word
                }
            }
            if (line.isNotEmpty()) drawTextLine(line, paint, lineHeight)
        }

        fun drawSection(title: String) {
            ensureSpace(34f)
            y += 5f
            drawTextLine(title, sectionPaint, 23f)
        }

        try {
            startPage()
            drawSection("Økonomisk overblik")
            drawTextLine("Indtægter registreret: ${money(income)}")
            drawTextLine("Udgifter registreret: ${money(expenses)}")
            val netPaint = android.graphics.Paint(bodyPaint).apply { color = if (income - expenses >= 0) green else red; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
            drawTextLine("Netto: ${money(income - expenses)}", netPaint)
            drawTextLine("Registrerede poster: ${transactions.size}")
            val unpaid = bills.filter { !it.optBoolean("paid", false) }
            drawTextLine("Regninger: ${bills.size} · Ubetalte: ${unpaid.size}")
            drawWrapped("Bemærk: Rapporten bygger på de oplysninger, der er indtastet i Saldo. Den er ikke en bankudskrift.", smallPaint, 13f)

            drawSection("Poster · seneste først")
            val rows = transactions.sortedByDescending { it.s("date") }.take(1000)
            if (rows.isEmpty()) {
                drawTextLine("Der er ingen registrerede poster endnu.", smallPaint)
            } else {
                rows.forEach { item ->
                    ensureSpace(37f)
                    val date = item.s("date", "Dato mangler")
                    val name = item.s("name", "Post uden navn").ifBlank { "Post uden navn" }.take(90)
                    drawWrapped("$date · $name", bodyPaint, 13f)
                    val amountColor = if (item.s("type") == "Indtægt") green else red
                    val detailPaint = android.graphics.Paint(smallPaint).apply { color = amountColor }
                    val detail = listOf(item.s("type", "Post"), item.s("category").takeIf { it.isNotBlank() }, money(item.n("amount")))
                        .filterNotNull().joinToString(" · ")
                    drawWrapped(detail, detailPaint, 12f)
                    y += 4f
                }
                if (transactions.size > rows.size) drawWrapped("Viser de seneste ${rows.size} af ${transactions.size} poster.", smallPaint, 12f)
            }

            drawSection("Ubetalte regninger")
            val sortedUnpaid = unpaid.sortedBy { it.s("date", "9999-12-31") }
            if (sortedUnpaid.isEmpty()) {
                drawTextLine("Ingen ubetalte regninger er registreret.", smallPaint)
            } else {
                sortedUnpaid.forEach { bill ->
                    ensureSpace(30f)
                    val due = bill.s("date", "Dato mangler")
                    val name = bill.s("name", "Regning uden navn").ifBlank { "Regning uden navn" }.take(90)
                    drawWrapped("$due · $name · ${money(bill.n("amount"))}", bodyPaint, 13f)
                }
            }
            drawSection("Privatliv")
            drawWrapped("Denne rapport kan indeholde følsomme økonomioplysninger. Del den kun med personer eller tjenester, du har tillid til.", smallPaint, 13f)
            currentPage?.let { document.finishPage(it) }
            currentPage = null
            val file = File(context.cacheDir, "Saldo-rapport-${exportFileStamp()}.pdf")
            FileOutputStream(file).use { document.writeTo(it) }
            val uri: Uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_SUBJECT, "Saldo-økonomirapport")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(intent, "Del PDF-rapport"))
        } finally {
            document.close()
        }
    }.onFailure {
        Toast.makeText(context, "Kunne ikke oprette PDF: ${it.message ?: "ukendt fejl"}", Toast.LENGTH_LONG).show()
    }
}

private fun supabaseAuth(email: String, password: String, signUp: Boolean): JSONObject {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    val endpoint = if (signUp) "$base/auth/v1/signup" else "$base/auth/v1/token?grant_type=password"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
    }
    try {
        val body = JSONObject().put("email", email).put("password", password).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
        if (status !in 200..299) {
            val message = json.optString("msg").ifBlank { json.optString("message") }.ifBlank { json.optString("error_description") }.ifBlank { json.optString("error") }.ifBlank { "Online-login fejlede (HTTP $status)." }
            throw IllegalStateException(message)
        }
        return json
    } finally { connection.disconnect() }
}

private fun supabasePasswordRecovery(email: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL skal være HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val redirectUri = Uri.encode("dk.saldo.app://auth-callback")
    val connection = (URL("$base/auth/v1/recover?redirect_to=$redirectUri").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
    }
    try {
        val body = JSONObject().put("email", email).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        if (status !in 200..299) {
            val response = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val message = runCatching { JSONObject(response).optString("message") }.getOrDefault("")
            throw IllegalStateException(message.ifBlank { "Nulstillingsanmodningen blev afvist (HTTP $status)." })
        }
    } finally { connection.disconnect() }
}

private fun supabaseUpdatePassword(recoveryToken: String, newPassword: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL skal være HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val connection = (URL("$base/auth/v1/user").openConnection() as HttpURLConnection).apply {
        requestMethod = "PUT"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        setRequestProperty("Authorization", "Bearer $recoveryToken")
    }
    try {
        val body = JSONObject().put("password", newPassword).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        if (status !in 200..299) throw IllegalStateException("Adgangskoden kunne ikke opdateres (HTTP $status).")
    } finally { connection.disconnect() }
}

private fun newPinSalt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }
    .joinToString("") { "%02x".format(it) }

private fun hashPin(pin: String, saltHex: String): String {
    val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
    return try {
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            .joinToString("") { "%02x".format(it) }
    } finally { spec.clearPassword() }
}

private fun hexToBytes(hex: String): ByteArray? = runCatching {
    require(hex.isNotBlank() && hex.length % 2 == 0)
    hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}.getOrNull()

private fun verifyAndUpgradePin(prefs: android.content.SharedPreferences, candidate: String): Boolean {
    val storedHash = prefs.getString("pin_hash", null)
    val storedSalt = prefs.getString("pin_salt", null)
    if (!storedHash.isNullOrBlank() && !storedSalt.isNullOrBlank()) {
        val expected = hexToBytes(storedHash) ?: return false
        val actual = hexToBytes(hashPin(candidate, storedSalt)) ?: return false
        return MessageDigest.isEqual(expected, actual)
    }
    // Existing installations used a plaintext PIN; upgrade it only after a correct unlock.
    val legacyPin = prefs.getString("pin", null)
    if (legacyPin != null && candidate == legacyPin) {
        val salt = newPinSalt()
        prefs.edit().putString("pin_salt", salt).putString("pin_hash", hashPin(candidate, salt))
            .remove("pin").apply()
        return true
    }
    return false
}

private fun updatePaid(bills: List<JSONObject>, target: JSONObject, store: (String, JSONArray) -> Unit) {
    val arr = JSONArray()
    val isMarkingPaid = !target.optBoolean("paid", false)
    bills.forEach { bill ->
        arr.put(if (bill.s("id") == target.s("id")) JSONObject(bill.toString()).put("paid", isMarkingPaid) else JSONObject(bill.toString()))
    }
    if (isMarkingPaid && isRecurringRepeat(target.s("repeat"))) {
        val paidDate = runCatching { LocalDate.parse(target.s("date")) }.getOrNull()
        val anchorDay = target.optInt("recurrenceDay", paidDate?.dayOfMonth ?: 1).coerceIn(1, 31)
        val nextDate = paidDate?.let { nextRecurringOccurrence(it, LocalDate.now(), target.s("repeat"), anchorDay) }
        if (nextDate != null) {
            val exists = bills.any {
                it.s("name").trim().equals(target.s("name").trim(), true) &&
                    it.s("date") == nextDate.toString() &&
                    kotlin.math.abs(it.n("amount") - target.n("amount")) < .01 &&
                    normalizedOwner(it.s("owner", "Mig")) == normalizedOwner(target.s("owner", "Mig"))
            }
            if (!exists) arr.put(JSONObject(target.toString()).put("id", "rec-${target.s("id")}-${nextDate}").put("date", nextDate.toString()).put("recurrenceDay", anchorDay).put("paid", false))
        }
    }
    store("bills", arr)
}

private fun normalizedOwner(owner: String): String = when {
    owner.trim().equals("Kæreste", ignoreCase = true) || owner.trim().equals("Partner", ignoreCase = true) -> "partner"
    owner.trim().equals("Fælles", ignoreCase = true) -> "fælles"
    else -> "mig"
}

/** Occurrences belonging to different budgets/owners must not suppress one another. */
private fun billOccurrenceKey(bill: JSONObject): String = listOf(
    bill.s("name").trim().lowercase(Locale.ROOT),
    bill.s("date"),
    kotlin.math.round(bill.n("amount") * 100.0).toLong().toString(),
    normalizedOwner(bill.s("owner", "Mig"))
).joinToString("|")

private fun recurrenceIntervalMonths(value: String): Long? = when {
    value.contains("kvartal", true) || value.contains("quarter", true) -> 3L
    value.contains("årlig", true) || value.contains("hvert år", true) || value.contains("annual", true) || value.contains("yearly", true) -> 12L
    value.contains("måned", true) || value.contains("monthly", true) || value.contains("month", true) -> 1L
    else -> null
}

private fun isRecurringRepeat(value: String): Boolean = recurrenceIntervalMonths(value) != null

private fun nextRecurringOccurrence(baseDate: LocalDate, today: LocalDate, repeat: String, anchorDay: Int = baseDate.dayOfMonth): LocalDate? {
    val interval = recurrenceIntervalMonths(repeat) ?: return null
    val day = anchorDay.coerceIn(1, 31)
    var targetMonth = runCatching { java.time.YearMonth.from(baseDate).plusMonths(interval) }.getOrNull() ?: return null
    var next = targetMonth.atDay(day.coerceAtMost(targetMonth.lengthOfMonth()))
    var steps = 0
    while (next.isBefore(today) && steps < 600) {
        targetMonth = runCatching { targetMonth.plusMonths(interval) }.getOrNull() ?: return null
        next = targetMonth.atDay(day.coerceAtMost(targetMonth.lengthOfMonth()))
        steps++
    }
    return next.takeUnless { it.isBefore(today) }
}

private fun exportFileStamp(): String = java.text.SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(java.util.Date())

@Composable private fun MonthlyFlowCard(monthIncome: Double, monthExpenses: Double) {
    val scale = maxOf(monthIncome, monthExpenses, 1.0)
    val incomeRatio = (monthIncome / scale).toFloat().coerceIn(0f, 1f)
    val expenseRatio = (monthExpenses / scale).toFloat().coerceIn(0f, 1f)
    val net = monthIncome - monthExpenses
    val savingsRate = if (monthIncome > 0) (net / monthIncome).coerceIn(-1.0, 1.0) else 0.0
    val animatedRate by animateFloatAsState(
        targetValue = savingsRate.toFloat().coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing),
        label = "monthly-savings-rate"
    )
    SaldoCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(19.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(Icons.AutoMirrored.Filled.ShowChart, Violet)
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Månedens pengestrøm", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("Indtægter sammenholdt med udgifter", color = Muted, fontSize = 11.sp)
            }
            Surface(color = if (net >= 0) Mint.copy(alpha = .13f) else SaldoDanger.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                Text(
                    if (net >= 0) "Plus" else "Minus",
                    color = if (net >= 0) Mint else SaldoDanger,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Månedens netto", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                AnimatedMoney(net, color = if (net >= 0) Mint else SaldoDanger, fontSize = 26.sp, letterSpacing = (-.6).sp, format = ::netMoney)
                Text("Forskel mellem registrerede indtægter og udgifter", color = Muted, fontSize = 10.sp)
            }
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(62.dp)) {
                CircularProgressIndicator(progress = { animatedRate }, modifier = Modifier.fillMaxSize(), color = Mint, trackColor = Mint.copy(alpha = .12f), strokeWidth = 5.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(savingsRate * 100).toInt()}%", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("sparet", color = Muted, fontSize = 9.sp)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Indtægter", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    AnimatedMoney(monthIncome, color = Mint, fontSize = 12.sp)
                }
                SaldoProgressBar(incomeRatio, height = 10.dp, colors = listOf(Color(0xFF3CC79A), Mint), track = Mint.copy(alpha = .12f))
            }
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Udgifter", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    AnimatedMoney(monthExpenses, color = Violet, fontSize = 12.sp)
                }
                SaldoProgressBar(expenseRatio, height = 10.dp, colors = listOf(Color(0xFFD99A2B), Violet), track = Violet.copy(alpha = .12f))
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String, subtitle: String? = null) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 2.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 4.dp, height = 16.dp).background(Brush.verticalGradient(listOf(Violet, Blue)), RoundedCornerShape(50)))
            Spacer(Modifier.width(8.dp))
            Text(title, color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        if (!subtitle.isNullOrBlank()) Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun CsvTransactionPreviewRow(
    transaction: JSONObject,
    categories: List<String>,
    onTypeChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    var typeMenuExpanded by remember(transaction.s("id")) { mutableStateOf(false) }
    var categoryMenuExpanded by remember(transaction.s("id")) { mutableStateOf(false) }
    val categoryConfidence = transaction.optInt("_saldoCsvConfidence", 40).coerceIn(0, 100)
    val directionConfidence = transaction.optInt("_saldoCsvDirectionConfidence", 50).coerceIn(0, 100)
    val needsCategoryReview = transaction.optBoolean("_saldoCsvNeedsReview", categoryConfidence < 72)
    val needsDirectionReview = directionConfidence < 80
    Surface(
        color = PanelRaised,
        shape = RoundedCornerShape(13.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (needsCategoryReview || needsDirectionReview) Color(0x66E4B866) else BorderSubtle),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(transaction.s("name").ifBlank { "Post uden beskrivelse" }, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 2)
                    Text(transaction.s("date"), color = Muted, fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(money(transaction.n("amount")), color = if (transaction.s("type") == "Indtægt") Mint else White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(if (needsDirectionReview) "Retning?" else "${directionConfidence}% retning", color = if (needsDirectionReview) Color(0xFFE4B866) else Muted, fontSize = 10.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(0.85f)) {
                    TextButton(onClick = { typeMenuExpanded = true }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(transaction.s("type"), fontSize = 11.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Skift indtægt eller udgift", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }) {
                        listOf("Indtægt", "Udgift").forEach { type ->
                            DropdownMenuItem(text = { Text(type) }, onClick = { typeMenuExpanded = false; onTypeChange(type) })
                        }
                    }
                }
                Box(Modifier.weight(1.3f)) {
                    TextButton(onClick = { categoryMenuExpanded = true }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(transaction.s("category"), fontSize = 11.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Skift kategori", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(expanded = categoryMenuExpanded, onDismissRequest = { categoryMenuExpanded = false }) {
                        categories.forEach { category ->
                            DropdownMenuItem(text = { Text(category) }, onClick = { categoryMenuExpanded = false; onCategoryChange(category) })
                        }
                    }
                }
            }
            Text(
                when {
                    needsCategoryReview && needsDirectionReview -> "Kontrollér retning og kategori · ${transaction.s("_saldoCsvReason", "Usikkert forslag")}"
                    needsDirectionReview -> "Kontrollér om posten er indtægt eller udgift · $directionConfidence% sikker"
                    needsCategoryReview -> "Kontrollér kategori · $categoryConfidence% sikker · ${transaction.s("_saldoCsvReason", "Usikkert forslag")}"
                    else -> "Kategori foreslået · $categoryConfidence% sikker · ${transaction.s("_saldoCsvReason", "Beskrivelse genkendt")}"
                },
                color = if (needsCategoryReview || needsDirectionReview) Color(0xFFE4B866) else Muted,
                fontSize = 10.sp,
                maxLines = 2
            )
        }
    }
}

@Composable private fun SettingsAction(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    danger: Boolean = false,
    trailing: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.ChevronRight,
    onClick: () -> Unit
) {
    SaldoCard(
        Modifier.fillMaxWidth().animateContentSize(),
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(20.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(icon, if (danger) SaldoDanger else Violet, size = 42.dp, iconSize = 20.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = if (danger) SaldoDanger else White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
            Icon(trailing, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable private fun Metric(label: String, value: String, modifier: Modifier = Modifier, positive: Boolean? = null) {
    val accent = when (positive) { true -> Mint; false -> Violet; else -> Blue }
    SaldoCard(modifier, shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(8.dp).background(Brush.radialGradient(listOf(accent, accent.copy(alpha = .35f))), RoundedCornerShape(50)))
            Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = .05.sp, maxLines = 2)
        }
        Text(value, color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.25).sp, maxLines = 1)
    }
}
@Composable private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    SaldoCard(
        modifier,
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SaldoIconTile(icon, Violet, size = 44.dp, iconSize = 22.dp) }
        Text(label, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable private fun DashboardMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier = Modifier, amount: Double? = null) {
    SaldoCard(modifier, shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(icon, accent, size = 34.dp, iconSize = 18.dp, contentDescription = label)
            Spacer(Modifier.width(8.dp))
            Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
        if (amount != null) AnimatedMoney(amount, color = White, fontSize = 17.sp, letterSpacing = (-.35).sp)
        else Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.35).sp, maxLines = 2, lineHeight = 20.sp)
        // Decorative accent only: never pretend a fixed percentage represents the metric.
        Box(Modifier.fillMaxWidth().height(3.dp).background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = .05f))), RoundedCornerShape(50)))
    }
}

@Composable private fun UpcomingBillCard(title: String, date: String, amount: String, modifier: Modifier = Modifier, onPaid: () -> Unit) {
    SaldoCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(Icons.AutoMirrored.Filled.ReceiptLong, Violet, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("Forfalder $date", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(amount, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Surface(onClick = onPaid, color = Mint.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                    Text("Markér betalt", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                }
            }
        }
    }
}

@Composable private fun RecordRow(title: String, detail: String, amount: String, positive: Boolean, onDelete: () -> Unit, onToggle: (() -> Unit)? = null, onEdit: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    var confirmDelete by remember(title, detail, amount) { mutableStateOf(false) }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Panel,
            title = { Text("Slet posten?", color = White, fontWeight = FontWeight.Bold) },
            text = { Text("\"$title\" slettes fra Saldo. Handlingen kan ikke fortrydes, medmindre du har en sikkerhedskopi.", color = Muted) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) {
                    Text("Slet", color = SaldoDanger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Annuller", color = Muted) }
            }
        )
    }
    SaldoCard(
        modifier.fillMaxWidth().padding(vertical = 4.dp).animateContentSize(),
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoAvatar(title, positive)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                Text(detail, color = Muted, fontSize = 10.sp, maxLines = 2)
            }
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(amount, color = if (positive) Mint else White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                    if (onToggle != null) {
                        IconButton(onClick = onToggle, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Markér regning som betalt", tint = Mint, modifier = Modifier.size(17.dp))
                        }
                    }
                    if (onEdit != null) {
                        IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Default.Edit, contentDescription = "Rediger $title", tint = Blue, modifier = Modifier.size(17.dp))
                        }
                    }
                    IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Slet $title", tint = SaldoDanger, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
    }
}

@Composable private fun OwnerSummaryCard(title: String, amount: Double, modifier: Modifier = Modifier, accent: Color = Violet) {
    SaldoCard(modifier, shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(accent, RoundedCornerShape(50)))
            Spacer(Modifier.width(5.dp))
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        AnimatedMoney(amount, color = accent, fontSize = 13.sp)
        Text("forbrug denne måned", color = Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable private fun ManagedList(title: String, records: List<JSONObject>, onAdd: () -> Unit, row: @Composable (JSONObject) -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp); Button(onClick = onAdd, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Tilføj") } }; if (records.isEmpty()) { Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(8.dp)); Text("Her er tomt endnu", color = White, fontWeight = FontWeight.SemiBold); Text("Tilføj din første post for at komme i gang.", color = Muted, fontSize = 12.sp) } } }; LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) { items(records, key = { it.s("id") }) { row(it) } } } }

private data class ParsedSaldoBackup(val data: JSONObject, val settings: JSONObject?)

private fun isValidSaldoDataObject(root: JSONObject): Boolean = runCatching {
    // Empty objects are not valid backups/cloud payloads: otherwise an empty response could
    // overwrite working local financial data. Fresh installs use emptySaldoData() directly.
    if (root.length() == 0) return@runCatching false
    val knownCollections = saldoCollectionKeys
    if (knownCollections.none { key -> root.has(key) && root.opt(key) is JSONArray }) return@runCatching false
    knownCollections.all { key ->
        if (!root.has(key)) true
        else {
            val array = root.optJSONArray(key) ?: return@all false
            (0 until array.length()).all { index ->
                val item = array.optJSONObject(index) ?: return@all false
                val numericFields = when (key) {
                    "transactions", "bills" -> listOf("amount")
                    "budgets" -> listOf("limit")
                    "goals" -> listOf("target", "saved")
                    "debts" -> listOf("balance", "rate", "payment")
                    "subs" -> listOf("monthly")
                    "fuel" -> listOf("liters", "cost", "km")
                    else -> emptyList()
                }
                numericFields.all { field ->
                    if (!item.has(field)) field in setOf("saved", "rate", "payment", "km")
                    else {
                        val value = item.optDouble(field, Double.NaN)
                        value.isFinite() && kotlin.math.abs(value) <= 1_000_000_000_000.0 &&
                            (field !in setOf("amount", "limit", "target", "monthly", "liters", "cost") || value > 0.0) &&
                            (field !in setOf("saved", "rate", "payment", "balance", "km") || value >= 0.0)
                    }
                }
            }
        }
    }
}.getOrDefault(false)

private fun parseSaldoBackup(raw: String): ParsedSaldoBackup? = runCatching {
    val root = JSONObject(raw)
    if (root.optString("format") == "dk.saldo.app.backup") {
        val data = root.optJSONObject("data") ?: return@runCatching null
        if (!isValidSaldoDataObject(data)) return@runCatching null
        val settings = root.optJSONObject("settings")
        if (settings != null) {
            val salary = settings.optDouble("payAmount", 10000.0)
            if (!salary.isFinite() || salary <= 0.0 || salary > 1_000_000_000_000.0) return@runCatching null
            if (settings.optBoolean("hasPayday", false) && runCatching { LocalDate.parse(settings.optString("payday")) }.isFailure) return@runCatching null
            if (settings.optBoolean("hasCashBalance", false) && (!settings.optDouble("cashBalance", Double.NaN).isFinite() || kotlin.math.abs(settings.optDouble("cashBalance", Double.NaN)) > 1_000_000_000_000.0)) return@runCatching null
        }
        ParsedSaldoBackup(data, settings)
    } else {
        if (!isValidSaldoDataObject(root)) return@runCatching null
        ParsedSaldoBackup(root, null)
    }
}.getOrNull()

private fun isValidSaldoBackup(raw: String): Boolean = parseSaldoBackup(raw) != null

private fun saldoSettingsJson(prefs: android.content.SharedPreferences): JSONObject {
    val hasBalance = prefs.contains("cash_balance")
    val settings = JSONObject()
        .put("payAmount", prefs.getFloat("pay_amount", 10000f).toDouble())
        .put("hasPayday", prefs.contains("payday"))
        .put("payday", prefs.getString("payday", "") ?: "")
        .put("hasCashBalance", hasBalance)
    if (hasBalance) settings.put("cashBalance", prefs.getFloat("cash_balance", 0f).toDouble())
    return settings
}

private fun applySaldoSettings(settings: JSONObject, editor: android.content.SharedPreferences.Editor) {
    val salary = settings.optDouble("payAmount", 10000.0)
    if (salary.isFinite() && salary > 0.0 && salary <= 1_000_000_000_000.0) editor.putFloat("pay_amount", salary.toFloat())
    if (settings.optBoolean("hasPayday", false)) {
        val payday = settings.optString("payday", "")
        if (runCatching { LocalDate.parse(payday) }.isSuccess) editor.putString("payday", payday)
    } else editor.remove("payday")
    if (settings.optBoolean("hasCashBalance", false)) {
        val balance = settings.optDouble("cashBalance", Double.NaN)
        if (balance.isFinite() && kotlin.math.abs(balance) <= 1_000_000_000_000.0) editor.putFloat("cash_balance", balance.toFloat())
    } else editor.remove("cash_balance")
}

private fun buildBackupJson(data: JSONObject, prefs: android.content.SharedPreferences): String = JSONObject()
    .put("format", "dk.saldo.app.backup")
    .put("schemaVersion", 1)
    .put("exportedAt", java.time.Instant.now().toString())
    .put("data", JSONObject(data.toString()))
    .put("settings", saldoSettingsJson(prefs))
    .toString(2)

@Composable
private fun BudgetEditDialog(budget: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    val context = LocalContext.current
    val budgetId = budget.s("id")
    var category by remember(budgetId) { mutableStateOf(budget.s("category")) }
    var limit by remember(budgetId) {
        mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(budget.n("limit")))
    }
    var owner by remember(budgetId) { mutableStateOf(budget.s("owner", "Mig")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rediger budget") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Kategori", category, { category = it })
                Field("Månedlig grænse (kr.)", limit, { limit = it }, numeric = true)
                Text("Budget for", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Mig", "Partner", "Fælles").forEach { option ->
                        FilterChip(selected = owner == option, onClick = { owner = option }, label = { Text(option) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsedLimit = parseDanishAmount(limit)
                if (category.isBlank() || parsedLimit == null || parsedLimit <= 0.0) {
                    Toast.makeText(context, "Indtast en kategori og en gyldig månedlig grænse.", Toast.LENGTH_LONG).show()
                } else {
                    onSave(JSONObject(budget.toString()).put("category", category.trim()).put("limit", parsedLimit).put("owner", owner))
                }
            }) { Text("Gem ændringer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller") } }
    )
}

@Composable private fun DataDialog(kind: String, onDismiss: () -> Unit, onSave: (String, JSONObject) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Diverse") }; var date by remember { mutableStateOf(LocalDate.now().toString()) }; var type by remember { mutableStateOf("Udgift") }; var owner by remember { mutableStateOf("Mig") }; var extra by remember { mutableStateOf("") }; var extra2 by remember { mutableStateOf("") }; var extra3 by remember { mutableStateOf("") }; var json by remember { mutableStateOf("") }; var ocrText by remember { mutableStateOf("") }; var ocrBusy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching { InputImage.fromFilePath(context, uri) }.onSuccess { image ->
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text
                        val parsed = parseBillText(result.text)
                        if (name.isBlank()) name = parsed.first
                        if (amount.isBlank()) amount = parsed.second
                        if (parsed.third.isNotBlank()) date = parsed.third
                        ocrBusy = false
                        recognizer.close()
                    }
                    .addOnFailureListener { ocrText = "Kunne ikke læse billedet. Prøv et skarpere og mere tydeligt skærmbillede."; ocrBusy = false; recognizer.close() }
            }.onFailure { ocrText = "Filen kunne ikke åbnes som et billede. Vælg et almindeligt PNG/JPG-skærmbillede."; ocrBusy = false }
        }
    }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Backupfilen kunne ikke læses.")
                val bytes = input.use { stream ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= 10 * 1024 * 1024) { "Backupfilen er større end 10 MB." }
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
            }.onSuccess { imported ->
                json = imported
                Toast.makeText(context, "Backupfil indlæst. Kontrollér filen, og tryk Gem for at gendanne.", Toast.LENGTH_LONG).show()
            }.onFailure { error ->
                Toast.makeText(context, error.message ?: "Backupfilen kunne ikke læses.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val title = when (kind) { "post" -> "Ny post"; "bill" -> "Ny regning"; "budget" -> "Budgetgrænse"; "goal" -> "Opsparingsmål"; "debt" -> "Ny gæld"; "fuel" -> "Ny tankning"; "sub" -> "Abonnement"; "payday" -> "Lønindstillinger"; "cashbalance" -> "Nuværende saldo"; "pin" -> "PIN-kode"; "backup" -> "Backup / gendannelse"; "ocr" -> "Importér regning"; else -> "Saldo" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (kind) {
                "post" -> { Field("Beskrivelse", name, { name = it }); Field("Beløb i kr.", amount, { amount = it }, true); Field("Kategori", category, { category = it }); Field("Dato (ÅÅÅÅ-MM-DD)", date, { date = it }); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Udgift", "Indtægt").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
                }
                "bill" -> { Field("Regning / modtager", name, { name = it }); Field("Beløb", amount, { amount = it }, true); Field("Forfaldsdato", date, { date = it }); Field("Gentagelse (månedlig, kvartalsvis eller årlig)", extra, { extra = it }); Field("Kategori", category, { category = it }); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "budget" -> { Field("Kategori", name, { name = it }); Field("Månedlig grænse", amount, { amount = it }, true); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "goal" -> { Field("Opsparingsmål", name, { name = it }); Field("Målsum", amount, { amount = it }, true); Field("Allerede sparet", extra, { extra = it }, true); Field("Måldato", date, { date = it }) }
                "debt" -> { Field("Kreditor", name, { name = it }); Field("Restgæld", amount, { amount = it }, true); Field("Årlig rente (%)", extra, { extra = it }, true); Field("Månedligt afdrag", extra2, { extra2 = it }, true) }
                "fuel" -> { Field("Dato", date, { date = it }); Field("Liter", amount, { amount = it }, true); Field("Samlet pris", extra, { extra = it }, true); Field("Kilometerstand", extra2, { extra2 = it }, true) }
                "sub" -> { Field("Abonnement", name, { name = it }); Field("Pris pr. måned", amount, { amount = it }, true); Field("Næste fornyelsesdato (ÅÅÅÅ-MM-DD)", extra, { extra = it }); Field("Opsig senest (ÅÅÅÅ-MM-DD)", extra2, { extra2 = it }); Field("Note (valgfri)", extra3, { extra3 = it }); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "payday" -> { Field("Løn hver 14. dag", amount, { amount = it }, true); Field("Næste løndato", date, { date = it }) }
                "cashbalance" -> { Field("Saldo på dine konti i kr.", amount, { amount = it }, true); Text("Brug den samlede saldo, som du faktisk har til rådighed lige nu. Saldo forbinder ikke til banken og ændrer ikke dine bankkonti.", color = Muted, fontSize = 11.sp) }
                "pin" -> {
                    Field("PIN (4-8 cifre)", amount, { amount = it }, true, true)
                    Field("Gentag PIN", extra, { extra = it }, true, true)
                    Text("PIN-koden gemmes som en saltet kryptografisk hash, ikke som læsbar tekst.", color = Muted, fontSize = 11.sp)
                }
                "backup" -> {
                    Button(onClick = { backupPicker.launch("application/json") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Vælg backupfil")
                    }
                    Field("Backup-JSON (kan også indsættes)", json, { json = it })
                    Text("Vælg en Saldo-JSON-backup fra Filer/Downloads. Data gendannes først, når du trykker Gem. Maks. 10 MB. Backupen indeholder økonomidata, lønindstilling og eventuel saldo, men ikke PIN eller login-session. Gem filen sikkert.", color = Muted, fontSize = 11.sp)
                }
                "ocr" -> {
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), enabled = !ocrBusy) { Text(if (ocrBusy) "Læser skærmbillede…" else "Vælg skærmbillede af regningen") }
                    Text(if (ocrText.isBlank()) "Vælg et skærmbillede fra dit galleri. Saldo forsøger at finde afsender, beløb og dato. Kontrollér altid felterne før gemning." else "Tekst genkendt – kontrollér oplysningerne nedenfor:", color = Muted)
                    if (ocrBusy) CircularProgressIndicator(color = Violet)
                    if (ocrText.isNotBlank()) {
                        Field("Afsender / regning", name, { name = it })
                        Field("Beløb i kr.", amount, { amount = it }, true)
                        Field("Forfaldsdato (ÅÅÅÅ-MM-DD)", date, { date = it })
                        Text("Genkendt tekst", color = White, fontWeight = FontWeight.SemiBold)
                        Text(ocrText.take(1800), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = {
        val a = parseDanishAmount(amount) ?: 0.0
        val id = System.currentTimeMillis().toString()
        val nameRequired = kind in setOf("post", "bill", "budget", "goal", "debt", "sub")
        if (nameRequired && name.isBlank()) {
            Toast.makeText(context, "Udfyld navn eller beskrivelse først.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind in setOf("post", "bill", "budget", "goal", "debt", "sub", "payday", "fuel") && (amount.isBlank() || a <= 0.0)) {
            Toast.makeText(context, "Indtast et beløb større end 0 kr.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "cashbalance" && (amount.isBlank() || parseDanishAmount(amount) == null)) {
            Toast.makeText(context, "Indtast en gyldig saldo — brug 0, hvis saldoen er nul.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "goal" && extra.isNotBlank() && (parseDanishAmount(extra)?.let { it >= 0.0 } != true)) {
            Toast.makeText(context, "Indtast et gyldigt, ikke-negativt beløb for allerede opsparet.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "debt" && listOf(extra, extra2).any { it.isNotBlank() && (parseDanishAmount(it)?.let { value -> value >= 0.0 } != true) }) {
            Toast.makeText(context, "Rente og afdrag skal være gyldige, ikke-negative tal.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        val datesToValidate = when (kind) {
            "post", "bill", "goal", "fuel", "payday", "ocr" -> listOf(date)
            "sub" -> listOf(extra, extra2).filter { it.isNotBlank() }
            else -> emptyList()
        }
        if (datesToValidate.any { runCatching { LocalDate.parse(it) }.isFailure }) {
            Toast.makeText(context, "Brug datoformatet ÅÅÅÅ-MM-DD.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "fuel" && ((parseDanishAmount(extra) ?: 0.0) <= 0.0 || (parseDanishAmount(extra2) ?: -1.0) < 0.0)) {
            Toast.makeText(context, "Indtast gyldigt brændstofforbrug, pris og kilometertal.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "pin" && !amount.matches(Regex("\\d{4,8}"))) {
            Toast.makeText(context, "PIN-koden skal bestå af 4-8 cifre.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "pin" && amount != extra) {
            Toast.makeText(context, "PIN-koderne er ikke ens.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "backup" && !isValidSaldoBackup(json)) {
            Toast.makeText(context, "Backupfilen er ugyldig eller indeholder poster i et ukendt format.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        val obj = when (kind) {
            "post" -> record("id" to id, "name" to name, "amount" to a, "category" to category, "date" to date, "type" to type, "owner" to owner)
            "bill" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to extra, "category" to category, "owner" to owner, "paid" to false)
            "budget" -> record("id" to id, "category" to name, "limit" to a, "owner" to owner)
            "goal" -> record("id" to id, "name" to name, "target" to a, "saved" to (parseDanishAmount(extra) ?: 0.0), "date" to date)
            "debt" -> record("id" to id, "name" to name, "balance" to a, "rate" to (parseDanishAmount(extra) ?: 0.0), "payment" to (parseDanishAmount(extra2) ?: 0.0))
            "fuel" -> record("id" to id, "date" to date, "liters" to a, "cost" to (parseDanishAmount(extra) ?: 0.0), "km" to (parseDanishAmount(extra2) ?: 0.0))
            "sub" -> record("id" to id, "name" to name, "monthly" to a, "renewalDate" to extra, "cancelByDate" to extra2, "cancelNote" to extra3, "owner" to owner, "active" to true)
            "payday" -> record("pay" to a, "date" to date)
            "cashbalance" -> record("balance" to a)
            "pin" -> record("pin" to amount)
            "backup" -> record("json" to json)
            "ocr" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to "Engangsbetaling", "category" to category, "owner" to owner, "paid" to false, "source" to "OCR-skærmbillede")
            else -> JSONObject()
        }
        // All input validation is performed above before the record is created.
        if (kind == "ocr") {
            if (ocrText.isBlank() || name.isBlank() || a <= 0.0 || runCatching { LocalDate.parse(date) }.isFailure) {
                Toast.makeText(context, "Kontrollér afsender, beløb og dato før gemning", Toast.LENGTH_LONG).show()
                return@TextButton
            }
            onSave("bill", obj)
        } else onSave(kind, obj)
    }) { Text(if (kind == "ocr") "Opret regning" else "Gem", color = Blue) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } })
}

@Composable
private fun Field(
    label: String,
    value: String,
    onValue: (String) -> Unit,
    numeric: Boolean = false,
    password: Boolean = false,
    email: Boolean = false
) {
    var passwordVisible by remember(label) { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (password && !passwordVisible) PasswordVisualTransformation()
            else androidx.compose.ui.text.input.VisualTransformation.None,
        trailingIcon = if (password) {
            {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = if (passwordVisible) "Skjul indhold" else "Vis indhold",
                        tint = Muted
                    )
                }
            }
        } else null,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (numeric && password) KeyboardType.NumberPassword
                else if (numeric) KeyboardType.Decimal
                else if (email) KeyboardType.Email
                else if (password) KeyboardType.Password
                else KeyboardType.Text
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = White,
            unfocusedTextColor = White,
            focusedBorderColor = Violet,
            unfocusedBorderColor = Muted,
            focusedLabelColor = Violet,
            unfocusedLabelColor = Muted
        )
    )
}

private fun parseBillText(text: String): Triple<String, String, String> {
    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
    val vendor = lines.firstOrNull { line ->
        line.length in 3..70 && line.any { it.isLetter() } &&
            !line.contains("faktura", true) && !line.contains("invoice", true) &&
            !line.contains("betalingsoversigt", true)
    }?.take(70).orEmpty()

    val datePatterns = listOf(
        Regex("(?<!\\d)(20\\d{2})[-./](0?[1-9]|1[0-2])[-./]([0-2]?\\d|3[01])(?!\\d)"),
        Regex("(?<!\\d)([0-3]?\\d)[./-](0?[1-9]|1[0-2])[./-](20\\d{2})(?!\\d)")
    )
    var date = ""
    for ((index, pattern) in datePatterns.withIndex()) {
        val match = pattern.find(text) ?: continue
        date = if (index == 0) {
            runCatching { LocalDate.of(match.groupValues[1].toInt(), match.groupValues[2].toInt(), match.groupValues[3].toInt()).toString() }.getOrDefault("")
        } else {
            runCatching { LocalDate.of(match.groupValues[3].toInt(), match.groupValues[2].toInt(), match.groupValues[1].toInt()).toString() }.getOrDefault("")
        }
        if (date.isNotBlank()) break
    }

    val moneyRegex = Regex("(?i)(?:i alt|total|at betale|beløb|amount|kr\\.?)[^\\d]{0,18}([0-9][0-9 .]*[,\\.][0-9]{2})")
    val match = moneyRegex.find(text) ?: Regex("(?<!\\d)([0-9]{1,3}(?:[ .][0-9]{3})*(?:[,\\.][0-9]{2}))(?!\\d)").find(text)
    val amount = match?.groupValues?.lastOrNull()?.let { parseDanishAmount(it) }?.takeIf { it > 0 }?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
    return Triple(vendor, amount, date)
}

internal data class CsvImportPlan(
    val recordsByCollection: Map<String, List<JSONObject>>,
    val rowsRead: Int,
    val skippedRows: Int,
    val invalidRows: Int
)

internal data class CsvKnownTransaction(
    val name: String,
    val category: String,
    val type: String,
    val amount: Double
)

internal data class CsvCategoryContext(
    val existingCategories: List<String> = emptyList(),
    val knownTransactions: List<CsvKnownTransaction> = emptyList(),
    val learnedMerchantCategories: Map<String, String> = emptyMap()
)

private data class BillImportDraft(
    val id: String,
    val name: String,
    val amount: String,
    val date: String,
    val selected: Boolean = true,
    val rawText: String = ""
)

private suspend fun <T> com.google.android.gms.tasks.Task<T>.saldoAwait(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result) }
        addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
        addOnCanceledListener { if (continuation.isActive) continuation.cancel() }
    }

private fun readTextFromUri(context: Context, uri: Uri, maxBytes: Int): String {
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalArgumentException("Filen kunne ikke åbnes.")
    val bytes = input.use { stream ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "CSV-filen er større end ${maxBytes / (1024 * 1024)} MB." }
            output.write(buffer, 0, count)
        }
        output.toByteArray()
    }
    return String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
}

private fun csvNormalized(value: String): String {
    val expanded = value.lowercase(Locale.ROOT)
        .replace("æ", "ae").replace("ø", "o").replace("å", "a")
    return Normalizer.normalize(expanded, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9]+"), "")
}

private fun parseCsvMatrix(raw: String): List<List<String>> {
    val text = raw.removePrefix("\uFEFF")
    val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }
        ?: throw IllegalArgumentException("CSV-filen er tom.")
    val delimiterCounts = linkedMapOf(';' to 0, '\t' to 0, ',' to 0)
    var delimiterQuoted = false
    var delimiterIndex = 0
    while (delimiterIndex < firstLine.length) {
        val ch = firstLine[delimiterIndex]
        when {
            ch == '"' && delimiterQuoted && delimiterIndex + 1 < firstLine.length && firstLine[delimiterIndex + 1] == '"' -> delimiterIndex++
            ch == '"' -> delimiterQuoted = !delimiterQuoted
            !delimiterQuoted && delimiterCounts.containsKey(ch) -> delimiterCounts[ch] = (delimiterCounts[ch] ?: 0) + 1
        }
        delimiterIndex++
    }
    val delimiter = delimiterCounts.entries.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key ?: ';'
    val rows = mutableListOf<List<String>>()
    val row = mutableListOf<String>()
    val cell = StringBuilder()
    var quoted = false
    var i = 0
    while (i < text.length) {
        val ch = text[i]
        when {
            ch == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> {
                cell.append('"'); i++
            }
            ch == '"' -> quoted = !quoted
            ch == delimiter && !quoted -> {
                row += cell.toString(); cell.setLength(0)
            }
            (ch == '\n' || ch == '\r') && !quoted -> {
                if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                row += cell.toString(); cell.setLength(0)
                if (row.any { it.isNotBlank() }) rows += row.toList()
                row.clear()
            }
            else -> cell.append(ch)
        }
        i++
    }
    row += cell.toString()
    if (row.any { it.isNotBlank() }) rows += row.toList()
    require(!quoted) { "CSV-filen indeholder an uafsluttet tekst med anførselstegn." }
    return rows
}

private fun parseCsvDate(raw: String): String? {
    val value = raw.trim().removePrefix("\uFEFF")
    if (value.isBlank()) return null
    runCatching { return LocalDate.parse(value).toString() }
    val formats = listOf(
        "d.M.uuuu", "dd.MM.uuuu", "d/M/uuuu", "dd/MM/uuuu",
        "d-M-uuuu", "dd-MM-uuuu", "uuuu/M/d", "uuuu.MM.dd"
    )
    formats.forEach { pattern ->
        runCatching { return LocalDate.parse(value, java.time.format.DateTimeFormatter.ofPattern(pattern, Locale.ROOT)).toString() }
    }
    return null
}

private fun parseCsvMoney(raw: String): Double? {
    var value = raw.trim()
    if (value.isBlank()) return null
    val parenthesized = value.startsWith("(") && value.endsWith(")")
    value = value.removePrefix("(").removeSuffix(")")
        .replace(Regex("(?i)kr\\.?|dkk|sek|eur|usd"), "")
        .replace("\u00A0", "").replace("\u202F", "").replace(" ", "")
        .replace(Regex("[^0-9,.+-]"), "")
    if (value.isBlank() || value in setOf(".", ",", "-", "+")) return null
    val negative = parenthesized || value.startsWith("-")
    value = value.removePrefix("+").removePrefix("-")
    val comma = value.lastIndexOf(',')
    val dot = value.lastIndexOf('.')
    val normalized = when {
        comma >= 0 && dot >= 0 -> {
            // The rightmost separator is the decimal separator: 1.234,56 or 1,234.56.
            if (comma > dot) value.replace(".", "").replace(',', '.') else value.replace(",", "")
        }
        comma >= 0 -> {
            val decimals = value.length - comma - 1
            when {
                value.count { it == ',' } > 1 && decimals in 1..2 -> value.substring(0, comma).replace(",", "") + "." + value.substring(comma + 1)
                value.count { it == ',' } > 1 -> value.replace(",", "")
                decimals in 1..2 -> value.replace(',', '.')
                decimals == 3 && value.substring(0, comma).length in 1..3 -> value.replace(",", "")
                else -> value.replace(',', '.')
            }
        }
        dot >= 0 -> {
            val decimals = value.length - dot - 1
            when {
                value.count { it == '.' } > 1 && decimals in 1..2 -> value.substring(0, dot).replace(".", "") + "." + value.substring(dot + 1)
                value.count { it == '.' } > 1 -> value.replace(".", "")
                decimals == 3 && value.substring(0, dot).length in 1..3 -> value.replace(".", "")
                else -> value
            }
        }
        else -> value
    }
    val parsed = normalized.toDoubleOrNull() ?: return null
    if (!parsed.isFinite() || kotlin.math.abs(parsed) > 1_000_000_000_000.0) return null
    return if (negative) -kotlin.math.abs(parsed) else kotlin.math.abs(parsed)
}

internal fun csvRecordFingerprint(collection: String, item: JSONObject): String {
    fun text(key: String) = item.s(key).trim().lowercase(Locale.ROOT)
    fun amount(key: String) = String.format(Locale.ROOT, "%.2f", item.n(key))
    fun owner() = normalizedOwner(item.s("owner", "Mig"))
    val parts = when (collection) {
        "transactions" -> listOf(text("name"), text("date"), text("type"), owner(), amount("amount"))
        "bills" -> listOf(text("name"), text("date"), owner(), amount("amount"))
        "budgets" -> listOf(text("category"), owner())
        "goals" -> listOf(text("name"), text("date"), amount("target"), amount("saved"))
        "debts" -> listOf(text("name"), amount("balance"))
        "subs" -> listOf(text("name"), text("renewalDate"), owner(), amount("monthly"))
        "fuel" -> listOf(text("date"), amount("liters"), amount("cost"), amount("km"))
        else -> listOf(item.toString())
    }
    return collection + "|" + parts.joinToString("\u001f")
}

private fun csvRecordsEquivalent(collection: String, a: JSONObject, b: JSONObject): Boolean =
    csvRecordFingerprint(collection, a) == csvRecordFingerprint(collection, b)

private fun csvContainsAny(value: String, vararg words: String): Boolean {
    val normalized = csvNormalized(value)
    return words.any { word -> normalized.contains(csvNormalized(word)) }
}

/** Maps a bank-export direction/type column to Saldo's two transaction types. */
private fun csvDirection(value: String): String? {
    val n = csvNormalized(value)
    if (n.isBlank()) return null
    // Explicit card/purchase terms must win over incidental words such as "credit card".
    if (listOf("kortbetaling", "kortkoeb", "debitcard", "creditcard", "kreditkort", "withdrawal", "udbetaling", "udgift", "expense", "debit", "debet", "outflow", "cashwithdrawal", "purchase", "koeb").any { n.contains(it) }) {
        return "Udgift"
    }
    if (listOf("løn", "loen", "salary", "payroll", "indbetaling", "deposit", "refund", "refusion", "cashback", "credit", "kredit", "indtægt", "indtaegt", "income", "inflow", "incoming", "incomingtransfer", "børnepenge", "boernepenge", "dagpenge", "kontanthjælp", "kontanthjaelp", "feriepenge", "renteindtægt", "renteindtaegt", "received").any { n.contains(csvNormalized(it)) }) {
        return "Indtægt"
    }
    return when (n) {
        "ind", "indgaaende", "modtaget", "positiv", "plus", "tilgang" -> "Indtægt"
        "ud", "udgaaende", "negativ", "minus", "afgang", "betaling" -> "Udgift"
        else -> null
    }
}

private fun csvDescriptionLooksLikeIncome(description: String): Boolean = csvContainsAny(
    description,
    "løn", "lønoverførsel", "loen", "salary", "payroll", "wages", "børnepenge", "boernepenge",
    "kontanthjælp", "kontanthjaelp", "dagpenge", "feriepenge", "su udbetaling", "udbetaling danmark",
    "pension", "refusion", "tilbagebetaling", "refund", "cashback", "renteindtægt", "renteindtaegt", "overførsel fra", "overfoersel fra", "modtaget fra", "indbetaling"
)

private data class CsvCategorySuggestion(
    val category: String,
    val confidence: Int,
    val reason: String
)

private fun csvMerchantKey(value: String): String {
    val expanded = Normalizer.normalize(
        value.lowercase(Locale.ROOT).replace("æ", "ae").replace("ø", "o").replace("å", "a"),
        Normalizer.Form.NFD
    ).replace(Regex("\\p{Mn}+"), "")
    val stopWords = setOf(
        "kort", "kortkoeb", "kortbetaling", "betaling", "betalingsservice", "pbs", "dankort", "visa",
        "mastercard", "purchase", "card", "payment", "transaction", "transaktion", "pos", "køb", "koeb", "outgoing", "outgoingpayment",
        "overfoersel", "overførsel", "udbetaling", "indbetaling", "fra", "til", "ref", "reference", "nr"
    )
    return Regex("[a-z0-9]+").findAll(expanded).map { it.value }
        .filter { token -> token.length >= 2 && !token.all { it.isDigit() } && token !in stopWords }
        .take(5).joinToString("-")
}

private fun csvLearningKey(description: String, transactionType: String): String =
    "${csvNormalized(transactionType)}|${csvMerchantKey(description)}"

private fun csvIsGenericCategory(value: String): Boolean = csvNormalized(value) in setOf(
    "", "diverse", "importeret", "ukendt", "unknown", "other", "andet", "ovrigt", "uncategorized",
    "uncategorised", "none", "na", "notcategorized", "generel", "indtaegt", "udgift", "expense",
    "income", "transaction", "transaktion", "standard"
)

private fun csvPreferredCategory(context: CsvCategoryContext, candidates: List<String>, fallback: String): String {
    return candidates.firstNotNullOfOrNull { candidate ->
        context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(candidate) }
    } ?: fallback
}

private data class CsvCategoryRule(
    val keywords: List<String>,
    val preferredCategories: List<String>,
    val fallback: String,
    val confidence: Int,
    val explanation: String
)

private fun csvCategoryRules(transactionType: String): List<CsvCategoryRule> {
    if (transactionType == "Indtægt") return listOf(
        CsvCategoryRule(listOf("løn", "loen", "salary", "payroll", "wages", "lønoverførsel", "arbejdsgiver", "lonoverforsel"), listOf("Løn", "Lønindkomst"), "Løn", 98, "Beskrivelsen ligner en lønudbetaling"),
        CsvCategoryRule(listOf("børnepenge", "boernepenge", "kontanthjælp", "kontanthjaelp", "dagpenge", "feriepenge", "su udbetaling", "udbetaling danmark", "pension", "ydelse"), listOf("Ydelser", "Børnepenge", "Kontanthjælp"), "Ydelser", 94, "Beskrivelsen ligner en offentlig ydelse"),
        CsvCategoryRule(listOf("refusion", "tilbagebetaling", "refund", "cashback", "renteindtægt", "renteindtaegt", "returvare"), listOf("Tilbagebetaling", "Refunderinger"), "Tilbagebetaling", 93, "Beskrivelsen ligner en tilbagebetaling"),
        CsvCategoryRule(listOf("rente", "interest payment", "renteindtægt", "renteindtaegt"), listOf("Renteindtægter", "Renter"), "Renteindtægter", 87, "Beskrivelsen nævner renter"),
        CsvCategoryRule(listOf("overførsel fra", "overfoersel fra", "mobilepay fra", "modtaget fra", "indbetaling fra"), listOf("Overførsler", "Private overførsler"), "Overførsler", 78, "Beskrivelsen ligner en overførsel"),
    )
    return listOf(
        CsvCategoryRule(listOf("daginstitution", "dagpleje", "børnehave", "boernehave", "sfo", "fritidsordning", "skolebetaling", "børnepasning", "boernepasning"), listOf("Daginstitution", "Familie", "Børn"), "Daginstitution", 96, "Beskrivelsen ligner en udgift til pasning eller skole"),
        CsvCategoryRule(listOf("husleje", "boligforening", "realkredit", "boligafgift", "boliglaan", "boliglån", "ejendomsskat", "husleje"), listOf("Husleje", "Bolig"), "Husleje", 96, "Beskrivelsen ligner en boligbetaling"),
        CsvCategoryRule(listOf("forsikring", "insurance", "codan", "topdanmark", "tryg", "alm brand", "gjensidige"), listOf("Forsikring", "Regninger"), "Forsikring", 94, "Beskrivelsen ligner en forsikringsbetaling"),
        CsvCategoryRule(listOf("internet", "bredbånd", "bredbaand", "fiber", "yousee internet"), listOf("Internet", "Regninger"), "Internet", 94, "Beskrivelsen ligner en internetregning"),
        CsvCategoryRule(listOf("mobilabonnement", "mobilregning", "mobilbetaling", "telenor", "telia", "3 danmark", "telefonregning", "mobil"), listOf("Mobil", "Telefon", "Regninger"), "Mobil", 92, "Beskrivelsen ligner en mobil- eller telefonregning"),
        CsvCategoryRule(listOf("elregning", "elbetaling", "elselskab", "stromregning", "strømregning", "elafgift", "norlys el"), listOf("El", "El og vand", "Regninger"), "El", 91, "Beskrivelsen ligner en elregning"),
        CsvCategoryRule(listOf("varmeregning", "fjernvarme", "varmebetaling", "varmeværk", "varmevaerk", "varmeudgift"), listOf("Varme", "El og vand", "Regninger"), "Varme", 92, "Beskrivelsen ligner en varmeregning"),
        CsvCategoryRule(listOf("vandregning", "vandafgift", "vandforsyning", "vandværk", "vandvaerk"), listOf("Vand", "El og vand", "Regninger"), "Vand", 91, "Beskrivelsen ligner en vandregning"),
        CsvCategoryRule(listOf("netto", "føtex", "foetex", "rema1000", "rema 1000", "lidl", "coop", "superbrugsen", "brugsen", "meny", "bilka", "aldi", "dagli brugsen", "dagligvarer", "discount"), listOf("Dagligvarer", "Mad"), "Dagligvarer", 94, "Butikken ligner et dagligvareindkøb"),
        CsvCategoryRule(listOf("restaurant", "cafe", "café", "wolt", "justeat", "foodora", "pizza", "takeaway", "kantine", "mcdonald", "burger king", "sunset boulevard"), listOf("Spisesteder", "Mad ude", "Mad"), "Spisesteder", 91, "Beskrivelsen ligner mad ude eller takeaway"),
        CsvCategoryRule(listOf("okbenzin", "circlek", "q8", "shell", "benzin", "diesel", "tankstation", "brændstof", "braendstof", "fuel"), listOf("Brændstof", "Bil", "Transport"), "Brændstof", 94, "Beskrivelsen ligner brændstof eller tankning"),
        CsvCategoryRule(listOf("dsb", "rejsekort", "togbillet", "busbillet", "metro", "pendlerkort", "flextrafik", "taxa", "taxi", "uber", "bolt", "parkering", "brobizz"), listOf("Transport", "Parkering", "Bil"), "Transport", 90, "Beskrivelsen ligner transport"),
        CsvCategoryRule(listOf("netflix", "spotify", "disneyplus", "disney plus", "tv2play", "tv 2 play", "hbo", "viaplay", "youtube premium", "icloud", "google one", "streaming", "abonnement", "amzn prime"), listOf("Streaming", "Abonnementer"), "Abonnementer", 95, "Tjenesten ligner et abonnement"),
        CsvCategoryRule(listOf("apotek", "læge", "laege", "tandlæge", "tandlaege", "medicin", "hospital", "sundhed", "fysioterapi", "optiker"), listOf("Sundhed", "Medicin"), "Sundhed", 92, "Beskrivelsen ligner en sundhedsudgift"),
        CsvCategoryRule(listOf("fitness", "fitnesscenter", "fitness world", "puregym", "sportsklub", "motionscenter"), listOf("Fitness", "Sport"), "Fitness", 91, "Beskrivelsen ligner fitness eller sport"),
        CsvCategoryRule(listOf("ikea", "jysk", "amazon", "amzn", "zalando", "h&m", "zara", "jemogfix", "jem og fix", "harald nyborg", "bauhaus", "elgiganten", "power dk"), listOf("Shopping", "Hjem"), "Shopping", 89, "Beskrivelsen ligner et varekøb"),
        CsvCategoryRule(listOf("opsparing", "opsparingskonto", "fast overførsel til opsparing", "fast overfoersel til opsparing", "savings transfer"), listOf("Opsparing"), "Opsparing", 91, "Beskrivelsen ligner en overførsel til opsparing"),
        CsvCategoryRule(listOf("bankgebyr", "kortgebyr", "kontogebyr", "gebyr", "fee"), listOf("Gebyrer", "Regninger"), "Gebyrer", 88, "Beskrivelsen ligner et bank- eller servicegebyr"),
        CsvCategoryRule(listOf("afdrag", "lånebetaling", "laanebetaling", "kreditkortafdrag", "forbrugslån", "forbrugslaan"), listOf("Gæld", "Afdrag"), "Gæld", 87, "Beskrivelsen ligner et gældsafdrag"),
        CsvCategoryRule(listOf("hund", "dyrlæge", "dyrelaege", "dyreklinik", "kattefoder", "hundefoder", "dyrehandel"), listOf("Kæledyr", "Dyr"), "Kæledyr", 88, "Beskrivelsen ligner en udgift til kæledyr"),
    )
}

/** Uses explicit categories, corrections and transaction history before conservative text rules. */
private fun resolveCsvCategory(
    rawCategory: String,
    description: String,
    transactionType: String,
    amount: Double,
    context: CsvCategoryContext
): CsvCategorySuggestion {
    val raw = rawCategory.trim()
    val n = csvNormalized(raw)
    if (!csvIsGenericCategory(raw)) {
        val aliases = when (n) {
            "food", "groceries", "dagligvarer", "madvarer" -> listOf("Dagligvarer", "Mad")
            "transportation", "transport" -> listOf("Transport")
            "housing", "rent", "bolig" -> listOf("Husleje", "Bolig")
            "utilities", "bills", "bill", "regninger" -> listOf("Regninger")
            "subscriptions", "subscription" -> listOf("Streaming", "Abonnementer")
            "health", "medical" -> listOf("Sundhed")
            "shopping" -> listOf("Shopping")
            "salary", "payroll" -> listOf("Løn")
            "income" -> if (transactionType == "Indtægt") listOf("Indtægt") else emptyList()
            "indtaegt" -> if (transactionType == "Indtægt") listOf("Indtægt") else emptyList()
            "expense", "udgift" -> if (transactionType == "Udgift") listOf("Diverse") else emptyList()
            else -> emptyList()
        }
        if (aliases.isNotEmpty()) {
            val fallback = if (n in setOf("subscriptions", "subscription")) "Abonnementer" else aliases.first()
            return CsvCategorySuggestion(csvPreferredCategory(context, aliases, fallback), 98, "Kategori fra CSV-filen")
        }
        val userExistingCategory = context.existingCategories.firstOrNull { csvNormalized(it) == n }
        return CsvCategorySuggestion(userExistingCategory ?: raw, 98, "Kategori fra CSV-filen")
    }

    val merchantKey = csvMerchantKey(description)
    if (merchantKey.isNotBlank()) {
        val learned = context.learnedMerchantCategories[csvLearningKey(description, transactionType)]
        if (!learned.isNullOrBlank()) {
            val existing = context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(learned) }
            return CsvCategorySuggestion(existing ?: learned, 99, "Din tidligere kategorisering af denne afsender")
        }

        val history = context.knownTransactions.filter { known ->
            known.type == transactionType && !csvIsGenericCategory(known.category) &&
                csvMerchantKey(known.name).isNotBlank() && csvMerchantKey(known.name) == merchantKey
        }
        if (history.isNotEmpty()) {
            val category = history.groupBy { it.category }.entries
                .maxByOrNull { it.value.size }?.key
            if (!category.isNullOrBlank()) {
                val closeAmount = history.any { known ->
                    val oldAmount = kotlin.math.abs(known.amount)
                    oldAmount > 0.0 && kotlin.math.abs(kotlin.math.abs(amount) - oldAmount) <= maxOf(5.0, oldAmount * 0.03)
                }
                val existing = context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(category) }
                return CsvCategorySuggestion(existing ?: category, if (closeAmount) 99 else 95,
                    if (closeAmount) "Samme afsender og næsten samme beløb som før" else "Samme afsender som i dine tidligere poster")
            }
        }
    }

    val matchedRule = csvCategoryRules(transactionType).firstOrNull { rule -> csvContainsAny(description, *rule.keywords.toTypedArray()) }
    if (matchedRule != null) {
        return CsvCategorySuggestion(
            csvPreferredCategory(context, matchedRule.preferredCategories, matchedRule.fallback),
            matchedRule.confidence,
            matchedRule.explanation
        )
    }

    val descNormalized = csvNormalized(description)
    val categoryMention = context.existingCategories
        .filterNot(::csvIsGenericCategory)
        .filter { csvNormalized(it).length >= 4 && descNormalized.contains(csvNormalized(it)) }
        .maxByOrNull { csvNormalized(it).length }
    if (categoryMention != null) {
        return CsvCategorySuggestion(categoryMention, 80, "Beskrivelsen nævner en af dine eksisterende kategorier")
    }

    return if (transactionType == "Indtægt") {
        CsvCategorySuggestion("Indtægt", 42, "Ukendt indtægtstype – kontrollér kategorien")
    } else {
        CsvCategorySuggestion("Diverse", 32, "Der er ikke nok oplysninger til en sikker kategori")
    }
}

private fun csvDirectionConfidence(
    explicitFlow: String?,
    splitColumnDirection: String?,
    rawAmount: Double,
    description: String
): Int = when {
    splitColumnDirection != null && explicitFlow != null && splitColumnDirection != explicitFlow -> 55
    splitColumnDirection != null -> 99
    explicitFlow == "Indtægt" && rawAmount < 0 -> 60
    explicitFlow != null -> 99
    rawAmount < 0 -> 97
    csvDescriptionLooksLikeIncome(description) -> 76
    else -> 54
}

private val csvTransientFields = listOf(
    "_saldoCsvConfidence", "_saldoCsvReason", "_saldoCsvNeedsReview", "_saldoCsvSuggestedCategory",
    "_saldoCsvDirectionConfidence", "_saldoCsvDirectionReason", "_saldoCsvUserChangedCategory", "_saldoCsvUserChangedType"
)

private val csvBuiltInCategories = listOf(
    "Løn", "Ydelser", "Tilbagebetaling", "Renteindtægter", "Overførsler", "Indtægt",
    "Bolig", "Husleje", "Familie", "Daginstitution", "Mad", "Dagligvarer", "Transport", "Brændstof",
    "Parkering", "Bil", "Regninger", "El", "Varme", "Vand", "Internet", "Mobil", "Forsikring",
    "Abonnementer", "Streaming", "Sundhed", "Fitness", "Shopping", "Opsparing", "Gæld", "Gebyrer",
    "Kæledyr", "Diverse"
)

private fun csvCategoryOptions(plan: CsvImportPlan, context: CsvCategoryContext): List<String> {
    val seen = linkedSetOf<String>()
    return (csvBuiltInCategories + context.existingCategories + plan.recordsByCollection["transactions"].orEmpty().map { it.s("category") })
        .map(String::trim).filter(String::isNotBlank)
        .filter { seen.add(csvNormalized(it)) }
}

private fun updateCsvPlanTransaction(
    plan: CsvImportPlan,
    id: String,
    newType: String? = null,
    newCategory: String? = null,
    context: CsvCategoryContext = CsvCategoryContext()
): CsvImportPlan {
    val updated = plan.recordsByCollection.mapValues { (_, rows) -> rows.map { row ->
        if (row.s("id") != id) return@map row
        val item = JSONObject(row.toString())
        if (newType != null && newType != item.s("type")) {
            val suggestion = resolveCsvCategory("", item.s("name"), newType, item.n("amount"), context)
            item.put("type", newType)
                .put("category", suggestion.category)
                .put("_saldoCsvSuggestedCategory", suggestion.category)
                .put("_saldoCsvConfidence", suggestion.confidence)
                .put("_saldoCsvReason", suggestion.reason)
                .put("_saldoCsvNeedsReview", suggestion.confidence < 72)
                .put("_saldoCsvDirectionConfidence", 100)
                .put("_saldoCsvDirectionReason", "Retning valgt af dig")
                .put("_saldoCsvUserChangedType", true)
                .put("_saldoCsvUserChangedCategory", false)
        }
        if (newCategory != null && newCategory != item.s("category")) {
            item.put("category", newCategory)
                .put("_saldoCsvConfidence", 100)
                .put("_saldoCsvReason", "Kategori valgt af dig")
                .put("_saldoCsvNeedsReview", false)
                .put("_saldoCsvUserChangedCategory", true)
        }
        item
    } }
    return plan.copy(recordsByCollection = updated)
}

private fun csvLearnedCategoriesPreferenceKey(prefs: android.content.SharedPreferences): String {
    val userId = prefs.getString("active_account_user_id", null).orEmpty()
    return if (userId.isBlank()) "csv_learned_categories_local" else "csv_learned_categories_$userId"
}

private fun loadCsvLearnedCategories(prefs: android.content.SharedPreferences): Map<String, String> {
    val raw = prefs.getString(csvLearnedCategoriesPreferenceKey(prefs), null).orEmpty()
    val json = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyMap()
    return json.keys().asSequence().mapNotNull { key ->
        json.optString(key).takeIf { it.isNotBlank() }?.let { key to it }
    }.toMap()
}

private fun persistCsvCategoryCorrection(prefs: android.content.SharedPreferences, description: String, type: String, category: String) {
    val key = csvLearningKey(description, type)
    if (csvMerchantKey(description).isBlank() || category.isBlank()) return
    val prefKey = csvLearnedCategoriesPreferenceKey(prefs)
    val json = runCatching { JSONObject(prefs.getString(prefKey, "{}") ?: "{}") }.getOrElse { JSONObject() }
    json.put(key, category)
    // Keep the local learner bounded; recent corrections are useful, unbounded history is not.
    val keys = json.keys().asSequence().toList()
    if (keys.size > 300) keys.take(keys.size - 300).forEach(json::remove)
    prefs.edit().putString(prefKey, json.toString()).apply()
}

private fun buildCsvCategoryContext(data: JSONObject, prefs: android.content.SharedPreferences): CsvCategoryContext {
    val categories = linkedSetOf<String>()
    val known = mutableListOf<CsvKnownTransaction>()
    fun collectCategories(collection: String, categoryKey: String) {
        (data.optJSONArray(collection) ?: JSONArray()).objects().forEach { item ->
            item.s(categoryKey).trim().takeIf { it.isNotBlank() && !csvIsGenericCategory(it) }?.let(categories::add)
        }
    }
    collectCategories("transactions", "category")
    collectCategories("bills", "category")
    collectCategories("budgets", "category")
    (data.optJSONArray("transactions") ?: JSONArray()).objects().takeLast(1500).forEach { item ->
        val name = item.s("name").trim()
        val category = item.s("category").trim()
        if (name.isNotBlank() && category.isNotBlank()) known += CsvKnownTransaction(name, category, item.s("type", "Udgift"), kotlin.math.abs(item.n("amount")))
    }
    (data.optJSONArray("bills") ?: JSONArray()).objects().takeLast(500).forEach { item ->
        val name = item.s("name").trim()
        val category = item.s("category").trim()
        if (name.isNotBlank() && category.isNotBlank()) known += CsvKnownTransaction(name, category, "Udgift", kotlin.math.abs(item.n("amount")))
    }
    return CsvCategoryContext(categories.toList(), known.takeLast(1800), loadCsvLearnedCategories(prefs))
}

internal fun parseSaldoCsv(raw: String, categoryContext: CsvCategoryContext = CsvCategoryContext()): CsvImportPlan {
    val rows = parseCsvMatrix(raw)
    require(rows.size >= 2) { "CSV-filen skal indeholde en overskriftsrække og mindst én datarække." }
    val headers = rows.first().map(::csvNormalized)
    fun indexOfAny(vararg aliases: String): Int {
        val normalizedAliases = aliases.map(::csvNormalized).toSet()
        return headers.indexOfFirst { it in normalizedAliases }
    }
    val typeIndex = indexOfAny("type", "posttype")
    val directionIndex = indexOfAny(
        "retning", "indtægt/udgift", "indtaegt/udgift", "transaktionsretning", "transaction type",
        "transaktionstype", "posteringstype", "transaktionsart", "betalingstype", "ind-/udbetaling",
        "debet/kredit", "debit/credit", "direction", "flow", "bevægelse", "bevægelsestype"
    )
    val nameIndex = indexOfAny(
        "navn", "beskrivelse", "tekst", "description", "name", "modtager", "betalingstekst", "transaktion",
        "merchant", "payee", "modpart", "afsender", "reference", "details", "transaction details"
    )
    val amountIndex = indexOfAny(
        "beløb", "belob", "amount", "value", "sum", "beløb dkk", "belob dkk", "transaktionsbeløb",
        "amount dkk", "amount (dkk)", "amount kr", "amount (kr)"
    )
    val creditIndex = indexOfAny(
        "indbetaling", "indbetalinger", "ind", "kredit", "credit", "deposit", "deposits", "income",
        "indtægt", "indtaegt", "beløb ind", "belob ind", "kreditbeløb", "kreditbelob", "kreditbeløb dkk", "credit amount", "deposit amount", "tilgang", "indgående beløb", "indgaaende beloeb"
    )
    val debitIndex = indexOfAny(
        "udbetaling", "udbetalinger", "ud", "debet", "debit", "withdrawal", "withdrawals", "expense",
        "udgift", "beløb ud", "belob ud", "debetbeløb", "debetbelob", "debetbeløb dkk", "debit amount", "withdrawal amount", "afgang", "udgående beløb", "udgaaende beloeb", "korttræk", "korttraek"
    )
    val categoryIndex = indexOfAny("kategori", "category", "gruppe", "expense category", "category name")
    val dateIndex = indexOfAny("dato", "date", "bogføringsdato", "bogfoeringsdato", "transaktionsdato", "valutadato", "booking date", "transaction date", "posting date")
    val statusIndex = indexOfAny("status", "retning", "indtægt/udgift", "indtaegt/udgift")
    val ownerIndex = indexOfAny("ejer", "owner", "budgetejer")
    val isSaldoExport = typeIndex >= 0 && nameIndex >= 0 && amountIndex >= 0 && categoryIndex >= 0 && dateIndex >= 0 && statusIndex >= 0 && ownerIndex >= 0
    val hasSplitAmounts = creditIndex >= 0 || debitIndex >= 0
    if (nameIndex < 0 || dateIndex < 0 || (amountIndex < 0 && !hasSplitAmounts)) {
        throw IllegalArgumentException(
            "CSV-formatet blev ikke genkendt. Filen skal have dato og beskrivelse samt enten en beløbskolonne eller separate debet-/kreditkolonner."
        )
    }

    val collected = linkedMapOf<String, MutableList<JSONObject>>()
    val seenFingerprints = mutableSetOf<String>()
    var skipped = 0
    var invalid = 0
    var parsedRows = 0

    fun field(row: List<String>, index: Int): String = if (index in row.indices) row[index].trim() else ""
    val importIdPrefix = "csv-${System.currentTimeMillis()}"
    fun uniqueId(rowNumber: Int) = "$importIdPrefix-$rowNumber"
    fun append(collection: String, obj: JSONObject) {
        if (!seenFingerprints.add(csvRecordFingerprint(collection, obj))) {
            skipped++
        } else {
            collected.getOrPut(collection) { mutableListOf() }.add(obj)
        }
    }
    fun moneyInStatus(status: String): Double = Regex("[-+]?[0-9][0-9 .]*(?:,[0-9]+)?")
        .find(status)?.value?.let { parseCsvMoney(it) }?.let { kotlin.math.abs(it) } ?: 0.0

    for (rowIndex in 1 until rows.size) {
        val row = rows[rowIndex]
        if (row.all { it.isBlank() }) continue
        parsedRows++
        val name = field(row, nameIndex).trim()
        val rawDate = field(row, dateIndex)
        val date = parseCsvDate(rawDate)
        val categoryRaw = field(row, categoryIndex)
        val status = field(row, statusIndex)
        val owner = field(row, ownerIndex).ifBlank { "Mig" }
        val normalizedType = csvNormalized(field(row, typeIndex))

        var splitColumnDirection: String? = null
        var rawAmount: Double? = null
        if (hasSplitAmounts) {
            val credit = if (creditIndex >= 0) parseCsvMoney(field(row, creditIndex))?.let { kotlin.math.abs(it) } else null
            val debit = if (debitIndex >= 0) parseCsvMoney(field(row, debitIndex))?.let { kotlin.math.abs(it) } else null
            val hasCredit = (credit ?: 0.0) > 0.0
            val hasDebit = (debit ?: 0.0) > 0.0
            when {
                hasCredit && hasDebit -> {
                    // If both columns contain values, use an explicit amount column if present;
                    // otherwise skip rather than guessing and silently corrupting the balance.
                    val explicitAmount = if (amountIndex >= 0) parseCsvMoney(field(row, amountIndex)) else null
                    if (explicitAmount == null) { invalid++; continue }
                    rawAmount = explicitAmount
                    splitColumnDirection = csvDirection(field(row, directionIndex))
                }
                hasCredit -> { rawAmount = credit; splitColumnDirection = "Indtægt" }
                hasDebit -> { rawAmount = debit?.let { -it }; splitColumnDirection = "Udgift" }
                else -> rawAmount = if (amountIndex >= 0) parseCsvMoney(field(row, amountIndex)) else null
            }
        } else {
            rawAmount = parseCsvMoney(field(row, amountIndex))
        }
        val amount = rawAmount?.let { kotlin.math.abs(it) }
        if (name.isBlank() || rawAmount == null) { invalid++; continue }
        val explicitFlow = csvDirection(field(row, directionIndex))
            ?: csvDirection(field(row, typeIndex))
            ?: csvDirection(status)
        val directionConfidence = csvDirectionConfidence(explicitFlow, splitColumnDirection, rawAmount, name)

        if (isSaldoExport) {
            when (normalizedType) {
                "post", "transaction", "transaktion" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val transactionType = splitColumnDirection ?: explicitFlow ?: if (rawAmount < 0) "Udgift" else if (csvDescriptionLooksLikeIncome(name)) "Indtægt" else "Udgift"
                    val suggestion = resolveCsvCategory(categoryRaw, name, transactionType, amount, categoryContext)
                    append("transactions", record(
                        "id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "category" to suggestion.category,
                        "date" to date, "type" to transactionType, "owner" to owner,
                        "_saldoCsvConfidence" to suggestion.confidence, "_saldoCsvReason" to suggestion.reason,
                        "_saldoCsvNeedsReview" to (suggestion.confidence < 72), "_saldoCsvSuggestedCategory" to suggestion.category,
                        "_saldoCsvDirectionConfidence" to directionConfidence,
                        "_saldoCsvDirectionReason" to if (directionConfidence >= 90) "Retning bestemt af CSV-filen eller beløbets fortegn" else "Retningen er foreslået ud fra beskrivelsen"
                    ))
                }
                "regning", "bill", "invoice" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val paid = csvNormalized(status) in setOf("betalt", "paid", "true")
                    append("bills", record("id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "date" to date, "repeat" to "Engangsbetaling", "category" to categoryRaw.ifBlank { "Regninger" }, "owner" to owner, "paid" to paid))
                }
                "budget" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    append("budgets", record("id" to uniqueId(rowIndex), "category" to name, "limit" to amount, "owner" to owner))
                }
                "opsparingsmal", "savingsgoal", "goal" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    val saved = moneyInStatus(status)
                    append("goals", record("id" to uniqueId(rowIndex), "name" to name, "target" to amount, "saved" to saved, "date" to (date ?: "")))
                }
                "gaeld", "debt" -> {
                    if (amount == null || amount < 0.0) { invalid++; continue }
                    val rate = Regex("(?i)rente\\s+([0-9]+(?:[,.][0-9]+)?)%")
                        .find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    val payment = Regex("(?i)afdrag\\s+(.+)$").find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) }?.let { kotlin.math.abs(it) } ?: 0.0
                    append("debts", record("id" to uniqueId(rowIndex), "name" to name, "balance" to amount, "rate" to rate, "payment" to payment))
                }
                "abonnement", "subscription" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    val cancelDate = Regex("(?i)opsig senest\\s+(\\d{4}-\\d{2}-\\d{2})").find(status)?.groupValues?.getOrNull(1).orEmpty()
                    append("subs", record("id" to uniqueId(rowIndex), "name" to name, "monthly" to amount, "renewalDate" to (date ?: ""), "cancelByDate" to cancelDate, "cancelNote" to "", "owner" to owner, "active" to true))
                }
                "braendstof", "fuel" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val liters = Regex("(?i)([0-9]+(?:[,.][0-9]+)?)\\s*liter").find(categoryRaw)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    val km = Regex("(?i)kilometerstand\\s+([0-9 .]+)").find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    append("fuel", record("id" to uniqueId(rowIndex), "date" to date, "liters" to liters, "cost" to amount, "km" to km))
                }
                else -> skipped++
            }
        } else {
            if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
            val transactionType = splitColumnDirection ?: explicitFlow
                ?: if (rawAmount < 0) "Udgift"
                else if (csvDescriptionLooksLikeIncome(name)) "Indtægt"
                else "Udgift"
            val suggestion = resolveCsvCategory(categoryRaw, name, transactionType, amount, categoryContext)
            append("transactions", record(
                "id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "category" to suggestion.category,
                "date" to date, "type" to transactionType, "owner" to owner,
                "_saldoCsvConfidence" to suggestion.confidence, "_saldoCsvReason" to suggestion.reason,
                "_saldoCsvNeedsReview" to (suggestion.confidence < 72), "_saldoCsvSuggestedCategory" to suggestion.category,
                "_saldoCsvDirectionConfidence" to directionConfidence,
                "_saldoCsvDirectionReason" to if (directionConfidence >= 90) "Retning bestemt af CSV-filen eller beløbets fortegn" else "Retningen er foreslået ud fra beskrivelsen"
            ))
        }
    }
    require(collected.values.sumOf { it.size } > 0) {
        "Ingen gyldige poster blev fundet. Kontrollér kolonnerne og datoformatet i CSV-filen. Ved debet-/kreditfiler skal mindst én af beløbskolonnerne være udfyldt pr. række."
    }
    return CsvImportPlan(collected.mapValues { it.value.toList() }, parsedRows, skipped, invalid)
}

@Composable
private fun GoalEditDialog(goal: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    val context = LocalContext.current
    val goalId = goal.s("id")
    var name by remember(goalId) { mutableStateOf(goal.s("name")) }
    var target by remember(goalId) { mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(goal.n("target"))) }
    var saved by remember(goalId) { mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(goal.n("saved"))) }
    var date by remember(goalId) { mutableStateOf(goal.s("date")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Rediger opsparingsmål", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Field("Navn på målet", name, { name = it })
                Field("Målsum (kr.)", target, { target = it }, numeric = true)
                Field("Allerede sparet (kr.)", saved, { saved = it }, numeric = true)
                Field("Måldato (valgfri, ÅÅÅÅ-MM-DD)", date, { date = it })
                Text("Dine registrerede indbetalinger ændres ikke, når du redigerer målet.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsedTarget = parseDanishAmount(target)
                val parsedSaved = parseDanishAmount(saved)
                if (goalId.isBlank()) {
                    Toast.makeText(context, "Opsparingsmålets ID mangler. Opret målet igen.", Toast.LENGTH_LONG).show()
                } else if (name.isBlank() || parsedTarget == null || parsedTarget <= 0.0 || parsedSaved == null || parsedSaved < 0.0) {
                    Toast.makeText(context, "Angiv et navn, en målsum over 0 kr. og en gyldig opsparing.", Toast.LENGTH_LONG).show()
                } else if (date.isNotBlank() && runCatching { LocalDate.parse(date) }.isFailure) {
                    Toast.makeText(context, "Måldatoen skal være ÅÅÅÅ-MM-DD eller stå tom.", Toast.LENGTH_LONG).show()
                } else {
                    onSave(JSONObject(goal.toString()).put("name", name.trim()).put("target", parsedTarget).put("saved", parsedSaved).put("date", date.trim()))
                }
            }) { Text("Gem ændringer", color = Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } }
    )
}

@Composable
private fun MultiBillImportDialog(
    drafts: List<BillImportDraft>,
    onDraftsChanged: (List<BillImportDraft>) -> Unit,
    onDismiss: () -> Unit,
    onImport: (List<BillImportDraft>) -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Gennemgå flere regninger", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Kontrollér afsender, beløb og dato for hver regning. OCR kan læse forkert; intet gemmes, før du trykker Importér.", color = Muted, fontSize = 12.sp)
                LazyColumn(Modifier.heightIn(max = 470.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(drafts, key = { it.id }) { draft ->
                        val draftIndex = drafts.indexOfFirst { it.id == draft.id }
                        Surface(color = PanelRaised, shape = RoundedCornerShape(16.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = draft.selected, onCheckedChange = { checked -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(selected = checked) else it }) })
                                    Text("Regning ${draftIndex + 1}", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (draft.selected) "Medtages" else "Springes over", color = Muted, fontSize = 10.sp)
                                }
                                OutlinedTextField(value = draft.name, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(name = value) else it }) }, label = { Text("Afsender / regning") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                OutlinedTextField(value = draft.amount, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(amount = value) else it }) }, label = { Text("Beløb i kr.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                OutlinedTextField(value = draft.date, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(date = value) else it }) }, label = { Text("Forfaldsdato (ÅÅÅÅ-MM-DD)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                if (draft.rawText.isNotBlank()) Text(draft.rawText.take(180), color = Muted, fontSize = 10.sp, maxLines = 3)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val selectedCount = drafts.count { it.selected }
                if (selectedCount == 0) Toast.makeText(context, "Vælg mindst én regning.", Toast.LENGTH_SHORT).show()
                else onImport(drafts)
            }) { Text("Importér valgte", color = Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } }
    )
}

private fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"")}\""

private fun shareCsv(context: Context, data: JSONObject) {
    runCatching {
        val lines = mutableListOf("type;navn;beløb;kategori;dato;status;ejer")
        fun row(type: String, name: String, amount: Double, category: String, date: String, status: String, owner: String = "") {
            val amountText = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(amount)
            lines += listOf(type, name, amountText, category, date, status, owner).joinToString(";") { csvCell(it) }
        }
        (data.optJSONArray("transactions") ?: JSONArray()).objects().forEach {
            row("post", it.s("name"), it.n("amount"), it.s("category"), it.s("date"), it.s("type"), it.s("owner"))
        }
        (data.optJSONArray("bills") ?: JSONArray()).objects().forEach {
            row("regning", it.s("name"), it.n("amount"), it.s("category"), it.s("date"), if (it.optBoolean("paid")) "betalt" else "ubetalt", it.s("owner"))
        }
        (data.optJSONArray("budgets") ?: JSONArray()).objects().forEach {
            row("budget", it.s("category"), it.n("limit"), it.s("category"), "", "månedlig grænse", it.s("owner"))
        }
        (data.optJSONArray("goals") ?: JSONArray()).objects().forEach {
            row("opsparingsmål", it.s("name"), it.n("target"), "Opsparing", it.s("date"), "Sparet: ${money(it.n("saved"))}")
        }
        (data.optJSONArray("debts") ?: JSONArray()).objects().forEach {
            row("gæld", it.s("name"), it.n("balance"), "Gæld", "", "Rente ${it.n("rate")}% · afdrag ${money(it.n("payment"))}")
        }
        (data.optJSONArray("subs") ?: JSONArray()).objects().forEach {
            row("abonnement", it.s("name"), it.n("monthly"), "Abonnement", it.s("renewalDate"), "Opsig senest ${it.s("cancelByDate")}", it.s("owner"))
        }
        (data.optJSONArray("fuel") ?: JSONArray()).objects().forEach {
            row("brændstof", "Tankning", it.n("cost"), "${it.n("liters")} liter", it.s("date"), "Kilometerstand ${it.n("km")}")
        }
        val file = File(context.cacheDir, "Saldo-data-${exportFileStamp()}.csv")
        FileOutputStream(file).use { out -> out.write(("\uFEFF" + lines.joinToString("\r\n")).toByteArray(Charsets.UTF_8)) }
        val uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).setType("text/csv")
            .putExtra(Intent.EXTRA_SUBJECT, "Saldo CSV-eksport")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Eksportér Saldo-data"))
    }.onFailure { Toast.makeText(context, "Kunne ikke oprette CSV-eksport: ${it.message}", Toast.LENGTH_LONG).show() }
}

private fun shareBackup(context: Context, json: String) {
    runCatching {
        val file = File(context.cacheDir, "Saldo-backup-${exportFileStamp()}.json")
        FileOutputStream(file).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        val uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).setType("application/json")
            .putExtra(Intent.EXTRA_SUBJECT, "Saldo sikkerhedskopi")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Gem eller del sikkerhedskopi"))
    }.onFailure { Toast.makeText(context, "Kunne ikke oprette backupfil: ${it.message}", Toast.LENGTH_LONG).show() }
}
