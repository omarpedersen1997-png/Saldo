package dk.saldo.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Saldo 2026 design system: shared motion tokens, glowing cards, animated numbers and bars.
// All animations are state-driven (no infinite loops), short and GPU-friendly (graphicsLayer).

internal object SaldoMotion {
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    const val SHORT = 160
    const val MEDIUM = 280
    const val LONG = 560
}

internal val SaldoDanger = Color(0xFFFF6B8B)
internal val SaldoWarning = Color(0xFFFFC078)

/** Deep violet gradient used for hero cards and primary accents. */
internal fun saldoHeroBrush(): Brush = Brush.linearGradient(
    listOf(Color(0xFF2B1F6E), Color(0xFF4A2DB5), Color(0xFF231C5C), Color(0xFF15183F))
)

/** Thin gradient border that gives cards a discreet glowing edge in both themes. */
internal fun saldoCardBorder(): BorderStroke = BorderStroke(
    1.dp,
    Brush.linearGradient(listOf(Violet.copy(alpha = .34f), BorderSubtle, BorderSubtle, Blue.copy(alpha = .20f)))
)

/** Subtle vertical gradient for elevated card surfaces. */
internal fun saldoCardBrush(): Brush = Brush.verticalGradient(listOf(PanelRaised.copy(alpha = .55f), Panel, Panel))

/** Spring-based press feedback. Returns a scale value for graphicsLayer (no relayout). */
@Composable
internal fun rememberPressScale(interactionSource: MutableInteractionSource, pressedScale: Float = .965f): State<Float> {
    val pressed by interactionSource.collectIsPressedAsState()
    return animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = .6f, stiffness = Spring.StiffnessMediumLow),
        label = "saldo-press-scale"
    )
}

/** Rounded card with gradient surface, glowing border and optional press animation. */
@Composable
internal fun SaldoCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(24.dp),
    contentPadding: PaddingValues = PaddingValues(18.dp),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(12.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    if (onClick != null) {
        val source = remember { MutableInteractionSource() }
        val scale by rememberPressScale(source)
        Surface(
            onClick = onClick,
            enabled = enabled,
            interactionSource = source,
            color = Color.Transparent,
            shape = shape,
            border = saldoCardBorder(),
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }
        ) {
            Column(Modifier.background(saldoCardBrush()).padding(contentPadding), verticalArrangement = verticalArrangement, content = content)
        }
    } else {
        Surface(color = Color.Transparent, shape = shape, border = saldoCardBorder(), modifier = modifier) {
            Column(Modifier.background(saldoCardBrush()).padding(contentPadding), verticalArrangement = verticalArrangement, content = content)
        }
    }
}

/** Icon inside a softly glowing gradient tile. */
@Composable
internal fun SaldoIconTile(icon: ImageVector, accent: Color = Violet, size: Dp = 42.dp, iconSize: Dp = 21.dp, contentDescription: String? = null) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * .32f))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = .26f), accent.copy(alpha = .08f)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = accent, modifier = Modifier.size(iconSize))
    }
}

/**
 * Money value that glides smoothly to a new amount when it changes. At rest the exact
 * value is shown, so float rounding never leaks into the displayed number.
 */
@Composable
internal fun AnimatedMoney(
    value: Double,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    format: (Double) -> String = ::money
) {
    val animatable = remember { Animatable(value.toFloat()) }
    LaunchedEffect(value) {
        animatable.animateTo(value.toFloat(), tween(SaldoMotion.LONG, easing = SaldoMotion.Emphasized))
    }
    val animatedColor by animateColorAsState(color, tween(SaldoMotion.MEDIUM), label = "saldo-money-color")
    val shown = if (animatable.isRunning) animatable.value.toDouble() else value
    Text(
        format(shown),
        color = animatedColor,
        fontSize = fontSize,
        fontWeight = fontWeight,
        letterSpacing = letterSpacing,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
    )
}

/** Animated gradient budget bar with a soft glowing tip. Grows in once when first shown. */
@Composable
internal fun SaldoProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 10.dp,
    colors: List<Color> = listOf(Violet, Blue),
    track: Color = Violet.copy(alpha = .12f)
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val animated by animateFloatAsState(
        targetValue = if (shown) progress.coerceIn(0f, 1f) else 0f,
        animationSpec = tween(720, easing = SaldoMotion.Emphasized),
        label = "saldo-progress"
    )
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
        if (animated > 0.001f) {
            Box(
                Modifier.fillMaxWidth(animated).fillMaxHeight().clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(colors))
                    .drawBehind {
                        val r = size.height * .30f
                        if (size.width > size.height) drawCircle(Color.White.copy(alpha = .65f), radius = r, center = Offset(size.width - size.height / 2f, size.height / 2f))
                    }
            )
        }
    }
}

/** Grouped bar chart: income (mint) and expenses (violet) per month, animated in sequence. */
@Composable
internal fun SaldoTrendChart(points: List<Triple<String, Double, Double>>, modifier: Modifier = Modifier) {
    val maxValue = points.maxOfOrNull { maxOf(it.second, it.third) }?.takeIf { it > 0.0 } ?: 1.0
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            points.forEachIndexed { index, (label, income, expense) ->
                val incomeHeight by animateFloatAsState(
                    if (shown) (income / maxValue).toFloat().coerceIn(0f, 1f) else 0f,
                    tween(620, delayMillis = index * 50, easing = SaldoMotion.Emphasized), label = "trend-income-$index"
                )
                val expenseHeight by animateFloatAsState(
                    if (shown) (expense / maxValue).toFloat().coerceIn(0f, 1f) else 0f,
                    tween(620, delayMillis = index * 50 + 40, easing = SaldoMotion.Emphasized), label = "trend-expense-$index"
                )
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        val barShape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 2.dp, bottomEnd = 2.dp)
                        Box(Modifier.width(10.dp).fillMaxHeight(incomeHeight.coerceAtLeast(.02f)).clip(barShape).background(Brush.verticalGradient(listOf(Mint, Mint.copy(alpha = .30f)))))
                        Box(Modifier.width(10.dp).fillMaxHeight(expenseHeight.coerceAtLeast(.02f)).clip(barShape).background(Brush.verticalGradient(listOf(Violet, Violet.copy(alpha = .30f)))))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(label, color = Muted, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            SaldoLegendDot(Mint, "Indtægter")
            SaldoLegendDot(Violet, "Udgifter")
        }
    }
}

@Composable
internal fun SaldoLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

internal data class SaldoNavItem(val key: String, val icon: ImageVector)

/** Floating pill navigation with an animated selection capsule and icon micro-animation. */
@Composable
internal fun SaldoBottomBar(items: List<SaldoNavItem>, selectedKey: String, onSelect: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Surface(
            color = Panel.copy(alpha = .97f),
            shape = RoundedCornerShape(28.dp),
            border = saldoCardBorder(),
            shadowElevation = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(5.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                items.forEach { item ->
                    val selected = item.key == selectedKey
                    val weight by animateFloatAsState(if (selected) 1.22f else 1f, tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized), label = "nav-weight-${item.key}")
                    val capsule by animateColorAsState(if (selected) Violet.copy(alpha = .18f) else Color.Transparent, tween(SaldoMotion.MEDIUM), label = "nav-bg-${item.key}")
                    val tint by animateColorAsState(if (selected) Violet else Muted, tween(SaldoMotion.MEDIUM), label = "nav-tint-${item.key}")
                    val iconScale by animateFloatAsState(if (selected) 1.14f else 1f, spring(dampingRatio = .45f, stiffness = Spring.StiffnessMedium), label = "nav-icon-${item.key}")
                    val source = remember { MutableInteractionSource() }
                    val press by rememberPressScale(source, .92f)
                    Surface(
                        onClick = { onSelect(item.key) },
                        interactionSource = source,
                        color = capsule,
                        shape = RoundedCornerShape(23.dp),
                        modifier = Modifier.weight(weight).height(58.dp).graphicsLayer { scaleX = press; scaleY = press }
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(item.icon, contentDescription = item.key, tint = tint, modifier = Modifier.size(22.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                            Spacer(Modifier.height(3.dp))
                            Text(
                                item.key,
                                color = if (selected) White else Muted,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Short, elegant confirmation shown after a record has been saved. Touches pass through. */
@Composable
internal fun SaldoSuccessOverlay(message: String?, onFinished: () -> Unit) {
    var lastMessage by remember { mutableStateOf("") }
    if (message != null) lastMessage = message
    LaunchedEffect(message) {
        if (message != null) {
            delay(1150)
            onFinished()
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = message != null,
            enter = fadeIn(tween(SaldoMotion.SHORT)) + scaleIn(initialScale = .82f, animationSpec = spring(dampingRatio = .58f, stiffness = Spring.StiffnessMediumLow)),
            exit = fadeOut(tween(220)) + scaleOut(targetScale = .94f, animationSpec = tween(220))
        ) {
            var ring by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { ring = true }
            val ringProgress by animateFloatAsState(if (ring) 1f else 0f, tween(520, easing = SaldoMotion.Emphasized), label = "success-ring")
            val checkScale by animateFloatAsState(if (ring) 1f else .3f, spring(dampingRatio = .45f, stiffness = Spring.StiffnessMediumLow), label = "success-check")
            Surface(color = Panel, shape = RoundedCornerShape(28.dp), border = saldoCardBorder(), shadowElevation = 24.dp) {
                Column(Modifier.padding(horizontal = 30.dp, vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(progress = { ringProgress }, modifier = Modifier.fillMaxSize(), color = Mint, trackColor = Mint.copy(alpha = .14f), strokeWidth = 4.dp)
                        Box(
                            Modifier.size(44.dp).graphicsLayer { scaleX = checkScale; scaleY = checkScale }.clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Mint, Color(0xFF3CC79A)))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF062A1E), modifier = Modifier.size(26.dp)) }
                    }
                    Text(lastMessage, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
