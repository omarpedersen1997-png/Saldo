package dk.saldo.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.material3.Typography
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// Saldo 2026 design system: shared motion tokens, glowing cards, animated numbers and bars.
// All animations are state-driven (no infinite loops), short and GPU-friendly (graphicsLayer).

internal object SaldoMotion {
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    const val SHORT = 160
    const val MEDIUM = 280
    const val LONG = 560
}

private fun saldoIsDark(): Boolean = Night.luminance() < .5f

/** Theme-aware semantic colours (read the observable palette, so they recompose on theme change). */
internal val SaldoDanger: Color get() = if (saldoIsDark()) Color(0xFFFB7185) else Color(0xFFD43D5B)
internal val SaldoWarning: Color get() = if (saldoIsDark()) Color(0xFFFF9F5A) else Color(0xFFC2410C)

/** The logo gradient: cream -> gold -> amber. Used for primary accents so app and logo match. */
internal fun saldoBrandBrush(): Brush = Brush.linearGradient(listOf(Color(0xFFFDE7B0), Color(0xFFF5C66B), Color(0xFFD99A2B)))
internal val SaldoBrandColors = listOf(Color(0xFFFDE7B0), Color(0xFFF5C66B), Color(0xFFD99A2B))

/** Deep indigo hero gradient, matching the logo tile. */
internal fun saldoHeroBrush(): Brush = Brush.linearGradient(
    listOf(Color(0xFF1C2A5E), Color(0xFF26306E), Color(0xFF16224F), Color(0xFF0B1433))
)

/** Inter, bundled (OFL-1.1), used for the whole app. */
internal val SaldoFontFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
    Font(R.font.inter_extrabold, FontWeight.ExtraBold)
)

internal fun saldoTypography(): Typography {
    val base = Typography()
    fun TextStyle.inter() = copy(fontFamily = SaldoFontFamily)
    return Typography(
        displayLarge = base.displayLarge.inter(), displayMedium = base.displayMedium.inter(), displaySmall = base.displaySmall.inter(),
        headlineLarge = base.headlineLarge.inter(), headlineMedium = base.headlineMedium.inter(), headlineSmall = base.headlineSmall.inter(),
        titleLarge = base.titleLarge.inter(), titleMedium = base.titleMedium.inter(), titleSmall = base.titleSmall.inter(),
        bodyLarge = base.bodyLarge.inter(), bodyMedium = base.bodyMedium.inter(), bodySmall = base.bodySmall.inter(),
        labelLarge = base.labelLarge.inter(), labelMedium = base.labelMedium.inter(), labelSmall = base.labelSmall.inter()
    )
}

/** Thin gradient border that gives cards a discreet glowing edge in both themes. */
internal fun saldoCardBorder(): BorderStroke = BorderStroke(
    1.dp,
    Brush.linearGradient(listOf(Violet.copy(alpha = .22f), BorderSubtle, BorderSubtle, Blue.copy(alpha = .14f)))
)

/** Subtle vertical gradient for elevated card surfaces. */
internal fun saldoCardBrush(): Brush = Brush.verticalGradient(listOf(PanelRaised.copy(alpha = .50f), Panel, Panel))

/** Spring-based press feedback. Returns a scale value for graphicsLayer (no relayout). */
@Composable
internal fun rememberPressScale(interactionSource: MutableInteractionSource, pressedScale: Float = .965f): State<Float> {
    val pressed by interactionSource.collectIsPressedAsState()
    return animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = .6f, stiffness = Spring.StiffnessMediumLow),
        label = "saldo-press-scale"
    )
}

/** Rounded card with gradient surface, glowing border and optional press animation. */
@Composable
internal fun SaldoCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(24.dp),
    contentPadding: PaddingValues = PaddingValues(18.dp),
    verticalArrangement: Arrangement.Vertical = Arrangement.spacedBy(12.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    if (onClick != null) {
        val source = remember { MutableInteractionSource() }
        val scale by rememberPressScale(source)
        Surface(
            onClick = onClick,
            enabled = enabled,
            interactionSource = source,
            color = Color.Transparent,
            shape = shape,
            border = saldoCardBorder(),
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }
        ) {
            Column(Modifier.background(saldoCardBrush()).padding(contentPadding), verticalArrangement = verticalArrangement, content = content)
        }
    } else {
        Surface(color = Color.Transparent, shape = shape, border = saldoCardBorder(), modifier = modifier) {
            Column(Modifier.background(saldoCardBrush()).padding(contentPadding), verticalArrangement = verticalArrangement, content = content)
        }
    }
}

/** Icon inside a softly glowing gradient tile. */
@Composable
internal fun SaldoIconTile(icon: ImageVector, accent: Color = Violet, size: Dp = 42.dp, iconSize: Dp = 21.dp, contentDescription: String? = null) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * .32f))
            .background(Brush.linearGradient(listOf(accent.copy(alpha = .26f), accent.copy(alpha = .08f)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = accent, modifier = Modifier.size(iconSize))
    }
}

/**
 * Money value that glides smoothly to a new amount when it changes. At rest the exact
 * value is shown, so float rounding never leaks into the displayed number.
 */
@Composable
internal fun AnimatedMoney(
    value: Double,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    format: (Double) -> String = ::money
) {
    val animatable = remember { Animatable(value.toFloat()) }
    LaunchedEffect(value) {
        animatable.animateTo(value.toFloat(), tween(SaldoMotion.LONG, easing = SaldoMotion.Emphasized))
    }
    val animatedColor by animateColorAsState(color, tween(SaldoMotion.MEDIUM), label = "saldo-money-color")
    val shown = if (animatable.isRunning) animatable.value.toDouble() else value
    val text = format(shown)
    val display = if (fontSize.isSp && fontSize.value >= 18f) {
        val comma = text.lastIndexOf(',')
        val cut = if (comma >= 0) comma else text.indexOf(" kr.").takeIf { it >= 0 } ?: text.length
        buildAnnotatedString {
            append(text.substring(0, cut))
            withStyle(SpanStyle(fontSize = fontSize * .56f, fontWeight = FontWeight.SemiBold)) { append(text.substring(cut)) }
        }
    } else AnnotatedString(text)
    Text(
        display,
        color = animatedColor,
        fontSize = fontSize,
        fontWeight = fontWeight,
        letterSpacing = letterSpacing,
        style = androidx.compose.material3.LocalTextStyle.current.copy(fontFeatureSettings = "tnum"),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
    )
}

/** Animated gradient budget bar with a soft glowing tip. Grows in once when first shown. */
@Composable
internal fun SaldoProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    height: Dp = 10.dp,
    colors: List<Color> = SaldoBrandColors,
    track: Color = Violet.copy(alpha = .12f),
    marker: Float? = null
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val animated by animateFloatAsState(
        targetValue = if (shown) progress.coerceIn(0f, 1f) else 0f,
        animationSpec = tween(720, easing = SaldoMotion.Emphasized),
        label = "saldo-progress"
    )
    val markerColor = White
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track).drawWithContent {
        drawContent()
        marker?.coerceIn(0f, 1f)?.let { position ->
            val x = size.width * position
            drawLine(markerColor.copy(alpha = .85f), Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx())
        }
    }) {
        if (animated > 0.001f) {
            Box(
                Modifier.fillMaxWidth(animated).fillMaxHeight().clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(colors))
                    .drawBehind {
                        val r = size.height * .30f
                        if (size.width > size.height) drawCircle(Color.White.copy(alpha = .45f), radius = r, center = Offset(size.width - size.height / 2f, size.height / 2f))
                    }
            )
        }
    }
}

/** Grouped bar chart: income (mint) and expenses (violet) per month, animated in sequence. */
@Composable
internal fun SaldoTrendChart(points: List<Triple<String, Double, Double>>, modifier: Modifier = Modifier) {
    val maxValue = points.maxOfOrNull { maxOf(it.second, it.third) }?.takeIf { it > 0.0 } ?: 1.0
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            points.forEachIndexed { index, (label, income, expense) ->
                val incomeHeight by animateFloatAsState(
                    if (shown) (income / maxValue).toFloat().coerceIn(0f, 1f) else 0f,
                    tween(620, delayMillis = index * 50, easing = SaldoMotion.Emphasized), label = "trend-income-$index"
                )
                val expenseHeight by animateFloatAsState(
                    if (shown) (expense / maxValue).toFloat().coerceIn(0f, 1f) else 0f,
                    tween(620, delayMillis = index * 50 + 40, easing = SaldoMotion.Emphasized), label = "trend-expense-$index"
                )
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        val barShape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 2.dp, bottomEnd = 2.dp)
                        Box(Modifier.width(10.dp).fillMaxHeight(incomeHeight.coerceAtLeast(.02f)).clip(barShape).background(Brush.verticalGradient(listOf(Mint, Mint.copy(alpha = .30f)))))
                        Box(Modifier.width(10.dp).fillMaxHeight(expenseHeight.coerceAtLeast(.02f)).clip(barShape).background(Brush.verticalGradient(listOf(Violet, Violet.copy(alpha = .30f)))))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(label, color = Muted, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            SaldoLegendDot(Mint, "Indtægter")
            SaldoLegendDot(Violet, "Udgifter")
        }
    }
}

@Composable
internal fun SaldoLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

internal data class SaldoNavItem(val key: String, val icon: ImageVector, val selectedIcon: ImageVector = icon)

/** Floating pill navigation with an animated selection capsule and icon micro-animation. */
@Composable
internal fun SaldoBottomBar(items: List<SaldoNavItem>, selectedKey: String, onSelect: (String) -> Unit) {
    val haptics = LocalHapticFeedback.current
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Surface(
            color = Panel.copy(alpha = .97f),
            shape = RoundedCornerShape(28.dp),
            border = saldoCardBorder(),
            shadowElevation = 16.dp,
            modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth()
        ) {
            Row(Modifier.padding(5.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                items.forEach { item ->
                    val selected = item.key == selectedKey
                    val weight by animateFloatAsState(if (selected) 1.22f else 1f, tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized), label = "nav-weight-${item.key}")
                    val capsule by animateFloatAsState(if (selected) 1f else 0f, tween(SaldoMotion.MEDIUM), label = "nav-bg-${item.key}")
                    val tint by animateColorAsState(if (selected) Violet else Muted, tween(SaldoMotion.MEDIUM), label = "nav-tint-${item.key}")
                    val iconScale by animateFloatAsState(if (selected) 1.14f else 1f, spring(dampingRatio = .45f, stiffness = Spring.StiffnessMedium), label = "nav-icon-${item.key}")
                    val source = remember { MutableInteractionSource() }
                    val press by rememberPressScale(source, .92f)
                    Surface(
                        onClick = {
                            if (!selected) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSelect(item.key)
                        },
                        interactionSource = source,
                        color = Color.Transparent,
                        shape = RoundedCornerShape(23.dp),
                        modifier = Modifier.weight(weight).height(58.dp).graphicsLayer { scaleX = press; scaleY = press }
                    ) {
                        Box(Modifier.fillMaxSize().graphicsLayer { alpha = capsule }.background(Brush.linearGradient(SaldoBrandColors.map { it.copy(alpha = .17f) })))
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(if (selected) item.selectedIcon else item.icon, contentDescription = item.key, tint = tint, modifier = Modifier.size(22.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                            Spacer(Modifier.height(3.dp))
                            Text(
                                item.key,
                                color = if (selected) White else Muted,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Short, elegant confirmation shown after a record has been saved. Touches pass through. */
@Composable
internal fun SaldoSuccessOverlay(message: String?, onFinished: () -> Unit) {
    var lastMessage by remember { mutableStateOf("") }
    if (message != null) lastMessage = message
    val haptics = LocalHapticFeedback.current
    LaunchedEffect(message) {
        if (message != null) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            delay(1150)
            onFinished()
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = message != null,
            enter = fadeIn(tween(SaldoMotion.SHORT)) + scaleIn(initialScale = .82f, animationSpec = spring(dampingRatio = .58f, stiffness = Spring.StiffnessMediumLow)),
            exit = fadeOut(tween(220)) + scaleOut(targetScale = .94f, animationSpec = tween(220))
        ) {
            var ring by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { ring = true }
            val ringProgress by animateFloatAsState(if (ring) 1f else 0f, tween(520, easing = SaldoMotion.Emphasized), label = "success-ring")
            val checkScale by animateFloatAsState(if (ring) 1f else .3f, spring(dampingRatio = .45f, stiffness = Spring.StiffnessMediumLow), label = "success-check")
            Surface(color = Panel, shape = RoundedCornerShape(28.dp), border = saldoCardBorder(), shadowElevation = 24.dp) {
                Column(Modifier.padding(horizontal = 30.dp, vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(progress = { ringProgress }, modifier = Modifier.fillMaxSize(), color = Mint, trackColor = Mint.copy(alpha = .14f), strokeWidth = 4.dp)
                        Box(
                            Modifier.size(44.dp).graphicsLayer { scaleX = checkScale; scaleY = checkScale }.clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Mint, Color(0xFF3CC79A)))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF062A1E), modifier = Modifier.size(26.dp)) }
                    }
                    Text(lastMessage, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Section title with optional subtitle and trailing text action. */
@Composable
internal fun SaldoSectionHeader(title: String, subtitle: String? = null, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.35).sp)
            if (!subtitle.isNullOrBlank()) Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        if (actionLabel != null && onAction != null) {
            Surface(onClick = onAction, color = Violet.copy(alpha = .12f), shape = RoundedCornerShape(50)) {
                Text(actionLabel, color = Violet, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
            }
        }
    }
}

/** Sticky group header used by grouped lists (dates, bill status). */
@Composable
internal fun SaldoGroupHeader(title: String, trailing: String? = null, accent: Color = Violet) {
    Row(
        Modifier.fillMaxWidth().background(Night.copy(alpha = .94f)).padding(top = 12.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
        Spacer(Modifier.width(8.dp))
        Text(title.uppercase(java.util.Locale("da", "DK")), color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** "I dag", "I går" or a Danish weekday/date label for an ISO date string. */
internal fun saldoDayLabel(isoDate: String, today: java.time.LocalDate = java.time.LocalDate.now()): String {
    val date = runCatching { java.time.LocalDate.parse(isoDate) }.getOrNull() ?: return isoDate.ifBlank { "Uden dato" }
    val danish = java.util.Locale("da", "DK")
    return when (date) {
        today -> "I dag"
        today.minusDays(1) -> "I går"
        today.plusDays(1) -> "I morgen"
        else -> {
            val pattern = if (date.year == today.year) "EEEE d. MMMM" else "d. MMMM yyyy"
            date.format(java.time.format.DateTimeFormatter.ofPattern(pattern, danish)).replaceFirstChar { it.uppercase() }
        }
    }
}

/** Time-of-day greeting for the overview header. */
internal fun saldoGreeting(hour: Int = java.time.LocalTime.now().hour): String = when (hour) {
    in 5..9 -> "God morgen"
    in 10..11 -> "God formiddag"
    in 12..17 -> "God eftermiddag"
    else -> "God aften"
}

/** Smooth animated sparkline with gradient stroke and soft fill; reveals left-to-right once. */
@Composable
internal fun SaldoSparkline(values: List<Double>, modifier: Modifier = Modifier, lineColors: List<Color> = listOf(Color(0xFFFDE7B0), Color(0xFFF5C66B))) {
    if (values.size < 2) return
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val progress by animateFloatAsState(if (shown) 1f else 0f, tween(900, easing = SaldoMotion.Emphasized), label = "saldo-sparkline")
    Canvas(modifier) {
        val min = values.minOrNull() ?: 0.0
        val max = values.maxOrNull() ?: 0.0
        val span = (max - min).takeIf { it > 0.0 } ?: 1.0
        val stepX = size.width / (values.size - 1)
        val points = values.mapIndexed { index, value ->
            Offset(index * stepX, size.height * .9f - ((value - min) / span).toFloat() * size.height * .8f)
        }
        val line = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 1 until points.size) {
                val previous = points[i - 1]
                val current = points[i]
                val midX = (previous.x + current.x) / 2f
                cubicTo(midX, previous.y, midX, current.y, current.x, current.y)
            }
        }
        val area = Path().apply {
            addPath(line)
            lineTo(points.last().x, size.height)
            lineTo(points.first().x, size.height)
            close()
        }
        clipRect(right = size.width * progress) {
            drawPath(area, Brush.verticalGradient(listOf(lineColors.first().copy(alpha = .30f), Color.Transparent)))
            drawPath(line, Brush.horizontalGradient(lineColors), style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
            drawCircle(Color.White, radius = 3.5.dp.toPx(), center = points.last())
            drawCircle(lineColors.last().copy(alpha = .35f), radius = 7.dp.toPx(), center = points.last())
        }
    }
}

/** Amount with an explicit sign, so income/expense is readable without relying on colour. */
internal fun signedMoney(amount: Double, income: Boolean): String = (if (income) "+" else "\u2212") + money(kotlin.math.abs(amount))

/** Net amount: explicit "+" for surplus, "−" for deficit. */
internal fun netMoney(value: Double): String = when {
    value > 0.004 -> "+" + money(value)
    value < -0.004 -> "\u2212" + money(kotlin.math.abs(value))
    else -> money(0.0)
}

private val saldoAvatarHues = listOf(
    Color(0xFF93A8F4), Color(0xFF6EE7B7), Color(0xFFF5C66B), Color(0xFF7DD3FC), Color(0xFFF9A8D4), Color(0xFFC4B5FD)
)

/** Round avatar with the record's initial and a small in/out badge (sign is also shown in text). */
@Composable
internal fun SaldoAvatar(title: String, positive: Boolean, size: Dp = 44.dp) {
    val initial = title.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "•"
    val hue = saldoAvatarHues[(title.trim().lowercase().hashCode() and Int.MAX_VALUE) % saldoAvatarHues.size]
    Box(Modifier.size(size)) {
        Box(
            Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(hue.copy(alpha = .30f), hue.copy(alpha = .12f)))),
            contentAlignment = Alignment.Center
        ) { Text(initial, color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        Box(
            Modifier.align(Alignment.BottomEnd).size(17.dp).clip(CircleShape).background(Panel).padding(2.dp).clip(CircleShape)
                .background(if (positive) Mint else Violet),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (positive) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                contentDescription = if (positive) "Indtægt" else "Udgift",
                tint = Panel,
                modifier = Modifier.size(10.dp)
            )
        }
    }
}

/** Tappable insight pill for the overview ("62 % af indtægten brugt"). */
@Composable
internal fun SaldoInsightChip(icon: ImageVector, text: String, accent: Color = Violet, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val scale by rememberPressScale(source)
    Surface(
        onClick = onClick,
        interactionSource = source,
        color = PanelRaised.copy(alpha = .75f),
        shape = RoundedCornerShape(50),
        border = saldoCardBorder(),
        modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            Text(text, color = White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

/** Savings goal card: progress, percentage and the monthly saving needed to reach the target date. */
@Composable
internal fun SaldoGoalCard(name: String, target: Double, saved: Double, isoDate: String, onEdit: () -> Unit, onDelete: () -> Unit) {
    var confirmDelete by remember(name, isoDate) { mutableStateOf(false) }
    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Panel,
            title = { Text("Slet opsparingsmålet?", color = White, fontWeight = FontWeight.Bold) },
            text = { Text("\"$name\" slettes fra Saldo. Handlingen kan ikke fortrydes, medmindre du har en sikkerhedskopi.", color = Muted) },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Slet", color = SaldoDanger, fontWeight = FontWeight.Bold) } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false }) { Text("Annuller", color = Muted) } }
        )
    }
    val progress = if (target > 0) (saved / target).toFloat().coerceIn(0f, 1f) else 0f
    val remaining = (target - saved).coerceAtLeast(0.0)
    val today = java.time.LocalDate.now()
    val targetDate = runCatching { java.time.LocalDate.parse(isoDate) }.getOrNull()
    val danish = java.util.Locale("da", "DK")
    val guidance = when {
        target <= 0 -> "Angiv en målsum for at følge fremskridtet."
        remaining <= 0.0 -> "Målet er nået. Godt gået!"
        targetDate == null -> "Mangler ${money(remaining)}. Tilføj en måldato for at se, hvor meget du skal spare pr. måned."
        !targetDate.isAfter(today) -> "Måldatoen er passeret · mangler ${money(remaining)}"
        else -> {
            val months = java.time.temporal.ChronoUnit.MONTHS.between(java.time.YearMonth.from(today), java.time.YearMonth.from(targetDate)).coerceAtLeast(1)
            "Spar ${money(remaining / months)} pr. måned for at nå målet ${targetDate.format(java.time.format.DateTimeFormatter.ofPattern("d. MMMM yyyy", danish))}"
        }
    }
    SaldoCard(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxSize(), color = if (remaining <= 0.0) Mint else Violet, trackColor = Violet.copy(alpha = .14f), strokeWidth = 5.dp)
                Text("${(progress * 100).toInt()}%", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(name.ifBlank { "Opsparingsmål" }, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${money(saved)} af ${money(target)}", color = Muted, fontSize = 12.sp, maxLines = 1)
            }
            androidx.compose.material3.IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Rediger $name", tint = Blue, modifier = Modifier.size(18.dp))
            }
            androidx.compose.material3.IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Slet $name", tint = SaldoDanger, modifier = Modifier.size(18.dp))
            }
        }
        SaldoProgressBar(progress, height = 9.dp, colors = if (remaining <= 0.0) listOf(Mint, Mint) else SaldoBrandColors)
        Text(guidance, color = if (remaining <= 0.0) Mint else Muted, fontSize = 12.sp)
    }
}
