package dk.saldo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Keeps all launcher widgets in sync with the same local budget data as the app. */
object SaldoWidgetUpdater {
    private fun prefs(context: Context) = saldoPreferences(context)
    private fun readData(context: Context): JSONObject = runCatching {
        JSONObject(prefs(context).getString("data", "{}") ?: "{}")
    }.getOrElse { JSONObject() }
    private fun array(root: JSONObject, key: String): List<JSONObject> {
        val values = root.optJSONArray(key) ?: JSONArray()
        return (0 until values.length()).mapNotNull { values.optJSONObject(it) }
    }
    private val wholeKroner = object : ThreadLocal<NumberFormat>() {
        override fun initialValue(): NumberFormat = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 0; minimumFractionDigits = 0 }
    }
    private fun money(amount: Double): String = wholeKroner.get()!!.format(if (amount.isFinite()) amount else 0.0) + " kr."
    private fun dueDate(item: JSONObject): LocalDate? = runCatching { LocalDate.parse(item.optString("date", "")) }.getOrNull()
    private fun pendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun updateAll(context: Context) {
        runCatching {
            val manager = AppWidgetManager.getInstance(context)
            updateBalance(context, manager, manager.getAppWidgetIds(ComponentName(context, SaldoBalanceWidgetProvider::class.java)))
            updateMonthly(context, manager, manager.getAppWidgetIds(ComponentName(context, SaldoMonthlyWidgetProvider::class.java)))
            updateBills(context, manager, manager.getAppWidgetIds(ComponentName(context, SaldoBillsWidgetProvider::class.java)))
        }
    }

    fun updateBalance(context: Context, manager: AppWidgetManager, ids: IntArray) {
        if (ids.isEmpty()) return
        val root = readData(context)
        val pref = prefs(context)
        val tx = array(root, "transactions")
        val bills = array(root, "bills")
        val today = LocalDate.now()
        val nowMonthTx = tx.filter { dueDate(it)?.let { d -> d.year == today.year && d.month == today.month } == true }
        val monthIncome = nowMonthTx.filter { it.optString("type") == "Indtægt" }.sumOf { it.optDouble("amount", 0.0) }
        val monthExpense = nowMonthTx.filter { it.optString("type") == "Udgift" }.sumOf { it.optDouble("amount", 0.0) }
        val payday = runCatching { LocalDate.parse(pref.getString("payday", today.toString())) }.getOrElse { today }
        val daysModulo = ChronoUnit.DAYS.between(today, payday).toInt().let { ((it % 14) + 14) % 14 }
        val daysToPay = if (daysModulo == 0) 14 else daysModulo
        val end = today.plusDays(daysToPay.toLong())
        val dueBeforePay = bills.filter { !it.optBoolean("paid", false) }.filter { bill ->
            dueDate(bill)?.let { d -> !d.isBefore(today) && !d.isAfter(end) } == true
        }.sumOf { it.optDouble("amount", 0.0) }
        val balance = if (pref.contains("cash_balance")) pref.saldoMoney("cash_balance", 0.0) - dueBeforePay
            else monthIncome - monthExpense - dueBeforePay
        val daily = balance / daysToPay.coerceAtLeast(1)
        val views = RemoteViews(context.packageName, R.layout.widget_balance).apply {
            setTextViewText(R.id.widget_balance_amount, money(balance))
            setTextViewText(R.id.widget_balance_daily, "${money(daily)} pr. dag")
            setTextViewText(R.id.widget_balance_caption, "Til næste løn · ca. $daysToPay dage")
            setOnClickPendingIntent(R.id.widget_balance_root, pendingIntent(context, 4101))
        }
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    fun updateMonthly(context: Context, manager: AppWidgetManager, ids: IntArray) {
        if (ids.isEmpty()) return
        val today = LocalDate.now()
        val tx = array(readData(context), "transactions").filter {
            dueDate(it)?.let { d -> d.year == today.year && d.month == today.month } == true
        }
        val income = tx.filter { it.optString("type") == "Indtægt" }.sumOf { it.optDouble("amount", 0.0) }
        val expense = tx.filter { it.optString("type") == "Udgift" }.sumOf { it.optDouble("amount", 0.0) }
        val views = RemoteViews(context.packageName, R.layout.widget_monthly).apply {
            setTextViewText(R.id.widget_month_label, today.month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() })
            setTextViewText(R.id.widget_month_income, money(income))
            setTextViewText(R.id.widget_month_expense, money(expense))
            setTextViewText(R.id.widget_month_net, "Netto: ${money(income - expense)}")
            setOnClickPendingIntent(R.id.widget_month_root, pendingIntent(context, 4102))
        }
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    fun updateBills(context: Context, manager: AppWidgetManager, ids: IntArray) {
        if (ids.isEmpty()) return
        val upcoming = array(readData(context), "bills")
            .filter { !it.optBoolean("paid", false) }
            .sortedWith(compareBy<JSONObject>({ dueDate(it) ?: LocalDate.MAX }, { it.optString("name") }))
            .take(2)
        val views = RemoteViews(context.packageName, R.layout.widget_bills).apply {
            setTextViewText(R.id.widget_bills_first, upcoming.getOrNull(0)?.let { "${it.optString("name", "Regning")} · ${dateLabel(it)} · ${money(it.optDouble("amount", 0.0))}" } ?: "Ingen ubetalte regninger")
            setTextViewText(R.id.widget_bills_second, upcoming.getOrNull(1)?.let { "${it.optString("name", "Regning")} · ${dateLabel(it)} · ${money(it.optDouble("amount", 0.0))}" } ?: "")
            setOnClickPendingIntent(R.id.widget_bills_root, pendingIntent(context, 4103))
        }
        ids.forEach { manager.updateAppWidget(it, views) }
    }

    private fun dateLabel(item: JSONObject): String = dueDate(item)?.let { d -> "${d.dayOfMonth}/${d.monthValue}" } ?: "Dato mangler"
}

class SaldoBalanceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { runCatching { SaldoWidgetUpdater.updateBalance(context, manager, ids) } }
}
class SaldoMonthlyWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { runCatching { SaldoWidgetUpdater.updateMonthly(context, manager, ids) } }
}
class SaldoBillsWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { runCatching { SaldoWidgetUpdater.updateBills(context, manager, ids) } }
}

fun requestSaldoWidget(context: Context, provider: Class<out AppWidgetProvider>) {
    val manager = AppWidgetManager.getInstance(context)
    val component = ComponentName(context, provider)
    if (android.os.Build.VERSION.SDK_INT >= 26 && manager.isRequestPinAppWidgetSupported) {
        val accepted = manager.requestPinAppWidget(component, null, null)
        if (!accepted) Toast.makeText(context, "Åbn telefonens startskærm, hold fingeren nede, og vælg Widgets → Saldo.", Toast.LENGTH_LONG).show()
    } else {
        Toast.makeText(context, "Åbn telefonens startskærm, hold fingeren nede, og vælg Widgets → Saldo.", Toast.LENGTH_LONG).show()
    }
}
