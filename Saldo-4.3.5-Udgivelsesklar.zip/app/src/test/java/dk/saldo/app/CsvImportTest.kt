package dk.saldo.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CsvImportTest {
    private fun transactions(csv: String, context: CsvCategoryContext = CsvCategoryContext()) = parseSaldoCsv(csv, context)
        .recordsByCollection["transactions"]
        .orEmpty()

    @Test
    fun signedAmountsUseDirectionAndSpecificCategories() {
        val csv = """Dato;Beskrivelse;Beløb;Kategori
2026-10-24;Løn fra arbejdsgiver;10.000,00;Importeret
2026-10-25;Netto;−562,50;Importeret
2026-10-26;OK Benzin;-375,00;
2026-10-27;Codan forsikring;-293,00;
""".replace("−", "-")
        val result = transactions(csv)
        assertEquals(4, result.size)
        val salary = result.single { it.getString("name").startsWith("Løn") }
        assertEquals("Indtægt", salary.getString("type"))
        assertEquals("Løn", salary.getString("category"))
        assertEquals(10000.0, salary.getDouble("amount"), 0.001)
        val groceries = result.single { it.getString("name") == "Netto" }
        assertEquals("Udgift", groceries.getString("type"))
        assertEquals("Mad", groceries.getString("category"))
        val fuel = result.single { it.getString("name") == "OK Benzin" }
        assertEquals("Transport", fuel.getString("category"))
        assertEquals("Forsikring", result.single { it.getString("name") == "Codan forsikring" }.getString("category"))
    }

    @Test
    fun separateDebitAndCreditColumnsWorkWithoutSingleAmountColumn() {
        val csv = """Dato;Beskrivelse;Debet;Kredit
2026-10-24;Løn fra arbejdsgiver;;10000,00
2026-10-25;Netto;562,50;
2026-10-26;Codan forsikring;293,00;
"""
        val result = transactions(csv)
        assertEquals(3, result.size)
        val salary = result.single { it.getString("name").startsWith("Løn") }
        assertEquals("Indtægt", salary.getString("type"))
        assertEquals("Løn", salary.getString("category"))
        assertEquals("Mad", result.single { it.getString("name") == "Netto" }.getString("category"))
        assertEquals("Forsikring", result.single { it.getString("name") == "Codan forsikring" }.getString("category"))
    }

    @Test
    fun explicitDirectionColumnOverridesPositiveAmount() {
        val csv = """Dato;Beskrivelse;Beløb;Retning
2026-10-24;Overførsel fra arbejdsgiver;1500,00;Indbetaling
2026-10-25;MobilePay køb;75,00;Udgift
"""
        val result = transactions(csv)
        assertEquals(2, result.size)
        assertEquals("Indtægt", result.single { it.getString("name").contains("arbejdsgiver") }.getString("type"))
        assertEquals("Udgift", result.single { it.getString("name").contains("MobilePay") }.getString("type"))
    }

    @Test
    fun suggestionsIncludeReviewConfidenceAndTransientMetadata() {
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Ukendt reference 843;125,00
""")
        val unknown = result.single()
        assertEquals("Diverse", unknown.getString("category"))
        assertTrue(unknown.getInt("_saldoCsvConfidence") < 72)
        assertTrue(unknown.getBoolean("_saldoCsvNeedsReview"))
        assertTrue(unknown.getInt("_saldoCsvDirectionConfidence") < 72)
        assertTrue(unknown.getString("_saldoCsvReason").isNotBlank())
    }

    @Test
    fun learnedMerchantCategoryWinsAndUsesExistingCategoryName() {
        val context = CsvCategoryContext(
            existingCategories = listOf("Dyrlæge", "Mad"),
            knownTransactions = listOf(CsvKnownTransaction("Dyreklinik Vest", "Dyrlæge", "Udgift", 450.0)),
            learnedMerchantCategories = mapOf("udgift|dyreklinik-vest" to "Dyrlæge")
        )
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Kortbetaling Dyreklinik Vest 123456;-450,00
""", context)
        val item = result.single()
        assertEquals("Dyrlæge", item.getString("category"))
        assertEquals(99, item.getInt("_saldoCsvConfidence"))
        assertTrue(item.getString("_saldoCsvReason").contains("tidligere kategorisering"))
    }

    @Test
    fun matchingHistoricalMerchantUsesAmountAsSupportingEvidence() {
        val context = CsvCategoryContext(
            knownTransactions = listOf(CsvKnownTransaction("Dyreklinik Vest", "Kæledyr", "Udgift", 452.0))
        )
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Kortbetaling Dyreklinik Vest 83473;-450,00
""", context)
        assertEquals("Kæledyr", result.single().getString("category"))
        assertEquals(99, result.single().getInt("_saldoCsvConfidence"))
    }

    @Test
    fun customExistingCategoryCanBeSuggestedFromDescription() {
        val context = CsvCategoryContext(existingCategories = listOf("Hesteudstyr", "Mad"))
        val item = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Betaling Hesteudstyr butik;-725,00
""", context).single()
        assertEquals("Hesteudstyr", item.getString("category"))
        assertEquals(80, item.getInt("_saldoCsvConfidence"))
    }

    @Test
    fun commaCsvWithQuotedCommaInDescriptionIsParsedCorrectly() {
        val result = transactions("""date,description,amount,type
2026-10-24,"Cafe, restaurant",-125.00,expense
""")
        assertEquals(1, result.size)
        assertEquals("Cafe, restaurant", result.single().getString("name"))
        assertEquals("Udgift", result.single().getString("type"))
        assertEquals("Mad", result.single().getString("category"))
    }

    @Test
    fun importPreviewDataIncludesTypeAndCategoryFields() {
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Løn;10000
2026-10-25;Netflix;-99
""")
        assertTrue(result.all { it.has("type") && it.has("category") })
        assertEquals("Abonnementer", result.single { it.getString("name") == "Netflix" }.getString("category"))
    }



    @Test
    fun conflictingDirectionAndDebitColumnAreMarkedForReview() {
        val result = transactions("""Dato;Beskrivelse;Debet;Kredit;Retning
2026-10-24;Køb;500,00;;Indtægt
""").single()
        assertEquals("Udgift", result.getString("type"))
        assertTrue(result.getInt("_saldoCsvDirectionConfidence") < 80)
        assertTrue(result.getBoolean("_saldoCsvNeedsReview"))
    }

    @Test
    fun categoriesPreferSpecificLabelsForDaycareAndHousing() {
        val result = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Daginstitution Nord;-3392,00
2026-10-25;Husleje SAB;-5655,00
""")
        assertEquals("Daginstitution", result.single { it.getString("name").contains("Daginstitution") }.getString("category"))
        assertEquals("Husleje", result.single { it.getString("name").contains("Husleje") }.getString("category"))
    }

    @Test
    fun unknownPositiveTransferIsMarkedForDirectionReview() {
        val row = transactions("""Dato;Beskrivelse;Beløb
2026-10-24;Overførsel reference 123;250,00
""").single()
        assertEquals("Udgift", row.getString("type"))
        assertTrue(row.getInt("_saldoCsvDirectionConfidence") < 72)
        assertTrue(row.getBoolean("_saldoCsvNeedsReview"))
    }

    @Test
    fun duplicateFingerprintIsCaseInsensitiveAndIgnoresImportMetadata() {
        val first = org.json.JSONObject().put("id", "a").put("name", "NETTO").put("amount", 125.0)
            .put("category", "Mad").put("date", "2026-10-24").put("type", "Udgift").put("owner", "Mig")
        val second = org.json.JSONObject(first.toString()).put("id", "csv-1").put("name", "Netto")
            .put("category", "Transport").put("_saldoCsvConfidence", 94)
        // The fingerprint is based on business fields, not generated IDs or confidence metadata.
        assertEquals(csvRecordFingerprint("transactions", first), csvRecordFingerprint("transactions", second))
    }
}
