# CSV-import i Saldo 4.3.5

Saldo kan importere bank-CSV og Saldo-eksport. Vælg filen under **Indstillinger → Import og eksport → Importér CSV-fil**. Importen analyserer filen, viser forslag og gemmer ikke noget, før du bekræfter.

## Kolonner

Dato og beskrivelse skal genkendes. Beløb kan komme fra én kolonne (`Beløb`, `Amount`, `Value`) eller separate debet-/udbetalings- og kredit-/indbetalingskolonner. Semikolon, komma og tabulator accepteres; felter i anførselstegn og danske/engelske talformater understøttes.

## Retning og kategori

Saldo prioriterer separate debet/kredit-felter, en tydelig retningstype og beløbets fortegn. Kendte indkomstord i teksten kan supplere retningen, men usikre forslag mærkes til gennemsyn. Kategoriforslag bruger, i denne rækkefølge, en specifik kategori i CSV, brugerens tidligere afsenderrettelser, sammenlignelige tidligere poster, tekstregler og brugerens eksisterende kategorier. Beløbslighed er kun et ekstra signal sammen med en genkendt afsender.

Brugeren kan ændre både indtægt/udgift og kategori i forhåndsvisningen. Kategorirettelser gemmes lokalt og pr. aktiv konto; de sendes ikke til en ekstern kategoriseringstjeneste. Ukendte beskrivelser markeres som usikre og falder tilbage til en generel kategori.

## Dubletter

Dubletkontrollen sammenligner transaktionens beskrivelse, dato, retning, ejer og beløb afrundet til øre. Kategori eller genereret import-id gør ikke samme transaktion til en ny post. Kontrollér alligevel importresultatet, især hvis banken bruger samme tekst til mange forskellige betalinger samme dag.

## Saldo-format

Skabelonen `Saldo-CSV-skabelon.csv` bruger `type;navn;beløb;kategori;dato;status;ejer`. En `type=post`-række har `status=Indtægt` eller `Udgift`, og beløbet kan være absolut. Andre bankformater kan bruge negative udgifter og positive indtægter.
