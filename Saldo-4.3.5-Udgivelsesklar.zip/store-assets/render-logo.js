// Renders the Saldo 2026 minimalist S logo into every required asset size.
const { chromium } = require('playwright');
const path = require('path');
const out = process.argv[2];

// Geometric S: two 245° arcs (r=74) with round caps, 512×512 design space.
const R = 74, CX = 256, TOP = 182, BOT = 330;
const rad = d => d * Math.PI / 180;
const p = (cy, a) => [(CX + R * Math.cos(rad(a))).toFixed(2), (cy + R * Math.sin(rad(a))).toFixed(2)];
const [sx, sy] = p(TOP, -28), [mx, my] = p(TOP, 90), [ex, ey] = p(BOT, 152);
const S_PATH = `M ${sx} ${sy} A ${R} ${R} 0 1 0 ${mx} ${my} A ${R} ${R} 0 1 1 ${ex} ${ey}`;
const STROKE = 60;

const defs = `
<defs>
  <linearGradient id="sg" x1="370" y1="90" x2="150" y2="430" gradientUnits="userSpaceOnUse">
    <stop offset="0" stop-color="#D8CCFF"/>
    <stop offset=".32" stop-color="#9B7BFF"/>
    <stop offset=".68" stop-color="#6366F1"/>
    <stop offset="1" stop-color="#38BDF8"/>
  </linearGradient>
  <linearGradient id="bg" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
    <stop offset="0" stop-color="#1A1747"/>
    <stop offset=".55" stop-color="#0C0F2B"/>
    <stop offset="1" stop-color="#060816"/>
  </linearGradient>
  <radialGradient id="glow" cx="256" cy="246" r="210" gradientUnits="userSpaceOnUse">
    <stop offset="0" stop-color="#7C5CFF" stop-opacity=".55"/>
    <stop offset=".55" stop-color="#4F46E5" stop-opacity=".16"/>
    <stop offset="1" stop-color="#4F46E5" stop-opacity="0"/>
  </radialGradient>
  <filter id="soft" filterUnits="userSpaceOnUse" x="-256" y="-256" width="1024" height="1024"><feGaussianBlur stdDeviation="16"/></filter>
</defs>`;

// The S mark, scaled around the canvas centre. `mono` draws a flat single-colour version.
const mark = (scale = 1, { mono = null, glow = true } = {}) => {
  const t = `translate(256 256) scale(${scale}) translate(-256 -256)`;
  if (mono) return `<g transform="${t}"><path d="${S_PATH}" fill="none" stroke="${mono}" stroke-width="${STROKE}" stroke-linecap="round"/></g>`;
  return `<g transform="${t}">
    ${glow ? `<path d="${S_PATH}" fill="none" stroke="#8B5CF6" stroke-opacity=".55" stroke-width="${STROKE}" stroke-linecap="round" filter="url(#soft)"/>` : ''}
    <path d="${S_PATH}" fill="none" stroke="url(#sg)" stroke-width="${STROKE}" stroke-linecap="round"/>
  </g>`;
};

const tile = (rx) => `
  <rect width="512" height="512" rx="${rx}" fill="url(#bg)"/>
  <rect width="512" height="512" rx="${rx}" fill="url(#glow)"/>
  ${rx > 0 ? `<rect x="2" y="2" width="508" height="508" rx="${rx - 2}" fill="none" stroke="#FFFFFF" stroke-opacity=".08" stroke-width="3"/>` : ''}`;

const svg = (body, w = 512, h = 512, vb = '0 0 512 512') =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="${vb}">${defs}${body}</svg>`;

const assets = [
  // In-app logo: rounded navy tile with the gradient S.
  { file: 'app/src/main/res/drawable-nodpi/ic_saldo_logo.png', size: 512, svg: svg(tile(118) + mark(.86)) },
  // Adaptive icon foreground (108dp canvas, mark inside the 66dp safe zone) and monochrome.
  { file: 'app/src/main/res/drawable-xxxhdpi/ic_launcher_foreground.png', size: 432, svg: svg(mark(.66)) },
  { file: 'app/src/main/res/drawable-xxxhdpi/ic_launcher_monochrome.png', size: 432, svg: svg(mark(.66, { mono: '#FFFFFF' })) },
  // Status-bar notification icon: white silhouette only.
  { file: 'app/src/main/res/drawable-nodpi/ic_saldo_notification.png', size: 96, svg: svg(mark(1.02, { mono: '#FFFFFF' })) },
  // Legacy launcher icons for devices without adaptive icons.
  ...[['mdpi', 48], ['hdpi', 72], ['xhdpi', 96], ['xxhdpi', 144], ['xxxhdpi', 192]].map(([d, s]) => (
    { file: `app/src/main/res/mipmap-${d}/ic_launcher.png`, size: s, svg: svg(tile(112) + mark(.80, { glow: s >= 96 })) })),
  // Store and website assets.
  { file: 'store-assets/app-icon-512.png', size: 512, svg: svg(tile(0) + mark(.84)), opaque: true },
  { file: 'docs/assets/saldo-icon.png', size: 512, svg: svg(tile(0) + mark(.84)), opaque: true },
  { file: 'store-assets/saldo-s-mark-transparent.png', size: 512, svg: svg(mark(1.12, { glow: false })) },
];

const wordmark = (textColor) => `<!doctype html><html><body style="margin:0;background:transparent">
  <div style="width:1500px;height:420px;display:flex;align-items:center;gap:56px;padding-left:60px;box-sizing:border-box">
    ${svg(tile(118) + mark(.86), 300, 300)}
    <div style="font-family:'Inter Display','Inter',sans-serif;font-weight:800;font-size:200px;letter-spacing:-7px;color:${textColor};line-height:1">Saldo</div>
  </div></body></html>`;

const feature = `<!doctype html><html><body style="margin:0">
  <div style="position:relative;width:1024px;height:500px;overflow:hidden;font-family:'Inter Display','Inter',sans-serif;
      background:radial-gradient(circle at 78% 18%, rgba(124,92,255,.45), transparent 46%),radial-gradient(circle at 8% 100%, rgba(56,189,248,.18), transparent 42%),linear-gradient(135deg,#1A1747 0%,#0C0F2B 55%,#060816 100%)">
    <div style="position:absolute;left:84px;top:110px">${svg(tile(118) + mark(.86), 280, 280)}</div>
    <div style="position:absolute;left:420px;top:136px;color:#F5F3FF">
      <div style="font-size:120px;font-weight:800;letter-spacing:-4px;line-height:1">Saldo</div>
      <div style="margin-top:22px;font-family:'Inter',sans-serif;font-size:36px;font-weight:500;color:#C9C6E8">Dit overblik. Din økonomi.</div>
      <div style="margin-top:28px;width:150px;height:8px;border-radius:8px;background:linear-gradient(90deg,#9B7BFF,#6366F1,#38BDF8)"></div>
    </div>
  </div></body></html>`;

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  for (const a of assets) {
    await page.setViewportSize({ width: a.size, height: a.size });
    await page.setContent(`<!doctype html><html><body style="margin:0;background:transparent">${a.svg.replace('<svg ', `<svg style="display:block;width:${a.size}px;height:${a.size}px" `)}</body></html>`);
    await page.screenshot({ path: path.join(out, a.file), omitBackground: !a.opaque, clip: { x: 0, y: 0, width: a.size, height: a.size } });
  }
  for (const [file, color] of [['store-assets/saldo-wordmark-dark.png', '#F5F3FF'], ['store-assets/saldo-wordmark-light.png', '#141633']]) {
    await page.setViewportSize({ width: 1500, height: 420 });
    await page.setContent(wordmark(color));
    await page.screenshot({ path: path.join(out, file), omitBackground: true, clip: { x: 0, y: 0, width: 1500, height: 420 } });
  }
  await page.setViewportSize({ width: 1024, height: 500 });
  await page.setContent(feature);
  await page.screenshot({ path: path.join(out, 'store-assets/feature-graphic-1024x500.jpg'), type: 'jpeg', quality: 92, clip: { x: 0, y: 0, width: 1024, height: 500 } });
  await browser.close();
  console.log('rendered', assets.length + 3, 'assets');
})();
