# Saldo 4.4.0 – udgivelsesrevision

## Automatisk kontrolleret
- `scripts/validate-saldo-source.py`: versionering, manifest, logo/ikoner, CSV-flow, kontoafgrænsning og workflow.
- GitHub Actions: JUnit-tests (CSV-import inkl. Nordea-/Danske Bank-format, Excel `sep=`-linje og metadata over overskrift), `assembleDebug`, APK-identitet (`dk.saldo.app`, versionCode 33, versionName 4.4.0) og valgfri signeret AAB.

## Gennemgået i koden
- Datoparsing er beskyttet; ID'er repareres ved indlæsning; ingen kald fejler på tomme lister.
- Synkronisering validerer data begge veje; tom/ugyldig onlinekopi overskriver aldrig lokale data.
- PIN gemmes saltet/hashet med konstant-tids-sammenligning og pause efter 5 forsøg; biometri kræver PIN som reserve; automatisk lås efter 60 sek. i baggrunden.
- Saldo og løn gemmes præcist (eksakt streng ved siden af den gamle Float-nøgle).

## Kræver manuel test på enhed
- Velkomstguide, "Del til Saldo" fra netbank/Filer, genveje på startskærmen, faste poster over månedsskifte, datovælger, cirkeldiagram, systemtema og widgets.
- TalkBack og stor skriftstørrelse.
