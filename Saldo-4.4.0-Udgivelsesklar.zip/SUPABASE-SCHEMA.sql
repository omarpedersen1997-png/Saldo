-- Kør i Supabase Dashboard → SQL Editor → New query.
-- Hver bruger kan kun læse/skrive sin egen Saldo-backup.
create table if not exists public.saldo_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.saldo_user_data enable row level security;

drop policy if exists "Users can read their own Saldo data" on public.saldo_user_data;
drop policy if exists "Users can insert their own Saldo data" on public.saldo_user_data;
drop policy if exists "Users can update their own Saldo data" on public.saldo_user_data;

create policy "Users can read their own Saldo data"
  on public.saldo_user_data for select to authenticated
  using (auth.uid() = user_id);

create policy "Users can insert their own Saldo data"
  on public.saldo_user_data for insert to authenticated
  with check (auth.uid() = user_id);

create policy "Users can update their own Saldo data"
  on public.saldo_user_data for update to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

grant select, insert, update on public.saldo_user_data to authenticated;

-- ---------------------------------------------------------------- Spørg Saldo (AI-svar)
-- Daglig grænse pr. bruger for edge-funktionen saldo-assistant. Kun service_role må kalde funktionen.
create table if not exists public.saldo_assistant_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null default current_date,
  count integer not null default 0,
  primary key (user_id, day)
);

alter table public.saldo_assistant_usage enable row level security;

create or replace function public.saldo_assistant_take(p_user uuid, p_limit integer)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  used integer;
begin
  insert into public.saldo_assistant_usage as u (user_id, day, count)
  values (p_user, current_date, 1)
  on conflict (user_id, day) do update set count = u.count + 1
  returning u.count into used;
  return used <= p_limit;
end;
$$;

revoke all on function public.saldo_assistant_take(uuid, integer) from public, anon, authenticated;
grant execute on function public.saldo_assistant_take(uuid, integer) to service_role;
