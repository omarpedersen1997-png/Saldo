package dk.saldo.app

import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

/** Actions that arrive from outside the app: share sheet, file "Åbn med" and launcher shortcuts. */
internal sealed interface SaldoExternalAction {
    data object NewPost : SaldoExternalAction
    data object PickCsv : SaldoExternalAction
    data class ImportUri(val uri: Uri) : SaldoExternalAction
    data class ImportText(val text: String) : SaldoExternalAction
}

class MainActivity : FragmentActivity() {
    private val externalAction = mutableStateOf<SaldoExternalAction?>(null)

    private fun handleExternalIntent(source: Intent?) {
        val action = when (source?.action) {
            Intent.ACTION_SEND -> androidx.core.content.IntentCompat.getParcelableExtra(source, Intent.EXTRA_STREAM, Uri::class.java)?.let { SaldoExternalAction.ImportUri(it) }
                ?: source.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.isNotBlank() }?.let { SaldoExternalAction.ImportText(it) }
            Intent.ACTION_VIEW -> source.data?.takeIf { it.scheme == "content" || it.scheme == "file" }?.let { SaldoExternalAction.ImportUri(it) }
            "dk.saldo.app.action.NEW_POST" -> SaldoExternalAction.NewPost
            "dk.saldo.app.action.IMPORT_CSV" -> SaldoExternalAction.PickCsv
            else -> null
        } ?: return
        externalAction.value = action
        // Do not re-run the import if the activity is recreated (rotation, theme change).
        setIntent(Intent(this, MainActivity::class.java))
    }

    private val passwordRecoveryToken = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15/16 edge-to-edge: draw backgrounds behind transparent system bars,
        // while each screen applies safe insets to keep interactive content clear.
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        saldoPreferences(this).let { designPrefs ->
            // The "Klar" redesign is light-first: once, let the theme follow the phone (it can be changed in Settings).
            if (!designPrefs.getBoolean("design_klar_applied", false)) {
                val systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
                designPrefs.edit().putString("theme_mode", "system").putBoolean("dark_mode", systemDark)
                    .putBoolean("design_2026_dark_applied", true).putBoolean("design_klar_applied", true).apply()
            }
        }
        setSaldoPalette(saldoPreferences(this).getBoolean("dark_mode", true))
        val initialDarkMode = saldoPreferences(this).getBoolean("dark_mode", true)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !initialDarkMode
            isAppearanceLightNavigationBars = !initialDarkMode
        }
        handlePasswordRecoveryIntent(intent)
        handleExternalIntent(intent)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("saldo-bill-reminders", ExistingPeriodicWorkPolicy.KEEP, PeriodicWorkRequestBuilder<BillReminderWorker>(24, TimeUnit.HOURS).build())
        setContent { SaldoApp(passwordRecoveryToken.value, { passwordRecoveryToken.value = null }, externalAction.value) { externalAction.value = null } }
    }

    override fun onStop() {
        // Encrypted writes run in the background; make sure they are on disk before Android may end the process.
        flushSaldoPreferences()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePasswordRecoveryIntent(intent)
        handleExternalIntent(intent)
    }

    private fun handlePasswordRecoveryIntent(source: Intent?) {
        val uri = source?.data
        val fragmentValues = uri?.fragment?.let { Uri.parse("https://saldo-recovery.invalid/?$it") }
        val type = uri?.getQueryParameter("type") ?: fragmentValues?.getQueryParameter("type")
        val token = uri?.getQueryParameter("access_token") ?: fragmentValues?.getQueryParameter("access_token")
        val prefs = saldoPreferences(this)
        if (type == "recovery" && !token.isNullOrBlank()) {
            prefs.edit().putString("password_recovery_token", token).apply()
            // Do not retain the access token inside the activity's original deep-link Intent.
            setIntent(Intent(this, MainActivity::class.java))
        }
        passwordRecoveryToken.value = prefs.getString("password_recovery_token", null)
    }
}

internal val mainTabs = listOf("Overblik", "Poster", "Regninger", "Budget", "Mere")

internal val moreTabs = listOf("Spørg Saldo", "Faste poster", "Kategorier", "Opsparing", "Gæld", "Bil", "Abonnementer", "Hvad nu hvis?", "Rapporter", "Indstillinger")

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable internal fun SaldoApp(passwordRecoveryToken: String? = null, onRecoveryComplete: () -> Unit = {}, externalAction: SaldoExternalAction? = null, onExternalActionHandled: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { saldoPreferences(context) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", null) ?: if (prefs.getBoolean("dark_mode", true)) "dark" else "light") }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    LaunchedEffect(themeMode, systemDark) {
        darkMode = when (themeMode) { "system" -> systemDark; "light" -> false; else -> true }
        prefs.edit().putString("theme_mode", themeMode).apply()
    }
    var visibleHomeSections by remember {
        mutableStateOf(prefs.getString("home_visible_sections", defaultHomeSections.joinToString("|"))
            .orEmpty().split("|").filter { item -> defaultHomeSections.contains(item) }.ifEmpty { defaultHomeSections })
    }
    fun updateHomeSection(section: String, enabled: Boolean) {
        val updated = if (enabled) (visibleHomeSections + section).distinct() else visibleHomeSections.filterNot { it == section }
        visibleHomeSections = updated
        prefs.edit().putString("home_visible_sections", updated.joinToString("|")).apply()
    }
    LaunchedEffect(darkMode) {
        setSaldoPalette(darkMode)
        prefs.edit().putBoolean("dark_mode", darkMode).apply()
        (context as? android.app.Activity)?.window?.let { appWindow ->
            WindowInsetsControllerCompat(appWindow, appWindow.decorView).apply {
                isAppearanceLightStatusBars = !darkMode
                isAppearanceLightNavigationBars = !darkMode
            }
        }
        SaldoWidgetRefreshQueue.request(context)
    }
    val initialDataLoad = remember { loadSaldoDataSafely(prefs) }
    var data by remember { mutableStateOf(initialDataLoad.data) }
    var dataRecoveryNotice by remember { mutableStateOf(initialDataLoad.recoveryNotice) }
    val csvCategoryContext = remember(data) { buildCsvCategoryContext(data, prefs) }
    LaunchedEffect(Unit) {
        SaldoWidgetRefreshQueue.request(context)
        val snapshot = data.toString()
        val editor = prefs.edit().putString("data", snapshot)
        if (!prefs.contains("auto_backup_data")) editor.putString("auto_backup_data", snapshot).putLong("auto_backup_time", System.currentTimeMillis())
        val activeUserId = prefs.getString("active_account_user_id", null)
        if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), snapshot)
        editor.apply()
        dataRecoveryNotice?.let { message ->
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            dataRecoveryNotice = null
        }
    }
    fun list(key: String) = data.optJSONArray(key) ?: JSONArray()
    fun store(key: String, arr: JSONArray) {
        data.put(key, arr)
        val snapshot = data.toString()
        // Preserve the previously committed data as the recovery point before replacing it.
        val previousSnapshot = prefs.getString("data", "{}") ?: "{}"
        val editor = prefs.edit().putString("data", snapshot)
        val activeUserId = prefs.getString("active_account_user_id", null)
        if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), snapshot)
        if (previousSnapshot != snapshot) {
            editor.putString("auto_backup_data", previousSnapshot)
                .putLong("auto_backup_time", System.currentTimeMillis())
            if (!activeUserId.isNullOrBlank()) editor.putString(localAccountBackupKey(activeUserId), previousSnapshot)
        } else if (!prefs.contains("auto_backup_data")) {
            editor.putString("auto_backup_data", previousSnapshot)
                .putLong("auto_backup_time", System.currentTimeMillis())
        }
        editor.apply()
        data = JSONObject(snapshot)
        SaldoWidgetRefreshQueue.request(context)
    }
    fun add(key: String, obj: JSONObject) { val arr = list(key); arr.put(obj); store(key, arr) }
    val undoScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    fun delete(key: String, id: String) {
        val items = list(key).objects()
        val index = items.indexOfFirst { it.s("id") == id }
        if (index < 0) return
        val removed = items[index]
        val arr = JSONArray()
        items.filterIndexed { i, _ -> i != index }.forEach { arr.put(it) }
        store(key, arr)
        // Deleting is confirmed first; "Fortryd" is a second safety net against mistakes.
        undoScope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            val label = removed.s("name").ifBlank { removed.s("category") }.ifBlank { "Posten" }
            val result = snackbarHostState.showSnackbar("\"$label\" er slettet", actionLabel = "Fortryd", duration = SnackbarDuration.Short)
            if (result == SnackbarResult.ActionPerformed) {
                val current = list(key).objects().toMutableList()
                if (current.none { it.s("id") == id }) {
                    current.add(index.coerceAtMost(current.size), removed)
                    val restored = JSONArray()
                    current.forEach { restored.put(it) }
                    store(key, restored)
                }
            }
        }
    }
    var tab by remember { mutableStateOf("Overblik") }
    var dialog by remember { mutableStateOf("") }
    var transactionSearch by remember { mutableStateOf("") }
    var transactionTypeFilter by remember { mutableStateOf("Alle") }
    var pin by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf(prefs.getString("last_account_email", "").orEmpty()) }
    /** Only people who have signed in on this phone before are greeted with "Velkommen tilbage". */
    val returningUser = remember { prefs.contains("last_account_email") }
    var localOnlyMode by remember { mutableStateOf(prefs.getBoolean("local_only_mode", false)) }
    var loginPassword by remember { mutableStateOf("") }
    var loginConfirm by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loginMode by remember { mutableStateOf(false) }
    var loginStep by remember { mutableStateOf(0) }
    // Old sessions without an account binding must re-authenticate once after this update.
    var accountUnlocked by remember { mutableStateOf(
        (prefs.getString("online_access_token", null) != null && prefs.getString("active_account_user_id", null) != null) ||
            prefs.getBoolean("local_only_mode", false)
    ) }
    var loginLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var pendingCsvImport by remember { mutableStateOf<CsvImportPlan?>(null) }
    var csvImportBusy by remember { mutableStateOf(false) }
    var csvImportError by remember { mutableStateOf("") }
    var multiBillProcessing by remember { mutableStateOf(false) }
    var multiBillDrafts by remember { mutableStateOf<List<BillImportDraft>>(emptyList()) }
    var showMultiBillDialog by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<JSONObject?>(null) }
    var saveSuccess by remember { mutableStateOf<String?>(null) }
    var editingRecord by remember { mutableStateOf<JSONObject?>(null) }
    var splittingRecord by remember { mutableStateOf<JSONObject?>(null) }
    var showRemoveLockDialog by remember { mutableStateOf(false) }
    var weeklySummaryOn by remember { mutableStateOf(prefs.getBoolean("weekly_summary_enabled", true)) }
    var entryReminder by remember { mutableStateOf(prefs.getString("entry_reminder", "off") ?: "off") }
    remember { saldoAmountsHidden = prefs.getBoolean("amounts_hidden", false); true }
    var recapDismissed by remember { mutableStateOf(prefs.getString("month_recap_dismissed", "").orEmpty()) }
    var transactionCategoryFilter by remember { mutableStateOf<String?>(null) }
    var transactionSort by remember { mutableStateOf("Dato") }
    var showBudgetSuggestions by remember { mutableStateOf(false) }
    var dialogNonce by remember { mutableIntStateOf(0) }
    var showSearch by remember { mutableStateOf(false) }
    var showAssistant by remember { mutableStateOf(false) }
    var globalQuery by remember { mutableStateOf("") }
    var depositGoal by remember { mutableStateOf<JSONObject?>(null) }
    var renamingCategory by remember { mutableStateOf<String?>(null) }
    var showOnboarding by remember {
        mutableStateOf(!prefs.getBoolean("onboarding_done", false) && !hasAnySaldoRecords(data) && !prefs.contains("payday"))
    }
    var removeLockPin by remember { mutableStateOf("") }

    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            csvImportBusy = true
            csvImportError = ""
            // Snapshot local categories, merchant history and previous corrections before doing IO.
            val categoryContext = csvCategoryContext
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val raw = readTextFromUri(context, uri, 10 * 1024 * 1024)
                        parseSaldoCsv(raw, categoryContext)
                    }
                }
                csvImportBusy = false
                result.onSuccess { plan -> pendingCsvImport = plan }
                    .onFailure { error ->
                        csvImportError = error.message ?: "CSV-filen kunne ikke læses."
                        Toast.makeText(context, csvImportError, Toast.LENGTH_LONG).show()
                    }
            }
        }
    }

    /** Shared CSV import used by the file picker, "Del til Saldo" and pasted/shared text. */
    fun runCsvImport(loader: () -> String) {
        csvImportBusy = true
        csvImportError = ""
        val categoryContext = csvCategoryContext
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val raw = loader()
                    parseSaldoCsv(raw, categoryContext)
                }
            }
            csvImportBusy = false
            result.onSuccess { plan -> pendingCsvImport = plan }
                .onFailure { error ->
                    csvImportError = error.message ?: "Filen kunne ikke læses som CSV."
                    Toast.makeText(context, csvImportError, Toast.LENGTH_LONG).show()
                }
        }
    }

    val multiBillPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            multiBillProcessing = true
            scope.launch {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val drafts = mutableListOf<BillImportDraft>()
                try {
                    uris.take(20).forEachIndexed { index, uri ->
                        val result = runCatching {
                            val image = withContext(Dispatchers.IO) { InputImage.fromFilePath(context, uri) }
                            recognizer.process(image).saldoAwait().text
                        }
                        result.onSuccess { text ->
                            val parsed = parseBillText(text)
                            drafts += BillImportDraft(
                                id = "multi-${System.currentTimeMillis()}-$index",
                                name = parsed.first,
                                amount = parsed.second,
                                date = parsed.third,
                                selected = parsed.first.isNotBlank() || parsed.second.isNotBlank() || parsed.third.isNotBlank(),
                                rawText = text.take(420)
                            )
                        }.onFailure { error ->
                            drafts += BillImportDraft(
                                id = "multi-${System.currentTimeMillis()}-$index",
                                name = "",
                                amount = "",
                                date = "",
                                selected = false,
                                rawText = "Kunne ikke læse dette billede: ${error.message ?: "ukendt fejl"}"
                            )
                        }
                    }
                } finally {
                    recognizer.close()
                }
                multiBillDrafts = drafts
                if (uris.size > 20) Toast.makeText(context, "Der blev valgt ${uris.size} billeder. De første 20 er læst; importér resten bagefter.", Toast.LENGTH_LONG).show()
                showMultiBillDialog = drafts.isNotEmpty()
                multiBillProcessing = false
                if (drafts.isEmpty()) Toast.makeText(context, "Ingen billeder kunne importeres.", Toast.LENGTH_LONG).show()
            }
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            scheduleDueBillNotification(context, list("bills").objects())
            scheduleBudgetWarningNotification(context, data)
            scheduleSubscriptionRenewalNotification(context, data)
        }
        else Toast.makeText(context, "Notifikationer er slået fra. Aktivér dem i Android-indstillinger.", Toast.LENGTH_LONG).show()
    }
    var cloudStatus by remember { mutableStateOf("Ikke synkroniseret") }
    var cloudBusy by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deleteAccountBusy by remember { mutableStateOf(false) }
    var deleteAccountError by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(prefs.getString("pin_hash", null) == null && prefs.getString("pin", null) == null && !prefs.getBoolean("biometric_enabled", false)) }
    val lifecycleOwner = context as? androidx.lifecycle.LifecycleOwner
    DisposableEffect(lifecycleOwner) {
        var backgroundedAt = 0L
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> backgroundedAt = System.currentTimeMillis()
                androidx.lifecycle.Lifecycle.Event.ON_START -> {
                    val lockConfigured = prefs.getString("pin_hash", null) != null || prefs.getString("pin", null) != null || prefs.getBoolean("biometric_enabled", false)
                    if (lockConfigured && backgroundedAt > 0L && System.currentTimeMillis() - backgroundedAt > 60_000L) {
                        unlocked = false
                        pin = ""
                    }
                    backgroundedAt = 0L
                }
                else -> Unit
            }
        }
        lifecycleOwner?.lifecycle?.addObserver(observer)
        onDispose { lifecycleOwner?.lifecycle?.removeObserver(observer) }
    }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(180); splash = false }
    val today = LocalDate.now()
    // Cache derived lists by the immutable data snapshot. This avoids re-filtering and
    // re-sorting every transaction/bill on unrelated UI recompositions.
    val tx = remember(data) { list("transactions").objects() }
    var carMaintenance by remember { mutableStateOf(parseCarMaintenance(prefs.getString(CAR_MAINTENANCE_KEY, null))) }
    val bills = remember(data) { list("bills").objects() }
    // Parse dates once per data snapshot. Monthly dashboards and reports share this index.
    val transactionsByMonth = remember(tx) {
        tx.mapNotNull { item ->
            runCatching { YearMonth.from(LocalDate.parse(item.s("date"))) }.getOrNull()?.let { month -> month to item }
        }.groupBy({ it.first }, { it.second })
    }
    val thisMonthTx = remember(transactionsByMonth, today) { transactionsByMonth[YearMonth.from(today)].orEmpty() }
    val monthSpendByCategoryOwner = remember(thisMonthTx) {
        thisMonthTx.asSequence()
            .filter { it.s("type") == "Udgift" }
            .groupBy { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }
            .mapValues { (_, rows) -> rows.sumOf { it.n("amount") } }
    }
    val income = remember(tx) { tx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") } }
    val expenses = remember(tx) { tx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") } }
    var viewMonth by remember { mutableStateOf(YearMonth.now()) }
    val viewMonthTx = remember(transactionsByMonth, viewMonth) { transactionsByMonth[viewMonth].orEmpty() }
    val viewSpendByCategoryOwner = remember(viewMonthTx) {
        viewMonthTx.asSequence()
            .filter { it.s("type") == "Udgift" }
            .groupBy { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }
            .mapValues { (_, rows) -> rows.sumOf { it.n("amount") } }
    }
    val viewIncome = remember(viewMonthTx) { viewMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") } }
    val viewExpenses = remember(viewMonthTx) { viewMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") } }
    /** How far through the viewed month we are: 1.0 for past months, today's share for the current month. */
    fun viewMonthProgress(): Float = if (viewMonth < YearMonth.now()) 1f else today.dayOfMonth.toFloat() / today.lengthOfMonth()
    val monthIncome = remember(thisMonthTx) { thisMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") } }
    val monthExpenses = remember(thisMonthTx) { thisMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") } }
    val unpaidBills = remember(bills) { bills.filter { !it.optBoolean("paid", false) } }
    val unpaid = remember(unpaidBills) { unpaidBills.sumOf { it.n("amount") } }
    val payday = runCatching { LocalDate.parse(prefs.getString("payday", today.toString())) }.getOrElse { today }
    val payAmount = prefs.saldoMoney("pay_amount", 10000.0)
    /** False until the user has entered their pay; screens then show a prompt instead of numbers based on the default. */
    val hasPaySetup = prefs.contains("payday")
    val payFrequency = prefs.getString("pay_frequency", null) ?: "monthly"
    val (daysToPay, daysUntilNextPay) = payCycle(payday, today, payFrequency)
    val payPeriodEnd = today.plusDays(daysUntilNextPay.toLong())
    val billsDueBeforePayday = remember(bills, today, payPeriodEnd) { bills.filter { bill ->
        !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due ->
            !due.isBefore(today) && !due.isAfter(payPeriodEnd)
        } == true
    }.sumOf { it.n("amount") } }
    val hasCurrentBalance = prefs.contains("cash_balance")
    val currentBalance = prefs.saldoMoney("cash_balance", 0.0)
    val estimatedAvailableToPayday = if (hasCurrentBalance) currentBalance - billsDueBeforePayday else monthIncome - monthExpenses - billsDueBeforePayday
    val dailyAllowance = estimatedAvailableToPayday / daysUntilNextPay.coerceAtLeast(1)
    val backupTimestamp = prefs.getLong("auto_backup_time", 0L)
    val backupDescription = if (backupTimestamp > 0L) {
        "Forrige datatilstand · ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("da", "DK")).format(java.util.Date(backupTimestamp))}"
    } else "Der er endnu ikke oprettet et gendannelsespunkt."
    LaunchedEffect(Unit) {
        val existing = (data.optJSONArray("bills") ?: JSONArray()).objects()
        val today = LocalDate.now()
        val knownOccurrences = existing.map { billOccurrenceKey(it) }.toMutableSet()
        val additions = existing.filter { it.optBoolean("paid", false) && isRecurringRepeat(it.s("repeat")) }.mapNotNull { bill ->
            val oldDate = runCatching { LocalDate.parse(bill.s("date")) }.getOrNull() ?: return@mapNotNull null
            val anchorDay = bill.optInt("recurrenceDay", oldDate.dayOfMonth).coerceIn(1, 31)
            val next = nextRecurringOccurrence(oldDate, today, bill.s("repeat"), anchorDay) ?: return@mapNotNull null
            val newBill = JSONObject(bill.toString()).put("id", "rec-${bill.s("id")}-${next}").put("date", next.toString()).put("recurrenceDay", anchorDay).put("paid", false)
            if (knownOccurrences.add(billOccurrenceKey(newBill))) newBill else null
        }
        if (additions.isNotEmpty()) { val arr = JSONArray(); (existing + additions).forEach { arr.put(it) }; store("bills", arr) }
    }
    LaunchedEffect(Unit) {
        // Recurring posts: create every due occurrence up to today, once. Generated ids are remembered,
        // so a deleted occurrence is never re-created, and setting "Engang" on the latest post stops the series.
        val existingTx = (data.optJSONArray("transactions") ?: JSONArray()).objects()
        val todayForRecurring = LocalDate.now()
        val generatedBefore = prefs.getStringSet("recurring_generated_ids", emptySet()).orEmpty()
        val generated = generateRecurringOccurrences(existingTx, todayForRecurring, generatedBefore)
        if (generated.isNotEmpty()) {
            val updated = JSONArray()
            (existingTx + generated).forEach { updated.put(it) }
            store("transactions", updated)
            prefs.edit().putStringSet("recurring_generated_ids", (generatedBefore + generated.map { it.s("id") }).toList().takeLast(1000).toSet()).apply()
            Toast.makeText(context, "${generated.size} faste ${if (generated.size == 1) "post er" else "poster er"} oprettet automatisk.", Toast.LENGTH_LONG).show()
        }
    }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            runCatching {
                val referenced = (data.optJSONArray("transactions") ?: JSONArray()).objects().map { it.s("receipt") }.filter { it.isNotBlank() }.toSet()
                File(context.filesDir, "receipts").listFiles()?.forEach { file ->
                    if (file.name !in referenced && System.currentTimeMillis() - file.lastModified() > 86_400_000L) file.delete()
                }
            }
        }
    }
    fun stopRecurringSeries(seriesId: String) {
        val updated = JSONArray()
        list("transactions").objects().forEach { item ->
            val copy = JSONObject(item.toString())
            if (copy.s("recurrenceId").ifBlank { copy.s("id") } == seriesId && isRecurringRepeat(copy.s("repeat"))) copy.put("repeat", "Engangsbetaling")
            updated.put(copy)
        }
        store("transactions", updated)
        saveSuccess = "Den faste post er stoppet"
    }
    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            secondary = Mint,
            onSecondary = Color(0xFF04140D),
            tertiary = Blue,
            background = Night,
            surface = Panel,
            surfaceVariant = PanelRaised,
            secondaryContainer = Violet.copy(alpha = .14f),
            onSecondaryContainer = Violet,
            onSurface = White,
            onSurfaceVariant = Muted,
            onBackground = White,
            outline = BorderSubtle
        ) else lightColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            secondary = Mint,
            onSecondary = Color.White,
            tertiary = Blue,
            background = Night,
            surface = Panel,
            surfaceVariant = PanelRaised,
            secondaryContainer = Violet.copy(alpha = .12f),
            onSecondaryContainer = Violet,
            onSurface = White,
            onSurfaceVariant = Muted,
            onBackground = White,
            outline = BorderSubtle
        ),
        typography = saldoTypography(),
        shapes = Shapes(
            extraSmall = RoundedCornerShape(10.dp),
            small = RoundedCornerShape(14.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(26.dp),
            extraLarge = RoundedCornerShape(32.dp)
        )
    ) {
        if (!passwordRecoveryToken.isNullOrBlank()) {
            var newPassword by remember { mutableStateOf("") }
            var confirmNewPassword by remember { mutableStateOf("") }
            var recoveryError by remember { mutableStateOf("") }
            Box(
                Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode))
                    .statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.Center
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(76.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Nulstil adgangskode", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("Vælg en ny adgangskode til din Saldo-konto.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(24.dp))
                    Surface(color = Panel.copy(alpha = .98f), shape = RoundedCornerShape(26.dp), border = saldoCardBorder(), shadowElevation = 10.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Field("Ny adgangskode (mindst 8 tegn)", newPassword, { newPassword = it; recoveryError = "" }, password = true)
                            Field("Gentag ny adgangskode", confirmNewPassword, { confirmNewPassword = it; recoveryError = "" }, password = true)
                            if (recoveryError.isNotBlank()) Text(recoveryError, color = SaldoDanger, fontSize = 12.sp)
                            Button(
                                onClick = {
                                    when {
                                        newPassword.length < 8 -> recoveryError = "Adgangskoden skal være mindst 8 tegn."
                                        newPassword != confirmNewPassword -> recoveryError = "Adgangskoderne er ikke ens."
                                        else -> {
                                            loginLoading = true
                                            recoveryError = ""
                                            scope.launch {
                                                val result = withContext(Dispatchers.IO) { runCatching { supabaseUpdatePassword(passwordRecoveryToken, newPassword) } }
                                                loginLoading = false
                                                result.onSuccess {
                                                    prefs.edit().remove("password_recovery_token").remove("online_access_token").remove("online_refresh_token").apply()
                                                    accountUnlocked = false
                                                    loginStep = 0
                                                    loginPassword = ""
                                                    newPassword = ""
                                                    confirmNewPassword = ""
                                                    onRecoveryComplete()
                                                    Toast.makeText(context, "Adgangskoden er ændret. Log ind med din nye adgangskode.", Toast.LENGTH_LONG).show()
                                                }.onFailure {
                                                    recoveryError = "Linket kan være udløbet. Bed om en ny nulstillingsmail, og prøv igen."
                                                }
                                            }
                                        }
                                    }
                                },
                                enabled = !loginLoading,
                                modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White, disabledContainerColor = Color.Transparent, disabledContentColor = Color.White.copy(alpha = .6f)),
                                shape = RoundedCornerShape(17.dp)
                            ) { Text(if (loginLoading) "Opdaterer…" else "Gem ny adgangskode", fontWeight = FontWeight.Bold) }
                            TextButton(onClick = {
                                prefs.edit().remove("password_recovery_token").apply()
                                onRecoveryComplete()
                            }, enabled = !loginLoading, modifier = Modifier.fillMaxWidth()) {
                                Text("Tilbage til login", color = Violet, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        } else if (splash) {
            Box(Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(96.dp).clip(RoundedCornerShape(30.dp)))
                    Spacer(Modifier.height(20.dp)); Text("saldo", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = (-1.8).sp)
                    Spacer(Modifier.height(4.dp)); Text("Dit overblik. Din økonomi.", color = Muted, fontSize = 15.sp)
                }
            }
        } else if (!accountUnlocked) {
            Box(
                Modifier.fillMaxSize().background(
                    saldoBackgroundBrush(darkMode)
                ).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.size(78.dp),
                        contentAlignment = Alignment.Center
                    ) { Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(72.dp).clip(RoundedCornerShape(22.dp))) }
                    Spacer(Modifier.height(17.dp))
                    Text("saldo", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.9).sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Din økonomi.\nDit overblik.", color = White, fontSize = 36.sp, lineHeight = 38.sp, letterSpacing = (-1.4).sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(9.dp))
                    Text("En enklere vej til økonomisk ro.", color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(27.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Panel.copy(alpha = 0.97f),
                        shape = RoundedCornerShape(28.dp),
                        border = saldoCardBorder(),
                        shadowElevation = 10.dp
                    ) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Two-step sign-in: email first, then a horizontal page transition to password.
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                repeat(2) { index ->
                                    Box(
                                        Modifier
                                            .padding(horizontal = 4.dp)
                                            .width(if (loginStep == index) 25.dp else 7.dp)
                                            .height(7.dp)
                                            .background(if (loginStep == index) Violet else PanelRaised, RoundedCornerShape(50))
                                    )
                                }
                            }
                            AnimatedContent(
                                targetState = loginStep,
                                transitionSpec = {
                                    if (targetState > initialState) {
                                        (slideInHorizontally(tween(320)) { it } + fadeIn(tween(220))) togetherWith
                                            (slideOutHorizontally(tween(320)) { -it } + fadeOut(tween(160)))
                                    } else {
                                        (slideInHorizontally(tween(320)) { -it } + fadeIn(tween(220))) togetherWith
                                            (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(160)))
                                    }
                                },
                                label = "login-two-step"
                            ) { step ->
                                Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                                    if (step == 0) {
                                        Text("Trin 1 af 2", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(if (loginMode) "Hvad er din e-mail?" else if (returningUser) "Velkommen tilbage" else "Log ind på Saldo", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (loginMode) "Vi starter med din e-mail og gør resten klar på næste side."
                                            else if (returningUser) "Skriv din e-mail, så gør vi klar til dit personlige overblik."
                                            else "Har du en Saldo-konto, så skriv din e-mail. Ellers kan du oprette en konto eller bruge appen uden konto nedenfor.",
                                            color = Muted, fontSize = 13.sp
                                        )
                                        Field("E-mailadresse", loginEmail, {
                                            if (loginEmail.trim().lowercase(Locale.ROOT) != it.trim().lowercase(Locale.ROOT)) {
                                                loginPassword = ""
                                                loginConfirm = ""
                                            }
                                            loginEmail = it
                                            loginError = ""
                                        }, email = true)
                                        if (loginError.isNotBlank()) Text(loginError, color = SaldoDanger, fontSize = 12.sp)
                                        Button(
                                            onClick = {
                                                val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                if (email.contains("@") && email.substringAfter("@").contains(".") && !email.endsWith(".")) {
                                                    loginEmail = email
                                                    loginError = ""
                                                    loginStep = 1
                                                } else {
                                                    loginError = "Indtast en gyldig e-mailadresse."
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White, disabledContainerColor = Color.Transparent, disabledContentColor = Color.White.copy(alpha = .6f)),
                                            shape = RoundedCornerShape(17.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                                Text("Fortsæt", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                                Spacer(Modifier.width(8.dp))
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    } else {
                                        Text("Trin 2 af 2", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(if (loginMode) "Vælg en adgangskode" else "Din adgangskode", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                        Text(if (loginMode) "Opret en sikker adgangskode på mindst 8 tegn." else "Indtast adgangskoden til din Saldo-konto.", color = Muted, fontSize = 13.sp)
                                        Surface(
                                            color = PanelRaised,
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                                            ) {
                                                Icon(Icons.Default.Email, contentDescription = null, tint = Violet, modifier = Modifier.size(18.dp))
                                                Text(loginEmail, color = White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                                TextButton(onClick = { loginStep = 0; loginError = ""; loginPassword = ""; loginConfirm = "" }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                                                    Text("Ret", color = Violet, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                        Field("Adgangskode", loginPassword, { loginPassword = it; loginError = "" }, password = true)
                                        if (loginMode) Field("Gentag adgangskode", loginConfirm, { loginConfirm = it; loginError = "" }, password = true)
                                        if (loginError.isNotBlank()) Text(loginError, color = SaldoDanger, fontSize = 12.sp)
                                        Button(
                                            onClick = {
                                                val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                when {
                                                    BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_ANON_KEY.isBlank() -> loginError = "Online-login er ikke tilgængeligt i denne version af appen."
                                                    loginPassword.isBlank() -> loginError = "Indtast din adgangskode."
                                                    loginMode && loginPassword.length < 8 -> loginError = "Ved oprettelse skal adgangskoden være mindst 8 tegn."
                                                    loginMode && loginPassword != loginConfirm -> loginError = "Adgangskoderne er ikke ens."
                                                    else -> {
                                                        loginLoading = true
                                                        loginError = ""
                                                        scope.launch {
                                                            val result = withContext(Dispatchers.IO) {
                                                                runCatching {
                                                                    supabaseAuth(email, loginPassword, loginMode).apply {
                                                                        val sessionToken = optString("access_token")
                                                                        if (sessionToken.isNotBlank()) put("_saldoUserId", currentCloudUserId(sessionToken))
                                                                    }
                                                                }
                                                            }
                                                            loginLoading = false
                                                            result.onSuccess { response ->
                                                                val token = response.optString("access_token")
                                                                if (loginMode && token.isBlank()) {
                                                                    loginError = "Kontoen er oprettet. Tjek din e-mail for bekræftelse, og log derefter ind."
                                                                    loginMode = false
                                                                    loginStep = 0
                                                                    loginPassword = ""
                                                                    loginConfirm = ""
                                                                } else if (token.isBlank()) {
                                                                    loginError = "Serveren returnerede ingen login-session."
                                                                } else {
                                                                    val userId = response.optString("_saldoUserId")
                                                                    if (userId.isBlank()) {
                                                                        loginError = "Login lykkedes ikke helt, fordi kontoen ikke kunne identificeres sikkert. Prøv igen."
                                                                    } else {
                                                                        // Coming from "uden konto": a new account on this phone takes the local data along.
                                                                        if (localOnlyMode && prefs.getString("active_account_user_id", null) == SALDO_LOCAL_ACCOUNT_ID && !prefs.contains(localAccountDataKey(userId))) {
                                                                            prefs.edit().remove("active_account_user_id").remove(localAccountDataKey(SALDO_LOCAL_ACCOUNT_ID))
                                                                                .remove(localAccountSettingsKey(SALDO_LOCAL_ACCOUNT_ID)).remove(localAccountBackupKey(SALDO_LOCAL_ACCOUNT_ID)).commit()
                                                                        }
                                                                        data = switchToAccountData(prefs, data, userId)
                                                                        prefs.edit().putString("online_access_token", token).putString("online_refresh_token", response.optString("refresh_token")).putString("account_email", email)
                                                                            .putString("last_account_email", email).putBoolean("local_only_mode", false).apply()
                                                                        localOnlyMode = false
                                                                        SaldoWidgetRefreshQueue.request(context)
                                                                        // Release credential strings from Compose state after a successful login.
                                                                        loginPassword = ""
                                                                        loginConfirm = ""
                                                                        loginError = ""
                                                                        unlocked = prefs.getString("pin_hash", null) == null &&
                                                                            prefs.getString("pin", null) == null &&
                                                                            !prefs.getBoolean("biometric_enabled", false)
                                                                        accountUnlocked = true
                                                                    }
                                                                }
                                                            }.onFailure { e -> loginError = e.message ?: "Kunne ikke oprette forbindelse. Kontrollér internet og konto." }
                                                        }
                                                    }
                                                }
                                            },
                                            enabled = !loginLoading,
                                            modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White, disabledContainerColor = Color.Transparent, disabledContentColor = Color.White.copy(alpha = .6f)),
                                            shape = RoundedCornerShape(17.dp)
                                        ) {
                                            Text(
                                                if (loginLoading) "Forbinder…" else if (loginMode) "Opret konto" else "Log sikkert ind",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        if (!loginMode) {
                                            TextButton(
                                                onClick = {
                                                    val email = loginEmail.trim().lowercase(Locale.ROOT)
                                                    when {
                                                        email.isBlank() || !email.contains("@") || !email.substringAfter("@").contains(".") -> loginError = "Indtast din e-mail på første side først."
                                                        BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_ANON_KEY.isBlank() -> loginError = "Online-login er ikke konfigureret endnu."
                                                        else -> {
                                                            loginLoading = true
                                                            loginError = ""
                                                            scope.launch {
                                                                val result = withContext(Dispatchers.IO) { runCatching { supabasePasswordRecovery(email) } }
                                                                loginLoading = false
                                                                result.onSuccess {
                                                                    Toast.makeText(context, "Hvis e-mailadressen er tilknyttet en konto, modtager du en nulstillingsmail.", Toast.LENGTH_LONG).show()
                                                                }.onFailure {
                                                                    loginError = "Kunne ikke sende nulstillingsmail. Kontrollér internetforbindelsen og Supabase-opsætningen."
                                                                }
                                                            }
                                                        }
                                                    }
                                                },
                                                enabled = !loginLoading,
                                                modifier = Modifier.fillMaxWidth()
                                            ) { Text("Glemt adgangskode?", color = Violet, fontWeight = FontWeight.SemiBold) }
                                        }
                                        TextButton(
                                            onClick = { loginStep = 0; loginError = ""; loginPassword = ""; loginConfirm = "" },
                                            enabled = !loginLoading,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Tilbage til e-mail", color = Violet, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = BorderSubtle)
                            TextButton(
                                onClick = {
                                    loginMode = !loginMode
                                    loginStep = 0
                                    loginError = ""
                                    loginPassword = ""
                                    loginConfirm = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (loginMode) "Har du allerede en konto? Log ind" else "Ny hos Saldo? Opret en konto", color = Violet, fontWeight = FontWeight.SemiBold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = Mint, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Din adgangskode gemmes ikke på telefonen", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = {
                            data = switchToAccountData(prefs, data, SALDO_LOCAL_ACCOUNT_ID)
                            prefs.edit().putBoolean("local_only_mode", true).apply()
                            localOnlyMode = true
                            loginPassword = ""
                            loginConfirm = ""
                            loginError = ""
                            SaldoWidgetRefreshQueue.request(context)
                            unlocked = prefs.getString("pin_hash", null) == null && prefs.getString("pin", null) == null && !prefs.getBoolean("biometric_enabled", false)
                            showOnboarding = !prefs.getBoolean("onboarding_done", false) && !hasAnySaldoRecords(data) && !prefs.contains("payday")
                            accountUnlocked = true
                        },
                        enabled = !loginLoading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(17.dp),
                        border = saldoCardBorder()
                    ) { Text("Fortsæt uden konto", color = White, fontWeight = FontWeight.SemiBold) }
                    Text("Dine data gemmes kun på telefonen. Du kan oprette en konto senere under Indstillinger for at få onlinebackup.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp, start = 8.dp, end = 8.dp))
                    Spacer(Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Violet, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Privat · Sikkert · Dit overblik", color = Muted, fontSize = 11.sp)
                    }
                    Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = { openSaldoExternalPage(context, SALDO_PRIVACY_POLICY_URL) }) {
                            Text("Privatlivspolitik", color = Muted, fontSize = 11.sp)
                        }
                        TextButton(onClick = { openSaldoExternalPage(context, SALDO_ACCOUNT_DELETION_URL) }) {
                            Text("Slet konto", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        } else if (!unlocked) {
            val hasPinLock = prefs.getString("pin_hash", null) != null || prefs.getString("pin", null) != null
            LaunchedEffect(Unit) {
                if (prefs.getBoolean("biometric_enabled", false)) {
                    val activity = context as? FragmentActivity
                    val biometricReady = BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
                    if (activity != null && biometricReady) startBiometric(activity, context) { unlocked = true }
                    else if (!hasPinLock) {
                        // Biometrics were the only lock and are no longer available: never lock the user out of their own data.
                        prefs.edit().putBoolean("biometric_enabled", false).apply()
                        unlocked = true
                    }
                } else if (!hasPinLock) unlocked = true
            }
            Column(Modifier.fillMaxSize().background(saldoBackgroundBrush(darkMode)).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(36.dp))
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(90.dp))
                Spacer(Modifier.height(18.dp))
                Text("Saldo er låst", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.5).sp)
                Spacer(Modifier.height(6.dp))
                Text("Bekræft at det er dig for at se dit overblik.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), contentPadding = PaddingValues(22.dp)) {
                if (hasPinLock) Field("PIN-kode", pin, { pin = it }, numeric = true, password = true)
                if (hasPinLock) Button(modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White, disabledContainerColor = Color.Transparent, disabledContentColor = Color.White.copy(alpha = .6f)), shape = RoundedCornerShape(17.dp), onClick = {
                    val now = System.currentTimeMillis()
                    val lockedUntil = prefs.getLong("pin_locked_until", 0L)
                    if (lockedUntil > now) {
                        val seconds = ((lockedUntil - now + 999) / 1000).coerceAtLeast(1)
                        Toast.makeText(context, "For mange forsøg. Prøv igen om $seconds sek.", Toast.LENGTH_LONG).show()
                    } else if (verifyAndUpgradePin(prefs, pin)) {
                        prefs.edit().remove("pin_failed_attempts").remove("pin_locked_until").apply()
                        unlocked = true
                    } else {
                        pin = ""
                        val attempts = prefs.getInt("pin_failed_attempts", 0) + 1
                        if (attempts >= 5) {
                            prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_locked_until", now + 30_000L).apply()
                            Toast.makeText(context, "Fem forkerte forsøg. PIN-oplåsning er sat på pause i 30 sekunder.", Toast.LENGTH_LONG).show()
                        } else {
                            prefs.edit().putInt("pin_failed_attempts", attempts).apply()
                            Toast.makeText(context, "Forkert PIN-kode. Forsøg ${attempts} af 5.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Icon(Icons.Default.Lock, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Lås op med PIN", fontWeight = FontWeight.Bold) }
                if (prefs.getBoolean("biometric_enabled", false)) FilledTonalButton(onClick = { val activity = context as? FragmentActivity; if (activity != null) startBiometric(activity, context) { unlocked = true } }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Violet)) { Icon(Icons.Default.Fingerprint, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text("Lås op med fingeraftryk", fontWeight = FontWeight.SemiBold) }
                }
            }
        } else {
            val navTab = if (tab in mainTabs) tab else "Mere"
            androidx.activity.compose.BackHandler(enabled = tab != "Overblik") {
                tab = if (tab in moreTabs) "Mere" else "Overblik"
            }
            Scaffold(modifier = Modifier.background(saldoBackgroundBrush(darkMode)), containerColor = Color.Transparent, snackbarHost = {
                SnackbarHost(snackbarHostState) { data ->
                    Snackbar(data, containerColor = PanelRaised, contentColor = White, actionColor = Violet, shape = RoundedCornerShape(16.dp))
                }
            }, bottomBar = {
                SaldoBottomBar(
                    items = mainTabs.map { t ->
                        when (t) {
                            "Overblik" -> SaldoNavItem(t, Icons.Outlined.OutlinedHome, Icons.Default.Home)
                            "Poster" -> SaldoNavItem(t, Icons.AutoMirrored.Outlined.OutlinedReceiptLong, Icons.AutoMirrored.Filled.ReceiptLong)
                            "Regninger" -> SaldoNavItem(t, Icons.Outlined.OutlinedCalendarMonth, Icons.Default.CalendarMonth)
                            "Budget" -> SaldoNavItem(t, Icons.Outlined.OutlinedPieChart, Icons.Default.PieChart)
                            else -> SaldoNavItem(t, Icons.Outlined.OutlinedGridView, Icons.Default.GridView)
                        }
                    },
                    selectedKey = navTab,
                    onSelect = { selected -> tab = selected },
                    onAdd = { dialog = "post" }
                )
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).wrapContentWidth(Alignment.CenterHorizontally).widthIn(max = 760.dp).padding(horizontal = 20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = tab in moreTabs,
                            enter = fadeIn(tween(SaldoMotion.MEDIUM)) + androidx.compose.animation.expandHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)),
                            exit = fadeOut(tween(SaldoMotion.SHORT)) + androidx.compose.animation.shrinkHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized))
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(onClick = { tab = "Mere" }, shape = RoundedCornerShape(50), color = Color.Transparent, modifier = Modifier.size(40.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Tilbage til Mere", tint = White, modifier = Modifier.size(20.dp)) }
                                }
                                Spacer(Modifier.width(10.dp))
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            if (tab == "Overblik") Text(saldoDayLabel(LocalDate.now().toString(), LocalDate.now().minusDays(7)), color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            AnimatedContent(
                                targetState = tab,
                                transitionSpec = {
                                    (fadeIn(tween(SaldoMotion.MEDIUM)) + androidx.compose.animation.slideInVertically(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { it / 2 }) togetherWith
                                        (fadeOut(tween(SaldoMotion.SHORT)) + androidx.compose.animation.slideOutVertically(tween(SaldoMotion.SHORT)) { -it / 2 })
                                },
                                label = "Saldo-title"
                            ) { title ->
                                androidx.compose.foundation.text.BasicText(
                                    if (title == "Overblik") saldoGreeting() else title,
                                    style = androidx.compose.ui.text.TextStyle(color = White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.3).sp, fontFamily = SaldoFontFamily),
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    // Long titles (and titles next to the back button) shrink to fit instead of being cut off.
                                    autoSize = androidx.compose.foundation.text.TextAutoSize.StepBased(minFontSize = 16.sp, maxFontSize = 32.sp, stepSize = 1.sp)
                                )
                            }
                        }
                        IconButton(onClick = {
                            saldoAmountsHidden = !saldoAmountsHidden
                            prefs.edit().putBoolean("amounts_hidden", saldoAmountsHidden).apply()
                        }, modifier = Modifier.size(42.dp)) {
                            Icon(if (saldoAmountsHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = if (saldoAmountsHidden) "Vis beløb" else "Skjul beløb", tint = if (saldoAmountsHidden) Violet else White, modifier = Modifier.size(20.dp))
                        }
                        if (tab == "Overblik") Spacer(Modifier.width(4.dp))
                        if (tab == "Overblik") {
                        val accountInitial = prefs.getString("account_email", "").orEmpty().trim().firstOrNull()?.uppercaseChar()?.toString() ?: "S"
                        Surface(onClick = { tab = "Indstillinger" }, shape = RoundedCornerShape(50), color = Violet.copy(alpha = .14f), modifier = Modifier.size(42.dp)) {
                            Box(contentAlignment = Alignment.Center) { Text(accountInitial, color = Violet, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                        }
                        }
                    }
                    fun tabOrder(t: String): Int = mainTabs.indexOf(t).takeIf { it >= 0 } ?: (mainTabs.size + moreTabs.indexOf(t))
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            val direction = if (tabOrder(targetState) >= tabOrder(initialState)) 1 else -1
                            (fadeIn(tween(SaldoMotion.MEDIUM, delayMillis = 40)) + slideInHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { direction * it / 8 } +
                                androidx.compose.animation.scaleIn(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized), initialScale = .985f)) togetherWith
                                (fadeOut(tween(SaldoMotion.SHORT)) + slideOutHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { -direction * it / 10 })
                        },
                        label = "Saldo-tab-transition"
                    ) { activeTab ->
                    when (activeTab) {
                        "Overblik" -> LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                            contentPadding = PaddingValues(bottom = 22.dp)
                        ) {
                            val recapMonth = YearMonth.now().minusMonths(1)
                            if (today.dayOfMonth <= 7 && recapDismissed != recapMonth.toString() && transactionsByMonth[recapMonth].orEmpty().isNotEmpty()) item {
                                val recapTx = transactionsByMonth[recapMonth].orEmpty()
                                val recapIncome = recapTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
                                val recapExpenses = recapTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
                                val recapTop = recapTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }.mapValues { e -> e.value.sumOf { it.n("amount") } }.maxByOrNull { it.value }
                                val recapName = recapMonth.month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() }
                                SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SaldoIconTile(Icons.Default.EventAvailable, Violet, size = 38.dp, iconSize = 19.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("$recapName er slut", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Text(if (recapIncome >= recapExpenses) "Du kom ud med overskud" else "Udgifterne var større end indtægterne", color = if (recapIncome >= recapExpenses) Mint else SaldoWarning, fontSize = 12.sp)
                                        }
                                        IconButton(onClick = { recapDismissed = recapMonth.toString(); prefs.edit().putString("month_recap_dismissed", recapDismissed).apply() }) { Icon(Icons.Default.Close, contentDescription = "Luk månedsafslutning", tint = Muted) }
                                    }
                                    Row {
                                        Column(Modifier.weight(1f)) { Text("Ind", color = Muted, fontSize = 11.sp); Text(money(recapIncome), color = Mint, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                                        Column(Modifier.weight(1f)) { Text("Ud", color = Muted, fontSize = 11.sp); Text(money(recapExpenses), color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) { Text("Netto", color = Muted, fontSize = 11.sp); Text(netMoney(recapIncome - recapExpenses), color = if (recapIncome >= recapExpenses) Mint else SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                                    }
                                    recapTop?.let { Text("Største udgift: ${it.key} (${money(it.value)})", color = Muted, fontSize = 12.sp) }
                                    TextButton(onClick = { viewMonth = recapMonth; tab = "Rapporter" }, contentPadding = PaddingValues(0.dp)) { Text("Se hele rapporten for $recapName", color = Violet, fontWeight = FontWeight.SemiBold) }
                                }
                            }
                            if ("balance" in visibleHomeSections) item {
                                val available = estimatedAvailableToPayday
                                val spendRatio = if (monthIncome > 0) (monthExpenses / monthIncome).toFloat().coerceIn(0f, 1f) else 0f
                                val heroHasData = hasPaySetup || hasCurrentBalance || tx.isNotEmpty() || bills.isNotEmpty()
                                // The headline number stands on the page itself – no card – like a modern bank app.
                                Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (hasCurrentBalance) "Til rådighed frem til løn" else "Anslået til rådighed frem til løn", color = Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                        if (heroHasData) Surface(color = if (available >= 0) Mint.copy(alpha = .14f) else SaldoDanger.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                                            Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(if (available >= 0) Mint else SaldoDanger))
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (available >= 0) "På sporet" else "Underskud", color = if (available >= 0) Mint else SaldoDanger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    AnimatedMoney(available, color = if (available >= 0) White else SaldoDanger, fontSize = 58.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-2.8).sp)
                                    SaldoProgressBar(spendRatio, height = 6.dp, colors = SaldoBrandColors, track = PanelRaised)
                                    Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                                        @Composable
                                        fun StatPill(label: String, value: String, accent: Color = White) {
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(label, color = Muted, fontSize = 13.sp)
                                                Text(value, color = accent, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.3).sp, maxLines = 1)
                                            }
                                        }
                                        StatPill("Pr. dag", if (hasPaySetup) wholeKroner(dailyAllowance) else "–", if (hasPaySetup && dailyAllowance < 0) SaldoDanger else Mint)
                                        StatPill("Løn", if (!hasPaySetup) "ikke angivet" else if (daysToPay == 0) "i dag" else if (daysToPay == 1) "i morgen" else "om $daysToPay dage")
                                        StatPill("Brugt", "${(spendRatio * 100).toInt()} %")
                                    }
                                    if (hasPaySetup && daysToPay == 0) Text(if (payFrequency == "biweekly") "Ny lønperiode · ca. 14 dage" else "Ny lønperiode · $daysUntilNextPay dage", color = Muted, fontSize = 12.sp)
                                }
                            }
                            item {
                                // Round shortcuts instead of tiles.
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    @Composable
                                    fun RoundAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean = false, onClick: () -> Unit) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.width(66.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick)) {
                                            Surface(shape = CircleShape, color = if (filled) White else Panel, modifier = Modifier.size(58.dp)) {
                                                Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = if (filled) Night else White, modifier = Modifier.size(24.dp)) }
                                            }
                                            Text(label, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        }
                                    }
                                    RoundAction("Spørg", Icons.Default.AutoAwesome, filled = true) { showAssistant = true }
                                    RoundAction("Søg", Icons.Default.Search) { showSearch = true }
                                    RoundAction("Scan", Icons.Default.DocumentScanner) { dialog = "ocr" }
                                    RoundAction("Regning", Icons.AutoMirrored.Filled.ReceiptLong) { dialog = "bill" }
                                    RoundAction("Budget", Icons.Default.Tune) { tab = "Budget" }
                                }
                            }
                            if ("balance" in visibleHomeSections) item {
                                val topCategory = remember(thisMonthTx) {
                                    thisMonthTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }
                                        .mapValues { entry -> entry.value.sumOf { it.n("amount") } }.maxByOrNull { it.value }
                                }
                                val billsBeforePayCount = remember(bills, today, payPeriodEnd) {
                                    bills.count { bill ->
                                        !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due -> !due.isBefore(today) && !due.isAfter(payPeriodEnd) } == true
                                    }
                                }
                                val overdueCount = remember(bills, today) {
                                    bills.count { bill -> !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.isBefore(today) == true }
                                }
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (!hasPaySetup) SaldoInsightChip(Icons.Default.Payments, "Angiv din løn og lønrytme", SaldoWarning) { dialog = "payday" }
                                    if (prefs.contains("payday") && !prefs.contains("pay_frequency")) SaldoInsightChip(Icons.Default.Payments, "Lønrytme: ${payFrequencyLabel(payFrequency)} – tryk for at ændre", SaldoWarning) { dialog = "payday" }
                                    if (overdueCount > 0) SaldoInsightChip(Icons.Default.WarningAmber, "$overdueCount forfaldne regninger", SaldoDanger) { tab = "Regninger" }
                                    val carFuelKm = remember(data, carMaintenance) { carCurrentKm(carMaintenance, list("fuel").objects()) }
                                    listOf(carSynStatus(carMaintenance, today), carServiceStatus(carMaintenance, carFuelKm, today)).forEach { status ->
                                        carAttentionText(status)?.let { text -> SaldoInsightChip(Icons.Default.DirectionsCar, text, if (status!!.overdue) SaldoDanger else SaldoWarning) { tab = "Bil" } }
                                    }
                                    val lastMonthSoFar = remember(transactionsByMonth, today) {
                                        transactionsByMonth[YearMonth.from(today).minusMonths(1)].orEmpty().filter { item ->
                                            item.s("type") == "Udgift" && runCatching { LocalDate.parse(item.s("date")).dayOfMonth <= today.dayOfMonth }.getOrDefault(false)
                                        }.sumOf { it.n("amount") }
                                    }
                                    if (lastMonthSoFar > 0 && monthExpenses > 0) {
                                        val change = ((monthExpenses - lastMonthSoFar) / lastMonthSoFar * 100).toInt()
                                        if (change <= -1) SaldoInsightChip(Icons.AutoMirrored.Filled.TrendingDown, "${-change} % mindre forbrug end sidste måned", Mint) { tab = "Rapporter" }
                                        else if (change >= 1) SaldoInsightChip(Icons.AutoMirrored.Filled.TrendingUp, "$change % mere forbrug end sidste måned", SaldoWarning) { tab = "Rapporter" }
                                    }
                                    if (billsBeforePayCount > 0) SaldoInsightChip(Icons.Default.Event, "$billsBeforePayCount ${if (billsBeforePayCount == 1) "regning" else "regninger"} før løn · ${money(billsDueBeforePayday)}") { tab = "Regninger" }
                                }
                            }
                            if ("warnings" in visibleHomeSections) item {
                                val budgetChecks = list("budgets").objects().map { budget ->
                                    val spendKey = "${budget.s("category").trim().lowercase(Locale.ROOT)}|${budget.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"
                                    val spentForBudget = monthSpendByCategoryOwner[spendKey] ?: 0.0
                                    Triple(budget.s("category"), budget.n("limit"), spentForBudget)
                                }
                                val criticalBudgets = budgetChecks.filter { it.second > 0 && it.third >= it.second * .8 }
                                if (criticalBudgets.isNotEmpty()) {
                                    Surface(onClick = { tab = "Budget" }, color = SaldoDanger.copy(alpha = .08f), shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, SaldoDanger.copy(alpha = .25f)), modifier = Modifier.fillMaxWidth().animateContentSize()) {
                                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.NotificationsActive, null, tint = SaldoDanger, modifier = Modifier.size(19.dp))
                                                Spacer(Modifier.width(7.dp))
                                                Text("Budgetadvarsel", color = SaldoDanger, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                            criticalBudgets.take(3).forEach { (category, limit, spent) ->
                                                Text("$category: ${if (spent >= limit) "overskredet med ${money(spent - limit)}" else "${money(limit - spent)} tilbage"}", color = White, fontSize = 12.sp)
                                            }
                                            Text("Tryk for at se alle budgetter", color = Muted, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                            if ("summary" in visibleHomeSections) item {
                                SaldoSectionHeader("Denne måned", LocalDate.now().month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK")).replaceFirstChar { it.uppercase() } + " ${LocalDate.now().year} · indtil nu", "Se mere") { tab = "Rapporter" }
                            }
                            if ("summary" in visibleHomeSections) item {
                                SaldoCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 16.dp, horizontal = 6.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        listOf(Triple("Ind", monthIncome, Mint), Triple("Ud", monthExpenses, White), Triple("Ubetalt", unpaid, SaldoWarning), Triple("Pr. dag", dailyAllowance, Violet)).forEachIndexed { index, (label, value, accent) ->
                                            if (index > 0) Box(Modifier.width(1.dp).height(34.dp).background(BorderSubtle))
                                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(label, color = Muted, fontSize = 12.sp)
                                                AnimatedMoney(value, color = accent, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, format = ::wholeKroner)
                                            }
                                        }
                                    }
                                }
                            }
                            if ("cashflow" in visibleHomeSections) item { MonthlyFlowCard(monthIncome = monthIncome, monthExpenses = monthExpenses) }
                            if ("bills" in visibleHomeSections) item {
                                SaldoSectionHeader("Kommende regninger", "Det næste, der skal betales", "Se alle") { tab = "Regninger" }
                            }
                            if ("bills" in visibleHomeSections && unpaidBills.isEmpty()) item {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(color = Mint.copy(alpha = .12f), shape = RoundedCornerShape(14.dp), modifier = Modifier.size(44.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.CheckCircle, null, tint = Mint) } }
                                        Spacer(Modifier.width(12.dp))
                                        Column { Text("Alt er betalt", color = White, fontWeight = FontWeight.SemiBold); Text("Du har ingen ubetalte regninger lige nu.", color = Muted, fontSize = 11.sp) }
                                    }
                                }
                            }
                            if ("bills" in visibleHomeSections && unpaidBills.isNotEmpty()) item {
                                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(unpaidBills.sortedBy { it.s("date") }.take(8), key = { "home-bill-${it.s("id")}" }) { b ->
                                        val overdue = runCatching { LocalDate.parse(b.s("date")).isBefore(today) }.getOrDefault(false)
                                        SaldoCard(Modifier.width(168.dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(if (overdue) "Forfalden" else saldoDayLabel(b.s("date")), color = if (overdue) SaldoDanger else Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text(b.s("name"), color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            Text(money(b.n("amount")), color = White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.5).sp, maxLines = 1)
                                            Surface(onClick = { updatePaid(bills, b, ::store) }, color = Mint.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                                                Text("Markér betalt", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                                            }
                                        }
                                    }
                                }
                            }
                            if ("activity" in visibleHomeSections) item {
                                SaldoSectionHeader("Seneste aktivitet", "Dine senest registrerede poster", "Alle poster") { tab = "Poster" }
                            }
                            if ("activity" in visibleHomeSections) items(tx.sortedByDescending { it.s("date") }.take(4), key = { "recent-${it.s("id")}" }) { x ->
                                RecordRow(x.s("name"), "${saldoDayLabel(x.s("date"))} · ${x.s("category")} · ${x.s("owner", "Mig")}", signedMoney(x.n("amount"), x.s("type") == "Indtægt"), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }, onEdit = { editingRecord = JSONObject(x.toString()); dialog = "post" }, modifier = Modifier.animateItem())
                            }
                        }
                        "Poster" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            SaldoMonthSwitcher(viewMonth, { viewMonth = it }, Modifier.fillMaxWidth())
                            // Month total stands on the page, with income/expenses as a quiet line underneath.
                            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Netto i måneden", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                AnimatedMoney(viewIncome - viewExpenses, color = if (viewIncome >= viewExpenses) White else SaldoDanger, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.4).sp, format = ::netMoney)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ArrowDownward, null, tint = Mint, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp))
                                    AnimatedMoney(viewIncome, color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold, format = ::wholeKroner)
                                    Spacer(Modifier.width(16.dp))
                                    Icon(Icons.Default.ArrowUpward, null, tint = Muted, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp))
                                    AnimatedMoney(viewExpenses, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, format = ::wholeKroner)
                                }
                            }
                            OutlinedTextField(
                                value = transactionSearch,
                                onValueChange = { transactionSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Søg efter navn, kategori eller dato") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                                shape = RoundedCornerShape(50),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedContainerColor = Panel, unfocusedContainerColor = Panel, focusedBorderColor = Violet, unfocusedBorderColor = Color.Transparent, focusedLabelColor = Violet, unfocusedLabelColor = Muted)
                            )
                            val monthCategories = remember(viewMonthTx) { viewMonthTx.map { it.s("category").trim() }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(10).map { it.key } }
                            // One scrolling row of filters instead of two.
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Alle", "Indtægt", "Udgift").forEach { filter ->
                                    FilterChip(selected = transactionTypeFilter == filter, onClick = { transactionTypeFilter = filter }, label = { Text(filter) }, shape = RoundedCornerShape(50), border = null, colors = FilterChipDefaults.filterChipColors(containerColor = Panel, labelColor = White, selectedContainerColor = White, selectedLabelColor = Night))
                                }
                                FilterChip(selected = transactionSort == "Beløb", onClick = { transactionSort = if (transactionSort == "Beløb") "Dato" else "Beløb" }, label = { Text(if (transactionSort == "Beløb") "Største først" else "Nyeste først") }, leadingIcon = { Icon(Icons.AutoMirrored.Filled.Sort, null, modifier = Modifier.size(16.dp)) }, shape = RoundedCornerShape(50), border = null, colors = FilterChipDefaults.filterChipColors(containerColor = Panel, labelColor = White, iconColor = Muted, selectedContainerColor = White, selectedLabelColor = Night, selectedLeadingIconColor = Night))
                                monthCategories.forEach { category ->
                                    FilterChip(selected = transactionCategoryFilter.equals(category, true), onClick = { transactionCategoryFilter = if (transactionCategoryFilter.equals(category, true)) null else category }, label = { Text(category) }, shape = RoundedCornerShape(50), border = null, colors = FilterChipDefaults.filterChipColors(containerColor = Panel, labelColor = White, selectedContainerColor = White, selectedLabelColor = Night))
                                }
                            }
                            val filteredTransactions = remember(tx, transactionTypeFilter, transactionSearch, viewMonth, transactionCategoryFilter) { tx.filter { (transactionTypeFilter == "Alle" || it.s("type") == transactionTypeFilter) && (transactionCategoryFilter == null || it.s("category").trim().equals(transactionCategoryFilter, true)) && (if (transactionSearch.isBlank()) it.s("date").startsWith(viewMonth.toString()) else true) && (transactionSearch.isBlank() || listOf(it.s("name"), it.s("category"), it.s("date"), it.s("owner"), it.s("type"), it.s("note")).any { field -> field.contains(transactionSearch, true) }) }.sortedByDescending { it.s("date") } }
                            if (filteredTransactions.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(28.dp))
                                        val filtering = transactionSearch.isNotBlank() || transactionCategoryFilter != null || transactionTypeFilter != "Alle"
                                        Text(if (filtering) "Ingen poster fundet" else "Ingen poster i ${viewMonth.month.getDisplayName(java.time.format.TextStyle.FULL, Locale("da", "DK"))}", color = White, fontWeight = FontWeight.SemiBold)
                                        Text(if (filtering) "Prøv en anden søgning, eller nulstil filtrene." else "Registrér en post, eller importér dine posteringer fra netbanken.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                                        if (filtering) TextButton(onClick = { transactionSearch = ""; transactionCategoryFilter = null; transactionTypeFilter = "Alle" }) { Text("Nulstil filtre", color = Violet) }
                                        else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilledTonalButton(onClick = { editingRecord = null; dialog = "post" }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Violet)) { Text("Ny post") }
                                            OutlinedButton(onClick = { csvPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "text/plain", "*/*")) }) { Text("Importér", color = White) }
                                        }
                                    }
                                }
                            } else {
                                val transactionsByDay = remember(filteredTransactions, transactionSort) {
                                    if (transactionSort == "Beløb") linkedMapOf("" to filteredTransactions.sortedByDescending { it.n("amount") })
                                    else filteredTransactions.sortedByDescending { it.s("date") }.groupBy { it.s("date") }
                                }
                                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                    transactionsByDay.forEach { (day, rows) ->
                                        val dayNet = rows.sumOf { if (it.s("type") == "Indtægt") it.n("amount") else -it.n("amount") }
                                        stickyHeader(key = "day-header-$day") {
                                            SaldoGroupHeader(if (day.isEmpty()) "Største beløb først" else saldoDayLabel(day), netMoney(dayNet), if (dayNet >= 0) Mint else Violet)
                                        }
                                        items(rows, key = { it.s("id") }) { x ->
                                            RecordRow(x.s("name"), "${x.s("category")} · ${x.s("owner", "Mig")}${x.s("note").takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()}${if (x.s("receipt").isNotBlank()) " · Kvittering" else ""}", signedMoney(x.n("amount"), x.s("type") == "Indtægt"), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }, onEdit = { editingRecord = JSONObject(x.toString()); dialog = "post" }, modifier = Modifier.animateItem(), onSplit = if (x.s("type") == "Udgift") ({ splittingRecord = JSONObject(x.toString()) }) else null)
                                        }
                                    }
                                }
                            }
                        }
                        "Regninger" -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            val (overdueBills, upcomingBills, settledBills) = remember(bills, today) {
                                val (overdue, upcoming) = bills.filter { !it.optBoolean("paid", false) }
                                    .partition { bill -> runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.isBefore(today) == true }
                                Triple(overdue.sortedBy { it.s("date") }, upcoming.sortedBy { it.s("date") }, bills.filter { it.optBoolean("paid", false) }.sortedByDescending { it.s("date") })
                            }
                            Surface(color = Color.Transparent, shape = RoundedCornerShape(28.dp), shadowElevation = if (darkMode) 0.dp else 8.dp, modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.background(saldoHeroBrush()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Ubetalt i alt", color = HeroMuted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                            AnimatedMoney(unpaid, color = HeroText, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.4).sp)
                                        }
                                        Surface(onClick = { dialog = "bill" }, color = Color(0xFF5B5BFF), shape = RoundedCornerShape(50)) {
                                            Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Ny regning", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }
                                    SaldoProgressBar(if (bills.isEmpty()) 0f else settledBills.size.toFloat() / bills.size, height = 8.dp, colors = listOf(Color(0xFF5FE3AE), Color(0xFF3FC48E)), track = Color.White.copy(alpha = .10f))
                                    Text("${overdueBills.size} forfaldne · ${upcomingBills.size} kommende · ${settledBills.size} betalt", color = HeroMuted, fontSize = 12.sp)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { dialog = "ocr" }) { Icon(Icons.Default.DocumentScanner, null, tint = Violet, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Scan regning", color = Violet, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                                TextButton(onClick = { multiBillPicker.launch(arrayOf("image/*")) }, enabled = !multiBillProcessing) { Icon(Icons.Default.PhotoLibrary, null, tint = Violet, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text(if (multiBillProcessing) "Læser…" else "Scan flere (op til 20)", color = Violet, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                            }
                            if (multiBillProcessing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Violet)
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                if (bills.isEmpty()) item {
                                    SaldoCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                            SaldoIconTile(Icons.AutoMirrored.Filled.ReceiptLong, Violet)
                                            Text("Ingen regninger endnu", color = White, fontWeight = FontWeight.SemiBold)
                                            Text("Tilføj en regning eller scan et billede af den.", color = Muted, fontSize = 11.sp)
                                        }
                                    }
                                }
                                listOf(
                                    Triple("Forfaldne", overdueBills, SaldoDanger),
                                    Triple("Kommende", upcomingBills, Violet),
                                    Triple("Betalt", settledBills, Mint)
                                ).filter { it.second.isNotEmpty() }.forEach { (groupTitle, groupBills, accent) ->
                                    stickyHeader(key = "bill-group-$groupTitle") {
                                        SaldoGroupHeader("$groupTitle · ${groupBills.size}", money(groupBills.sumOf { it.n("amount") }), accent)
                                    }
                                    items(groupBills, key = { it.s("id") }) { b ->
                                        RecordRow(b.s("name"), "${saldoDayLabel(b.s("date"))} · ${b.s("repeat", "Engangsbetaling")}", money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }, onEdit = { editingRecord = JSONObject(b.toString()); dialog = "bill" }, modifier = Modifier.animateItem())
                                    }
                                }
                            }
                        }
                        "Budget" -> Column(Modifier.fillMaxSize()) {
                            var editingBudget by remember { mutableStateOf<JSONObject?>(null) }
                            var deletingBudget by remember { mutableStateOf<JSONObject?>(null) }
                            SaldoMonthSwitcher(viewMonth, { viewMonth = it }, Modifier.fillMaxWidth().padding(bottom = 10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Dine budgetter", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.5).sp)
                                    Text("Forbrug mod dine månedlige grænser", color = Muted, fontSize = 11.sp)
                                }
                                IconButton(onClick = { showBudgetSuggestions = true }) { Icon(Icons.Default.AutoAwesome, contentDescription = "Foreslå budgetter", tint = Violet) }
                                FilledTonalButton(onClick = { dialog = "budget" }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) {
                                    Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("Nyt budget")
                                }
                            }
                            val budgetItems = list("budgets").objects()
                            // A legacy backup might contain duplicate owner/category rows. Count one
                            // effective monthly limit per owner/category so totals remain meaningful.
                            val effectiveBudgetItems = budgetItems.groupBy {
                                "${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}|${it.s("category").trim().lowercase(Locale.ROOT)}"
                            }.values.map { group -> group.maxBy { it.n("limit") } }
                            val totalLimit = effectiveBudgetItems.sumOf { it.n("limit") }
                            val currentMonthSpendingByOwner = remember(viewSpendByCategoryOwner) {
                                viewSpendByCategoryOwner.entries.groupBy { entry -> entry.key.substringAfter('|') }
                                    .mapValues { (_, entries) -> entries.sumOf { it.value } }
                            }
                            // Each transaction must count once in the aggregate, even if an old backup
                            // contains duplicate budget rows for the same owner/category.
                            val budgetKeys = effectiveBudgetItems.map {
                                "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"
                            }.toSet()
                            val totalSpent = budgetKeys.sumOf { viewSpendByCategoryOwner[it] ?: 0.0 }
                            val totalUsedRatio = if (totalLimit > 0) (totalSpent / totalLimit).coerceAtLeast(0.0) else 0.0
                            val totalRatio = totalUsedRatio.toFloat().coerceIn(0f, 1f) // Progress bars are capped; the label below is not.
                            val totalUsedPercent = (totalUsedRatio * 100.0).toInt()
                            if (effectiveBudgetItems.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OwnerSummaryCard("Mig", currentMonthSpendingByOwner["mig"] ?: 0.0, Modifier.weight(1f), Violet)
                                OwnerSummaryCard("Partner", currentMonthSpendingByOwner["partner"] ?: 0.0, Modifier.weight(1f), Blue)
                                OwnerSummaryCard("Fælles", currentMonthSpendingByOwner["fælles"] ?: 0.0, Modifier.weight(1f), Mint)
                            }
                            if (effectiveBudgetItems.isNotEmpty()) Surface(color = Color.Transparent, shape = RoundedCornerShape(28.dp), shadowElevation = if (darkMode) 0.dp else 8.dp, modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                                Column(Modifier.background(saldoHeroBrush()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("Samlet budgetstatus", color = HeroMuted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            val totalRemaining = totalLimit - totalSpent
                                            AnimatedMoney(kotlin.math.abs(totalRemaining), color = HeroText, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.4).sp)
                                            Text(if (totalRemaining < 0) "overskredet med ${money(kotlin.math.abs(totalRemaining))}" else "tilbage af ${money(totalLimit)}", color = if (totalRemaining < 0) HeroNegative else HeroMuted, fontSize = 12.sp)
                                        }
                                        Surface(color = if (totalUsedRatio >= 1.0) Color(0xFFE5484D) else Color(0xFF5B5BFF), shape = RoundedCornerShape(50)) {
                                            Text("${totalUsedPercent} % brugt", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp))
                                        }
                                    }
                                    val totalMonthProgress = viewMonthProgress()
                                    SaldoProgressBar(totalRatio, height = 10.dp, colors = if (totalUsedRatio >= 1.0) listOf(Color(0xFFFF8A8F), Color(0xFFE5484D)) else listOf(Color(0xFF9C9CFF), Color(0xFF5B5BFF)), track = Color.White.copy(alpha = .10f), marker = if (totalLimit > 0) totalMonthProgress else null, markerColor = HeroText)
                                    if (totalLimit > 0) Text(
                                        "Markøren viser, hvor langt måneden er (${(totalMonthProgress * 100).toInt()} %). " +
                                            if (totalUsedRatio > totalMonthProgress + .10f) "I dette tempo ender forbruget på ca. ${money(totalSpent / totalMonthProgress.coerceAtLeast(.03f))}." else "Forbruget følger planen.",
                                        color = HeroMuted, fontSize = 11.sp
                                    )
                                }
                            }
                            if (effectiveBudgetItems.isEmpty()) {
                                Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Tune, null, tint = Violet, modifier = Modifier.size(32.dp))
                                        Text("Lav dit første budget", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Sæt en månedlig grænse for en kategori, og følg forbruget her.", color = Muted, fontSize = 12.sp)
                                        FilledTonalButton(onClick = { dialog = "budget" }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = PanelRaised, contentColor = Blue)) { Text("Opret budget") }
                                        TextButton(onClick = { showBudgetSuggestions = true }) { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Foreslå budgetter eller brug 50/30/20", color = Violet) }
                                    }
                                }
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                    items(effectiveBudgetItems, key = { it.s("id") }) { b ->
                                        val spent = viewSpendByCategoryOwner["${b.s("category").trim().lowercase(Locale.ROOT)}|${b.s("owner", "Mig").trim().lowercase(Locale.ROOT)}"] ?: 0.0
                                        val limit = b.n("limit")
                                        val ratio = if (limit > 0) (spent / limit).toFloat().coerceAtLeast(0f) else 0f
                                        val over = ratio >= 1f
                                        SaldoCard(Modifier.fillMaxWidth().animateItem(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(16.dp)) {
                                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    SaldoIconTile(Icons.Default.PieChart, if (over) SaldoDanger else Violet, size = 40.dp, iconSize = 20.dp)
                                                    Spacer(Modifier.width(11.dp))
                                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                        Text(b.s("category"), color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                                        Text(b.s("owner", "Husstand"), color = Muted, fontSize = 10.sp)
                                                    }
                                                    Surface(color = if (over) SaldoDanger.copy(alpha = .10f) else Mint.copy(alpha = .10f), shape = RoundedCornerShape(50)) {
                                                        Text(if (over) "Overskredet" else "${((1f - ratio.coerceIn(0f, 1f)) * 100).toInt()}% tilbage", color = if (over) SaldoDanger else Mint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                                                    }
                                                    IconButton(onClick = { editingBudget = JSONObject(b.toString()) }, modifier = Modifier.size(30.dp)) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Rediger budget", tint = Blue, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(onClick = { deletingBudget = JSONObject(b.toString()) }, modifier = Modifier.size(30.dp)) {
                                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Slet budget", tint = SaldoDanger, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                                Row(verticalAlignment = Alignment.Bottom) {
                                                    AnimatedMoney(spent, color = White, fontSize = 20.sp, letterSpacing = (-.4).sp)
                                                    Spacer(Modifier.width(5.dp))
                                                    Text("af ${money(limit)}", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                                                }
                                                val monthProgress = viewMonthProgress()
                                                val forecast = spent / monthProgress.coerceAtLeast(.03f)
                                                val aheadOfPace = !over && ratio > monthProgress + .10f
                                                SaldoProgressBar(ratio, height = 10.dp, colors = if (over) listOf(SaldoDanger, SaldoWarning) else if (aheadOfPace || ratio >= .8f) listOf(Violet, SaldoWarning) else listOf(Violet, Blue), marker = monthProgress)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(if (over) "Budget overskredet med ${money(spent - limit)}" else "Tilbage: ${money(limit - spent)}", color = if (over) SaldoDanger else Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                                    if (!over && spent > 0) Text(
                                                        if (forecast > limit) "Prognose ${money(forecast)}" else "Inden for tempo",
                                                        color = if (forecast > limit) SaldoWarning else Mint,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            editingBudget?.let { target ->
                                BudgetEditDialog(
                                    budget = target,
                                    onDismiss = { editingBudget = null },
                                    onSave = { updated ->
                                        val budgetId = target.s("id").trim()
                                        val newCategory = updated.s("category").trim()
                                        val newOwner = updated.s("owner", "Mig").trim()
                                        val duplicateElsewhere = list("budgets").objects().any { item ->
                                            item.s("id") != budgetId &&
                                                item.s("category").trim().equals(newCategory, true) &&
                                                item.s("owner", "Mig").trim().equals(newOwner, true)
                                        }
                                        if (budgetId.isBlank()) {
                                            Toast.makeText(context, "Budgettet mangler et sikkert ID. Luk og åbn budgettet igen, og prøv derefter.", Toast.LENGTH_LONG).show()
                                        } else if (duplicateElsewhere) {
                                            Toast.makeText(context, "Der findes allerede et budget for den valgte kategori og ejer.", Toast.LENGTH_LONG).show()
                                        } else {
                                            val updatedBudgets = JSONArray()
                                            var replaced = false
                                            list("budgets").objects().forEach { item ->
                                                if (item.s("id") == budgetId && !replaced) {
                                                    updatedBudgets.put(JSONObject(updated.toString()).put("id", budgetId))
                                                    replaced = true
                                                } else updatedBudgets.put(item)
                                            }
                                            if (replaced) {
                                                store("budgets", updatedBudgets)
                                                editingBudget = null
                                                saveSuccess = "Budgettet er opdateret"
                                            } else {
                                                Toast.makeText(context, "Budgettet blev ændret et andet sted. Åbn det igen, før du gemmer.", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            }
                            deletingBudget?.let { target ->
                                AlertDialog(
                                    onDismissRequest = { deletingBudget = null },
                                    title = { Text("Slet budget?") },
                                    text = { Text("Budgettet for ${target.s("category")} (${target.s("owner", "Mig")}) slettes. Dette sletter ikke dine registrerede poster.") },
                                    confirmButton = {
                                        TextButton(onClick = {
                                            val budgetId = target.s("id").trim()
                                            if (budgetId.isBlank()) {
                                                Toast.makeText(context, "Budgettet mangler et ID og blev ikke slettet.", Toast.LENGTH_LONG).show()
                                            } else {
                                                val updatedBudgets = JSONArray()
                                                list("budgets").objects().filterNot { it.s("id") == budgetId }.forEach { updatedBudgets.put(it) }
                                                store("budgets", updatedBudgets)
                                            }
                                            deletingBudget = null
                                        }) { Text("Slet", color = SaldoDanger) }
                                    },
                                    dismissButton = { TextButton(onClick = { deletingBudget = null }) { Text("Annuller") } }
                                )
                            }
                        }
                        "Mere" -> androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                            columns = androidx.compose.foundation.lazy.grid.GridCells.Adaptive(150.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 18.dp)
                        ) {
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                Column(Modifier.padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Alt det ekstra til at holde styr på økonomien.", color = Muted, fontSize = 13.sp)
                                }
                            }
                            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                                // Spørg Saldo is the featured tool: an ink card like the overview hero.
                                Surface(onClick = { showAssistant = true }, shape = RoundedCornerShape(28.dp), color = Color.Transparent, shadowElevation = if (darkMode) 0.dp else 8.dp, modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.background(saldoHeroBrush()).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Spørg Saldo", color = HeroText, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.5).sp)
                                            Text("Spørg om din økonomi – fx hvad du kan bruge i dag, eller hvad ÅOP betyder.", color = HeroMuted, fontSize = 12.sp, lineHeight = 16.sp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(50)).background(Color(0xFF5B5BFF)), contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                }
                            }
                            items(moreTabs.filter { it != "Spørg Saldo" }) { t ->
                                val icon = when (t) {
                                    "Spørg Saldo" -> Icons.Default.AutoAwesome
                                    "Faste poster" -> Icons.Default.Autorenew
                                    "Kategorier" -> Icons.Default.Category
                                    "Opsparing" -> Icons.Default.AccountBalanceWallet
                                    "Gæld" -> Icons.Default.AccountBalance
                                    "Bil" -> Icons.Default.DirectionsCar
                                    "Abonnementer" -> Icons.Default.Sync
                                    "Hvad nu hvis?" -> Icons.Default.Science
                                    "Rapporter" -> Icons.Default.Insights
                                    else -> Icons.Default.Settings
                                }
                                val subtitle = when (t) {
                                    "Spørg Saldo" -> "Få svar på spørgsmål om din økonomi og appen"
                                    "Faste poster" -> "Løn, husleje og andre faste beløb oprettes automatisk"
                                    "Kategorier" -> "Omdøb og flet kategorier efter import"
                                    "Opsparing" -> "Følg dine mål og fremskridt"
                                    "Gæld" -> "Restgæld, renter og afdrag"
                                    "Bil" -> "Servicetjek, syn og tankninger"
                                    "Abonnementer" -> "Faste betalinger og årlige omkostninger"
                                    "Hvad nu hvis?" -> "Saldo frem til løn, og hvad ekstra forbrug eller opsparing betyder"
                                    "Rapporter" -> "Opsummeringer og eksport af data"
                                    else -> "Sikkerhed, backup og onlinekonto"
                                }
                                SaldoCard(Modifier.fillMaxWidth().heightIn(min = 148.dp), onClick = { if (t == "Spørg Saldo") showAssistant = true else tab = t }, shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.Top) {
                                        val toolHues = listOf(Violet, Blue, Mint, Color(0xFFFF7A59), Color(0xFFE8A23B), Color(0xFFE0559A))
                                        SaldoIconTile(icon, toolHues[moreTabs.indexOf(t).coerceAtLeast(0) % toolHues.size], size = 46.dp, iconSize = 22.dp)
                                        Spacer(Modifier.weight(1f))
                                        Icon(Icons.Default.NorthEast, null, tint = Muted, modifier = Modifier.size(18.dp))
                                    }
                                    Text(t, color = White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.3).sp, maxLines = 1)
                                    Text(subtitle, color = Muted, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3)
                                }
                            }
                        }
                        "Faste poster" -> {
                            val recurringSeries = remember(tx) {
                                tx.filter { it.s("recurrenceId").isNotBlank() || isRecurringRepeat(it.s("repeat")) }
                                    .groupBy { it.s("recurrenceId").ifBlank { it.s("id") } }
                                    .mapNotNull { (seriesId, series) -> series.maxByOrNull { it.s("date") }?.takeIf { isRecurringRepeat(it.s("repeat")) }?.let { seriesId to it } }
                                    .sortedBy { it.second.s("name").lowercase(Locale.ROOT) }
                            }
                            val monthlyNet = recurringSeries.sumOf { (_, x) -> (if (x.s("type") == "Indtægt") 1.0 else -1.0) * x.n("amount") / (recurrenceIntervalMonths(x.s("repeat")) ?: 1L) }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                item { SaldoSectionHeader("Faste poster", "Oprettes automatisk på datoen · netto ${netMoney(monthlyNet)} pr. måned", "Ny fast post") { editingRecord = null; dialog = "post" } }
                                if (recurringSeries.isEmpty()) item {
                                    SaldoCard(Modifier.fillMaxWidth()) {
                                        SaldoIconTile(Icons.Default.Autorenew, Violet)
                                        Text("Ingen faste poster endnu", color = White, fontWeight = FontWeight.SemiBold)
                                        Text("Opret en post, og vælg Månedlig, Kvartalsvis eller Årlig under Gentagelse. Så lægger Saldo den ind af sig selv fremover – fx løn, husleje og forsikring.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                                items(recurringSeries, key = { "recurring-${it.first}" }) { (seriesId, x) ->
                                    val interval = recurrenceIntervalMonths(x.s("repeat")) ?: 1L
                                    val nextDate = runCatching { LocalDate.parse(x.s("date")) }.getOrNull()?.let { last ->
                                        val month = YearMonth.from(last).plusMonths(interval)
                                        month.atDay(x.optInt("recurrenceDay", last.dayOfMonth).coerceIn(1, 31).coerceAtMost(month.lengthOfMonth()))
                                    }
                                    var confirmStop by remember(seriesId) { mutableStateOf(false) }
                                    if (confirmStop) AlertDialog(
                                        onDismissRequest = { confirmStop = false },
                                        containerColor = Panel,
                                        title = { Text("Stop den faste post?", color = White, fontWeight = FontWeight.Bold) },
                                        text = { Text("\"${x.s("name")}\" bliver ikke oprettet automatisk fremover. Allerede registrerede poster bevares.", color = Muted) },
                                        confirmButton = { TextButton(onClick = { confirmStop = false; stopRecurringSeries(seriesId) }) { Text("Stop", color = SaldoDanger, fontWeight = FontWeight.Bold) } },
                                        dismissButton = { TextButton(onClick = { confirmStop = false }) { Text("Annuller", color = Muted) } }
                                    )
                                    SaldoCard(Modifier.fillMaxWidth().animateItem(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            SaldoAvatar(x.s("name"), x.s("type") == "Indtægt")
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(x.s("name"), color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                                                Text("${x.s("repeat")} · næste ${nextDate?.let { saldoDayLabel(it.toString()).replaceFirstChar { c -> c.lowercase() } } ?: "ukendt"}", color = Muted, fontSize = 11.sp, maxLines = 1)
                                            }
                                            Text(signedMoney(x.n("amount"), x.s("type") == "Indtægt"), color = if (x.s("type") == "Indtægt") Mint else White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                            TextButton(onClick = { editingRecord = JSONObject(x.toString()); dialog = "post" }) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Rediger") }
                                            TextButton(onClick = { confirmStop = true }) { Icon(Icons.Default.PauseCircle, null, tint = SaldoDanger, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Stop", color = SaldoDanger) }
                                        }
                                    }
                                }
                            }
                        }
                        "Kategorier" -> {
                            val categoryStats = remember(data) {
                                (list("transactions").objects().map { it to "post" } + list("bills").objects().map { it to "bill" } + list("budgets").objects().map { it to "budget" })
                                    .filter { it.first.s("category").isNotBlank() }
                                    .groupBy { it.first.s("category").trim().lowercase(Locale.ROOT) }
                                    .map { (_, rows) ->
                                        val display = rows.first().first.s("category").trim()
                                        val spent = rows.filter { it.second == "post" && it.first.s("type") == "Udgift" }.sumOf { it.first.n("amount") }
                                        Triple(display, rows.size, spent)
                                    }
                                    .sortedByDescending { it.third }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                                item { SaldoSectionHeader("Kategorier", "${categoryStats.size} kategorier · tryk for at omdøbe eller flette") }
                                if (categoryStats.isEmpty()) item { Text("Ingen kategorier endnu. De opstår, når du opretter eller importerer poster.", color = Muted, fontSize = 12.sp) }
                                items(categoryStats, key = { "category-${it.first.lowercase(Locale.ROOT)}" }) { (name, count, spent) ->
                                    SaldoCard(Modifier.fillMaxWidth().animateItem(), onClick = { renamingCategory = name }, shape = RoundedCornerShape(20.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            SaldoAvatar(name, false)
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                                                Text("$count ${if (count == 1) "registrering" else "registreringer"}", color = Muted, fontSize = 11.sp)
                                            }
                                            if (spent > 0) Text(money(spent), color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Spacer(Modifier.width(6.dp))
                                            Icon(Icons.Default.Edit, contentDescription = "Omdøb $name", tint = Muted, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                        "Opsparing" -> ManagedList("Opsparingsmål", list("goals").objects(), { dialog = "goal" }, { g -> SaldoGoalCard(g.s("name"), g.n("target"), g.n("saved"), g.s("date"), onEdit = { editingGoal = JSONObject(g.toString()) }, onDelete = { delete("goals", g.s("id")) }, onDeposit = { depositGoal = JSONObject(g.toString()) }) })
                        "Gæld" -> { val debts = list("debts").objects(); Column(Modifier.fillMaxSize()) { val monthlyInterest = debts.sumOf { it.n("balance") * it.n("rate") / 1200.0 }; Text("Samlet restgæld", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); AnimatedMoney(debts.sumOf { it.n("balance") }, color = White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.4).sp); Spacer(Modifier.height(12.dp)); SaldoStatList(listOf(Triple("Månedlige afdrag", money(debts.sumOf { it.n("payment") }), White), Triple("Renter pr. måned (anslået)", money(monthlyInterest), SaldoDanger))); Spacer(Modifier.height(12.dp)); if (debts.isNotEmpty()) DebtPlanCard(debts); ManagedList("Gæld og afdragsplan", debts, { dialog = "debt" }) { d -> val balance = d.n("balance"); val payment = d.n("payment"); val rate = d.n("rate") / 1200.0; val months = if (payment <= balance * rate || payment <= 0) null else if (rate > 0) ceil(ln(payment / (payment - balance * rate)) / ln(1 + rate)).toInt() else ceil(balance / payment).toInt(); RecordRow(d.s("name"), "Rente ${saldoInputNumber(d.n("rate"))} % · afdrag ${money(payment)}/md. · ${months?.let { "$it mdr. tilbage" } ?: "Afdrag dækker ikke renten"}", money(balance), false, { delete("debts", d.s("id")) }, onEdit = { editingRecord = JSONObject(d.toString()); dialog = "debt" }) } } }
                        "Bil" -> CarScreen(
                            fuel = list("fuel").objects(),
                            maintenance = carMaintenance,
                            onSaveMaintenance = { updated -> carMaintenance = updated; prefs.edit().putString(CAR_MAINTENANCE_KEY, updated.toString()).apply() },
                            onAddExpense = { name, amount, date -> add("transactions", JSONObject().put("id", java.util.UUID.randomUUID().toString()).put("name", name).put("amount", amount).put("category", "Bil").put("date", date.toString()).put("type", "Udgift").put("owner", "Mig")) },
                            onAddFuel = { editingRecord = null; dialog = "fuel" }
                        ) { f -> val pricePerLiter = if (f.n("liters") > 0) f.n("cost") / f.n("liters") else 0.0; RecordRow(saldoDayLabel(f.s("date")), "${saldoInputNumber(f.n("liters"))} liter · ${saldoInputNumber(f.n("km"))} km · ${money(pricePerLiter)}/liter", money(f.n("cost")), false, { delete("fuel", f.s("id")) }, onEdit = { editingRecord = JSONObject(f.toString()); dialog = "fuel" }) }
                        "Abonnementer" -> {
                            val subscriptions = list("subs").objects().filter { it.optBoolean("active", true) }
                            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Metric("Abonnementer pr. måned", money(subscriptions.sumOf { it.n("monthly") }), Modifier.fillMaxWidth())
                                Metric("Abonnementer pr. år", money(subscriptions.sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth())
                                Text("Fornyelsesdato og opsigelsesnote vises på hvert abonnement, hvis du har indtastet dem.", color = Muted, fontSize = 11.sp)
                                var radarIgnored by remember { mutableStateOf(prefs.getStringSet("radar_ignored", emptySet()).orEmpty()) }
                                val radar = remember(tx, data, radarIgnored) { detectRecurringPayments(tx, list("subs").objects(), radarIgnored, YearMonth.now()) }
                                if (radar.isNotEmpty()) SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SaldoIconTile(Icons.Default.Radar, Violet, size = 36.dp, iconSize = 18.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text("Abonnementsradar", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text("Betalinger der går igen hver måned, men ikke er registreret", color = Muted, fontSize = 11.sp)
                                        }
                                    }
                                    radar.forEach { (key, name, average) ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(name, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                                Text("ca. ${money(average)}/md. · ${money(average * 12)} om året", color = Muted, fontSize = 11.sp)
                                            }
                                            TextButton(onClick = {
                                                radarIgnored = radarIgnored + key
                                                prefs.edit().putStringSet("radar_ignored", radarIgnored).apply()
                                            }) { Text("Ignorér", color = Muted) }
                                            TextButton(onClick = {
                                                add("subs", record("id" to "radar-${System.currentTimeMillis()}", "name" to name, "monthly" to kotlin.math.round(average * 100) / 100.0, "renewalDate" to "", "cancelByDate" to "", "cancelNote" to "Fundet af abonnementsradar", "owner" to "Mig", "active" to true))
                                                saveSuccess = "$name er tilføjet som abonnement"
                                            }) { Text("Tilføj", color = Violet, fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                }
                                ManagedList("Abonnementer", subscriptions, { dialog = "sub" }) { sub ->
                                    val renewal = sub.s("renewalDate").takeIf { it.isNotBlank() }?.let { "Fornyes ${saldoDayLabel(it).replaceFirstChar { c -> c.lowercase() }}" } ?: "Fornyelsesdato ikke angivet"
                                    val cancelBy = sub.s("cancelByDate").takeIf { it.isNotBlank() }?.let { " · Opsig senest ${saldoDayLabel(it).replaceFirstChar { c -> c.lowercase() }}" }.orEmpty()
                                    val note = sub.s("cancelNote").takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
                                    RecordRow(sub.s("name"), "$renewal$cancelBy$note · Årligt ${money(sub.n("monthly") * 12)}", "${money(sub.n("monthly"))}/md.", false, { delete("subs", sub.s("id")) }, onEdit = { editingRecord = JSONObject(sub.toString()); dialog = "sub" })
                                }
                            }
                        }
                        "Hvad nu hvis?" -> {
                            var extraSpend by remember { mutableFloatStateOf(500f) }
                            var monthlySave by remember { mutableFloatStateOf(1000f) }
                            val today = LocalDate.now()
                            val recentExpenses = tx.filter { it.s("type") == "Udgift" && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(today.minusDays(90)) && !d.isAfter(today) } == true }.sumOf { it.n("amount") } / 3.0
                            val recurringSubscriptions = list("subs").objects().sumOf { it.n("monthly") }
                            val debtPayments = list("debts").objects().sumOf { it.n("payment") }
                            val estimatedMonthlyIncome = monthlyIncomeFromPay(payAmount, payFrequency)
                            val estimatedBaseline = estimatedMonthlyIncome - recentExpenses - recurringSubscriptions - debtPayments
                            val scenarioMonthlyRemainder = estimatedBaseline - extraSpend.toDouble() - monthlySave.toDouble()
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Hvad nu hvis?", color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp)
                                Text("Prøv ændringer af uden at ændre dine rigtige budgetdata.", color = Muted, fontSize = 12.sp)
                                if (!hasPaySetup) SaldoCard(Modifier.fillMaxWidth()) {
                                    Text("Din løn er ikke angivet", color = White, fontWeight = FontWeight.SemiBold)
                                    Text("Beregningen bruger indtil videre en standardløn på ${money(payAmount)} Angiv din egen løn og lønrytme for et retvisende resultat.", color = Muted, fontSize = 12.sp)
                                    TextButton(onClick = { dialog = "payday" }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text("Angiv løn →", color = Violet, fontWeight = FontWeight.SemiBold) }
                                }
                                if (hasCurrentBalance) {
                                    val dailyVariable = recentExpenses / 30.0
                                    val forecastDays = ChronoUnit.DAYS.between(today, payPeriodEnd).toInt().coerceIn(1, 31)
                                    val projection = remember(bills, currentBalance, forecastDays, dailyVariable) { projectBalance(currentBalance, bills, today, forecastDays, dailyVariable) }
                                    val lowest = projection.withIndex().minBy { it.value }
                                    SaldoCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Saldo frem til næste løn", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        SaldoSparkline(projection, Modifier.fillMaxWidth().height(72.dp), lineColors = if (lowest.value < 0) listOf(SaldoWarning, SaldoDanger) else SaldoBrandColors)
                                        Row {
                                            Column(Modifier.weight(1f)) { Text("I dag", color = Muted, fontSize = 11.sp); Text(money(currentBalance), color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                                            Column(horizontalAlignment = Alignment.End) { Text("Ved løn (${saldoDayLabel(payPeriodEnd.toString()).replaceFirstChar { it.lowercase() }})", color = Muted, fontSize = 11.sp); Text(money(projection.last()), color = if (projection.last() >= 0) Mint else SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
                                        }
                                        Text(
                                            if (lowest.value < 0) "Saldoen kan gå i minus omkring ${saldoDayLabel(today.plusDays(lowest.index.toLong()).toString()).replaceFirstChar { it.lowercase() }} (${money(lowest.value)})."
                                            else "Laveste punkt: ${money(lowest.value)} ${saldoDayLabel(today.plusDays(lowest.index.toLong()).toString()).replaceFirstChar { it.lowercase() }}.",
                                            color = if (lowest.value < 0) SaldoDanger else Mint, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                        )
                                        Text("Beregnet ud fra din registrerede saldo, ubetalte regninger og et gennemsnitligt dagligt forbrug på ${money(dailyVariable)}.", color = Muted, fontSize = 11.sp)
                                    }
                                } else {
                                    SaldoCard(Modifier.fillMaxWidth(), onClick = { dialog = "cashbalance" }, shape = RoundedCornerShape(22.dp)) {
                                        Text("Se din saldo dag for dag frem til løn", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("Tryk og indtast din nuværende saldo, så viser Saldo hvordan den udvikler sig, når regningerne trækkes.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                                Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ShoppingCart, null, tint = Violet); Spacer(Modifier.width(8.dp)); Text("Ekstra forbrug pr. måned", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(money(extraSpend.toDouble()), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                        Slider(value = extraSpend, onValueChange = { extraSpend = (it / 50f).roundToInt() * 50f }, valueRange = 0f..5000f, colors = SliderDefaults.colors(thumbColor = Violet, activeTrackColor = Violet, inactiveTrackColor = PanelRaised, activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent))
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("0 kr.", color = Muted, fontSize = 10.sp); Text("5.000 kr.", color = Muted, fontSize = 10.sp) }
                                        HorizontalDivider(color = BorderSubtle)
                                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Savings, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text("Ekstra opsparing pr. måned", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(money(monthlySave.toDouble()), color = Mint, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                                        Slider(value = monthlySave, onValueChange = { monthlySave = (it / 50f).roundToInt() * 50f }, valueRange = 0f..5000f, colors = SliderDefaults.colors(thumbColor = Violet, activeTrackColor = Violet, inactiveTrackColor = PanelRaised, activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent))
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("0 kr.", color = Muted, fontSize = 10.sp); Text("5.000 kr.", color = Muted, fontSize = 10.sp) }
                                    }
                                }
                                Surface(color = Color.Transparent, shape = RoundedCornerShape(22.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.background(saldoAccentSurfaceBrush()).padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                                        Text("Resultat af scenariet", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        AnimatedMoney(scenarioMonthlyRemainder, color = if (scenarioMonthlyRemainder >= 0) Mint else SaldoDanger, fontSize = 28.sp, format = ::netMoney)
                                        Text("Anslået tilbage pr. måned efter ændringer", color = Muted, fontSize = 11.sp)
                                        HorizontalDivider(color = BorderSubtle)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Ekstra forbrug på et år", color = White, fontSize = 12.sp); Text(money(extraSpend.toDouble() * 12), color = SaldoDanger, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Mulig ekstra opsparing på et år", color = White, fontSize = 12.sp); Text(money(monthlySave.toDouble() * 12), color = Mint, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Effekt på rådighedsbeløb pr. måned", color = White, fontSize = 11.sp); Text(netMoney((-extraSpend - monthlySave).toDouble()), color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 11.sp) }
                                    }
                                }
                                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                                    Text("Grundlaget er lønindstillingen omregnet til gennemsnit pr. måned minus registrerede udgifter de seneste 90 dage, abonnementer og gældsafdrag. Beløbet er et overslag, ikke en bankbalance; undgå at tælle abonnementer eller afdrag dobbelt, hvis de også er registreret som almindelige udgifter.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(14.dp))
                                }
                            }
                        }
                        "Rapporter" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) { SaldoMonthSwitcher(viewMonth, { viewMonth = it }, Modifier.fillMaxWidth()); val currentMonthTx = viewMonthTx; val monthIncome = currentMonthTx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }; val monthExpenses = currentMonthTx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }; val categories = currentMonthTx.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse") }.mapValues { entry -> entry.value.sumOf { it.n("amount") } }.toList().sortedByDescending { it.second }; Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text("Månedens netto", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); AnimatedMoney(monthIncome - monthExpenses, color = if (monthIncome >= monthExpenses) White else SaldoDanger, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.4).sp, format = ::netMoney) }; SaldoStatList(listOf(Triple("Indtægter", money(monthIncome), Mint), Triple("Udgifter", money(monthExpenses), White))); Text("Udvikling – seneste 6 måneder", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); val monthTrend = (0..5).map { offset -> val month = viewMonth.atDay(1).minusMonths((5 - offset).toLong()); val monthEntries = transactionsByMonth[YearMonth.from(month)].orEmpty(); Triple(month, monthEntries.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }, monthEntries.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }) }; SaldoCard(Modifier.fillMaxWidth()) { SaldoTrendChart(monthTrend.map { (month, trendIncome, trendExpenses) -> Triple(month.month.getDisplayName(java.time.format.TextStyle.SHORT, Locale("da", "DK")).trimEnd('.').replaceFirstChar { it.uppercase() }, trendIncome, trendExpenses) }); HorizontalDivider(color = BorderSubtle); monthTrend.takeLast(3).forEach { (month, trendIncome, trendExpenses) -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("${month.monthValue}/${month.year}", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text("Netto ", color = Muted, fontSize = 12.sp); Text(netMoney(trendIncome - trendExpenses), color = if (trendIncome >= trendExpenses) Mint else SaldoDanger, fontSize = 13.sp, fontWeight = FontWeight.Bold) } } }; Text("Største udgiftskategorier", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); if (categories.isEmpty()) Text("Ingen udgifter registreret i denne måned endnu.", color = Muted) else SaldoCard(Modifier.fillMaxWidth()) { SaldoDonutChart(categories) }; SaldoCard(Modifier.fillMaxWidth()) { Text("Forbrug pr. dag", color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp); SaldoSpendCalendar(viewMonth, currentMonthTx.filter { it.s("type") == "Udgift" }.groupBy { runCatching { LocalDate.parse(it.s("date")).dayOfMonth }.getOrDefault(0) }.mapValues { entry -> entry.value.sumOf { it.n("amount") } }) }; SaldoCard(Modifier.fillMaxWidth()) { val topCategoryTotal = categories.firstOrNull()?.second?.takeIf { it > 0 } ?: 1.0; categories.take(5).forEach { (category, total) -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(category, Modifier.weight(1f), color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(money(total), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp) }; SaldoProgressBar((total / topCategoryTotal).toFloat(), height = 7.dp) } } }; Text("Alle poster", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); SaldoStatList(listOf(Triple("Indtægter i alt", money(income), Mint), Triple("Udgifter i alt", money(expenses), White), Triple("Netto i alt", money(income - expenses), if (income >= expenses) White else SaldoDanger), Triple("Abonnementer pr. år", money(list("subs").objects().sumOf { it.n("monthly") * 12 }), White))); Text("Data", color = White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); SaldoCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) { listOf<Triple<androidx.compose.ui.graphics.vector.ImageVector, String, () -> Unit>>(Triple(Icons.Default.FileOpen, if (csvImportBusy) "Indlæser CSV…" else "Importér CSV-fil", { if (!csvImportBusy) csvPicker.launch(arrayOf("*/*")) }), Triple(Icons.Default.IosShare, "Eksportér CSV", { shareCsv(context, data) }), Triple(Icons.Default.Backup, "Eksportér sikkerhedskopi", { shareBackup(context, buildBackupJson(data, prefs)) }), Triple(Icons.Default.Restore, "Gendan sikkerhedskopi", { dialog = "backup" })).forEachIndexed { index, (icon, label, action) -> if (index > 0) HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(start = 46.dp)); Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = action).padding(horizontal = 10.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Violet, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(16.dp)); Text(label, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp)) } } } }
                        "Indstillinger" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Indstillinger", color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp)
                            Text("Udseende", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Vælg dit tema", color = White, fontWeight = FontWeight.SemiBold)
                                    Text("Dit valg gemmes og bruges næste gang, du åbner Saldo.", color = Muted, fontSize = 12.sp)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        FilterChip(selected = themeMode == "light", onClick = { themeMode = "light" }, label = { Text("Lys") }, leadingIcon = { Icon(Icons.Default.LightMode, null) }, modifier = Modifier.weight(1f))
                                        FilterChip(selected = themeMode == "dark", onClick = { themeMode = "dark" }, label = { Text("Mørk") }, leadingIcon = { Icon(Icons.Default.DarkMode, null) }, modifier = Modifier.weight(1f))
                                        FilterChip(selected = themeMode == "system", onClick = { themeMode = "system" }, label = { Text("System") }, leadingIcon = { Icon(Icons.Default.BrightnessAuto, null) }, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                            Text("Tilpas startside", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Vælg de kort, du vil se på dit overblik. Ændringerne gemmes med det samme.", color = Muted, fontSize = 12.sp)
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                                    homeSectionOptions.forEachIndexed { index, option ->
                                        val (key, title, description) = option
                                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                Text(description, color = Muted, fontSize = 11.sp)
                                            }
                                            Checkbox(checked = key in visibleHomeSections, onCheckedChange = { enabled ->
                                                if (!enabled && visibleHomeSections.size == 1) Toast.makeText(context, "Behold mindst ét kort på startsiden.", Toast.LENGTH_SHORT).show()
                                                else updateHomeSection(key, enabled)
                                            })
                                        }
                                        if (index < homeSectionOptions.lastIndex) HorizontalDivider(color = BorderSubtle)
                                    }
                                }
                            }
                            Text("Widgets på telefonens startskærm", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Tilføj Saldo-kort uden at åbne appen. Widgets kan vise økonomiske beløb på startskærmen. Hvis din launcher ikke understøtter hurtig tilføjelse, kan du holde fingeren på telefonens startskærm og vælge Widgets → Saldo.", color = Muted, fontSize = 12.sp)
                            SettingsAction("Widget · Rådighedsbeløb", "Vis estimeret rådighed frem til næste løn", Icons.Default.AccountBalanceWallet) { requestSaldoWidget(context, SaldoBalanceWidgetProvider::class.java) }
                            SettingsAction("Widget · Månedens overblik", "Vis månedens indtægter og udgifter", Icons.Default.PieChart) { requestSaldoWidget(context, SaldoMonthlyWidgetProvider::class.java) }
                            SettingsAction("Widget · Budgetstatus", "Vis de budgetter, der er tættest på grænsen", Icons.Default.PieChart) { requestSaldoWidget(context, SaldoBudgetWidgetProvider::class.java) }
                            SettingsAction("Widget · Kommende regninger", "Vis de næste ubetalte regninger", Icons.Default.CalendarMonth) { requestSaldoWidget(context, SaldoBillsWidgetProvider::class.java) }
                            SettingsAction("Løn og lønrytme", "${payFrequencyLabel(payFrequency)} · ${money(payAmount)} pr. udbetaling", Icons.Default.CalendarMonth) { dialog = "payday" }
                            SettingsAction("Nuværende saldo", if (hasCurrentBalance) "Registreret saldo: ${money(currentBalance)}" else "Indtast saldoen på dine konti for en bedre rådighedsberegning", Icons.Default.AccountBalanceWallet) { dialog = "cashbalance" }
                            SettingsSectionHeader("Sikkerhed og gendannelse", "Lokal backup, PIN og biometrisk oplåsning")
                            SettingsAction("Gendan automatisk lokal backup", backupDescription, Icons.Default.Restore) {
                                val backup = prefs.getString("auto_backup_data", null)
                                if (backup.isNullOrBlank()) Toast.makeText(context, "Der er endnu ingen automatisk backup.", Toast.LENGTH_LONG).show()
                                else runCatching {
                                    val restored = JSONObject(backup)
                                    require(isValidSaldoDataObject(restored)) { "Den lokale backup er tom eller ugyldig." }
                                    normalizeSaldoData(restored)
                                }.onSuccess { restored ->
                                    val currentSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                                    val restoredSnapshot = restored.toString()
                                    val editor = prefs.edit().putString("auto_backup_data", currentSnapshot)
                                        .putLong("auto_backup_time", System.currentTimeMillis())
                                        .putString("data", restoredSnapshot)
                                    val activeUserId = prefs.getString("active_account_user_id", null)
                                    if (!activeUserId.isNullOrBlank()) editor.putString(localAccountDataKey(activeUserId), restoredSnapshot).putString(localAccountBackupKey(activeUserId), currentSnapshot)
                                    editor.apply()
                                    data = restored
                                    SaldoWidgetRefreshQueue.request(context)
                                    Toast.makeText(context, "Gendannet. Den tidligere version er bevaret som næste gendannelsespunkt.", Toast.LENGTH_LONG).show()
                                }.onFailure { Toast.makeText(context, it.message ?: "Den lokale backup kunne ikke læses.", Toast.LENGTH_LONG).show() }
                            }
                            SettingsAction("Opret / ændr PIN", "Beskyt appen med en PIN-kode", Icons.Default.Lock) { dialog = "pin" }
                            SettingsAction("Biometrisk oplåsning", if (prefs.getBoolean("biometric_enabled", false)) "Aktiv · fingeraftryk eller ansigt" else "Brug fingeraftryk eller ansigt", Icons.Default.Fingerprint) {
                                if (prefs.getString("pin_hash", null) == null && prefs.getString("pin", null) == null) {
                                    Toast.makeText(context, "Opret først en PIN-kode. Den bruges som reserve, hvis fingeraftryk ikke virker.", Toast.LENGTH_LONG).show()
                                    dialog = "pin"
                                } else {
                                    val activity = context as? FragmentActivity
                                    if (activity != null) startBiometric(activity, context) { prefs.edit().putBoolean("biometric_enabled", true).apply(); Toast.makeText(context, "Biometrisk oplåsning aktiveret.", Toast.LENGTH_SHORT).show() }
                                    else Toast.makeText(context, "Biometrisk oplåsning er ikke tilgængelig her.", Toast.LENGTH_LONG).show()
                                }
                            }
                            if (prefs.getString("pin_hash", null) != null || prefs.getString("pin", null) != null || prefs.getBoolean("biometric_enabled", false)) {
                                SettingsAction("Fjern app-lås", "Slå PIN og biometrisk oplåsning fra", Icons.Default.LockOpen, danger = true) { removeLockPin = ""; showRemoveLockDialog = true }
                            }
                            SettingsSectionHeader("Import og eksport", "Flyt dine økonomidata ind og ud af Saldo")
                            SettingsAction("Importér fra netbank (CSV)", "Eksportér posteringer i netbanken, og vælg filen her – eller del filen direkte til Saldo", Icons.Default.FileOpen, enabled = !csvImportBusy) { csvPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "application/octet-stream", "*/*")) }
                            if (csvImportBusy) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Violet)
                                Text("Analyserer beskrivelser, beløb og dine eksisterende kategorier…", color = Muted, fontSize = 11.sp)
                            }
                            if (csvImportError.isNotBlank()) Text(csvImportError, color = SaldoDanger, fontSize = 11.sp)
                            SettingsAction("Eksportér CSV", "Del poster, regninger og øvrige registreringer som CSV", Icons.Default.FileDownload) { shareCsv(context, data) }
                            SettingsAction("Eksportér sikkerhedskopi", "Gem en kopi af dine data", Icons.Default.CloudUpload) { shareBackup(context, buildBackupJson(data, prefs)) }
                            SettingsAction("Gendan sikkerhedskopi", "Gendan fra en tidligere kopi", Icons.Default.Restore) { dialog = "backup" }
                            SettingsAction("Eksportér PDF-rapport", "Lav en rapport over din økonomi", Icons.Default.PictureAsPdf) { sharePdfReport(context, tx, bills, income, expenses) }
                            SettingsSectionHeader("Onlinekonto og synkronisering", if (localOnlyMode) "Du bruger Saldo uden konto – data gemmes kun på telefonen" else "Manuel synkronisering mellem dine enheder")
                            if (localOnlyMode) SettingsAction("Log ind eller opret konto", "Få onlinebackup og brug Saldo på flere enheder. Dine data følger med til en ny konto.", Icons.Default.Login) {
                                loginMode = false
                                loginStep = 0
                                loginError = ""
                                accountUnlocked = false
                            }
                            if (!localOnlyMode) {
                            SettingsAction("Gem lokale data online", "Sikkerhedskopiér til din onlinekonto", Icons.Default.CloudUpload, enabled = !cloudBusy, trailing = if (cloudBusy) Icons.Default.Sync else Icons.Default.ArrowForward) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før synkronisering."
                                else { cloudBusy = true; cloudStatus = "Gemmer online…"; scope.launch {
                                    val uploadSnapshot = JSONObject(data.toString())
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { withRefreshedCloudSession(prefs, token) { freshToken -> syncCloud(freshToken, uploadSnapshot, prefs) } }
                                    }
                                    cloudBusy = false
                                    result.onSuccess { cloudStatus = "Lokale data er gemt online." }.onFailure { cloudStatus = "Synkronisering fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            SettingsAction("Hent data fra onlinekonto", "Hent din seneste online sikkerhedskopi", Icons.Default.CloudDownload, enabled = !cloudBusy) {
                                val token = prefs.getString("online_access_token", "").orEmpty()
                                if (token.isBlank()) cloudStatus = "Log ind igen før hentning."
                                else { cloudBusy = true; cloudStatus = "Henter online data…"; scope.launch {
                                    val expectedUserId = prefs.getString("active_account_user_id", null)
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { withRefreshedCloudSession(prefs, token) { freshToken -> fetchCloud(freshToken, expectedUserId) } }
                                    }
                                    cloudBusy = false
                                    result.onSuccess { cloudData -> if (cloudData == null) cloudStatus = "Der er ingen online backup endnu." else {
                                        val previousSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                                        val cloudSettings = cloudData.optJSONObject("_saldoSettings")
                                        val cloudBusinessData = JSONObject(cloudData.toString()).apply { remove("_saldoSettings") }
                                        val normalizedCloudData = normalizeSaldoData(cloudBusinessData)
                                        val downloadedSnapshot = normalizedCloudData.toString()
                                        val restoreEditor = prefs.edit()
                                            .putString("auto_backup_data", previousSnapshot)
                                            .putLong("auto_backup_time", System.currentTimeMillis())
                                            .putString("data", downloadedSnapshot)
                                        val activeUserId = prefs.getString("active_account_user_id", null)
                                        if (!activeUserId.isNullOrBlank()) restoreEditor.putString(localAccountDataKey(activeUserId), downloadedSnapshot).putString(localAccountBackupKey(activeUserId), previousSnapshot)
                                        cloudSettings?.let { settings ->
                                            applySaldoSettings(settings, restoreEditor)
                                            if (!activeUserId.isNullOrBlank()) restoreEditor.putString(localAccountSettingsKey(activeUserId), settings.toString())
                                        }
                                        restoreEditor.apply()
                                        data = normalizedCloudData
                                        SaldoWidgetRefreshQueue.request(context)
                                        cloudStatus = "Online data hentet og gemt lokalt. Den tidligere lokale version er bevaret som gendannelsespunkt."
                                    } }.onFailure { cloudStatus = "Hentning fejlede: ${it.message ?: "ukendt fejl"}" }
                                } }
                            }
                            Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) { Text(cloudStatus, color = Blue, fontSize = 12.sp, modifier = Modifier.padding(14.dp)) }
                            }
                            SettingsSectionHeader("Notifikationer og privatliv", "Påmindelser, kontoadgang og dine data")
                            SettingsAction("Ugentlig opsummering", if (weeklySummaryOn) "Til · hver mandag: ugens forbrug og største kategori" else "Fra", Icons.Default.Summarize) {
                                weeklySummaryOn = !weeklySummaryOn
                                prefs.edit().putBoolean("weekly_summary_enabled", weeklySummaryOn).apply()
                                Toast.makeText(context, if (weeklySummaryOn) "Ugentlig opsummering er slået til." else "Ugentlig opsummering er slået fra.", Toast.LENGTH_SHORT).show()
                            }
                            SettingsAction(
                                "Påmindelse om at registrere",
                                when (entryReminder) { "daily" -> "Hver dag, hvis du ikke har registreret noget"; "weekly" -> "Søndag, hvis ugen er tom"; else -> "Fra · tryk for at slå til" },
                                Icons.Default.Alarm
                            ) {
                                entryReminder = when (entryReminder) { "off" -> "daily"; "daily" -> "weekly"; else -> "off" }
                                prefs.edit().putString("entry_reminder", entryReminder).apply()
                                if (entryReminder != "off" && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                Toast.makeText(context, when (entryReminder) { "daily" -> "Daglig påmindelse er slået til."; "weekly" -> "Ugentlig påmindelse er slået til."; else -> "Påmindelsen er slået fra." }, Toast.LENGTH_SHORT).show()
                            }
                            SettingsAction("Notifikationer og budgetadvarsler", "Kontrollér regninger og budgetgrænser", Icons.Default.NotificationsActive) {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                else { scheduleDueBillNotification(context, bills); scheduleBudgetWarningNotification(context, data); scheduleSubscriptionRenewalNotification(context, data) }
                            }
                            SettingsAction("Privatlivspolitik", "Se hvordan Saldo behandler dine oplysninger", Icons.Default.Policy) {
                                openSaldoExternalPage(context, SALDO_PRIVACY_POLICY_URL)
                            }
                            SettingsAction("Anmod om kontosletning", "Åbn den eksterne sletningsside", Icons.Default.DeleteOutline, danger = true) {
                                openSaldoExternalPage(context, SALDO_ACCOUNT_DELETION_URL)
                            }
                            if (!prefs.getString("online_access_token", null).isNullOrBlank() && !prefs.getString("active_account_user_id", null).isNullOrBlank()) {
                                SettingsAction("Slet onlinekonto og clouddata", "Permanent sletning af konto og tilknyttede online data", Icons.Default.DeleteForever, enabled = !deleteAccountBusy, danger = true) {
                                    deleteAccountError = ""
                                    showDeleteAccountDialog = true
                                }
                            }
                            if (!localOnlyMode) SettingsAction("Log ud", "Afslut online-sessionen", Icons.Default.Logout, danger = true) {
                                val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
                                val editor = prefs.edit().remove("online_access_token").remove("online_refresh_token").remove("account_email")
                                if (activeUserId.isNotBlank()) {
                                    editor.putString(localAccountDataKey(activeUserId), data.toString())
                                        .putString(localAccountSettingsKey(activeUserId), saldoSettingsJson(prefs).toString())
                                    prefs.getString("auto_backup_data", null)?.let { editor.putString(localAccountBackupKey(activeUserId), it) }
                                }
                                val blank = emptySaldoData()
                                editor.putString("data", blank.toString()).remove("auto_backup_data")
                                    .remove("cash_balance").remove("cash_balance_exact").remove("payday").remove("pay_frequency").apply()
                                data = blank
                                SaldoWidgetRefreshQueue.request(context)
                                accountUnlocked = false
                                unlocked = prefs.getString("pin_hash", null) == null &&
                                    prefs.getString("pin", null) == null &&
                                    !prefs.getBoolean("biometric_enabled", false)
                                loginMode = false
                                loginPassword = ""
                                loginConfirm = ""
                            }
                        }
                    }
                    }
                }
            }
        }
        if (showOnboarding && unlocked && accountUnlocked && !splash && passwordRecoveryToken.isNullOrBlank()) {
            SaldoOnboarding(
                themeMode = themeMode,
                onThemeChange = { themeMode = it },
                onSkip = {
                    prefs.edit().putBoolean("onboarding_done", true).apply()
                    showOnboarding = false
                },
                onFinish = { pay, payday, balance, frequency ->
                    val editor = prefs.edit().putBoolean("onboarding_done", true).putString("pay_frequency", frequency)
                    if (pay != null) editor.putSaldoMoney("pay_amount", pay)
                    if (payday != null) editor.putString("payday", payday)
                    if (balance != null) editor.putSaldoMoney("cash_balance", balance)
                    editor.apply()
                    persistSaldoSettingsForActiveAccount(prefs)
                    SaldoWidgetRefreshQueue.request(context)
                    showOnboarding = false
                    saveSuccess = "Saldo er klar"
                }
            )
        }
        splittingRecord?.let { post ->
            val splitCategories = remember(tx) { tx.map { it.s("category").trim() }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key } }
            SplitPostDialog(
                post = post,
                categories = splitCategories,
                onDismiss = { splittingRecord = null },
                onSplit = { part, category, owner ->
                    splitTransaction(post, part, category, owner, "split-${System.currentTimeMillis()}")?.let { (remaining, split) ->
                        val updated = JSONArray()
                        list("transactions").objects().forEach { item -> updated.put(if (item.s("id") == post.s("id")) remaining else item) }
                        updated.put(split)
                        store("transactions", updated)
                        saveSuccess = "Posten er delt i to"
                    }
                    splittingRecord = null
                }
            )
        }
        if (showBudgetSuggestions) {
            // Average monthly spend per category/owner over the last three complete months, rounded up to 100 kr.
            var useTemplate by remember { mutableStateOf(false) }
            val templateIncome = monthlyIncomeFromPay(payAmount, payFrequency)
            val suggestions = remember(transactionsByMonth, data, useTemplate) {
                val recent = (1..3).flatMap { transactionsByMonth[YearMonth.now().minusMonths(it.toLong())].orEmpty() }
                if (useTemplate) fiftyThirtyTwentyBudgets(templateIncome, recent, list("budgets").objects())
                else suggestBudgets(recent, list("budgets").objects())
            }
            var selected by remember(suggestions) { mutableStateOf(suggestions.map { "${it.first}|${it.second}" }.toSet()) }
            AlertDialog(
                onDismissRequest = { showBudgetSuggestions = false },
                containerColor = Panel,
                title = { Text(if (useTemplate) "Budget efter 50/30/20" else "Foreslåede budgetter", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = !useTemplate, onClick = { useTemplate = false }, label = { Text("Ud fra forbrug", maxLines = 1) }, modifier = Modifier.weight(1f))
                        FilterChip(selected = useTemplate, onClick = { useTemplate = true }, label = { Text("50/30/20", maxLines = 1) }, modifier = Modifier.weight(1f))
                    }
                    if (useTemplate) Text(
                        "Ud fra din løn på ${money(templateIncome)} om måneden: ${money(templateIncome * .5)} til nødvendige udgifter (50 %), ${money(templateIncome * .3)} til resten (30 %) og ${money(templateIncome * .2)} til opsparing og afdrag (20 %). Beløbene fordeles efter, hvad du har brugt de seneste tre måneder." +
                            if (!hasPaySetup) " Angiv din løn under Indstillinger for et præcist resultat." else "",
                        color = Muted, fontSize = 12.sp
                    )
                    if (suggestions.isEmpty()) Text("Der er ikke nok udgifter fra de seneste tre måneder til at lave forslag – eller alle kategorier har allerede et budget.", color = Muted)
                    else LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (!useTemplate) item { Text("Gennemsnitligt forbrug pr. måned de seneste tre måneder, rundet op. Fravælg det, du ikke vil have.", color = Muted, fontSize = 12.sp) }
                        items(suggestions, key = { "${it.first}|${it.second}" }) { (category, owner, limit) ->
                            val key = "$category|$owner"
                            Row(Modifier.fillMaxWidth().clickable { selected = if (key in selected) selected - key else selected + key }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = key in selected, onCheckedChange = { selected = if (it) selected + key else selected - key })
                                Column(Modifier.weight(1f)) {
                                    Text(category, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(owner, color = Muted, fontSize = 11.sp)
                                }
                                Text(money(limit), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                    }
                },
                confirmButton = {
                    TextButton(enabled = suggestions.isNotEmpty() && selected.isNotEmpty(), onClick = {
                        val updated = list("budgets")
                        suggestions.filter { "${it.first}|${it.second}" in selected }.forEachIndexed { index, (category, owner, limit) ->
                            updated.put(record("id" to "suggested-${System.currentTimeMillis()}-$index", "category" to category, "limit" to limit, "owner" to owner))
                        }
                        store("budgets", updated)
                        showBudgetSuggestions = false
                        saveSuccess = "${selected.size} budgetter er oprettet"
                    }) { Text("Opret valgte", color = Violet, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showBudgetSuggestions = false }) { Text("Annuller", color = Muted) } }
            )
        }
        depositGoal?.let { goal ->
            var depositAmount by remember(goal.s("id")) { mutableStateOf("") }
            var alsoRegister by remember(goal.s("id")) { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { depositGoal = null },
                containerColor = Panel,
                title = { Text("Indbetal på ${goal.s("name")}", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Field("Beløb i kr.", depositAmount, { depositAmount = it }, numeric = true)
                        Row(Modifier.fillMaxWidth().clickable { alsoRegister = !alsoRegister }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = alsoRegister, onCheckedChange = { alsoRegister = it })
                            Text("Registrér også som en overførsel til opsparing i Poster", color = White, fontSize = 13.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val amount = parseDanishAmount(depositAmount)
                        if (amount == null || amount <= 0.0) {
                            Toast.makeText(context, "Indtast et beløb større end 0 kr.", Toast.LENGTH_SHORT).show()
                        } else {
                            val goals = JSONArray()
                            list("goals").objects().forEach { item ->
                                if (item.s("id") == goal.s("id")) goals.put(JSONObject(item.toString()).put("saved", item.n("saved") + amount)) else goals.put(item)
                            }
                            store("goals", goals)
                            if (alsoRegister) add("transactions", record("id" to "goal-${System.currentTimeMillis()}", "name" to "Opsparing: ${goal.s("name")}", "amount" to amount, "category" to "Opsparing", "date" to LocalDate.now().toString(), "type" to "Udgift", "owner" to "Mig"))
                            depositGoal = null
                            saveSuccess = "${money(amount)} indbetalt"
                        }
                    }) { Text("Indbetal", color = Violet, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { depositGoal = null }) { Text("Annuller", color = Muted) } }
            )
        }
        renamingCategory?.let { oldName ->
            var newName by remember(oldName) { mutableStateOf(oldName) }
            val otherCategories = remember(data, oldName) {
                (list("transactions").objects() + list("bills").objects() + list("budgets").objects()).map { it.s("category").trim() }
                    .filter { it.isNotBlank() && !it.equals(oldName, true) }.distinctBy { it.lowercase(Locale.ROOT) }.sorted().take(30)
            }
            AlertDialog(
                onDismissRequest = { renamingCategory = null },
                containerColor = Panel,
                title = { Text("Omdøb eller flet kategori", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Alle poster, regninger og budgetter med \"$oldName\" flyttes til det nye navn. Vælg en eksisterende kategori for at flette dem.", color = Muted, fontSize = 12.sp)
                        Field("Nyt navn", newName, { newName = it })
                        if (otherCategories.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            otherCategories.forEach { option -> SuggestionChip(onClick = { newName = option }, label = { Text(option) }) }
                        }
                    }
                },
                confirmButton = {
                    TextButton(enabled = newName.isNotBlank() && !newName.trim().equals(oldName, false), onClick = {
                        val target = newName.trim()
                        fun relabel(key: String) {
                            val updated = JSONArray()
                            list(key).objects().forEach { item ->
                                updated.put(if (item.s("category").trim().equals(oldName, true)) JSONObject(item.toString()).put("category", target) else item)
                            }
                            store(key, updated)
                        }
                        relabel("transactions"); relabel("bills")
                        // Merge budgets: one budget per category/owner, keeping the highest limit.
                        val budgets = list("budgets").objects().map { if (it.s("category").trim().equals(oldName, true)) JSONObject(it.toString()).put("category", target) else it }
                        val mergedBudgets = JSONArray()
                        budgets.groupBy { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }
                            .values.forEach { group -> mergedBudgets.put(group.maxBy { it.n("limit") }) }
                        store("budgets", mergedBudgets)
                        renamingCategory = null
                        saveSuccess = "Kategorien hedder nu $target"
                    }) { Text("Gem", color = Violet, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { renamingCategory = null }) { Text("Annuller", color = Muted) } }
            )
        }
        if (showSearch) {
            val query = globalQuery.trim()
            val results = remember(query, data) {
                if (query.length < 2) emptyList() else buildList {
                    fun JSONObject.matches() = listOf(s("name"), s("category"), s("note"), s("date")).any { it.contains(query, ignoreCase = true) }
                    list("transactions").objects().filter { it.matches() }.sortedByDescending { it.s("date") }.take(25).forEach { add(Triple("Post", it, it.n("amount"))) }
                    list("bills").objects().filter { it.matches() }.take(10).forEach { add(Triple("Regning", it, it.n("amount"))) }
                    list("subs").objects().filter { it.matches() }.take(10).forEach { add(Triple("Abonnement", it, it.n("monthly"))) }
                    list("goals").objects().filter { it.matches() }.take(10).forEach { add(Triple("Opsparingsmål", it, it.n("target"))) }
                    list("debts").objects().filter { it.matches() }.take(10).forEach { add(Triple("Gæld", it, it.n("balance"))) }
                }
            }
            androidx.compose.ui.window.Dialog(onDismissRequest = { showSearch = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
                Column(Modifier.fillMaxSize().background(Night).statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showSearch = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Luk søgning", tint = White) }
                        OutlinedTextField(
                            value = globalQuery, onValueChange = { globalQuery = it }, singleLine = true, modifier = Modifier.weight(1f),
                            placeholder = { Text("Søg i hele Saldo") }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = BorderSubtle)
                        )
                    }
                    if (query.length < 2) Text("Skriv mindst to tegn. Søgningen dækker navne, kategorier, noter og datoer.", color = Muted, fontSize = 12.sp)
                    else if (results.isEmpty()) Text("Ingen resultater for \"$query\".", color = Muted, fontSize = 13.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(results, key = { "${it.first}-${it.second.s("id")}" }) { (kind, item, amount) ->
                            SaldoCard(Modifier.fillMaxWidth(), onClick = {
                                tab = when (kind) { "Post" -> "Poster"; "Regning" -> "Regninger"; "Abonnement" -> "Abonnementer"; "Opsparingsmål" -> "Opsparing"; else -> "Gæld" }
                                if (kind == "Post") {
                                    transactionSearch = query
                                    viewMonth = runCatching { YearMonth.from(LocalDate.parse(item.s("date"))) }.getOrDefault(viewMonth)
                                }
                                showSearch = false
                            }, shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SaldoAvatar(item.s("name").ifBlank { kind }, item.s("type") == "Indtægt", size = 38.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(item.s("name").ifBlank { item.s("category") }, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                                        Text(listOf(kind, item.s("category"), item.s("date").takeIf { it.isNotBlank() }?.let { saldoDayLabel(it) }.orEmpty()).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 11.sp, maxLines = 1)
                                    }
                                    Text(money(amount), color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (showAssistant) SaldoAssistantScreen(
            SaldoAssistantContext(
                today = today, available = estimatedAvailableToPayday, dailyAllowance = dailyAllowance, daysToPay = daysToPay,
                payFrequency = payFrequency, payAmount = payAmount, hasBalance = hasCurrentBalance, transactions = tx, bills = bills,
                budgets = list("budgets").objects(), goals = list("goals").objects(), subscriptions = list("subs").objects(), debts = list("debts").objects()
            ),
            onClose = { showAssistant = false },
            onNavigate = { target -> showAssistant = false; tab = target }
        )
        SaldoSuccessOverlay(saveSuccess) { saveSuccess = null }
        // Run share/shortcut actions only once the user is signed in and has unlocked the app.
        LaunchedEffect(externalAction, unlocked, accountUnlocked, splash, passwordRecoveryToken) {
            val action = externalAction ?: return@LaunchedEffect
            if (!unlocked || !accountUnlocked || splash || !passwordRecoveryToken.isNullOrBlank()) return@LaunchedEffect
            onExternalActionHandled()
            when (action) {
                SaldoExternalAction.NewPost -> { editingRecord = null; dialog = "post" }
                SaldoExternalAction.PickCsv -> csvPicker.launch(arrayOf("text/csv", "text/comma-separated-values", "application/vnd.ms-excel", "text/plain", "*/*"))
                is SaldoExternalAction.ImportUri -> runCsvImport { readTextFromUri(context, action.uri, 10 * 1024 * 1024) }
                is SaldoExternalAction.ImportText -> runCsvImport { action.text }
            }
        }
        if (showRemoveLockDialog) {
            val pinConfigured = prefs.getString("pin_hash", null) != null || prefs.getString("pin", null) != null
            fun removeLock() {
                prefs.edit().remove("pin_hash").remove("pin_salt").remove("pin").remove("biometric_enabled")
                    .remove("pin_failed_attempts").remove("pin_locked_until").apply()
                showRemoveLockDialog = false
                removeLockPin = ""
                saveSuccess = "App-låsen er fjernet"
            }
            AlertDialog(
                onDismissRequest = { showRemoveLockDialog = false; removeLockPin = "" },
                containerColor = Panel,
                title = { Text("Fjern app-lås?", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (pinConfigured) "Bekræft med din nuværende PIN-kode. Herefter åbner Saldo uden PIN og fingeraftryk." else "Bekræft med fingeraftryk. Herefter åbner Saldo uden biometrisk oplåsning.", color = Muted)
                        if (pinConfigured) Field("Nuværende PIN-kode", removeLockPin, { removeLockPin = it }, numeric = true, password = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (pinConfigured) {
                            if (verifyAndUpgradePin(prefs, removeLockPin)) removeLock()
                            else { removeLockPin = ""; Toast.makeText(context, "Forkert PIN-kode.", Toast.LENGTH_SHORT).show() }
                        } else {
                            val activity = context as? FragmentActivity
                            if (activity != null) startBiometric(activity, context) { removeLock() }
                        }
                    }) { Text("Fjern lås", color = SaldoDanger, fontWeight = FontWeight.Bold) }
                },
                dismissButton = { TextButton(onClick = { showRemoveLockDialog = false; removeLockPin = "" }) { Text("Annuller", color = Muted) } }
            )
        }
        if (dialog.isNotEmpty()) {
            key(dialogNonce) { DataDialog(dialog, initial = editingRecord?.takeIf { dialog in saldoEditableKinds }, suggestions = remember(tx) { tx.sortedByDescending { it.s("date") }.distinctBy { it.s("name").trim().lowercase(Locale.ROOT) }.take(300) }, onDismiss = { dialog = ""; editingRecord = null }, onSave = { kind, obj ->
                val keepPostOpen = obj.optBoolean("_keepOpen", false)
                obj.remove("_keepOpen")
                val editTarget = editingRecord
                if (editTarget != null && kind in saldoEditableKinds) {
                    val collection = saldoCollectionForKind(kind)
                    val targetId = editTarget.s("id")
                    val updatedRecords = JSONArray()
                    var replaced = false
                    list(collection).objects().forEach { item ->
                        if (!replaced && item.s("id") == targetId) { updatedRecords.put(obj); replaced = true } else updatedRecords.put(item)
                    }
                    if (replaced) {
                        store(collection, updatedRecords)
                        saveSuccess = "Ændringerne er gemt"
                    } else Toast.makeText(context, "Posten findes ikke længere. Den kan være slettet.", Toast.LENGTH_LONG).show()
                    editingRecord = null
                    dialog = ""
                    return@DataDialog
                }
                when (kind) {
                    "post" -> { add("transactions", obj); saveSuccess = if (obj.s("type") == "Indtægt") "Indtægten er gemt" else "Posten er gemt" }
                    "bill" -> {
                        val duplicate = list("bills").objects().any {
                            it.s("name").trim().equals(obj.s("name").trim(), true) &&
                                it.s("date") == obj.s("date") &&
                                kotlin.math.abs(it.n("amount") - obj.n("amount")) < 0.01 &&
                                normalizedOwner(it.s("owner", "Mig")) == normalizedOwner(obj.s("owner", "Mig"))
                        }
                        if (duplicate) Toast.makeText(context, "Mulig dublet: regningen findes allerede", Toast.LENGTH_LONG).show() else { add("bills", obj); saveSuccess = "Regningen er gemt" }
                    }
                    "budget" -> {
                        val duplicate = list("budgets").objects().any {
                            it.s("category").trim().equals(obj.s("category").trim(), ignoreCase = true) &&
                                it.s("owner", "Mig").trim().equals(obj.s("owner", "Mig").trim(), ignoreCase = true)
                        }
                        if (duplicate) {
                            Toast.makeText(context, "Der findes allerede et budget for denne kategori og ejer. Brug det eksisterende budget i stedet.", Toast.LENGTH_LONG).show()
                        } else { add("budgets", obj); saveSuccess = "Budgettet er gemt" }
                    }
                    "goal" -> { add("goals", obj); saveSuccess = "Opsparingsmålet er gemt" }
                    "debt" -> { add("debts", obj); saveSuccess = "Gælden er gemt" }
                    "fuel" -> { add("fuel", obj); saveSuccess = "Tankningen er gemt" }
                    "sub" -> { add("subs", obj); saveSuccess = "Abonnementet er gemt" }
                    "payday" -> {
                        prefs.edit().putSaldoMoney("pay_amount", obj.n("pay")).putString("payday", obj.s("date")).putString("pay_frequency", obj.s("frequency", "monthly")).apply()
                        persistSaldoSettingsForActiveAccount(prefs)
                        saveSuccess = "Lønindstillingen er gemt"
                    }
                    "pin" -> {
                        val salt = newPinSalt()
                        val hash = hashPin(obj.s("pin"), salt)
                        prefs.edit().putString("pin_salt", salt).putString("pin_hash", hash)
                            .remove("pin").apply()
                        unlocked = true
                    }
                    "backup" -> {
                        val importedBackup = parseSaldoBackup(obj.s("json"))
                            ?: throw IllegalArgumentException("Backupfilen kunne ikke valideres.")
                        val restored = normalizeSaldoData(importedBackup.data)
                        val snapshot = restored.toString()
                        val previousSnapshot = prefs.getString("data", data.toString()) ?: data.toString()
                        val editor = prefs.edit()
                            .putString("auto_backup_data", previousSnapshot)
                            .putLong("auto_backup_time", System.currentTimeMillis())
                            .putString("data", snapshot)
                        importedBackup.settings?.let { settings ->
                            applySaldoSettings(settings, editor)
                            prefs.getString("active_account_user_id", null)?.takeIf { it.isNotBlank() }?.let { editor.putString(localAccountSettingsKey(it), settings.toString()) }
                        }
                        editor.apply()
                        data = restored
                    }
                    "cashbalance" -> {
                        prefs.edit().putSaldoMoney("cash_balance", obj.n("balance")).apply()
                        persistSaldoSettingsForActiveAccount(prefs)
                        saveSuccess = "Saldoen er opdateret"
                    }
                }
                SaldoWidgetRefreshQueue.request(context)
                dialog = if (keepPostOpen && kind == "post") "post" else ""
                if (keepPostOpen && kind == "post") dialogNonce++
            }) }
        }
        pendingCsvImport?.let { plan ->
            val totalImportedRows = plan.recordsByCollection.values.sumOf { it.size }
            val summary = listOf(
                "Poster" to (plan.recordsByCollection["transactions"]?.size ?: 0),
                "Regninger" to (plan.recordsByCollection["bills"]?.size ?: 0),
                "Budgetter" to (plan.recordsByCollection["budgets"]?.size ?: 0),
                "Opsparingsmål" to (plan.recordsByCollection["goals"]?.size ?: 0),
                "Gæld" to (plan.recordsByCollection["debts"]?.size ?: 0),
                "Abonnementer" to (plan.recordsByCollection["subs"]?.size ?: 0),
                "Tankninger" to (plan.recordsByCollection["fuel"]?.size ?: 0)
            ).filter { it.second > 0 }
            val transactionPreview = plan.recordsByCollection["transactions"].orEmpty()
            val categoryContext = csvCategoryContext
            val categoryOptions = csvCategoryOptions(plan, categoryContext)
            val needsReviewCount = transactionPreview.count {
                it.optBoolean("_saldoCsvNeedsReview", it.optInt("_saldoCsvConfidence", 0) < 72) ||
                    it.optInt("_saldoCsvDirectionConfidence", 0) < 80
            }
            AlertDialog(
                onDismissRequest = { pendingCsvImport = null },
                containerColor = Panel,
                title = { Text("Kontrollér CSV-import", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 500.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 6.dp)
                    ) {
                        item {
                            Text("Saldo har læst ${plan.rowsRead} datarække(r)${if (plan.columnSummary.isNotBlank()) " fra kolonnerne " + plan.columnSummary else ""}. Intet ændres, før du bekræfter importen.", color = Muted, fontSize = 13.sp)
                        }
                        if (summary.isNotEmpty()) item {
                            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    summary.forEach { (label, count) ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, color = White, fontSize = 13.sp)
                                            Text(count.toString(), color = Violet, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                        if (transactionPreview.isNotEmpty()) {
                            item {
                                val incomeRows = transactionPreview.filter { it.s("type") == "Indtægt" }
                                val expenseRows = transactionPreview.filter { it.s("type") == "Udgift" }
                                Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Text("Gennemgå og ret forslag", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text("${incomeRows.size} indtægter · ${money(incomeRows.sumOf { it.n("amount") })}   ${expenseRows.size} udgifter · ${money(expenseRows.sumOf { it.n("amount") })}", color = Muted, fontSize = 11.sp)
                                        Text(if (needsReviewCount == 0) "Alle forslag har høj sikkerhed. Kontrollér stadig beløb og retning." else "$needsReviewCount post(er) bør kontrolleres. Du kan ændre både retning og kategori før import.", color = if (needsReviewCount == 0) Mint else SaldoWarning, fontSize = 11.sp)
                                    }
                                }
                            }
                            items(transactionPreview, key = { it.s("id") }) { transaction ->
                                CsvTransactionPreviewRow(
                                    transaction = transaction,
                                    categories = categoryOptions,
                                    onTypeChange = { selectedType ->
                                        pendingCsvImport = updateCsvPlanTransaction(plan = pendingCsvImport ?: plan, id = transaction.s("id"), newType = selectedType, context = categoryContext)
                                    },
                                    onCategoryChange = { selectedCategory ->
                                        pendingCsvImport = updateCsvPlanTransaction(plan = pendingCsvImport ?: plan, id = transaction.s("id"), newCategory = selectedCategory, context = categoryContext)
                                    }
                                )
                            }
                        }
                        if (plan.skippedRows > 0) item { Text("Sprunget over som dublet eller ukendt posttype: ${plan.skippedRows}.", color = Muted, fontSize = 11.sp) }
                        if (plan.invalidRows > 0) item { Text("Rækker med manglende eller ugyldige felter: ${plan.invalidRows}.", color = SaldoDanger, fontSize = 11.sp) }
                        item {
                            Text("Importerede poster lægges oven i dine eksisterende data. De erstatter ikke din økonomi.", color = Mint, fontSize = 11.sp)
                            Text("Retningen afgøres først og fremmest af CSV-filens retning, debet/kredit eller beløbets fortegn. Beløbsstørrelse bruges kun som ekstra støtte ved genkendelse af tidligere transaktioner.", color = Muted, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        var imported = 0
                        var duplicates = 0
                        plan.recordsByCollection.forEach { (collection, incoming) ->
                            val merged = list(collection).objects().toMutableList()
                            val fingerprints = merged.mapTo(mutableSetOf()) { csvRecordFingerprint(collection, it) }
                            incoming.forEach { candidate ->
                                val cleanCandidate = JSONObject(candidate.toString())
                                val learnCorrection = collection == "transactions" && candidate.optBoolean("_saldoCsvUserChangedCategory", false)
                                val correctionName = cleanCandidate.s("name")
                                val correctionType = cleanCandidate.s("type")
                                val correctionCategory = cleanCandidate.s("category")
                                csvTransientFields.forEach(cleanCandidate::remove)
                                if (!fingerprints.add(csvRecordFingerprint(collection, cleanCandidate))) {
                                    duplicates++
                                } else {
                                    merged += cleanCandidate
                                    imported++
                                    if (learnCorrection) persistCsvCategoryCorrection(prefs, correctionName, correctionType, correctionCategory)
                                }
                            }
                            if (merged.size > list(collection).length()) {
                                store(collection, JSONArray().apply { merged.forEach { put(it) } })
                            }
                        }
                        pendingCsvImport = null
                        csvImportError = ""
                        Toast.makeText(context, "CSV-import færdig: $imported tilføjet, $duplicates dubletter sprunget over.", Toast.LENGTH_LONG).show()
                    }, enabled = totalImportedRows > 0) { Text("Importér $totalImportedRows", color = Blue) }
                },
                dismissButton = { TextButton(onClick = { pendingCsvImport = null }) { Text("Annuller", color = Muted) } }
            )
        }

        if (showMultiBillDialog) {
            MultiBillImportDialog(
                drafts = multiBillDrafts,
                onDraftsChanged = { multiBillDrafts = it },
                onDismiss = { showMultiBillDialog = false; multiBillDrafts = emptyList() },
                onImport = { drafts ->
                    var added = 0
                    var duplicates = 0
                    val existingBillsForImport = list("bills").objects()
                    val importedBills = mutableListOf<JSONObject>()
                    var invalid = 0
                    drafts.filter { it.selected }.forEach { draft ->
                        val parsedAmount = parseDanishAmount(draft.amount)
                        val validDate = runCatching { LocalDate.parse(draft.date) }.isSuccess
                        if (draft.name.isBlank() || parsedAmount == null || parsedAmount <= 0.0 || !validDate) {
                            invalid++
                        } else {
                            val candidate = record(
                                "id" to draft.id,
                                "name" to draft.name.trim(),
                                "amount" to parsedAmount,
                                "date" to draft.date,
                                "repeat" to "Engangsbetaling",
                                "category" to "Regning",
                                "owner" to "Mig",
                                "paid" to false,
                                "source" to "Masseimport af billeder"
                            )
                            val exists = (existingBillsForImport + importedBills).any { existing -> csvRecordsEquivalent("bills", existing, candidate) }
                            if (exists) duplicates++ else { importedBills += candidate; added++ }
                        }
                    }
                    if (importedBills.isNotEmpty()) {
                        val updatedBills = list("bills")
                        importedBills.forEach { updatedBills.put(it) }
                        store("bills", updatedBills)
                    }
                    showMultiBillDialog = false
                    multiBillDrafts = emptyList()
                    Toast.makeText(context, "Regningsimport: $added tilføjet, $duplicates dubletter, $invalid ugyldige/skippede.", Toast.LENGTH_LONG).show()
                }
            )
        }

        editingGoal?.let { goal ->
            GoalEditDialog(
                goal = goal,
                onDismiss = { editingGoal = null },
                onSave = { updated ->
                    val goalId = goal.s("id")
                    val updatedGoals = JSONArray()
                    list("goals").objects().forEach { current ->
                        updatedGoals.put(if (current.s("id") == goalId) updated else current)
                    }
                    store("goals", updatedGoals)
                    editingGoal = null
                    Toast.makeText(context, "Opsparingsmålet er opdateret.", Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (showDeleteAccountDialog) {
            AlertDialog(
                onDismissRequest = { if (!deleteAccountBusy) showDeleteAccountDialog = false },
                containerColor = Panel,
                title = { Text("Slet onlinekonto?", color = White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Dette sletter din Supabase-konto og dens online backup permanent. Saldo fjerner også denne kontos lokale data fra telefonen. Handlingen kan ikke fortrydes.", color = Muted)
                        Text("Eksportér først en JSON-sikkerhedskopi, hvis du vil gemme dine oplysninger.", color = White, fontWeight = FontWeight.SemiBold)
                        if (deleteAccountError.isNotBlank()) Text(deleteAccountError, color = SaldoDanger, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !deleteAccountBusy,
                        onClick = {
                            val token = prefs.getString("online_access_token", "").orEmpty()
                            val accountId = prefs.getString("active_account_user_id", "").orEmpty()
                            if (token.isBlank() || accountId.isBlank()) {
                                deleteAccountError = "Du skal være logget ind på den konto, der skal slettes."
                            } else {
                                deleteAccountBusy = true
                                deleteAccountError = ""
                                scope.launch {
                                    val result = withContext(Dispatchers.IO) {
                                        runCatching { supabaseDeleteAccount(token) }
                                    }
                                    deleteAccountBusy = false
                                    result.onSuccess {
                                        val blank = emptySaldoData()
                                        prefs.edit()
                                            .remove("online_access_token")
                                            .remove("online_refresh_token")
                                            .remove("account_email")
                                            .remove("active_account_user_id")
                                            .remove(localAccountDataKey(accountId))
                                            .remove(localAccountBackupKey(accountId))
                                            .remove(localAccountSettingsKey(accountId))
                                            .remove("auto_backup_data")
                                            .remove("auto_backup_time")
                                            .remove("corrupt_data_backup")
                                            .remove("cash_balance").remove("cash_balance_exact")
                                            .remove("payday").remove("pay_frequency")
                                            .putSaldoMoney("pay_amount", 10000.0)
                                            .putString("data", blank.toString())
                                            .apply()
                                        data = blank
                                        loginEmail = ""
                                        loginPassword = ""
                                        loginConfirm = ""
                                        pin = ""
                                        accountUnlocked = false
                                        showDeleteAccountDialog = false
                                        deleteAccountError = ""
                                        SaldoWidgetRefreshQueue.request(context)
                                        Toast.makeText(context, "Onlinekonto og tilknyttede data er slettet.", Toast.LENGTH_LONG).show()
                                    }.onFailure { error ->
                                        deleteAccountError = error.message ?: "Kontoen kunne ikke slettes. Prøv igen, eller brug sletningssiden."
                                    }
                                }
                            }
                        }
                    ) { Text(if (deleteAccountBusy) "Sletter…" else "Slet konto permanent", color = SaldoDanger) }
                },
                dismissButton = {
                    TextButton(enabled = !deleteAccountBusy, onClick = { showDeleteAccountDialog = false }) {
                        Text("Annuller", color = Muted)
                    }
                }
            )
        }
    }
}

internal suspend fun <T> com.google.android.gms.tasks.Task<T>.saldoAwait(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result) }
        addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
        addOnCanceledListener { if (continuation.isActive) continuation.cancel() }
    }
