package dk.saldo.app

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

// "Spørg Saldo": an on-device assistant. It answers questions about the user's own numbers, how the app works and
// general Danish personal-finance topics (SaldoKnowledge.kt). Nothing leaves the phone and it costs nothing.

internal data class SaldoAssistantContext(
    val today: LocalDate,
    val available: Double,
    val dailyAllowance: Double,
    val daysToPay: Int,
    val payFrequency: String,
    val payAmount: Double,
    val hasBalance: Boolean,
    val transactions: List<JSONObject>,
    val bills: List<JSONObject>,
    val budgets: List<JSONObject>,
    val goals: List<JSONObject>,
    val subscriptions: List<JSONObject>,
    val debts: List<JSONObject>
)

/** An answer, optionally with a shortcut to the screen where the user can act on it. */
internal data class SaldoAnswer(val text: String, val actionLabel: String? = null, val actionTab: String? = null)

internal val saldoAssistantSuggestions = listOf(
    "Hvor meget kan jeg bruge i dag?",
    "Hvornår får jeg løn?",
    "Hvilke regninger skal betales?",
    "Hvad bruger jeg mest på?",
    "Hvor meget brugte jeg på mad sidste måned?",
    "Hvordan går mit budget?",
    "Hvordan kan jeg spare?",
    "Skal jeg betale gæld af eller spare op?",
    "Hvad er ÅOP?",
    "Hvordan importerer jeg fra banken?"
)

private val danish = Locale("da", "DK")
private val monthNames = listOf("januar", "februar", "marts", "april", "maj", "juni", "juli", "august", "september", "oktober", "november", "december")

private fun normalizeQuestion(text: String): String =
    " " + text.lowercase(danish).replace(Regex("[^a-z0-9æøåé ]"), " ").replace(Regex("\\s+"), " ").trim() + " "

private fun String.hasAny(vararg words: String) = words.any { this.contains(it) }

private fun monthLabel(month: YearMonth) = month.month.getDisplayName(TextStyle.FULL, danish) + if (month.year != YearMonth.now().year) " ${month.year}" else ""

/** Finds which month a question is about ("sidste måned", "i oktober", "denne måned"); defaults to the current month. */
private fun questionMonth(q: String, today: LocalDate): YearMonth {
    val current = YearMonth.from(today)
    if (q.hasAny(" sidste måned ", " forrige måned ", " sidste maaned ")) return current.minusMonths(1)
    monthNames.forEachIndexed { index, name ->
        if (q.contains(" $name ")) {
            val candidate = YearMonth.of(today.year, index + 1)
            return if (candidate > current) candidate.minusYears(1) else candidate
        }
    }
    return current
}

private fun expensesIn(ctx: SaldoAssistantContext, month: YearMonth) = ctx.transactions.filter { item ->
    item.s("type") == "Udgift" && item.s("date").startsWith(month.toString())
}

/** Answers a question about the user's own finances or about how the app works. */
internal fun answerSaldoQuestion(question: String, ctx: SaldoAssistantContext, format: (Double) -> String = ::money): SaldoAnswer =
    // Amounts end in "kr.", so a sentence ending right after one would otherwise get a double full stop.
    answerSaldoQuestionRaw(question, ctx, format).let { it.copy(text = it.text.replace("kr..", "kr.")) }

private fun answerSaldoQuestionRaw(question: String, ctx: SaldoAssistantContext, format: (Double) -> String): SaldoAnswer {
    val q = normalizeQuestion(question)
    if (q.isBlank()) return SaldoAnswer("Skriv et spørgsmål, eller vælg et af forslagene nedenfor.")
    val knowledge = findSaldoKnowledge(q)
    val knowledgeAnswer = knowledge?.let { SaldoAnswer(it.text, it.actionLabel, it.actionTab) }
    // General questions ("hvad er ÅOP", "skal jeg betale gæld af eller spare op") go to the knowledge base before
    // the personal intents, whose broad keywords (" lån", " betale") would otherwise catch them.
    if (knowledgeAnswer != null && q.hasAny(" hvad er ", " hvad betyder", " forklar", " hvordan fungerer", " hvordan virker", " forskel", " skal jeg ", " bør jeg ", " burde jeg ", " er det klogt", " kan det betale sig", " gode råd", " tips til")) return knowledgeAnswer

    // ---------------------------------------------------------------- how-to questions
    if (q.hasAny(" importer", " import", " csv ", " netbank", " fra banken", " bankforbindelse", " forbind")) return SaldoAnswer(
        "Saldo forbinder ikke direkte til banken, men du kan importere dine posteringer:\n1. Eksportér posteringerne som CSV i din netbank.\n2. Tryk Del og vælg \"Importér i Saldo\" – eller vælg filen under Indstillinger → Importér fra netbank.\n3. Kontrollér forslagene til retning og kategori, og bekræft. Dubletter springes over.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" backup", " sikkerhedskopi", " gendan", " skift telefon", " ny telefon")) return SaldoAnswer(
        "Under Indstillinger kan du eksportere en sikkerhedskopi (JSON) og gemme dine data online på din konto. På en ny telefon logger du ind og vælger \"Hent data fra onlinekonto\" – eller gendanner sikkerhedskopien. Kvitteringsbilleder er kun på telefonen og kommer ikke med.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" pin", " fingeraftryk", " biometri", " lås ", " låse", " adgangskode")) return SaldoAnswer(
        "Under Indstillinger kan du oprette en PIN-kode og derefter slå fingeraftryk til. Appen låser automatisk efter 60 sekunder i baggrunden. \"Fjern app-lås\" slår det fra igen.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" slet konto", " slette min konto", " slette konto", " slet mine data")) return SaldoAnswer(
        "Under Indstillinger → \"Slet onlinekonto og clouddata\" sletter du konto og onlinebackup permanent. Data på telefonen fjernes ved at afinstallere appen.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" widget")) return SaldoAnswer(
        "Saldo har fire widgets: rådighedsbeløb, månedens overblik, kommende regninger og budgetstatus. Tilføj dem under Indstillinger, eller hold fingeren på telefonens startskærm og vælg Widgets → Saldo.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" lønrytme", " ændre løn", " ændre min løn", " løndato", " hver 14", " ugentlig løn", " månedlig løn")) return SaldoAnswer(
        "Under Indstillinger → Løn og lønrytme vælger du Månedlig, Hver 14. dag eller Ugentlig, beløbet pr. udbetaling og næste løndato. Du får nu: ${payFrequencyLabel(ctx.payFrequency).lowercase(danish)} løn på ${format(ctx.payAmount)}.",
        "Åbn Indstillinger", "Indstillinger")
    if (q.hasAny(" fast post", " faste poster", " gentag", " automatisk")) return SaldoAnswer(
        "Opret en post og vælg Månedlig, Kvartalsvis eller Årlig under Gentagelse – så lægger Saldo den ind af sig selv fremover. Du ser og stopper faste poster under Mere → Faste poster.",
        "Se faste poster", "Faste poster")
    if (q.hasAny(" pdf", " eksport", " rapport til")) return SaldoAnswer(
        "Under Mere → Rapporter kan du eksportere CSV, og under Indstillinger kan du lave en PDF-rapport og en sikkerhedskopi.",
        "Åbn Rapporter", "Rapporter")
    if (q.hasAny(" skjul", " privat")) return SaldoAnswer("Tryk på øje-ikonet øverst, så skjules alle beløb på skærmen. Tryk igen for at vise dem.")

    // ---------------------------------------------------------------- "hvor meget brugte jeg på X"
    val spendMatch = Regex(" på (.+)").find(q)
    if (q.hasAny(" brugt", " brugte", " bruger jeg på", " givet", " spenderet", " betalt for") && spendMatch != null) {
        val month = questionMonth(q, ctx.today)
        val term = spendMatch.groupValues[1]
            .replace(Regex(" (i|denne|sidste|forrige) (måned|maaned) .*"), " ")
            .replace(Regex(" i (${monthNames.joinToString("|")}) .*"), " ")
            .replace(Regex(" i år .*"), " ").trim()
        if (term.isNotBlank()) {
            val rows = expensesIn(ctx, month).filter { item -> item.s("category").lowercase(danish).contains(term) || item.s("name").lowercase(danish).contains(term) }
            return if (rows.isEmpty()) SaldoAnswer("Jeg fandt ingen udgifter til \"$term\" i ${monthLabel(month)}.", "Søg i Poster", "Poster")
            else SaldoAnswer("I ${monthLabel(month)} brugte du ${format(rows.sumOf { it.n("amount") })} på \"$term\" fordelt på ${rows.size} ${if (rows.size == 1) "post" else "poster"}.", "Se poster", "Poster")
        }
    }

    // ---------------------------------------------------------------- the user's numbers
    if (q.hasAny(" rådighed", " kan jeg bruge", " pr dag", " per dag", " om dagen", " råd til", " tilbage til", " har jeg tilbage")) {
        val basis = if (ctx.hasBalance) "din registrerede saldo minus regninger før løn" else "månedens poster og regninger før løn – indtast din saldo under Indstillinger for et mere præcist tal"
        return SaldoAnswer(
            "Du har ca. ${format(ctx.available)} til rådighed frem til næste løn om ${ctx.daysToPay} ${if (ctx.daysToPay == 1) "dag" else "dage"}. Det svarer til ${format(ctx.dailyAllowance)} pr. dag.\n(Beregnet ud fra $basis.)",
            "Åbn Overblik", "Overblik")
    }
    if (q.hasAny(" løn ", " lønnen", " udbetaling", " lønningsdag")) {
        val next = ctx.today.plusDays(ctx.daysToPay.toLong())
        val whenText = if (ctx.daysToPay == 0) "i dag" else "om ${ctx.daysToPay} ${if (ctx.daysToPay == 1) "dag" else "dage"} (${saldoDayLabel(next.toString()).lowercase(danish)})"
        return SaldoAnswer("Din næste løn kommer $whenText. Du får ${payFrequencyLabel(ctx.payFrequency).lowercase(danish)} løn på ${format(ctx.payAmount)}.", "Ret lønindstilling", "Indstillinger")
    }
    if (q.hasAny(" regning", " forfald", " betale", " skal betales", " skylder")) {
        val unpaid = ctx.bills.filter { !it.optBoolean("paid", false) }
        val overdue = unpaid.filter { runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.isBefore(ctx.today) == true }
        val upcoming = (unpaid - overdue.toSet()).sortedBy { it.s("date") }.take(3)
        if (unpaid.isEmpty()) return SaldoAnswer("Du har ingen ubetalte regninger lige nu. 🎉".replace(" 🎉", ""), "Se regninger", "Regninger")
        val lines = buildList {
            if (overdue.isNotEmpty()) add("${overdue.size} ${if (overdue.size == 1) "regning er" else "regninger er"} forfalden: ${overdue.joinToString(", ") { "${it.s("name")} (${format(it.n("amount"))})" }}.")
            if (upcoming.isNotEmpty()) add("Næste: " + upcoming.joinToString("; ") { "${it.s("name")} ${format(it.n("amount"))} ${saldoDayLabel(it.s("date")).lowercase(danish)}" } + ".")
            add("I alt ubetalt: ${format(unpaid.sumOf { it.n("amount") })}.")
        }
        return SaldoAnswer(lines.joinToString("\n"), "Se regninger", "Regninger")
    }
    if (q.hasAny(" mest på", " største udgift", " største udgifter", " hvor går pengene", " kategori", " hvad bruger jeg")) {
        val month = questionMonth(q, ctx.today)
        val top = expensesIn(ctx, month).groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }
            .mapValues { e -> e.value.sumOf { it.n("amount") } }.toList().sortedByDescending { it.second }.take(3)
        if (top.isEmpty()) return SaldoAnswer("Der er ingen udgifter registreret i ${monthLabel(month)} endnu.", "Ny post", "Poster")
        val total = expensesIn(ctx, month).sumOf { it.n("amount") }
        return SaldoAnswer("I ${monthLabel(month)} bruger du mest på:\n" + top.mapIndexed { i, (category, amount) -> "${i + 1}. $category – ${format(amount)} (${(amount / total * 100).toInt()} %)" }.joinToString("\n"), "Se rapport", "Rapporter")
    }
    if (q.hasAny(" budget")) {
        val spent = expensesIn(ctx, YearMonth.from(ctx.today)).groupBy { "${it.s("category").trim().lowercase(danish)}|${it.s("owner", "Mig").trim().lowercase(danish)}" }
            .mapValues { e -> e.value.sumOf { it.n("amount") } }
        val status = ctx.budgets.filter { it.n("limit") > 0 }.map { budget ->
            val used = spent["${budget.s("category").trim().lowercase(danish)}|${budget.s("owner", "Mig").trim().lowercase(danish)}"] ?: 0.0
            Triple(budget.s("category"), used, budget.n("limit"))
        }
        if (status.isEmpty()) return SaldoAnswer("Du har ingen budgetter endnu. Tryk ✨ på Budget, så foreslår Saldo budgetter ud fra dit forbrug.".replace("✨ ", ""), "Åbn Budget", "Budget")
        val over = status.filter { it.second > it.third }
        val near = status.filter { it.second <= it.third && it.second >= it.third * .8 }
        val text = buildList {
            add("Du har brugt ${format(status.sumOf { it.second })} af ${format(status.sumOf { it.third })} i dine budgetter denne måned.")
            if (over.isNotEmpty()) add("Overskredet: " + over.joinToString(", ") { "${it.first} (${format(it.second - it.third)} over)" } + ".")
            if (near.isNotEmpty()) add("Tæt på grænsen: " + near.joinToString(", ") { "${it.first} (${format(it.third - it.second)} tilbage)" } + ".")
            if (over.isEmpty() && near.isEmpty()) add("Alle budgetter er inden for grænsen.")
        }
        return SaldoAnswer(text.joinToString("\n"), "Åbn Budget", "Budget")
    }
    if (q.hasAny(" spare", " sparer", " billigere", " skære ned", " tips", " råd ")) {
        val month = YearMonth.from(ctx.today)
        val lastMonth = month.minusMonths(1)
        val base = expensesIn(ctx, month).ifEmpty { expensesIn(ctx, lastMonth) }
        val top = base.groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }.mapValues { e -> e.value.sumOf { it.n("amount") } }.maxByOrNull { it.value }
        val subsMonthly = ctx.subscriptions.filter { it.optBoolean("active", true) }.sumOf { it.n("monthly") }
        val tips = buildList {
            top?.let { add("Din største post er ${it.key} med ${format(it.value)}. Sæt et budget lidt under det beløb – fx ${format(kotlin.math.floor(it.value * .9 / 100) * 100)}.") }
            if (subsMonthly > 0) add("Abonnementer koster dig ${format(subsMonthly)} om måneden (${format(subsMonthly * 12)} om året). Gennemgå dem under Mere → Abonnementer – abonnementsradaren finder også dem, du har glemt.")
            if (ctx.debts.isNotEmpty()) add("Betal den dyreste gæld først. Gældfri-planen under Mere → Gæld viser, hvor meget et ekstra afdrag sparer i renter.")
            add("Brug faste poster til løn og husleje, så ser du hurtigt, hvad der reelt er tilbage.")
        }
        return SaldoAnswer(tips.joinToString("\n• ", prefix = "• "), "Åbn Budget", "Budget")
    }
    if (q.hasAny(" opspar", " sparemål", " mål ")) {
        if (ctx.goals.isEmpty()) return SaldoAnswer("Du har ingen opsparingsmål endnu. Opret et under Mere → Opsparing, så viser Saldo hvor meget du skal spare pr. måned.", "Åbn Opsparing", "Opsparing")
        return SaldoAnswer(ctx.goals.joinToString("\n") { goal ->
            val target = goal.n("target"); val saved = goal.n("saved")
            "${goal.s("name")}: ${format(saved)} af ${format(target)} (${if (target > 0) (saved / target * 100).toInt() else 0} %)"
        }, "Åbn Opsparing", "Opsparing")
    }
    if (q.hasAny(" abonnement", " streaming")) {
        val active = ctx.subscriptions.filter { it.optBoolean("active", true) }
        if (active.isEmpty()) return SaldoAnswer("Du har ingen abonnementer registreret. Abonnementsradaren under Mere → Abonnementer kan finde faste betalinger i dine poster.", "Åbn Abonnementer", "Abonnementer")
        return SaldoAnswer("Du har ${active.size} abonnementer for ${format(active.sumOf { it.n("monthly") })} om måneden – ${format(active.sumOf { it.n("monthly") } * 12)} om året. Dyreste: ${active.maxBy { it.n("monthly") }.s("name")}.", "Åbn Abonnementer", "Abonnementer")
    }
    if (q.hasAny(" gæld", " lån", " gældfri")) {
        if (ctx.debts.isEmpty()) return SaldoAnswer("Du har ingen gæld registreret.", "Åbn Gæld", "Gæld")
        val plan = simulateDebtPlan(ctx.debts, 0.0, avalanche = true)
        val freeText = plan.months?.let { months -> "Med dine nuværende afdrag er du gældfri i ${monthLabel(YearMonth.from(ctx.today).plusMonths(months.toLong()))}." } ?: "Afdragene dækker ikke renterne – hæv afdraget for at blive gældfri."
        return SaldoAnswer("Din samlede restgæld er ${format(ctx.debts.sumOf { it.n("balance") })}. $freeText", "Se gældfri-plan", "Gæld")
    }
    if (q.hasAny(" sidste måned", " sammenlign", " mere end", " mindre end")) {
        val month = YearMonth.from(ctx.today)
        val now = expensesIn(ctx, month).filter { runCatching { LocalDate.parse(it.s("date")).dayOfMonth <= ctx.today.dayOfMonth }.getOrDefault(false) }.sumOf { it.n("amount") }
        val before = expensesIn(ctx, month.minusMonths(1)).filter { runCatching { LocalDate.parse(it.s("date")).dayOfMonth <= ctx.today.dayOfMonth }.getOrDefault(false) }.sumOf { it.n("amount") }
        if (before <= 0.0) return SaldoAnswer("Der er ingen udgifter i ${monthLabel(month.minusMonths(1))} at sammenligne med.")
        val change = ((now - before) / before * 100).toInt()
        return SaldoAnswer("Indtil den ${ctx.today.dayOfMonth}. har du brugt ${format(now)} mod ${format(before)} på samme tid i ${monthLabel(month.minusMonths(1))} – ${if (change <= 0) "${-change} % mindre" else "$change % mere"}.", "Se rapport", "Rapporter")
    }
    if (q.hasAny(" hej ", " hejsa", " goddag", " hvad kan du", " hjælp ")) return SaldoAnswer(
        "Hej! Jeg kan svare på spørgsmål om din økonomi i Saldo – fx hvad du har til rådighed, hvornår du får løn, hvilke regninger der skal betales, hvad du bruger mest på og hvordan du kan spare. Jeg kan også forklare, hvordan appen virker.")
    if (knowledgeAnswer != null) return knowledgeAnswer
    return SaldoAnswer("Det spørgsmål kan jeg desværre ikke svare på. Jeg kan svare på din egen økonomi (fx \"Hvad kan jeg bruge i dag?\" eller \"Hvad brugte jeg på mad i oktober?\"), på hvordan Saldo bruges, og på emner som ÅOP, renter, gæld, opsparing, budget, boligkøb, investering, pension, skat, fradrag, SU, dagpenge, forsikringer og svindel. Prøv at spørge med et af de ord.")
}

/** Full-screen chat for "Spørg Saldo". */
@Composable
internal fun SaldoAssistantScreen(context: SaldoAssistantContext, onClose: () -> Unit, onNavigate: (String) -> Unit) {
    val messages = remember { mutableStateListOf<Pair<Boolean, SaldoAnswer>>(false to SaldoAnswer("Hej! Spørg mig om din økonomi eller om emner som gæld, opsparing, skat, pension og boligkøb – eller vælg et forslag nedenfor. Jeg svarer ud fra dine egne tal i Saldo, og intet sendes ud af telefonen.")) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    fun ask(text: String) {
        val question = text.trim()
        if (question.isBlank()) return
        messages += true to SaldoAnswer(question)
        messages += false to answerSaldoQuestion(question, context)
        input = ""
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Night).statusBarsPadding().navigationBarsPadding().imePadding(), contentAlignment = Alignment.TopCenter) {
            Column(Modifier.fillMaxSize().widthIn(max = 720.dp).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Luk", tint = White) }
                    SaldoIconTile(Icons.Default.AutoAwesome, Violet, size = 36.dp, iconSize = 18.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Spørg Saldo", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, letterSpacing = (-.5).sp)
                        Text("Svarer ud fra dine data · kører på telefonen", color = Muted, fontSize = 11.sp)
                    }
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(messages) { _, (fromUser, answer) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (fromUser) Violet else Panel,
                                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (fromUser) 18.dp else 4.dp, bottomEnd = if (fromUser) 4.dp else 18.dp),
                                border = if (fromUser) null else saldoCardBorder(),
                                modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth(if (fromUser) .82f else .92f)
                            ) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(answer.text, color = if (fromUser) androidx.compose.ui.graphics.Color.White else White, fontSize = 14.sp, lineHeight = 20.sp)
                                    if (!fromUser && answer.actionTab != null && answer.actionLabel != null) {
                                        TextButton(onClick = { onNavigate(answer.actionTab) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                                            Text(answer.actionLabel + " →", color = Violet, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    saldoAssistantSuggestions.forEach { suggestion -> SuggestionChip(onClick = { ask(suggestion) }, label = { Text(suggestion, maxLines = 1) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Skriv et spørgsmål …") }, maxLines = 3,
                        shape = RoundedCornerShape(18.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { ask(input) }),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = BorderSubtle)
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = { ask(input) }, enabled = input.isNotBlank()) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = if (input.isNotBlank()) Violet else Muted, modifier = Modifier.size(24.dp))
                    }
                }
                Text("Svarene er vejledende og bygger på det, du har registreret i Saldo.", color = Muted, fontSize = 10.sp)
            }
        }
    }
}
