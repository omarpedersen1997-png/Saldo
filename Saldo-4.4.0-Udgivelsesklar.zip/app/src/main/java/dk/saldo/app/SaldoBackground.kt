package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// Daily background work: bill/subscription/budget reminders, cash-flow warnings and the weekly summary.

class BillReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return runCatching {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
            val prefs = saldoPreferences(applicationContext)
            val data = JSONObject(prefs.getString("data", "{}") ?: "{}")
            val bills = (data.optJSONArray("bills") ?: JSONArray()).objects()
            val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
            if (due.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = due.take(5).joinToString("\n") { "${it.s("name")}: ${moneyPlain(it.n("amount"))} · ${it.s("date")}" }
                val n = NotificationCompat.Builder(applicationContext, "saldo_bills").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(351, n)
            }
            val subscriptions = (data.optJSONArray("subs") ?: JSONArray()).objects()
            val todayForRenewal = LocalDate.now()
            val renewals = subscriptions.filter { sub ->
                val renewal = runCatching { LocalDate.parse(sub.s("renewalDate")) }.getOrNull()
                val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
                listOfNotNull(renewal, cancelBy).any { !it.isBefore(todayForRenewal) && !it.isAfter(todayForRenewal.plusDays(7)) } && sub.optBoolean("active", true)
            }
            if (renewals.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_subscriptions", "Abonnementer og fornyelser", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = renewals.take(5).joinToString("\n") { sub ->
                    val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
                    val actionDate = if (cancelBy != null && !cancelBy.isBefore(todayForRenewal) && !cancelBy.isAfter(todayForRenewal.plusDays(7))) "Opsig senest ${sub.s("cancelByDate")}" else "Fornyes ${sub.s("renewalDate")}" 
                    "${sub.s("name")}: $actionDate · ${moneyPlain(sub.n("monthly"))}/md."
                }
                val n = NotificationCompat.Builder(applicationContext, "saldo_subscriptions").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: abonnement fornyes snart").setContentText("${renewals.size} abonnement(er) fornyes inden for 7 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(353, n)
            }
            val budgets = (data.optJSONArray("budgets") ?: JSONArray()).objects()
            val transactions = (data.optJSONArray("transactions") ?: JSONArray()).objects()
            val now = LocalDate.now()
            val critical = budgets.mapNotNull { budget ->
                val limit = budget.n("limit")
                if (limit <= 0) return@mapNotNull null
                val spent = transactions.filter { tx -> tx.s("type") == "Udgift" && tx.s("category").equals(budget.s("category"), true) && tx.s("owner", "Mig").equals(budget.s("owner", "Mig"), true) && runCatching { LocalDate.parse(tx.s("date")) }.getOrNull()?.let { it.year == now.year && it.month == now.month } == true }.sumOf { it.n("amount") }
                if (spent >= limit * .8) "${budget.s("category")}: ${moneyPlain(spent)} af ${moneyPlain(limit)}${if (spent >= limit) " (overskredet)" else " (over 80 %)"}" else null
            }
            if (critical.isNotEmpty()) {
                val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_budgets", "Budgetadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
                val detail = critical.take(5).joinToString("\n")
                val n = NotificationCompat.Builder(applicationContext, "saldo_budgets").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: tjek dine budgetter").setContentText("${critical.size} budget(ter) nærmer sig eller har overskredet grænsen").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                NotificationManagerCompat.from(applicationContext).notify(352, n)
            }
            if (prefs.contains("cash_balance")) {
                val configuredPayday = runCatching { LocalDate.parse(prefs.getString("payday", now.toString())) }.getOrElse { now }
                val untilPayday = ChronoUnit.DAYS.between(now, configuredPayday).toInt().let { ((it % 14) + 14) % 14 }.let { if (it == 0) 14 else it }
                val periodEnd = now.plusDays(untilPayday.toLong())
                val nextBills = bills.filter { bill ->
                    !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { d -> !d.isBefore(now) && !d.isAfter(periodEnd) } == true
                }.sumOf { it.n("amount") }
                val daily = (prefs.saldoMoney("cash_balance", 0.0) - nextBills) / untilPayday.coerceAtLeast(1)
                if (daily < 150.0) {
                    val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_cashflow", "Rådighedsadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
                    val detail = "Efter registrerede regninger: ${moneyPlain(prefs.saldoMoney("cash_balance", 0.0) - nextBills)} tilbage. Vejledende ${moneyPlain(daily)} pr. dag frem til næste løn. Kontrollér, at saldo og regninger er opdateret."
                    val n = NotificationCompat.Builder(applicationContext, "saldo_cashflow").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle(if (daily < 0) "Saldo: regninger overstiger registreret saldo" else "Saldo: lavt rådighedsbeløb frem til løn").setContentText(detail).setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                    NotificationManagerCompat.from(applicationContext).notify(354, n)
                }
            }
            // Weekly summary every Monday (once per ISO week), unless switched off in Settings.
            val nowDate = LocalDate.now()
            val weekKey = "${nowDate.get(java.time.temporal.IsoFields.WEEK_BASED_YEAR)}-${nowDate.get(java.time.temporal.IsoFields.WEEK_OF_WEEK_BASED_YEAR)}"
            if (prefs.getBoolean("weekly_summary_enabled", true) && nowDate.dayOfWeek == java.time.DayOfWeek.MONDAY && prefs.getString("weekly_summary_sent", "") != weekKey) {
                val lastWeek = (data.optJSONArray("transactions") ?: JSONArray()).objects().filter { item ->
                    runCatching { LocalDate.parse(item.s("date")) }.getOrNull()?.let { d -> !d.isBefore(nowDate.minusDays(7)) && d.isBefore(nowDate) } == true
                }
                if (lastWeek.isNotEmpty()) {
                    val spent = lastWeek.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
                    val earned = lastWeek.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
                    val top = lastWeek.filter { it.s("type") == "Udgift" }.groupBy { it.s("category", "Diverse").ifBlank { "Diverse" } }
                        .mapValues { e -> e.value.sumOf { it.n("amount") } }.maxByOrNull { it.value }
                    val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("saldo_weekly", "Ugentlig opsummering", NotificationManager.IMPORTANCE_LOW))
                    val detail = "Brugt ${moneyPlain(spent)} · ind ${moneyPlain(earned)} de seneste 7 dage." + (top?.let { "\nStørste udgift: ${it.key} (${moneyPlain(it.value)})." } ?: "")
                    val n = NotificationCompat.Builder(applicationContext, "saldo_weekly").setSmallIcon(R.drawable.ic_saldo_notification)
                        .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Din uge i Saldo").setContentText("Brugt ${moneyPlain(spent)} de seneste 7 dage")
                        .setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
                    NotificationManagerCompat.from(applicationContext).notify(355, n)
                }
                prefs.edit().putString("weekly_summary_sent", weekKey).apply()
            }
        }.fold({ Result.success() }, { Result.retry() })
    }
}

internal fun scheduleDueBillNotification(context: Context, bills: List<JSONObject>) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Tillad notifikationer i Android-indstillinger for at modtage påmindelser.", Toast.LENGTH_LONG).show(); return
    }
    val due = bills.filter { !it.optBoolean("paid", false) && runCatching { LocalDate.parse(it.s("date")) }.getOrNull()?.let { d -> !d.isBefore(LocalDate.now()) && !d.isAfter(LocalDate.now().plusDays(3)) } == true }
    if (due.isEmpty()) { Toast.makeText(context, "Ingen ubetalte regninger med forfald inden for 3 dage.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_bills", "Regningspåmindelser", NotificationManager.IMPORTANCE_DEFAULT))
    val details = due.take(4).joinToString("\n") { "${it.s("name")}: ${moneyPlain(it.n("amount"))} · ${it.s("date")}" }
    val notification = NotificationCompat.Builder(context, "saldo_bills").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: kommende regninger").setContentText("${due.size} regning(er) forfalder inden for 3 dage").setStyle(NotificationCompat.BigTextStyle().bigText(details)).setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(351, notification)
    Toast.makeText(context, "Påmindelse sendt for ${due.size} regning(er). Dette er en manuel kontrol, ikke en daglig baggrundsalarm.", Toast.LENGTH_LONG).show()
}

internal fun scheduleSubscriptionRenewalNotification(context: Context, data: JSONObject) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    val today = LocalDate.now()
    val renewals = (data.optJSONArray("subs") ?: JSONArray()).objects().filter { sub ->
        val renewal = runCatching { LocalDate.parse(sub.s("renewalDate")) }.getOrNull()
        val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
        val relevantDates = listOfNotNull(renewal, cancelBy)
        sub.optBoolean("active", true) && relevantDates.any { !it.isBefore(today) && !it.isAfter(today.plusDays(7)) }
    }
    if (renewals.isEmpty()) { Toast.makeText(context, "Ingen registrerede abonnementsfornyelser inden for 7 dage.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_subscriptions", "Abonnementer og fornyelser", NotificationManager.IMPORTANCE_DEFAULT))
    val detail = renewals.take(5).joinToString("\n") { sub ->
        val cancelBy = runCatching { LocalDate.parse(sub.s("cancelByDate")) }.getOrNull()
        val actionDate = if (cancelBy != null && !cancelBy.isBefore(today) && !cancelBy.isAfter(today.plusDays(7))) "Opsig senest ${sub.s("cancelByDate")}" else "Fornyes ${sub.s("renewalDate")}" 
        "${sub.s("name")}: $actionDate · ${moneyPlain(sub.n("monthly"))}/md."
    }
    val notification = NotificationCompat.Builder(context, "saldo_subscriptions").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: abonnement fornyes snart").setContentText("${renewals.size} abonnement(er) fornyes inden for 7 dage").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(353, notification)
    Toast.makeText(context, "Påmindelse sendt for ${renewals.size} abonnement(er).", Toast.LENGTH_LONG).show()
}

internal fun scheduleBudgetWarningNotification(context: Context, data: JSONObject) {
    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Tillad notifikationer i Android-indstillinger for at modtage budgetadvarsler.", Toast.LENGTH_LONG).show(); return
    }
    val now = LocalDate.now()
    val transactions = (data.optJSONArray("transactions") ?: JSONArray()).objects()
    val budgets = (data.optJSONArray("budgets") ?: JSONArray()).objects()
    val critical = budgets.mapNotNull { budget ->
        val limit = budget.n("limit")
        if (limit <= 0) return@mapNotNull null
        val spent = transactions.filter { tx -> tx.s("type") == "Udgift" && tx.s("category").equals(budget.s("category"), true) && tx.s("owner", "Mig").equals(budget.s("owner", "Mig"), true) && runCatching { LocalDate.parse(tx.s("date")) }.getOrNull()?.let { it.year == now.year && it.month == now.month } == true }.sumOf { it.n("amount") }
        if (spent >= limit * .8) "${budget.s("category")}: ${moneyPlain(spent)} af ${moneyPlain(limit)}${if (spent >= limit) " (overskredet)" else " (over 80 %)"}" else null
    }
    if (critical.isEmpty()) { Toast.makeText(context, "Ingen budgetter over 80 % af grænsen.", Toast.LENGTH_LONG).show(); return }
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("saldo_budgets", "Budgetadvarsler", NotificationManager.IMPORTANCE_DEFAULT))
    val detail = critical.take(5).joinToString("\n")
    val notification = NotificationCompat.Builder(context, "saldo_budgets").setSmallIcon(R.drawable.ic_saldo_notification).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentTitle("Saldo: tjek dine budgetter").setContentText("${critical.size} budget(ter) nærmer sig eller har overskredet grænsen").setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
    NotificationManagerCompat.from(context).notify(352, notification)
    Toast.makeText(context, "Budgetadvarsel sendt for ${critical.size} kategori(er).", Toast.LENGTH_LONG).show()
}
