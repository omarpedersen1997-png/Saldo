package dk.saldo.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.util.Locale

/** The "Bil" screen: fuel economy as one stat list, then the fuel log. */
@Composable
internal fun CarScreen(fuel: List<JSONObject>, onAddFuel: () -> Unit, fuelRow: @Composable (JSONObject) -> Unit) {
    val sortedFuel = remember(fuel) { fuel.sortedBy { it.n("km") } }
    val totalLiters = fuel.sumOf { it.n("liters") }
    val totalCost = fuel.sumOf { it.n("cost") }
    val kmSpan = if (sortedFuel.size >= 2) sortedFuel.last().n("km") - sortedFuel.first().n("km") else 0.0
    val consumption = if (kmSpan > 0) (totalLiters - sortedFuel.first().n("liters")) * 100 / kmSpan else 0.0
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
        item { SaldoSectionHeader("Brændstof") }
        item {
            SaldoStatList(listOf(
                Triple("Samlet brændstof", String.format(Locale("da", "DK"), "%.1f liter", totalLiters), White),
                Triple("Samlet pris", money(totalCost), White),
                Triple("Gennemsnit", if (consumption > 0) String.format(Locale("da", "DK"), "%.1f l/100 km", consumption) else "Mindst 2 tankninger", if (consumption > 0) White else Muted)
            ))
        }
        item { SaldoSectionHeader("Tankninger", actionLabel = "Tilføj", onAction = onAddFuel) }
        if (fuel.isEmpty()) item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Icon(Icons.Default.LocalGasStation, null, tint = Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Registrér km-stand ved hver tankning, så beregner Saldo dit forbrug.", color = Muted, fontSize = 13.sp)
            }
        }
        items(sortedFuel.reversed(), key = { "fuel-${it.s("id")}" }) { fuelRow(it) }
    }
}
