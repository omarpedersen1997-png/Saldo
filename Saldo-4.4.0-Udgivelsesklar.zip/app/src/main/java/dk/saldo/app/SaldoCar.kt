package dk.saldo.app

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.UUID

// ---------------------------------------------------------------------------------------------
// Servicetjek og syn: data is one small JSON object in the preferences ("car_maintenance"):
// { nextSyn, lastServiceDate, lastServiceKm, serviceMonths, serviceKm, odometer, history: [...] }
// ---------------------------------------------------------------------------------------------

internal const val CAR_MAINTENANCE_KEY = "car_maintenance"
internal const val CAR_DEFAULT_SERVICE_MONTHS = 12
internal const val CAR_DEFAULT_SERVICE_KM = 15000.0
/** In Denmark a car is inspected after 4 years and then every 2 years. */
internal const val CAR_SYN_INTERVAL_YEARS = 2L

internal data class CarCheckStatus(
    val kind: String,          // "service" or "syn"
    val dueDate: LocalDate?,
    val daysLeft: Long?,
    val kmLeft: Double?,
    val overdue: Boolean,
    val soon: Boolean,
    val headline: String,      // e.g. "Om 42 dage", "Overskredet"
    val detail: String
)

internal fun parseCarMaintenance(raw: String?): JSONObject =
    runCatching { JSONObject(raw ?: "{}") }.getOrDefault(JSONObject())

private fun JSONObject.dateOrNull(key: String): LocalDate? =
    optString(key, "").takeIf { it.isNotBlank() }?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

private fun JSONObject.positiveOrNull(key: String): Double? =
    optDouble(key, Double.NaN).takeIf { it.isFinite() && it > 0.0 }

private val carDateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("d. MMMM yyyy", Locale("da", "DK"))
internal fun carDate(date: LocalDate): String = date.format(carDateFormat)

private fun carKm(km: Double): String = String.format(Locale("da", "DK"), "%,.0f km", km).replace(',', '.')

/** Best known odometer reading: the highest of fuel log, last service and a manually entered reading. */
internal fun carCurrentKm(maintenance: JSONObject, fuel: List<JSONObject>): Double? =
    (fuel.mapNotNull { it.optDouble("km", Double.NaN).takeIf { km -> km.isFinite() && km > 0 } } +
        listOfNotNull(maintenance.positiveOrNull("odometer"), maintenance.positiveOrNull("lastServiceKm"))).maxOrNull()

private fun daysText(days: Long): String = when {
    days < -1 -> "${-days} dage over"
    days == -1L -> "1 dag over"
    days == 0L -> "I dag"
    days == 1L -> "I morgen"
    else -> "Om $days dage"
}

/** Service is due at whichever comes first: the time interval or the kilometre interval. */
internal fun carServiceStatus(maintenance: JSONObject, currentKm: Double?, today: LocalDate = LocalDate.now()): CarCheckStatus? {
    val lastDate = maintenance.dateOrNull("lastServiceDate") ?: return null
    val months = maintenance.optInt("serviceMonths", CAR_DEFAULT_SERVICE_MONTHS).coerceIn(1, 60)
    val intervalKm = maintenance.positiveOrNull("serviceKm") ?: CAR_DEFAULT_SERVICE_KM
    val dueDate = lastDate.plusMonths(months.toLong())
    val daysLeft = ChronoUnit.DAYS.between(today, dueDate)
    val lastKm = maintenance.positiveOrNull("lastServiceKm")
    val kmLeft = if (lastKm != null && currentKm != null) lastKm + intervalKm - currentKm else null
    val overdue = daysLeft < 0 || (kmLeft != null && kmLeft < 0)
    val soon = !overdue && (daysLeft <= 30 || (kmLeft != null && kmLeft <= 1000))
    val kmIsCloser = kmLeft != null && (kmLeft < 0 || (daysLeft > 0 && kmLeft / intervalKm < daysLeft.toDouble() / (months * 30.4)))
    val headline = when {
        kmLeft != null && kmLeft < 0 -> "${carKm(-kmLeft)} over"
        daysLeft < 0 -> daysText(daysLeft)
        kmIsCloser && kmLeft != null -> "Om ${carKm(kmLeft)}"
        else -> daysText(daysLeft)
    }
    val atKm = lastKm?.let { " eller ved ${carKm(it + intervalKm)}" }.orEmpty()
    return CarCheckStatus("service", dueDate, daysLeft, kmLeft, overdue, soon, headline, "Senest ${carDate(dueDate)}$atKm")
}

internal fun carSynStatus(maintenance: JSONObject, today: LocalDate = LocalDate.now()): CarCheckStatus? {
    val due = maintenance.dateOrNull("nextSyn") ?: return null
    val daysLeft = ChronoUnit.DAYS.between(today, due)
    val overdue = daysLeft < 0
    // Syn can be booked up to 2 months before the deadline, so warn a month ahead.
    val soon = !overdue && daysLeft <= 30
    return CarCheckStatus("syn", due, daysLeft, null, overdue, soon, daysText(daysLeft), "Senest ${carDate(due)}")
}

/** Records a finished service or syn: moves the next due date and appends to the history. */
internal fun carRecordDone(maintenance: JSONObject, kind: String, date: LocalDate, km: Double?, cost: Double?): JSONObject {
    val updated = JSONObject(maintenance.toString())
    when (kind) {
        "service" -> {
            updated.put("lastServiceDate", date.toString())
            if (km != null && km > 0) updated.put("lastServiceKm", km)
        }
        "syn" -> updated.put("nextSyn", date.plusYears(CAR_SYN_INTERVAL_YEARS).toString())
    }
    if (km != null && km > (updated.positiveOrNull("odometer") ?: 0.0)) updated.put("odometer", km)
    val history = updated.optJSONArray("history") ?: JSONArray()
    history.put(JSONObject().put("id", UUID.randomUUID().toString()).put("kind", kind).put("date", date.toString()).apply {
        if (km != null && km > 0) put("km", km)
        if (cost != null && cost > 0) put("cost", cost)
    })
    updated.put("history", history)
    return updated
}

/** A short line for notifications and the Overblik chip, or null when nothing needs attention. */
internal fun carAttentionText(status: CarCheckStatus?): String? {
    if (status == null || !(status.overdue || status.soon)) return null
    val name = if (status.kind == "syn") "Syn" else "Service"
    return if (status.overdue) "$name er overskredet (${status.headline.lowercase(Locale("da", "DK"))})"
    else "$name: ${status.headline.lowercase(Locale("da", "DK"))}"
}

// ------------------------------------------- UI --------------------------------------------

@Composable
private fun CarCheckCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, status: CarCheckStatus?, emptyText: String, onSetup: () -> Unit, onDone: () -> Unit) {
    val accent = when {
        status == null -> Muted
        status.overdue -> SaldoDanger
        status.soon -> SaldoWarning
        else -> Mint
    }
    SaldoCard(Modifier.fillMaxWidth(), onClick = onSetup, contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(icon, accent = if (status == null) Violet else accent)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text(status?.detail ?: emptyText, color = Muted, fontSize = 12.sp, maxLines = 2)
            }
        }
        if (status != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(8.dp))
                Text(status.headline, color = if (status.overdue || status.soon) accent else White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.6).sp, modifier = Modifier.weight(1f))
                Surface(onClick = onDone, color = Violet, shape = RoundedCornerShape(50)) {
                    Text("Udført", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
        } else {
            Text("Tryk for at sætte op", color = Violet, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** The whole "Bil" screen: service and syn first, then fuel economy and the fuel log. */
@Composable
internal fun CarScreen(
    fuel: List<JSONObject>,
    maintenance: JSONObject,
    onSaveMaintenance: (JSONObject) -> Unit,
    onAddExpense: (name: String, amount: Double, date: LocalDate) -> Unit,
    onAddFuel: () -> Unit,
    fuelRow: @Composable (JSONObject) -> Unit
) {
    var dialog by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now()
    val sortedFuel = remember(fuel) { fuel.sortedBy { it.n("km") } }
    val currentKm = carCurrentKm(maintenance, fuel)
    val service = carServiceStatus(maintenance, currentKm, today)
    val syn = carSynStatus(maintenance, today)
    val totalLiters = fuel.sumOf { it.n("liters") }
    val totalCost = fuel.sumOf { it.n("cost") }
    val kmSpan = if (sortedFuel.size >= 2) sortedFuel.last().n("km") - sortedFuel.first().n("km") else 0.0
    val consumption = if (kmSpan > 0) (totalLiters - sortedFuel.first().n("liters")) * 100 / kmSpan else 0.0
    val history = remember(maintenance.toString()) { (maintenance.optJSONArray("history") ?: JSONArray()).objects().sortedByDescending { it.s("date") } }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
        item { SaldoSectionHeader("Servicetjek og syn") }
        item { CarCheckCard("Servicetjek", Icons.Default.Build, service, "Angiv seneste service, så husker Saldo den næste.", { dialog = "setup-service" }, { dialog = "done-service" }) }
        item { CarCheckCard("Syn", Icons.Default.Verified, syn, "Angiv datoen for næste syn. Nye biler skal til syn efter 4 år, derefter hvert 2. år.", { dialog = "setup-syn" }, { dialog = "done-syn" }) }
        if (currentKm != null) item { Text("Kilometerstand: ${carKm(currentKm)} (fra tankninger og service)", color = Muted, fontSize = 12.sp) }
        item { Spacer(Modifier.size(4.dp)); SaldoSectionHeader("Brændstof") }
        item {
            SaldoStatList(listOf(
                Triple("Samlet brændstof", String.format(Locale("da", "DK"), "%.1f liter", totalLiters), White),
                Triple("Samlet pris", money(totalCost), White),
                Triple("Gennemsnit", if (consumption > 0) String.format(Locale("da", "DK"), "%.1f l/100 km", consumption) else "Mindst 2 tankninger", if (consumption > 0) White else Muted)
            ))
        }
        item { SaldoSectionHeader("Tankninger", actionLabel = "Tilføj", onAction = onAddFuel) }
        if (fuel.isEmpty()) item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Icon(Icons.Default.LocalGasStation, null, tint = Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Registrér km-stand ved hver tankning, så beregner Saldo dit forbrug.", color = Muted, fontSize = 13.sp)
            }
        }
        items(sortedFuel.reversed(), key = { "fuel-${it.s("id")}" }) { fuelRow(it) }
        if (history.isNotEmpty()) {
            item { Spacer(Modifier.size(4.dp)); SaldoSectionHeader("Historik") }
            items(history, key = { "car-history-${it.s("id")}" }) { entry ->
                Column {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (entry.s("kind") == "syn") "Syn" else "Service", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(listOfNotNull(runCatching { carDate(LocalDate.parse(entry.s("date"))) }.getOrNull(), entry.optDouble("km", Double.NaN).takeIf { it.isFinite() }?.let(::carKm)).joinToString(" · "), color = Muted, fontSize = 12.sp)
                        }
                        entry.optDouble("cost", Double.NaN).takeIf { it.isFinite() }?.let { Text(money(it), color = White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                    HorizontalDivider(color = BorderSubtle)
                }
            }
        }
    }

    when (dialog) {
        "setup-service" -> CarServiceSetupDialog(maintenance, onDismiss = { dialog = null }) { onSaveMaintenance(it); dialog = null }
        "setup-syn" -> CarSynSetupDialog(maintenance, onDismiss = { dialog = null }) { onSaveMaintenance(it); dialog = null }
        "done-service", "done-syn" -> {
            val kind = dialog!!.removePrefix("done-")
            CarDoneDialog(kind, currentKm, onDismiss = { dialog = null }) { date, km, cost ->
                onSaveMaintenance(carRecordDone(maintenance, kind, date, km, cost))
                if (cost != null && cost > 0) onAddExpense(if (kind == "syn") "Syn" else "Bilservice", cost, date)
                dialog = null
            }
        }
    }
}

@Composable
private fun CarDialog(title: String, onDismiss: () -> Unit, onSave: () -> Unit, content: @Composable () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(title, color = White, fontWeight = FontWeight.ExtraBold) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() } },
        confirmButton = { TextButton(onClick = onSave) { Text("Gem", color = Violet, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } }
    )
}

@Composable
private fun CarServiceSetupDialog(maintenance: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    val context = LocalContext.current
    var lastDate by remember { mutableStateOf(maintenance.optString("lastServiceDate", "").ifBlank { LocalDate.now().toString() }) }
    var lastKm by remember { mutableStateOf(maintenance.positiveOrNull("lastServiceKm")?.let(::saldoInputNumber).orEmpty()) }
    var months by remember { mutableStateOf(maintenance.optInt("serviceMonths", CAR_DEFAULT_SERVICE_MONTHS).toString()) }
    var intervalKm by remember { mutableStateOf(saldoInputNumber(maintenance.positiveOrNull("serviceKm") ?: CAR_DEFAULT_SERVICE_KM)) }
    CarDialog("Servicetjek", onDismiss, onSave = {
        val m = months.trim().toIntOrNull()
        val km = if (lastKm.isBlank()) null else parseDanishAmount(lastKm)
        val interval = parseDanishAmount(intervalKm)
        if (m == null || m !in 1..60 || interval == null || interval <= 0 || (lastKm.isNotBlank() && (km == null || km < 0))) {
            Toast.makeText(context, "Tjek interval (1–60 måneder), km-interval og kilometerstand.", Toast.LENGTH_LONG).show()
        } else {
            val updated = JSONObject(maintenance.toString()).put("lastServiceDate", lastDate).put("serviceMonths", m).put("serviceKm", interval)
            if (km != null && km > 0) updated.put("lastServiceKm", km) else updated.remove("lastServiceKm")
            onSave(updated)
        }
    }) {
        Text("Bilen skal til service, når enten tiden eller kilometerne er gået – det der kommer først. Intervallet står i bilens servicebog.", color = Muted, fontSize = 12.sp)
        SaldoDateField("Seneste service", lastDate) { lastDate = it }
        Field("Km-stand ved seneste service (valgfri)", lastKm, { lastKm = it }, true)
        Field("Interval i måneder", months, { months = it }, true)
        Field("Interval i km", intervalKm, { intervalKm = it }, true)
    }
}

@Composable
private fun CarSynSetupDialog(maintenance: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    var next by remember { mutableStateOf(maintenance.optString("nextSyn", "").ifBlank { LocalDate.now().plusMonths(6).toString() }) }
    CarDialog("Næste syn", onDismiss, onSave = { onSave(JSONObject(maintenance.toString()).put("nextSyn", next)) }) {
        Text("Datoen står på din seneste synsrapport eller på Motorstyrelsens side \"Hvornår skal min bil til syn?\". Nye biler skal til syn efter 4 år og derefter hvert 2. år.", color = Muted, fontSize = 12.sp)
        SaldoDateField("Senest dato for næste syn", next) { next = it }
    }
}

@Composable
private fun CarDoneDialog(kind: String, currentKm: Double?, onDismiss: () -> Unit, onSave: (LocalDate, Double?, Double?) -> Unit) {
    val context = LocalContext.current
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var km by remember { mutableStateOf(currentKm?.let(::saldoInputNumber).orEmpty()) }
    var cost by remember { mutableStateOf("") }
    CarDialog(if (kind == "syn") "Syn udført" else "Service udført", onDismiss, onSave = {
        val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull()
        val parsedKm = if (km.isBlank()) null else parseDanishAmount(km)
        val parsedCost = if (cost.isBlank()) null else parseDanishAmount(cost)
        if (parsedDate == null || (km.isNotBlank() && (parsedKm == null || parsedKm < 0)) || (cost.isNotBlank() && (parsedCost == null || parsedCost < 0))) {
            Toast.makeText(context, "Tjek dato, kilometerstand og pris.", Toast.LENGTH_LONG).show()
        } else onSave(parsedDate, parsedKm, parsedCost)
    }) {
        Text(
            if (kind == "syn") "Næste syn sættes automatisk 2 år frem. Udfyldes prisen, gemmes den også som en udgift under Bil."
            else "Næste service regnes fra denne dato og km-stand. Udfyldes prisen, gemmes den også som en udgift under Bil.",
            color = Muted, fontSize = 12.sp
        )
        SaldoDateField("Dato", date) { date = it }
        Field("Kilometerstand (valgfri)", km, { km = it }, true)
        Field("Pris (valgfri)", cost, { cost = it }, true)
    }
}
