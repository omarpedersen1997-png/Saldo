package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// Supabase authentication, session refresh, online backup/restore and account deletion.

internal fun openSaldoExternalPage(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        .onFailure { Toast.makeText(context, "Siden kunne ikke åbnes. Kontrollér internetforbindelsen.", Toast.LENGTH_LONG).show() }
}

internal class SupabaseHttpException(val statusCode: Int, message: String) : IllegalStateException(message)

internal fun supabaseDeleteAccount(accessToken: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL mangler eller er ikke HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val connection = (URL("$base/functions/v1/delete-account").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 20000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        setRequestProperty("Authorization", "Bearer $accessToken")
    }
    try {
        connection.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (status !in 200..299) {
            val message = runCatching { JSONObject(body).optString("error").takeIf { it.isNotBlank() } }.getOrNull()
            throw IllegalStateException(message ?: "Kontosletning fejlede (HTTP $status). Kontrollér, at delete-account-funktionen er installeret.")
        }
    } finally {
        connection.disconnect()
    }
}

internal fun cloudRequest(path: String, token: String, method: String = "GET", body: JSONObject? = null, prefer: String? = null): String {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL mangler eller er ikke HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val c = (URL("$base$path").openConnection() as HttpURLConnection).apply {
        requestMethod = method; connectTimeout = 15000; readTimeout = 20000; doInput = true
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        // Refresh requests authenticate with the project API key. Avoid sending a publishable
        // key as a Bearer JWT; every user-scoped request still uses its access token below.
        if (!path.startsWith("/auth/v1/token?grant_type=refresh_token")) {
            setRequestProperty("Authorization", "Bearer $token")
        }
        setRequestProperty("Content-Type", "application/json")
        if (prefer != null) setRequestProperty("Prefer", prefer)
        if (body != null) doOutput = true
    }
    try {
        if (body != null) c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val message = runCatching { JSONObject(text).optString("message").ifBlank { JSONObject(text).optString("msg") } }
                .getOrDefault(text).ifBlank { "Serveren afviste forespørgslen." }.take(240)
            throw SupabaseHttpException(code, "Supabase HTTP $code: $message")
        }
        return text
    } finally { c.disconnect() }
}

internal fun currentCloudUserId(token: String): String {
    val user = JSONObject(cloudRequest("/auth/v1/user", token))
    return user.optString("id").takeIf { it.isNotBlank() } ?: throw IllegalStateException("Kunne ikke identificere onlinekontoen.")
}

/** Refresh an expired Supabase access token using the encrypted local refresh token. */
internal fun refreshSupabaseSession(prefs: android.content.SharedPreferences): String {
    val refreshToken = prefs.getString("online_refresh_token", null).orEmpty()
    require(refreshToken.isNotBlank()) { "Din session er udløbet. Log ind igen for at fortsætte." }
    val response = JSONObject(
        cloudRequest(
            "/auth/v1/token?grant_type=refresh_token",
            BuildConfig.SUPABASE_ANON_KEY,
            "POST",
            JSONObject().put("refresh_token", refreshToken)
        )
    )
    val accessToken = response.optString("access_token")
    require(accessToken.isNotBlank()) { "Supabase returnerede ingen ny session. Log ind igen." }
    val refreshedUserId = currentCloudUserId(accessToken)
    val expectedUserId = prefs.getString("active_account_user_id", null).orEmpty()
    require(expectedUserId.isBlank() || expectedUserId == refreshedUserId) {
        "Den fornyede session tilhører en anden konto. Log ind igen, så kontodata ikke blandes."
    }
    val editor = prefs.edit().putString("online_access_token", accessToken)
    response.optString("refresh_token").takeIf { it.isNotBlank() }?.let { editor.putString("online_refresh_token", it) }
    response.optString("email").takeIf { it.isNotBlank() }?.let { editor.putString("account_email", it) }
    check(editor.commit()) { "Den fornyede session kunne ikke gemmes sikkert. Log ind igen." }
    return accessToken
}

/** Retry exactly once after a 401; all other server errors remain visible to the user. */
internal fun <T> withRefreshedCloudSession(
    prefs: android.content.SharedPreferences,
    token: String,
    action: (String) -> T
): T = try {
    action(token)
} catch (error: SupabaseHttpException) {
    if (error.statusCode != 401) throw error
    action(refreshSupabaseSession(prefs))
}

internal fun syncCloud(token: String, data: JSONObject, prefs: android.content.SharedPreferences) {
    require(isValidSaldoDataObject(data) && hasAnySaldoRecords(data)) {
        "De lokale økonomidata er tomme eller ugyldige og blev ikke uploadet, så en eksisterende online backup ikke risikerer at blive overskrevet."
    }
    val userId = currentCloudUserId(token)
    val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
    require(activeUserId.isBlank() || activeUserId == userId) {
        "Den lokale dataejer matcher ikke den onlinekonto, der er logget ind. Log ind på den rigtige konto først."
    }
    if (activeUserId.isBlank()) {
        prefs.edit().putString("active_account_user_id", userId).putString(localAccountDataKey(userId), data.toString()).apply()
    }
    // Store settings alongside the JSON data without mixing them into the app's transaction collections.
    val cloudPayload = JSONObject(data.toString()).put("_saldoSettings", saldoSettingsJson(prefs))
    val body = JSONObject().put("user_id", userId).put("data", cloudPayload).put("updated_at", java.time.Instant.now().toString())
    cloudRequest("/rest/v1/saldo_user_data?on_conflict=user_id", token, "POST", body, "resolution=merge-duplicates,return=minimal")
}

internal fun fetchCloud(token: String, expectedUserId: String? = null): JSONObject? {
    val userId = currentCloudUserId(token)
    require(expectedUserId.isNullOrBlank() || expectedUserId == userId) {
        "Den lokale dataejer matcher ikke den onlinekonto, der er logget ind. Dine lokale data er ikke ændret."
    }
    val rows = JSONArray(cloudRequest("/rest/v1/saldo_user_data?select=data&user_id=eq.$userId&limit=1", token))
    val cloudData = if (rows.length() == 0) null else rows.optJSONObject(0)?.optJSONObject("data")
    if (cloudData != null) {
        // Never let malformed cloud JSON replace the working local budget.
        val businessData = JSONObject(cloudData.toString()).apply { remove("_saldoSettings") }
        require(isValidSaldoDataObject(businessData) && hasAnySaldoRecords(businessData)) {
            "Onlinekopien er tom eller indeholder ugyldige/ufuldstændige økonomidata. Dine lokale data er ikke ændret."
        }
        cloudData.optJSONObject("_saldoSettings")?.let { settings ->
            val salary = settings.optDouble("payAmount", 10000.0)
            require(salary.isFinite() && salary > 0.0 && salary <= 1_000_000_000_000.0) {
                "Onlinekopiens lønindstilling er ugyldig. Dine lokale data er ikke ændret."
            }
            if (settings.optBoolean("hasPayday", false)) {
                require(runCatching { LocalDate.parse(settings.optString("payday")) }.isSuccess) {
                    "Onlinekopiens løndato er ugyldig. Dine lokale data er ikke ændret."
                }
            }
            if (settings.optBoolean("hasCashBalance", false)) {
                val balance = settings.optDouble("cashBalance", Double.NaN)
                require(balance.isFinite() && kotlin.math.abs(balance) <= 1_000_000_000_000.0) {
                    "Onlinekopiens kontosaldo er ugyldig. Dine lokale data er ikke ændret."
                }
            }
        }
    }
    return cloudData
}

internal fun supabaseAuth(email: String, password: String, signUp: Boolean): JSONObject {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    val endpoint = if (signUp) "$base/auth/v1/signup" else "$base/auth/v1/token?grant_type=password"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
    }
    try {
        val body = JSONObject().put("email", email).put("password", password).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
        if (status !in 200..299) {
            val message = json.optString("msg").ifBlank { json.optString("message") }.ifBlank { json.optString("error_description") }.ifBlank { json.optString("error") }.ifBlank { "Online-login fejlede (HTTP $status)." }
            throw IllegalStateException(message)
        }
        return json
    } finally { connection.disconnect() }
}

internal fun supabasePasswordRecovery(email: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL skal være HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val redirectUri = Uri.encode("dk.saldo.app://auth-callback")
    val connection = (URL("$base/auth/v1/recover?redirect_to=$redirectUri").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
    }
    try {
        val body = JSONObject().put("email", email).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        if (status !in 200..299) {
            val response = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val message = runCatching { JSONObject(response).optString("message") }.getOrDefault("")
            throw IllegalStateException(message.ifBlank { "Nulstillingsanmodningen blev afvist (HTTP $status)." })
        }
    } finally { connection.disconnect() }
}

internal fun supabaseUpdatePassword(recoveryToken: String, newPassword: String) {
    val base = BuildConfig.SUPABASE_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Supabase URL skal være HTTPS." }
    require(BuildConfig.SUPABASE_ANON_KEY.isNotBlank()) { "Supabase-nøglen er ikke konfigureret." }
    val connection = (URL("$base/auth/v1/user").openConnection() as HttpURLConnection).apply {
        requestMethod = "PUT"
        connectTimeout = 15000
        readTimeout = 15000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        setRequestProperty("Authorization", "Bearer $recoveryToken")
    }
    try {
        val body = JSONObject().put("password", newPassword).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        if (status !in 200..299) throw IllegalStateException("Adgangskoden kunne ikke opdateres (HTTP $status).")
    } finally { connection.disconnect() }
}
