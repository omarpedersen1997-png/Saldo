package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// Reusable screen components, forms and dialogs.

@Composable internal fun MonthlyFlowCard(monthIncome: Double, monthExpenses: Double) {
    val scale = maxOf(monthIncome, monthExpenses, 1.0)
    val incomeRatio = (monthIncome / scale).toFloat().coerceIn(0f, 1f)
    val expenseRatio = (monthExpenses / scale).toFloat().coerceIn(0f, 1f)
    val net = monthIncome - monthExpenses
    val savingsRate = if (monthIncome > 0) (net / monthIncome).coerceIn(-1.0, 1.0) else 0.0
    val animatedRate by animateFloatAsState(
        targetValue = savingsRate.toFloat().coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing),
        label = "monthly-savings-rate"
    )
    SaldoCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(19.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(Icons.AutoMirrored.Filled.ShowChart, Violet)
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Månedens pengestrøm", color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("Indtægter sammenholdt med udgifter", color = Muted, fontSize = 11.sp)
            }
            Surface(color = if (net >= 0) Mint.copy(alpha = .13f) else SaldoDanger.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                Text(
                    if (net >= 0) "Plus" else "Minus",
                    color = if (net >= 0) Mint else SaldoDanger,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Månedens netto", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                AnimatedMoney(net, color = if (net >= 0) Mint else SaldoDanger, fontSize = 26.sp, letterSpacing = (-.6).sp, format = ::netMoney)
                Text("Forskel mellem registrerede indtægter og udgifter", color = Muted, fontSize = 10.sp)
            }
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(62.dp)) {
                CircularProgressIndicator(progress = { animatedRate }, modifier = Modifier.fillMaxSize(), color = Mint, trackColor = Mint.copy(alpha = .12f), strokeWidth = 5.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${(savingsRate * 100).toInt()}%", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("sparet", color = Muted, fontSize = 9.sp)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Indtægter", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    AnimatedMoney(monthIncome, color = Mint, fontSize = 12.sp)
                }
                SaldoProgressBar(incomeRatio, height = 10.dp, colors = listOf(Mint.copy(alpha = .7f), Mint), track = Mint.copy(alpha = .12f))
            }
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Udgifter", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    AnimatedMoney(monthExpenses, color = Violet, fontSize = 12.sp)
                }
                SaldoProgressBar(expenseRatio, height = 10.dp, colors = listOf(Violet.copy(alpha = .7f), Violet), track = Violet.copy(alpha = .12f))
            }
        }
    }
}

@Composable
internal fun SettingsSectionHeader(title: String, subtitle: String? = null) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 2.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.4).sp)
        if (!subtitle.isNullOrBlank()) Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
internal fun CsvTransactionPreviewRow(
    transaction: JSONObject,
    categories: List<String>,
    onTypeChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit
) {
    var typeMenuExpanded by remember(transaction.s("id")) { mutableStateOf(false) }
    var categoryMenuExpanded by remember(transaction.s("id")) { mutableStateOf(false) }
    val categoryConfidence = transaction.optInt("_saldoCsvConfidence", 40).coerceIn(0, 100)
    val directionConfidence = transaction.optInt("_saldoCsvDirectionConfidence", 50).coerceIn(0, 100)
    val needsCategoryReview = transaction.optBoolean("_saldoCsvNeedsReview", categoryConfidence < 72)
    val needsDirectionReview = directionConfidence < 80
    Surface(
        color = PanelRaised,
        shape = RoundedCornerShape(13.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (needsCategoryReview || needsDirectionReview) SaldoWarning.copy(alpha = .4f) else BorderSubtle),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(transaction.s("name").ifBlank { "Post uden beskrivelse" }, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 2)
                    Text(transaction.s("date"), color = Muted, fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(money(transaction.n("amount")), color = if (transaction.s("type") == "Indtægt") Mint else White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(if (needsDirectionReview) "Retning?" else "${directionConfidence}% retning", color = if (needsDirectionReview) SaldoWarning else Muted, fontSize = 10.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(0.85f)) {
                    TextButton(onClick = { typeMenuExpanded = true }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(transaction.s("type"), fontSize = 11.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Skift indtægt eller udgift", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(expanded = typeMenuExpanded, onDismissRequest = { typeMenuExpanded = false }) {
                        listOf("Indtægt", "Udgift").forEach { type ->
                            DropdownMenuItem(text = { Text(type) }, onClick = { typeMenuExpanded = false; onTypeChange(type) })
                        }
                    }
                }
                Box(Modifier.weight(1.3f)) {
                    TextButton(onClick = { categoryMenuExpanded = true }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(transaction.s("category"), fontSize = 11.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Skift kategori", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(expanded = categoryMenuExpanded, onDismissRequest = { categoryMenuExpanded = false }) {
                        categories.forEach { category ->
                            DropdownMenuItem(text = { Text(category) }, onClick = { categoryMenuExpanded = false; onCategoryChange(category) })
                        }
                    }
                }
            }
            Text(
                when {
                    needsCategoryReview && needsDirectionReview -> "Kontrollér retning og kategori · ${transaction.s("_saldoCsvReason", "Usikkert forslag")}"
                    needsDirectionReview -> "Kontrollér om posten er indtægt eller udgift · $directionConfidence% sikker"
                    needsCategoryReview -> "Kontrollér kategori · $categoryConfidence% sikker · ${transaction.s("_saldoCsvReason", "Usikkert forslag")}"
                    else -> "Kategori foreslået · $categoryConfidence% sikker · ${transaction.s("_saldoCsvReason", "Beskrivelse genkendt")}"
                },
                color = if (needsCategoryReview || needsDirectionReview) SaldoWarning else Muted,
                fontSize = 10.sp,
                maxLines = 2
            )
        }
    }
}

@Composable internal fun SettingsAction(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean = true,
    danger: Boolean = false,
    trailing: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.ChevronRight,
    onClick: () -> Unit
) {
    SaldoCard(
        Modifier.fillMaxWidth().animateContentSize(),
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(icon, if (danger) SaldoDanger else Violet, size = 42.dp, iconSize = 20.dp)
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = if (danger) SaldoDanger else White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(trailing, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable internal fun Metric(label: String, value: String, modifier: Modifier = Modifier, positive: Boolean? = null) {
    SaldoCard(modifier, shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
        Text(value, color = if (positive == true) Mint else White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp, maxLines = 1)
    }
}

@Composable internal fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    SaldoCard(
        modifier,
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SaldoIconTile(icon, Violet, size = 44.dp, iconSize = 22.dp) }
        Text(label, color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable internal fun DashboardMetric(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier = Modifier, amount: Double? = null) {
    SaldoCard(modifier, shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SaldoIconTile(icon, accent, size = 34.dp, iconSize = 18.dp, contentDescription = label)
        Text(label, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        if (amount != null) AnimatedMoney(amount, color = White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.6).sp)
        else Text(value, color = White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.6).sp, maxLines = 2, lineHeight = 22.sp)
    }
}

@Composable internal fun UpcomingBillCard(title: String, date: String, amount: String, modifier: Modifier = Modifier, onPaid: () -> Unit) {
    SaldoCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(Icons.AutoMirrored.Filled.ReceiptLong, Violet, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("Forfalder $date", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(amount, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Surface(onClick = onPaid, color = Mint.copy(alpha = .14f), shape = RoundedCornerShape(50)) {
                    Text("Markér betalt", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                }
            }
        }
    }
}

@Composable internal fun RecordRow(title: String, detail: String, amount: String, positive: Boolean, onDelete: () -> Unit, onToggle: (() -> Unit)? = null, onEdit: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    var confirmDelete by remember(title, detail, amount) { mutableStateOf(false) }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Panel,
            title = { Text("Slet posten?", color = White, fontWeight = FontWeight.Bold) },
            text = { Text("\"$title\" slettes fra Saldo. Handlingen kan ikke fortrydes, medmindre du har en sikkerhedskopi.", color = Muted) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) {
                    Text("Slet", color = SaldoDanger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Annuller", color = Muted) }
            }
        )
    }
    SaldoCard(
        modifier.fillMaxWidth().padding(vertical = 4.dp).animateContentSize(),
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoAvatar(title, positive)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                Text(detail, color = Muted, fontSize = 12.sp, maxLines = 2)
            }
            Spacer(Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(amount, color = if (positive) Mint else White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = (-.3).sp, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                    if (onToggle != null) {
                        IconButton(onClick = onToggle, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Markér regning som betalt", tint = Mint, modifier = Modifier.size(17.dp))
                        }
                    }
                    if (onEdit != null) {
                        IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                            Icon(Icons.Default.Edit, contentDescription = "Rediger $title", tint = Muted, modifier = Modifier.size(17.dp))
                        }
                    }
                    IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Slet $title", tint = Muted, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
    }
}

@Composable internal fun OwnerSummaryCard(title: String, amount: Double, modifier: Modifier = Modifier, accent: Color = Violet) {
    SaldoCard(modifier, shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(accent, RoundedCornerShape(50)))
            Spacer(Modifier.width(6.dp))
            Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        AnimatedMoney(amount, color = White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.4).sp)
        Text("denne måned", color = Muted, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable internal fun ManagedList(title: String, records: List<JSONObject>, onAdd: () -> Unit, row: @Composable (JSONObject) -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp); Button(onClick = onAdd, shape = RoundedCornerShape(50)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Tilføj") } }; if (records.isEmpty()) { Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(8.dp)); Text("Her er tomt endnu", color = White, fontWeight = FontWeight.SemiBold); Text("Tilføj din første post for at komme i gang.", color = Muted, fontSize = 12.sp) } } }; LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) { items(records, key = { it.s("id") }) { row(it) } } } }

@Composable
internal fun BudgetEditDialog(budget: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    val context = LocalContext.current
    val budgetId = budget.s("id")
    var category by remember(budgetId) { mutableStateOf(budget.s("category")) }
    var limit by remember(budgetId) {
        mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(budget.n("limit")))
    }
    var owner by remember(budgetId) { mutableStateOf(budget.s("owner", "Mig")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rediger budget") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Kategori", category, { category = it })
                Field("Månedlig grænse (kr.)", limit, { limit = it }, numeric = true)
                Text("Budget for", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Mig", "Partner", "Fælles").forEach { option ->
                        FilterChip(selected = owner == option, onClick = { owner = option }, label = { Text(option) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsedLimit = parseDanishAmount(limit)
                if (category.isBlank() || parsedLimit == null || parsedLimit <= 0.0) {
                    Toast.makeText(context, "Indtast en kategori og en gyldig månedlig grænse.", Toast.LENGTH_LONG).show()
                } else {
                    onSave(JSONObject(budget.toString()).put("category", category.trim()).put("limit", parsedLimit).put("owner", owner))
                }
            }) { Text("Gem ændringer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller") } }
    )
}

internal fun saldoInputNumber(value: Double): String =
    if (value == kotlin.math.floor(value)) String.format(Locale("da", "DK"), "%.0f", value) else String.format(Locale("da", "DK"), "%.2f", value)

internal val saldoEditableKinds = setOf("post", "bill", "sub", "debt", "fuel")

internal fun saldoCollectionForKind(kind: String): String = when (kind) { "post" -> "transactions"; "bill" -> "bills"; "sub" -> "subs"; "debt" -> "debts"; else -> "fuel" }

/** Three short steps for new users: welcome, salary/payday and current balance + theme. */
@Composable
internal fun SaldoOnboarding(themeMode: String, onThemeChange: (String) -> Unit, onSkip: () -> Unit, onFinish: (Double?, String?, Double?, String) -> Unit) {
    var step by remember { mutableStateOf(0) }
    var pay by remember { mutableStateOf("") }
    var payday by remember { mutableStateOf(LocalDate.now().plusMonths(1).withDayOfMonth(1).toString()) }
    var payFrequency by remember { mutableStateOf("monthly") }
    var balance by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    androidx.compose.ui.window.Dialog(onDismissRequest = {}, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false, dismissOnClickOutside = false)) {
        Box(Modifier.fillMaxSize().background(saldoBackgroundBrush(Night.luminance() < .5f)).statusBarsPadding().navigationBarsPadding(), contentAlignment = Alignment.TopCenter) {
            Column(Modifier.fillMaxSize().widthIn(max = 560.dp).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    repeat(3) { index ->
                        Box(Modifier.padding(end = 6.dp).height(5.dp).width(if (index == step) 26.dp else 10.dp).clip(RoundedCornerShape(50)).background(if (index <= step) Violet else PanelRaised))
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onSkip) { Text("Spring over", color = Muted) }
                }
                AnimatedContent(targetState = step, transitionSpec = {
                    (fadeIn(tween(SaldoMotion.MEDIUM)) + slideInHorizontally(tween(SaldoMotion.MEDIUM, easing = SaldoMotion.Emphasized)) { it / 6 }) togetherWith fadeOut(tween(SaldoMotion.SHORT))
                }, label = "onboarding-step") { current ->
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (current) {
                            0 -> {
                                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(84.dp))
                                Text("Velkommen til Saldo", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.6).sp)
                                Text("Få overblik over, hvad du har til rådighed frem til næste løn – på et minut.", color = Muted, fontSize = 15.sp)
                                listOf(
                                    Icons.Default.AccountBalanceWallet to "Se dit rådighedsbeløb og hvad du kan bruge pr. dag",
                                    Icons.Default.Autorenew to "Faste poster og regninger lægger sig ind af sig selv",
                                    Icons.Default.FileOpen to "Importér posteringer fra netbanken med \"Del til Saldo\"",
                                    Icons.Default.Lock to "Dine data er krypteret på telefonen"
                                ).forEach { (icon, text) ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SaldoIconTile(icon, Violet, size = 40.dp, iconSize = 20.dp)
                                        Spacer(Modifier.width(12.dp))
                                        Text(text, color = White, fontSize = 14.sp)
                                    }
                                }
                            }
                            1 -> {
                                Text("Din løn", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Saldo beregner dit rådighedsbeløb frem til næste udbetaling. Du kan altid ændre det under Indstillinger.", color = Muted, fontSize = 14.sp)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    saldoPayFrequencies.forEach { (key, label) -> FilterChip(selected = payFrequency == key, onClick = { payFrequency = key }, label = { Text(label, maxLines = 1) }, modifier = Modifier.weight(1f)) }
                                }
                                Field("Løn pr. udbetaling (efter skat), kr.", pay, { pay = it; error = "" }, numeric = true)
                                SaldoDateField("Næste løndato", payday) { payday = it; error = "" }
                            }
                            else -> {
                                Text("Din saldo nu", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Skriv hvad du har på dine konti lige nu, så bliver rådighedsbeløbet præcist. Du kan springe det over.", color = Muted, fontSize = 14.sp)
                                Field("Saldo på dine konti, kr. (valgfri)", balance, { balance = it; error = "" }, numeric = true)
                                Text("Udseende", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("dark" to "Mørk", "light" to "Lys", "system" to "System").forEach { (mode, label) ->
                                        FilterChip(selected = themeMode == mode, onClick = { onThemeChange(mode) }, label = { Text(label) }, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = SaldoDanger, fontSize = 13.sp)
                Button(
                    onClick = {
                        when (step) {
                            0 -> step = 1
                            1 -> {
                                val parsedPay = parseDanishAmount(pay)
                                when {
                                    pay.isNotBlank() && (parsedPay == null || parsedPay <= 0.0) -> error = "Skriv lønnen som et beløb, fx 18.500."
                                    runCatching { LocalDate.parse(payday) }.isFailure -> error = "Vælg en gyldig løndato."
                                    else -> step = 2
                                }
                            }
                            else -> {
                                val parsedBalance = parseDanishAmount(balance)
                                if (balance.isNotBlank() && parsedBalance == null) error = "Skriv saldoen som et beløb, fx 4.250,50."
                                else onFinish(parseDanishAmount(pay)?.takeIf { it > 0.0 }, payday.takeIf { runCatching { LocalDate.parse(it) }.isSuccess }, parsedBalance, payFrequency)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp).background(saldoBrandBrush(), RoundedCornerShape(17.dp)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White),
                    shape = RoundedCornerShape(17.dp)
                ) { Text(when (step) { 0 -> "Kom i gang"; 1 -> "Fortsæt"; else -> "Færdig" }, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                if (step > 0) TextButton(onClick = { step -= 1; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("Tilbage", color = Muted) }
            }
        }
    }
}

@Composable
internal fun DebtPlanCard(debts: List<JSONObject>) {
    var avalanche by remember { mutableStateOf(true) }
    var extra by remember { mutableFloatStateOf(0f) }
    val plan = remember(debts, avalanche, extra) { simulateDebtPlan(debts, extra.toDouble(), avalanche) }
    val baseline = remember(debts, avalanche) { simulateDebtPlan(debts, 0.0, avalanche) }
    val danish = Locale("da", "DK")
    fun monthLabel(offset: Int) = YearMonth.now().plusMonths(offset.toLong()).let { it.month.getDisplayName(java.time.format.TextStyle.FULL, danish) + " " + it.year }
    SaldoCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SaldoIconTile(Icons.Default.Flag, Mint, size = 38.dp, iconSize = 19.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Gældfri-plan", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(plan.months?.let { if (it == 0) "Du har ingen restgæld" else "Gældfri i ${monthLabel(it)}" } ?: "Afdragene dækker ikke renterne – hæv afdraget", color = if (plan.months != null) Mint else SaldoDanger, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = avalanche, onClick = { avalanche = true }, label = { Text("Højeste rente først") }, modifier = Modifier.weight(1f))
            FilterChip(selected = !avalanche, onClick = { avalanche = false }, label = { Text("Mindste gæld først") }, modifier = Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ekstra afdrag pr. måned", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(money(extra.toDouble()), color = Violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Slider(value = extra, onValueChange = { extra = (it / 100f).roundToInt() * 100f }, valueRange = 0f..5000f, colors = SliderDefaults.colors(thumbColor = Violet, activeTrackColor = Violet, inactiveTrackColor = PanelRaised, activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent))
        Text("Renter i alt: ${money(plan.totalInterest)}" + if (extra > 0f && plan.months != null && baseline.months != null) " · du sparer ${money((baseline.totalInterest - plan.totalInterest).coerceAtLeast(0.0))} og ${(baseline.months - plan.months).coerceAtLeast(0)} mdr." else "", color = Muted, fontSize = 12.sp)
        plan.payoffOrder.take(5).forEachIndexed { index, (name, month) ->
            Text("${index + 1}. $name – betalt ud i ${monthLabel(month)}", color = White, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun SaldoRepeatChips(value: String, onChange: (String) -> Unit) {
    val selectedMonths = recurrenceIntervalMonths(value)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Gentagelse", color = Muted, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Engangsbetaling" to null, "Månedlig" to 1L, "Kvartalsvis" to 3L, "Årlig" to 12L).forEach { (label, months) ->
                FilterChip(selected = selectedMonths == months, onClick = { onChange(label) }, label = { Text(if (months == null) "Engang" else label) })
            }
        }
    }
}

@Composable internal fun DataDialog(kind: String, initial: JSONObject? = null, suggestions: List<JSONObject> = emptyList(), onDismiss: () -> Unit, onSave: (String, JSONObject) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initial?.s("name").orEmpty()) }; var amount by remember { mutableStateOf(initial?.let { saldoInputNumber(it.n(when (kind) { "sub" -> "monthly"; "debt" -> "balance"; "fuel" -> "liters"; else -> "amount" })) }.orEmpty()) }; var category by remember { mutableStateOf(initial?.s("category", "Diverse")?.ifBlank { "Diverse" } ?: "Diverse") }; var date by remember { mutableStateOf(initial?.s("date")?.ifBlank { null } ?: LocalDate.now().toString()) }; var type by remember { mutableStateOf(initial?.s("type", "Udgift")?.ifBlank { "Udgift" } ?: "Udgift") }; var owner by remember { mutableStateOf(initial?.s("owner", "Mig")?.ifBlank { "Mig" } ?: "Mig") }; var extra by remember { mutableStateOf(when (kind) { "bill", "post" -> initial?.s("repeat").orEmpty(); "sub" -> initial?.s("renewalDate").orEmpty(); "debt" -> initial?.let { saldoInputNumber(it.n("rate")) }.orEmpty(); "fuel" -> initial?.let { saldoInputNumber(it.n("cost")) }.orEmpty(); else -> "" }) }; var extra2 by remember { mutableStateOf(when (kind) { "sub" -> initial?.s("cancelByDate").orEmpty(); "debt" -> initial?.let { saldoInputNumber(it.n("payment")) }.orEmpty(); "fuel" -> initial?.let { saldoInputNumber(it.n("km")) }.orEmpty(); else -> "" }) }; var extra3 by remember { mutableStateOf(when (kind) { "sub" -> initial?.s("cancelNote").orEmpty(); "post" -> initial?.s("note").orEmpty(); else -> "" }) }; var json by remember { mutableStateOf("") }; var ocrText by remember { mutableStateOf("") }; var ocrBusy by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf(initial?.s("receipt").orEmpty()) }
    var receiptBusy by remember { mutableStateOf(false) }
    var keepOpen by remember { mutableStateOf(false) }
    var payFrequency by remember { mutableStateOf(saldoPreferences(context).getString("pay_frequency", null) ?: "monthly") }
    var showReceipt by remember { mutableStateOf(false) }
    val receiptScope = rememberCoroutineScope()
    val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            receiptBusy = true
            receiptScope.launch {
                val saved = withContext(Dispatchers.IO) { runCatching { saveReceiptImage(context, uri) } }
                receiptBusy = false
                saved.onSuccess { receipt = it }.onFailure { Toast.makeText(context, it.message ?: "Billedet kunne ikke gemmes.", Toast.LENGTH_LONG).show() }
            }
        }
    }
    val receiptBitmap = remember(receipt) {
        if (receipt.isBlank()) null else runCatching {
            android.graphics.BitmapFactory.decodeFile(receiptFile(context, receipt).absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
        }.getOrNull()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching { InputImage.fromFilePath(context, uri) }.onSuccess { image ->
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text
                        val parsed = parseBillText(result.text)
                        if (name.isBlank()) name = parsed.first
                        if (amount.isBlank()) amount = parsed.second
                        if (parsed.third.isNotBlank()) date = parsed.third
                        ocrBusy = false
                        recognizer.close()
                    }
                    .addOnFailureListener { ocrText = "Kunne ikke læse billedet. Prøv et skarpere og mere tydeligt skærmbillede."; ocrBusy = false; recognizer.close() }
            }.onFailure { ocrText = "Filen kunne ikke åbnes som et billede. Vælg et almindeligt PNG/JPG-skærmbillede."; ocrBusy = false }
        }
    }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Backupfilen kunne ikke læses.")
                val bytes = input.use { stream ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= 10 * 1024 * 1024) { "Backupfilen er større end 10 MB." }
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
            }.onSuccess { imported ->
                json = imported
                Toast.makeText(context, "Backupfil indlæst. Kontrollér filen, og tryk Gem for at gendanne.", Toast.LENGTH_LONG).show()
            }.onFailure { error ->
                Toast.makeText(context, error.message ?: "Backupfilen kunne ikke læses.", Toast.LENGTH_LONG).show()
            }
        }
    }
    val baseTitle = when (kind) { "post" -> if (initial != null) "Rediger post" else "Ny post"; "bill" -> if (initial != null) "Rediger regning" else "Ny regning"; "budget" -> "Budgetgrænse"; "goal" -> "Opsparingsmål"; "debt" -> "Ny gæld"; "fuel" -> "Ny tankning"; "sub" -> "Abonnement"; "payday" -> "Lønindstillinger"; "cashbalance" -> "Nuværende saldo"; "pin" -> "PIN-kode"; "backup" -> "Backup / gendannelse"; "ocr" -> "Importér regning"; else -> "Saldo" }
    val title = if (initial == null) baseTitle else when (kind) { "sub" -> "Rediger abonnement"; "debt" -> "Rediger gæld"; "fuel" -> "Rediger tankning"; else -> baseTitle }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (kind) {
                "post" -> { Field("Beskrivelse", name, { name = it })
                    // Remembered merchants: one tap fills category, type, owner and the usual amount.
                    val matches = if (name.isBlank() || initial != null) emptyList() else suggestions.filter { it.s("name").contains(name.trim(), ignoreCase = true) && !it.s("name").equals(name.trim(), ignoreCase = true) }.take(6)
                    if (matches.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        matches.forEach { match ->
                            SuggestionChip(onClick = {
                                name = match.s("name"); category = match.s("category", category).ifBlank { category }
                                type = match.s("type", type).ifBlank { type }; owner = match.s("owner", owner).ifBlank { owner }
                                if (amount.isBlank()) amount = String.format(Locale("da", "DK"), "%.2f", match.n("amount"))
                            }, label = { Text("${match.s("name")} · ${money(match.n("amount"))}", maxLines = 1) })
                        }
                    }
                    Field("Beløb i kr.", amount, { amount = it }, true)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("+", "−", "×", "÷").forEach { op -> SuggestionChip(onClick = { amount += op }, label = { Text(op, fontWeight = FontWeight.Bold) }, modifier = Modifier.semantics { contentDescription = when (op) { "+" -> "Plus"; "−" -> "Minus"; "×" -> "Gange"; else -> "Divider" } }) }
                        Spacer(Modifier.weight(1f))
                        if (amount.trim().drop(1).any { it in "+-−*×/÷" }) Text(evaluateAmountExpression(amount)?.let { "= ${money(it)}" } ?: "Ugyldigt regnestykke", color = if (evaluateAmountExpression(amount) != null) Violet else SaldoDanger, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Field("Kategori", category, { category = it }); SaldoDateField("Dato", date, { date = it }); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Udgift", "Indtægt").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
                    SaldoRepeatChips(extra) { extra = it }
                    Field("Note (valgfri)", extra3, { extra3 = it })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (receiptBitmap != null) {
                            Image(receiptBitmap, contentDescription = "Kvittering", contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).clickable { showReceipt = true })
                            TextButton(onClick = { receipt = "" }) { Text("Fjern kvittering", color = SaldoDanger) }
                        } else {
                            OutlinedButton(onClick = { receiptPicker.launch("image/*") }, enabled = !receiptBusy, shape = RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.Receipt, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                                Text(if (receiptBusy) "Gemmer billede…" else "Tilføj kvittering")
                            }
                        }
                    }
                    if (receiptBitmap != null) Text("Kvitteringer gemmes kun på telefonen og er ikke med i sikkerhedskopier.", color = Muted, fontSize = 11.sp)
                    if (initial == null) Row(Modifier.fillMaxWidth().clickable { keepOpen = !keepOpen }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = keepOpen, onCheckedChange = { keepOpen = it })
                        Text("Opret en ny post bagefter", color = White, fontSize = 13.sp)
                    }
                    if (showReceipt && receiptBitmap != null) androidx.compose.ui.window.Dialog(onDismissRequest = { showReceipt = false }) {
                        Image(receiptBitmap, contentDescription = "Kvittering", modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { showReceipt = false })
                    }
                }
                "bill" -> { Field("Regning / modtager", name, { name = it }); Field("Beløb", amount, { amount = it }, true); SaldoDateField("Forfaldsdato", date, { date = it }); SaldoRepeatChips(extra) { extra = it }; Field("Kategori", category, { category = it }); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "budget" -> { Field("Kategori", name, { name = it }); Field("Månedlig grænse", amount, { amount = it }, true); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "goal" -> { Field("Opsparingsmål", name, { name = it }); Field("Målsum", amount, { amount = it }, true); Field("Allerede sparet", extra, { extra = it }, true); SaldoDateField("Måldato", date, { date = it }) }
                "debt" -> { Field("Kreditor", name, { name = it }); Field("Restgæld", amount, { amount = it }, true); Field("Årlig rente (%)", extra, { extra = it }, true); Field("Månedligt afdrag", extra2, { extra2 = it }, true) }
                "fuel" -> { SaldoDateField("Dato", date, { date = it }); Field("Liter", amount, { amount = it }, true); Field("Samlet pris", extra, { extra = it }, true); Field("Kilometerstand", extra2, { extra2 = it }, true) }
                "sub" -> { Field("Abonnement", name, { name = it }); Field("Pris pr. måned", amount, { amount = it }, true); SaldoDateField("Næste fornyelsesdato", extra, { extra = it }); SaldoDateField("Opsig senest", extra2, { extra2 = it }); Field("Note (valgfri)", extra3, { extra3 = it }); Row { listOf("Mig", "Partner", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "payday" -> {
                    Text("Hvor ofte får du løn?", color = White, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        saldoPayFrequencies.forEach { (key, label) -> FilterChip(selected = payFrequency == key, onClick = { payFrequency = key }, label = { Text(label, maxLines = 1) }, modifier = Modifier.weight(1f)) }
                    }
                    Field("Løn pr. udbetaling (efter skat), kr.", amount, { amount = it }, true)
                    SaldoDateField(if (payFrequency == "monthly") "Næste løndato (dagen bruges hver måned)" else "Næste løndato", date, { date = it })
                    Text(when (payFrequency) { "monthly" -> "Saldo regner med løn på samme dato hver måned. Falder den på en dag, måneden ikke har, bruges sidste dag."; "weekly" -> "Saldo regner med løn hver 7. dag fra den valgte dato."; else -> "Saldo regner med løn hver 14. dag fra den valgte dato." }, color = Muted, fontSize = 11.sp)
                }
                "cashbalance" -> { Field("Saldo på dine konti i kr.", amount, { amount = it }, true); Text("Brug den samlede saldo, som du faktisk har til rådighed lige nu. Saldo forbinder ikke til banken og ændrer ikke dine bankkonti.", color = Muted, fontSize = 11.sp) }
                "pin" -> {
                    Field("PIN (4-8 cifre)", amount, { amount = it }, true, true)
                    Field("Gentag PIN", extra, { extra = it }, true, true)
                    Text("PIN-koden gemmes som en saltet kryptografisk hash, ikke som læsbar tekst.", color = Muted, fontSize = 11.sp)
                }
                "backup" -> {
                    Button(onClick = { backupPicker.launch("application/json") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Vælg backupfil")
                    }
                    Field("Backup-JSON (kan også indsættes)", json, { json = it })
                    Text("Vælg en Saldo-JSON-backup fra Filer/Downloads. Data gendannes først, når du trykker Gem. Maks. 10 MB. Backupen indeholder økonomidata, lønindstilling og eventuel saldo, men ikke PIN eller login-session. Gem filen sikkert.", color = Muted, fontSize = 11.sp)
                }
                "ocr" -> {
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), enabled = !ocrBusy) { Text(if (ocrBusy) "Læser skærmbillede…" else "Vælg skærmbillede af regningen") }
                    Text(if (ocrText.isBlank()) "Vælg et skærmbillede fra dit galleri. Saldo forsøger at finde afsender, beløb og dato. Kontrollér altid felterne før gemning." else "Tekst genkendt – kontrollér oplysningerne nedenfor:", color = Muted)
                    if (ocrBusy) CircularProgressIndicator(color = Violet)
                    if (ocrText.isNotBlank()) {
                        Field("Afsender / regning", name, { name = it })
                        Field("Beløb i kr.", amount, { amount = it }, true)
                        SaldoDateField("Forfaldsdato", date, { date = it })
                        Text("Genkendt tekst", color = White, fontWeight = FontWeight.SemiBold)
                        Text(ocrText.take(1800), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = {
        val a = evaluateAmountExpression(amount) ?: 0.0
        val id = System.currentTimeMillis().toString()
        val nameRequired = kind in setOf("post", "bill", "budget", "goal", "debt", "sub")
        if (nameRequired && name.isBlank()) {
            Toast.makeText(context, "Udfyld navn eller beskrivelse først.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind in setOf("post", "bill", "budget", "goal", "debt", "sub", "payday", "fuel") && (amount.isBlank() || a <= 0.0)) {
            Toast.makeText(context, "Indtast et beløb større end 0 kr.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "cashbalance" && (amount.isBlank() || parseDanishAmount(amount) == null)) {
            Toast.makeText(context, "Indtast en gyldig saldo — brug 0, hvis saldoen er nul.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "goal" && extra.isNotBlank() && (parseDanishAmount(extra)?.let { it >= 0.0 } != true)) {
            Toast.makeText(context, "Indtast et gyldigt, ikke-negativt beløb for allerede opsparet.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "debt" && listOf(extra, extra2).any { it.isNotBlank() && (parseDanishAmount(it)?.let { value -> value >= 0.0 } != true) }) {
            Toast.makeText(context, "Rente og afdrag skal være gyldige, ikke-negative tal.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        val datesToValidate = when (kind) {
            "post", "bill", "goal", "fuel", "payday", "ocr" -> listOf(date)
            "sub" -> listOf(extra, extra2).filter { it.isNotBlank() }
            else -> emptyList()
        }
        if (datesToValidate.any { runCatching { LocalDate.parse(it) }.isFailure }) {
            Toast.makeText(context, "Brug datoformatet ÅÅÅÅ-MM-DD.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "fuel" && ((parseDanishAmount(extra) ?: 0.0) <= 0.0 || (parseDanishAmount(extra2) ?: -1.0) < 0.0)) {
            Toast.makeText(context, "Indtast gyldigt brændstofforbrug, pris og kilometertal.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "pin" && !amount.matches(Regex("\\d{4,8}"))) {
            Toast.makeText(context, "PIN-koden skal bestå af 4-8 cifre.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "pin" && amount != extra) {
            Toast.makeText(context, "PIN-koderne er ikke ens.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        if (kind == "backup" && !isValidSaldoBackup(json)) {
            Toast.makeText(context, "Backupfilen er ugyldig eller indeholder poster i et ukendt format.", Toast.LENGTH_LONG).show()
            return@TextButton
        }
        val obj = when (kind) {
            "post" -> record("id" to id, "name" to name, "amount" to a, "category" to category, "date" to date, "type" to type, "owner" to owner).apply {
                if (keepOpen) put("_keepOpen", true)
                if (extra3.isNotBlank()) put("note", extra3.trim())
                if (receipt.isNotBlank() || initial?.has("receipt") == true) put("receipt", receipt)
                if (isRecurringRepeat(extra)) put("repeat", extra).put("recurrenceDay", runCatching { LocalDate.parse(date).dayOfMonth }.getOrDefault(1))
                else if (initial?.s("repeat")?.let(::isRecurringRepeat) == true) put("repeat", "Engangsbetaling")
            }
            "bill" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to extra, "category" to category, "owner" to owner, "paid" to false)
            "budget" -> record("id" to id, "category" to name, "limit" to a, "owner" to owner)
            "goal" -> record("id" to id, "name" to name, "target" to a, "saved" to (parseDanishAmount(extra) ?: 0.0), "date" to date)
            "debt" -> record("id" to id, "name" to name, "balance" to a, "rate" to (parseDanishAmount(extra) ?: 0.0), "payment" to (parseDanishAmount(extra2) ?: 0.0))
            "fuel" -> record("id" to id, "date" to date, "liters" to a, "cost" to (parseDanishAmount(extra) ?: 0.0), "km" to (parseDanishAmount(extra2) ?: 0.0))
            "sub" -> record("id" to id, "name" to name, "monthly" to a, "renewalDate" to extra, "cancelByDate" to extra2, "cancelNote" to extra3, "owner" to owner, "active" to true)
            "payday" -> record("pay" to a, "date" to date, "frequency" to payFrequency)
            "cashbalance" -> record("balance" to a)
            "pin" -> record("pin" to amount)
            "backup" -> record("json" to json)
            "ocr" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to "Engangsbetaling", "category" to category, "owner" to owner, "paid" to false, "source" to "OCR-skærmbillede")
            else -> JSONObject()
        }
        // Editing keeps the record's identity, payment state and any extra fields (e.g. import source).
        if (initial != null && kind in saldoEditableKinds) {
            initial.keys().forEach { key -> if (!obj.has(key)) obj.put(key, initial.get(key)) }
            obj.put("id", initial.s("id").ifBlank { id })
            if (kind == "bill") obj.put("paid", initial.optBoolean("paid", false))
            if (kind == "sub") obj.put("active", initial.optBoolean("active", true))
        }
        // All input validation is performed above before the record is created.
        if (kind == "ocr") {
            if (ocrText.isBlank() || name.isBlank() || a <= 0.0 || runCatching { LocalDate.parse(date) }.isFailure) {
                Toast.makeText(context, "Kontrollér afsender, beløb og dato før gemning", Toast.LENGTH_LONG).show()
                return@TextButton
            }
            onSave("bill", obj)
        } else onSave(kind, obj)
    }) { Text(if (kind == "ocr") "Opret regning" else "Gem", color = Blue) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } })
}

@Composable
internal fun Field(
    label: String,
    value: String,
    onValue: (String) -> Unit,
    numeric: Boolean = false,
    password: Boolean = false,
    email: Boolean = false
) {
    var passwordVisible by remember(label) { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (password && !passwordVisible) PasswordVisualTransformation()
            else androidx.compose.ui.text.input.VisualTransformation.None,
        trailingIcon = if (password) {
            {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = if (passwordVisible) "Skjul indhold" else "Vis indhold",
                        tint = Muted
                    )
                }
            }
        } else null,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (numeric && password) KeyboardType.NumberPassword
                else if (numeric) KeyboardType.Decimal
                else if (email) KeyboardType.Email
                else if (password) KeyboardType.Password
                else KeyboardType.Text
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = White,
            unfocusedTextColor = White,
            focusedBorderColor = Violet,
            unfocusedBorderColor = Muted,
            focusedLabelColor = Violet,
            unfocusedLabelColor = Muted
        )
    )
}

@Composable
internal fun GoalEditDialog(goal: JSONObject, onDismiss: () -> Unit, onSave: (JSONObject) -> Unit) {
    val context = LocalContext.current
    val goalId = goal.s("id")
    var name by remember(goalId) { mutableStateOf(goal.s("name")) }
    var target by remember(goalId) { mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(goal.n("target"))) }
    var saved by remember(goalId) { mutableStateOf(NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(goal.n("saved"))) }
    var date by remember(goalId) { mutableStateOf(goal.s("date")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Rediger opsparingsmål", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Field("Navn på målet", name, { name = it })
                Field("Målsum (kr.)", target, { target = it }, numeric = true)
                Field("Allerede sparet (kr.)", saved, { saved = it }, numeric = true)
                SaldoDateField("Måldato (valgfri)", date, { date = it })
                Text("Dine registrerede indbetalinger ændres ikke, når du redigerer målet.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsedTarget = parseDanishAmount(target)
                val parsedSaved = parseDanishAmount(saved)
                if (goalId.isBlank()) {
                    Toast.makeText(context, "Opsparingsmålets ID mangler. Opret målet igen.", Toast.LENGTH_LONG).show()
                } else if (name.isBlank() || parsedTarget == null || parsedTarget <= 0.0 || parsedSaved == null || parsedSaved < 0.0) {
                    Toast.makeText(context, "Angiv et navn, en målsum over 0 kr. og en gyldig opsparing.", Toast.LENGTH_LONG).show()
                } else if (date.isNotBlank() && runCatching { LocalDate.parse(date) }.isFailure) {
                    Toast.makeText(context, "Måldatoen skal være ÅÅÅÅ-MM-DD eller stå tom.", Toast.LENGTH_LONG).show()
                } else {
                    onSave(JSONObject(goal.toString()).put("name", name.trim()).put("target", parsedTarget).put("saved", parsedSaved).put("date", date.trim()))
                }
            }) { Text("Gem ændringer", color = Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } }
    )
}

@Composable
internal fun MultiBillImportDialog(
    drafts: List<BillImportDraft>,
    onDraftsChanged: (List<BillImportDraft>) -> Unit,
    onDismiss: () -> Unit,
    onImport: (List<BillImportDraft>) -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Gennemgå flere regninger", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Kontrollér afsender, beløb og dato for hver regning. OCR kan læse forkert; intet gemmes, før du trykker Importér.", color = Muted, fontSize = 12.sp)
                LazyColumn(Modifier.heightIn(max = 470.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(drafts, key = { it.id }) { draft ->
                        val draftIndex = drafts.indexOfFirst { it.id == draft.id }
                        Surface(color = PanelRaised, shape = RoundedCornerShape(16.dp), border = saldoCardBorder(), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = draft.selected, onCheckedChange = { checked -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(selected = checked) else it }) })
                                    Text("Regning ${draftIndex + 1}", color = White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (draft.selected) "Medtages" else "Springes over", color = Muted, fontSize = 10.sp)
                                }
                                OutlinedTextField(value = draft.name, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(name = value) else it }) }, label = { Text("Afsender / regning") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                OutlinedTextField(value = draft.amount, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(amount = value) else it }) }, label = { Text("Beløb i kr.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                OutlinedTextField(value = draft.date, onValueChange = { value -> onDraftsChanged(drafts.map { if (it.id == draft.id) it.copy(date = value) else it }) }, label = { Text("Forfaldsdato (ÅÅÅÅ-MM-DD)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = draft.selected)
                                if (draft.rawText.isNotBlank()) Text(draft.rawText.take(180), color = Muted, fontSize = 10.sp, maxLines = 3)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val selectedCount = drafts.count { it.selected }
                if (selectedCount == 0) Toast.makeText(context, "Vælg mindst én regning.", Toast.LENGTH_SHORT).show()
                else onImport(drafts)
            }) { Text("Importér valgte", color = Blue) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } }
    )
}
