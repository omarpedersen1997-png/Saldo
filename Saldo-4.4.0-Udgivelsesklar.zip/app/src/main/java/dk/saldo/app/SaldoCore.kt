package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// Encrypted storage, palette, money formatting, JSON helpers, data loading, account scoping and backup format.

// Saldo 4.4.0 — navy & gold redesign, bank-export import, recurring posts, month navigation and onboarding.
// Observable palette: all components that use these tokens update immediately when the user switches theme.
internal const val SALDO_PREFERENCES_NAME = "saldo_data_v4"

internal const val SALDO_ENCRYPTED_PREFERENCES_NAME = "saldo_data_v4_encrypted"

internal const val SALDO_ENCRYPTION_MIGRATION_MARKER = "_saldo_encrypted_migration_v1"

internal const val SALDO_PRIVACY_POLICY_URL = "https://omarpedersen1997-png.github.io/Saldo/privacy/"

internal const val SALDO_ACCOUNT_DELETION_URL = "https://omarpedersen1997-png.github.io/Saldo/account-deletion/"

internal val saldoPreferencesLock = Any()

@Volatile internal var cachedSaldoPreferences: SharedPreferences? = null

/** Encrypted preferences shared by the activity, reminder worker and home-screen widgets. */
fun saldoPreferences(context: Context): SharedPreferences = synchronized(saldoPreferencesLock) {
    cachedSaldoPreferences?.let { return@synchronized it }
    val legacy = context.applicationContext.getSharedPreferences(SALDO_PREFERENCES_NAME, Context.MODE_PRIVATE)
    val masterKey = MasterKey.Builder(context.applicationContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()
    val encrypted = EncryptedSharedPreferences.create(
        context.applicationContext,
        SALDO_ENCRYPTED_PREFERENCES_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    if (!encrypted.getBoolean(SALDO_ENCRYPTION_MIGRATION_MARKER, false)) {
        val values = legacy.all
        val editor = encrypted.edit()
        values.forEach { (key, value) ->
            if (key != SALDO_ENCRYPTION_MIGRATION_MARKER) {
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
            }
        }
        editor.putBoolean(SALDO_ENCRYPTION_MIGRATION_MARKER, true)
        check(editor.commit()) { "Saldo kunne ikke gemme de krypterede data. De oprindelige data er bevaret." }
    }
    // Do not leave a second, plaintext copy behind after migration or a previously interrupted run.
    if (legacy.all.isNotEmpty()) {
        check(legacy.edit().clear().commit()) { "Saldo kunne ikke rydde den gamle ukrypterede datakopi. Genstart appen, og kontrollér lagerpladsen." }
    }
    cachedSaldoPreferences = encrypted
    encrypted
}

// Navy & gold palette. Initial values are the dark theme; setSaldoPalette() applies the saved choice.
internal var Night by mutableStateOf(Color(0xFF0D1224))

internal var Panel by mutableStateOf(Color(0xFF151B33))

internal var PanelRaised by mutableStateOf(Color(0xFF1E2642))

internal var Violet by mutableStateOf(Color(0xFFD8BC84))

internal var Blue by mutableStateOf(Color(0xFF9AA9D6))

internal var Mint by mutableStateOf(Color(0xFF86CFAE))

internal var Muted by mutableStateOf(Color(0xFF9CA3BF))

internal var White by mutableStateOf(Color(0xFFE4E7F1))

internal var BorderSubtle by mutableStateOf(Color(0x14FFFFFF))

internal fun setSaldoPalette(dark: Boolean) {
    if (dark) {
        Night = Color(0xFF0D1224)
        Panel = Color(0xFF151B33)
        PanelRaised = Color(0xFF1E2642)
        Violet = Color(0xFFD8BC84)
        Blue = Color(0xFF9AA9D6)
        Mint = Color(0xFF86CFAE)
        Muted = Color(0xFF9CA3BF)
        White = Color(0xFFE4E7F1)
        BorderSubtle = Color(0x14FFFFFF)
    } else {
        Night = Color(0xFFF6F4EE)
        Panel = Color(0xFFFFFFFF)
        PanelRaised = Color(0xFFF2ECDD)
        Violet = Color(0xFF8A5A00)
        Blue = Color(0xFF1E3A8A)
        Mint = Color(0xFF047857)
        Muted = Color(0xFF5E6385)
        White = Color(0xFF0E1533)
        BorderSubtle = Color(0x1A0E1533)
    }
}

/** Reads a money setting exactly (string copy), falling back to the legacy Float key. */
internal fun SharedPreferences.saldoMoney(key: String, default: Double): Double =
    getString("${key}_exact", null)?.toDoubleOrNull()?.takeIf { it.isFinite() }
        ?: if (contains(key)) getFloat(key, default.toFloat()).toDouble() else default

/** Writes a money setting both as the legacy Float and as an exact string. */
internal fun SharedPreferences.Editor.putSaldoMoney(key: String, value: Double): SharedPreferences.Editor =
    putFloat(key, value.toFloat()).putString("${key}_exact", value.toString())

internal fun saldoBackgroundBrush(dark: Boolean): Brush = if (dark) {
    Brush.verticalGradient(listOf(Color(0xFF151C36), Color(0xFF10162C), Night, Color(0xFF0B0F1F)))
} else {
    Brush.verticalGradient(listOf(Color(0xFFFBF7EC), Color(0xFFF6F4EE), Color(0xFFF4F4F7), Color(0xFFEEF1F8)))
}

internal val homeSectionOptions = listOf(
    Triple("balance", "Rådighedsbeløb", "Saldo, dagligt beløb og næste løn"),
    Triple("quick", "Hurtige handlinger", "Tilføj post, regning og budget"),
    Triple("warnings", "Budgetadvarsler", "Vis budgetter, der nærmer sig grænsen"),
    Triple("summary", "Månedens tal", "Indtægter og udgifter"),
    Triple("cashflow", "Pengestrøm", "Sammenlign månedens indtægter og udgifter"),
    Triple("bills", "Kommende regninger", "Vis de næste ubetalte regninger"),
    Triple("activity", "Seneste aktivitet", "Vis de seneste poster")
)

internal val defaultHomeSections = homeSectionOptions.map { it.first }

// NumberFormat is expensive to create and not thread-safe: cache one per thread. money() runs on
// every recomposition and every frame of an animated amount.
internal val saldoMoneyFormat = object : ThreadLocal<NumberFormat>() {
    override fun initialValue(): NumberFormat = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { minimumFractionDigits = 2; maximumFractionDigits = 2 }
}

internal fun moneyPlain(v: Double): String = saldoMoneyFormat.get()!!.format(if (v.isFinite()) v else 0.0) + " kr."

/** Privacy mode: on-screen amounts are masked. Exports, reports and notifications use [moneyPlain]. */
internal var saldoAmountsHidden by mutableStateOf(false)

internal fun money(v: Double): String = if (saldoAmountsHidden) "•••• kr." else moneyPlain(v)

internal fun parseDanishAmount(raw: String): Double? {
    val cleaned = raw.trim().replace(" ", "").replace("\u00A0", "").replace("\u202F", "")
    if (cleaned.isBlank()) return null
    val normalized = if (cleaned.contains(',')) cleaned.replace(".", "").replace(',', '.')
        else if (Regex("^-?\\d{1,3}(?:\\.\\d{3})+$").matches(cleaned)) cleaned.replace(".", "")
        else cleaned
    return normalized.toDoubleOrNull()?.takeIf { it.isFinite() && kotlin.math.abs(it) <= 1_000_000_000_000.0 }
}

internal fun JSONObject.s(k: String, d: String = "") = optString(k, d).let { if (it == "null") d else it }

internal fun JSONObject.n(k: String, d: Double = 0.0) = optDouble(k, d)

internal fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }

internal fun record(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }

internal val saldoCollectionKeys = listOf("transactions", "bills", "budgets", "goals", "debts", "subs", "fuel")

/** Coalesces widget refreshes and runs RemoteViews work off the UI thread. */
internal object SaldoWidgetRefreshQueue {
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "SaldoWidgetRefresh").apply { isDaemon = true }
    }
    @Volatile private var pending: ScheduledFuture<*>? = null

    @Synchronized
    fun request(context: Context) {
        pending?.cancel(false)
        val appContext = context.applicationContext
        pending = executor.schedule({
            runCatching { SaldoWidgetUpdater.updateAll(appContext) }
        }, 120, TimeUnit.MILLISECONDS)
    }
}

internal fun emptySaldoData(): JSONObject = JSONObject().apply {
    saldoCollectionKeys.forEach { put(it, JSONArray()) }
}

internal fun isEmptySaldoDataObject(data: JSONObject): Boolean = saldoCollectionKeys.all { key ->
    (data.optJSONArray(key)?.length() ?: 0) == 0
}

internal fun hasAnySaldoRecords(data: JSONObject): Boolean = saldoCollectionKeys.any { key ->
    (data.optJSONArray(key)?.length() ?: 0) > 0
}

internal fun persistSaldoSettingsForActiveAccount(prefs: android.content.SharedPreferences) {
    val userId = prefs.getString("active_account_user_id", null).orEmpty()
    if (userId.isNotBlank()) prefs.edit().putString(localAccountSettingsKey(userId), saldoSettingsJson(prefs).toString()).apply()
}

internal fun normalizeSaldoData(source: JSONObject): JSONObject = JSONObject(source.toString()).apply {
    // Older versions did not always include every collection. Missing collections are safe to
    // initialize, but malformed collections are rejected by validation before normalization.
    saldoCollectionKeys.forEach { key -> if (!has(key)) put(key, JSONArray()) }
    listOf("transactions", "bills", "budgets", "subs").forEach { key ->
        optJSONArray(key)?.objects()?.forEach { item ->
            val owner = item.s("owner").trim()
            when {
                owner.equals("Kæreste", ignoreCase = true) -> item.put("owner", "Partner")
                owner.isNotBlank() -> item.put("owner", owner)
            }
        }
    }
    // LazyColumn keys and deletion actions rely on unique IDs. Repair IDs in older/malformed
    // backups once, before the normalized snapshot is persisted, to avoid deleting multiple rows.
    saldoCollectionKeys.forEach { key ->
        val array = optJSONArray(key) ?: return@forEach
        val seenIds = mutableSetOf<String>()
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val existingId = item.s("id").trim()
            if (existingId.isBlank() || !seenIds.add(existingId)) {
                var replacement: String
                do {
                    replacement = "migrated-$key-${java.util.UUID.randomUUID()}"
                } while (!seenIds.add(replacement))
                item.put("id", replacement)
            }
        }
    }
}

internal data class LoadedSaldoData(val data: JSONObject, val recoveryNotice: String?)

internal fun localAccountDataKey(userId: String) = "saldo_account_data_$userId"

internal fun localAccountBackupKey(userId: String) = "saldo_account_backup_$userId"

internal fun localAccountSettingsKey(userId: String) = "saldo_account_settings_$userId"

internal fun findValidLocalRecoveryData(prefs: android.content.SharedPreferences): JSONObject? {
    val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
    val candidates = buildList {
        if (activeUserId.isNotBlank()) {
            // Once an online account is active, recover only from that account's scoped copies.
            // Never fall back to a legacy global backup that may belong to a different user.
            prefs.getString(localAccountDataKey(activeUserId), null)?.let(::add)
            prefs.getString(localAccountBackupKey(activeUserId), null)?.let(::add)
        } else {
            // Global recovery points are allowed only before any online account is attached.
            prefs.getString("auto_backup_data", null)?.let(::add)
        }
    }
    return candidates.firstNotNullOfOrNull { rawCandidate ->
        val candidate = runCatching { JSONObject(rawCandidate) }.getOrNull() ?: return@firstNotNullOfOrNull null
        candidate.takeIf { isValidSaldoDataObject(it) && hasAnySaldoRecords(it) }
    }
}

/** Load local data without ever turning a parse/validation failure into an unprotected empty overwrite. */
internal fun loadSaldoDataSafely(prefs: android.content.SharedPreferences): LoadedSaldoData {
    val raw = prefs.getString("data", null)
    if (raw == null) {
        val activeUserId = prefs.getString("active_account_user_id", null).orEmpty()
        val scopedData = activeUserId.takeIf { it.isNotBlank() }
            ?.let { prefs.getString(localAccountDataKey(it), null) }
            ?.let { runCatching { JSONObject(it) }.getOrNull() }
        if (scopedData != null && isValidSaldoDataObject(scopedData) && hasAnySaldoRecords(scopedData)) {
            val restored = normalizeSaldoData(scopedData)
            check(prefs.edit().putString("data", restored.toString()).commit()) {
                "Saldo kunne ikke gemme de gendannede data. Den oprindelige kontokopi er bevaret."
            }
            return LoadedSaldoData(restored, "Saldo gendannede de lokale data fra kontoens gemte kopi. Kontrollér dine poster.")
        }
        // A missing active cache can happen after an interrupted update. Prefer a validated,
        // non-empty recovery point over silently starting with an empty financial overview.
        val recovery = findValidLocalRecoveryData(prefs)
        if (recovery != null) {
            val restored = normalizeSaldoData(recovery)
            check(prefs.edit().putString("data", restored.toString()).commit()) {
                "Saldo kunne ikke gemme de gendannede data. Den oprindelige backup er bevaret."
            }
            return LoadedSaldoData(restored, "Saldo gendannede et lokalt gendannelsespunkt, fordi den aktive datafil manglede. Kontrollér dine poster.")
        }
        return LoadedSaldoData(emptySaldoData(), null)
    }
    val parsed = runCatching { JSONObject(raw) }.getOrNull()
    if (parsed != null && parsed.length() > 0 && isValidSaldoDataObject(parsed)) {
        return LoadedSaldoData(normalizeSaldoData(parsed), null)
    }
    val recoveryCandidate = findValidLocalRecoveryData(prefs)
    if (parsed != null && parsed.length() == 0 && recoveryCandidate == null) {
        // Empty JSON was used by older versions for a fresh install; don't warn on that case.
        return LoadedSaldoData(emptySaldoData(), null)
    }

    // Preserve the damaged input for diagnostics/recovery instead of silently destroying it.
    prefs.edit().putString("corrupt_data_backup", raw).apply()
    if (recoveryCandidate != null) {
        val restored = normalizeSaldoData(recoveryCandidate)
        prefs.edit().putString("data", restored.toString()).apply()
        val message = if (parsed?.length() == 0) {
            "Saldo fandt tomme lokale data, men der var en gyldig backup. Backupen er gendannet; kontrollér dine poster."
        } else {
            "Saldo fandt ugyldige lokale data og gendannede den seneste gyldige lokale kopi. Kontrollér dine poster."
        }
        return LoadedSaldoData(restored, message)
    }
    val empty = emptySaldoData()
    prefs.edit().putString("data", empty.toString()).apply()
    return LoadedSaldoData(empty, "Saldo kunne ikke læse de lokale data. De oprindelige data er bevaret internt som gendannelsesmateriale, og appen er startet med et tomt datasæt. Gendan en kendt backup hurtigst muligt.")
}

/** Keep local data separated when multiple online accounts use the same device. */
internal fun switchToAccountData(
    prefs: android.content.SharedPreferences,
    currentData: JSONObject,
    newUserId: String
): JSONObject {
    require(newUserId.isNotBlank()) { "Onlinekontoen kunne ikke identificeres." }
    val oldUserId = prefs.getString("active_account_user_id", null).orEmpty()
    val currentSnapshot = normalizeSaldoData(currentData).toString()
    val editor = prefs.edit()

    if (oldUserId.isNotBlank() && oldUserId != newUserId) {
        // Every regular data/settings change already updates the scoped snapshot. After logout,
        // the shared active cache is intentionally empty; never copy that empty cache over the
        // previous account's real snapshot or settings during the next account's login.
        val hasSavedProfileSnapshot = prefs.contains(localAccountDataKey(oldUserId))
        val shouldCommitCurrentData = hasAnySaldoRecords(currentData) || !hasSavedProfileSnapshot
        if (shouldCommitCurrentData) {
            editor.putString(localAccountDataKey(oldUserId), currentSnapshot)
                .putString(localAccountSettingsKey(oldUserId), saldoSettingsJson(prefs).toString())
        } else if (!prefs.contains(localAccountSettingsKey(oldUserId))) {
            editor.putString(localAccountSettingsKey(oldUserId), saldoSettingsJson(prefs).toString())
        }
        prefs.getString("auto_backup_data", null)?.let { editor.putString(localAccountBackupKey(oldUserId), it) }
    }

    val switchingToDifferentAccount = oldUserId.isNotBlank() && oldUserId != newUserId
    val candidateRaw = prefs.getString(localAccountDataKey(newUserId), null)
    val candidate = candidateRaw?.let { runCatching { JSONObject(it) }.getOrNull() }
    val selected = when {
        switchingToDifferentAccount && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        switchingToDifferentAccount -> emptySaldoData()
        oldUserId.isBlank() && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        oldUserId == newUserId && isEmptySaldoDataObject(currentData) && candidate != null && isValidSaldoDataObject(candidate) -> normalizeSaldoData(candidate)
        else -> normalizeSaldoData(currentData)
    }
    val selectedSnapshot = selected.toString()
    editor.putString("active_account_user_id", newUserId)
        .putString("data", selectedSnapshot)
        .putString(localAccountDataKey(newUserId), selectedSnapshot)

    val settingsRaw = prefs.getString(localAccountSettingsKey(newUserId), null)
    val savedSettings = settingsRaw?.let { runCatching { JSONObject(it) }.getOrNull() }
    if (switchingToDifferentAccount) {
        // Reset settings first so malformed/missing settings from the next account
        // can never inherit the previous account's salary, payday, or cash balance.
        editor.putSaldoMoney("pay_amount", 10000.0).remove("payday").remove("pay_frequency").remove("cash_balance").remove("cash_balance_exact")
        if (savedSettings != null) applySaldoSettings(savedSettings, editor)
    } else if (savedSettings != null && ((oldUserId.isBlank() && candidate != null && isValidSaldoDataObject(candidate)) ||
            (oldUserId == newUserId && isEmptySaldoDataObject(currentData) && candidate != null && isValidSaldoDataObject(candidate)))) {
        applySaldoSettings(savedSettings, editor)
    } else {
        editor.putString(localAccountSettingsKey(newUserId), saldoSettingsJson(prefs).toString())
    }

    val backupRaw = prefs.getString(localAccountBackupKey(newUserId), null)
    if (switchingToDifferentAccount) {
        if (backupRaw == null) editor.remove("auto_backup_data") else editor.putString("auto_backup_data", backupRaw)
    } else if (((oldUserId.isBlank() || (oldUserId == newUserId && isEmptySaldoDataObject(currentData))) && candidate != null && isValidSaldoDataObject(candidate)) && backupRaw != null) {
        editor.putString("auto_backup_data", backupRaw)
    } else {
        val existingBackup = prefs.getString("auto_backup_data", null)
        if (existingBackup != null) editor.putString(localAccountBackupKey(newUserId), existingBackup)
    }
    editor.putLong("auto_backup_time", System.currentTimeMillis()).apply()
    return selected
}

internal data class ParsedSaldoBackup(val data: JSONObject, val settings: JSONObject?)

internal fun isValidSaldoDataObject(root: JSONObject): Boolean = runCatching {
    // Empty objects are not valid backups/cloud payloads: otherwise an empty response could
    // overwrite working local financial data. Fresh installs use emptySaldoData() directly.
    if (root.length() == 0) return@runCatching false
    val knownCollections = saldoCollectionKeys
    if (knownCollections.none { key -> root.has(key) && root.opt(key) is JSONArray }) return@runCatching false
    knownCollections.all { key ->
        if (!root.has(key)) true
        else {
            val array = root.optJSONArray(key) ?: return@all false
            (0 until array.length()).all { index ->
                val item = array.optJSONObject(index) ?: return@all false
                val numericFields = when (key) {
                    "transactions", "bills" -> listOf("amount")
                    "budgets" -> listOf("limit")
                    "goals" -> listOf("target", "saved")
                    "debts" -> listOf("balance", "rate", "payment")
                    "subs" -> listOf("monthly")
                    "fuel" -> listOf("liters", "cost", "km")
                    else -> emptyList()
                }
                numericFields.all { field ->
                    if (!item.has(field)) field in setOf("saved", "rate", "payment", "km")
                    else {
                        val value = item.optDouble(field, Double.NaN)
                        value.isFinite() && kotlin.math.abs(value) <= 1_000_000_000_000.0 &&
                            (field !in setOf("amount", "limit", "target", "monthly", "liters", "cost") || value > 0.0) &&
                            (field !in setOf("saved", "rate", "payment", "balance", "km") || value >= 0.0)
                    }
                }
            }
        }
    }
}.getOrDefault(false)

internal fun parseSaldoBackup(raw: String): ParsedSaldoBackup? = runCatching {
    val root = JSONObject(raw)
    if (root.optString("format") == "dk.saldo.app.backup") {
        val data = root.optJSONObject("data") ?: return@runCatching null
        if (!isValidSaldoDataObject(data)) return@runCatching null
        val settings = root.optJSONObject("settings")
        if (settings != null) {
            val salary = settings.optDouble("payAmount", 10000.0)
            if (!salary.isFinite() || salary <= 0.0 || salary > 1_000_000_000_000.0) return@runCatching null
            if (settings.optBoolean("hasPayday", false) && runCatching { LocalDate.parse(settings.optString("payday")) }.isFailure) return@runCatching null
            if (settings.optBoolean("hasCashBalance", false) && (!settings.optDouble("cashBalance", Double.NaN).isFinite() || kotlin.math.abs(settings.optDouble("cashBalance", Double.NaN)) > 1_000_000_000_000.0)) return@runCatching null
        }
        ParsedSaldoBackup(data, settings)
    } else {
        if (!isValidSaldoDataObject(root)) return@runCatching null
        ParsedSaldoBackup(root, null)
    }
}.getOrNull()

internal fun isValidSaldoBackup(raw: String): Boolean = parseSaldoBackup(raw) != null

internal fun saldoSettingsJson(prefs: android.content.SharedPreferences): JSONObject {
    val hasBalance = prefs.contains("cash_balance")
    val settings = JSONObject()
        .put("payAmount", prefs.saldoMoney("pay_amount", 10000.0))
        .put("hasPayday", prefs.contains("payday"))
        .put("payFrequency", prefs.getString("pay_frequency", null) ?: "monthly")
        .put("payday", prefs.getString("payday", "") ?: "")
        .put("hasCashBalance", hasBalance)
    if (hasBalance) settings.put("cashBalance", prefs.saldoMoney("cash_balance", 0.0))
    return settings
}

internal fun applySaldoSettings(settings: JSONObject, editor: android.content.SharedPreferences.Editor) {
    val salary = settings.optDouble("payAmount", 10000.0)
    if (salary.isFinite() && salary > 0.0 && salary <= 1_000_000_000_000.0) editor.putSaldoMoney("pay_amount", salary)
    settings.optString("payFrequency", "").takeIf { it in setOf("monthly", "biweekly", "weekly") }?.let { editor.putString("pay_frequency", it) }
    if (settings.optBoolean("hasPayday", false)) {
        val payday = settings.optString("payday", "")
        if (runCatching { LocalDate.parse(payday) }.isSuccess) editor.putString("payday", payday)
    } else editor.remove("payday").remove("pay_frequency")
    if (settings.optBoolean("hasCashBalance", false)) {
        val balance = settings.optDouble("cashBalance", Double.NaN)
        if (balance.isFinite() && kotlin.math.abs(balance) <= 1_000_000_000_000.0) editor.putSaldoMoney("cash_balance", balance)
    } else editor.remove("cash_balance").remove("cash_balance_exact")
}

internal fun buildBackupJson(data: JSONObject, prefs: android.content.SharedPreferences): String = JSONObject()
    .put("format", "dk.saldo.app.backup")
    .put("schemaVersion", 1)
    .put("exportedAt", java.time.Instant.now().toString())
    .put("data", JSONObject(data.toString()))
    .put("settings", saldoSettingsJson(prefs))
    .toString(2)
