package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// CSV import: bank-format detection, parsing, categorisation and learning.

internal fun parseBillText(text: String): Triple<String, String, String> {
    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
    val vendor = lines.firstOrNull { line ->
        line.length in 3..70 && line.any { it.isLetter() } &&
            !line.contains("faktura", true) && !line.contains("invoice", true) &&
            !line.contains("betalingsoversigt", true)
    }?.take(70).orEmpty()

    val datePatterns = listOf(
        Regex("(?<!\\d)(20\\d{2})[-./](0?[1-9]|1[0-2])[-./]([0-2]?\\d|3[01])(?!\\d)"),
        Regex("(?<!\\d)([0-3]?\\d)[./-](0?[1-9]|1[0-2])[./-](20\\d{2})(?!\\d)")
    )
    var date = ""
    for ((index, pattern) in datePatterns.withIndex()) {
        val match = pattern.find(text) ?: continue
        date = if (index == 0) {
            runCatching { LocalDate.of(match.groupValues[1].toInt(), match.groupValues[2].toInt(), match.groupValues[3].toInt()).toString() }.getOrDefault("")
        } else {
            runCatching { LocalDate.of(match.groupValues[3].toInt(), match.groupValues[2].toInt(), match.groupValues[1].toInt()).toString() }.getOrDefault("")
        }
        if (date.isNotBlank()) break
    }

    val moneyRegex = Regex("(?i)(?:i alt|total|at betale|beløb|amount|kr\\.?)[^\\d]{0,18}([0-9][0-9 .]*[,\\.][0-9]{2})")
    val match = moneyRegex.find(text) ?: Regex("(?<!\\d)([0-9]{1,3}(?:[ .][0-9]{3})*(?:[,\\.][0-9]{2}))(?!\\d)").find(text)
    val amount = match?.groupValues?.lastOrNull()?.let { parseDanishAmount(it) }?.takeIf { it > 0 }?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
    return Triple(vendor, amount, date)
}

internal data class CsvImportPlan(
    val recordsByCollection: Map<String, List<JSONObject>>,
    val rowsRead: Int,
    val skippedRows: Int,
    val invalidRows: Int,
    val columnSummary: String = ""
)

internal val csvDateHeaderAliases = listOf("dato", "date", "bogføringsdato", "bogfoeringsdato", "bogført", "bogfort", "posteringsdato", "transaktionsdato", "valutadato", "rentedato", "valør", "booking date", "transaction date", "posting date")

internal val csvAmountHeaderAliases = listOf("beløb", "belob", "amount", "beløb dkk", "transaktionsbeløb", "indbetaling", "udbetaling", "kredit", "debet", "credit", "debit", "beløb ind", "beløb ud")

internal data class CsvKnownTransaction(
    val name: String,
    val category: String,
    val type: String,
    val amount: Double
)

internal data class CsvCategoryContext(
    val existingCategories: List<String> = emptyList(),
    val knownTransactions: List<CsvKnownTransaction> = emptyList(),
    val learnedMerchantCategories: Map<String, String> = emptyMap()
)

internal data class BillImportDraft(
    val id: String,
    val name: String,
    val amount: String,
    val date: String,
    val selected: Boolean = true,
    val rawText: String = ""
)

internal fun readTextFromUri(context: Context, uri: Uri, maxBytes: Int): String {
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalArgumentException("Filen kunne ikke åbnes.")
    val bytes = input.use { stream ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "CSV-filen er større end ${maxBytes / (1024 * 1024)} MB." }
            output.write(buffer, 0, count)
        }
        output.toByteArray()
    }
    return String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
}

internal fun csvNormalized(value: String): String {
    val expanded = value.lowercase(Locale.ROOT)
        .replace("æ", "ae").replace("ø", "o").replace("å", "a")
    return Normalizer.normalize(expanded, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9]+"), "")
}

internal fun parseCsvMatrix(raw: String): List<List<String>> {
    val text = raw.removePrefix("\uFEFF")
    val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() }
        ?: throw IllegalArgumentException("CSV-filen er tom.")
    val delimiterCounts = linkedMapOf(';' to 0, '\t' to 0, ',' to 0)
    var delimiterQuoted = false
    var delimiterIndex = 0
    while (delimiterIndex < firstLine.length) {
        val ch = firstLine[delimiterIndex]
        when {
            ch == '"' && delimiterQuoted && delimiterIndex + 1 < firstLine.length && firstLine[delimiterIndex + 1] == '"' -> delimiterIndex++
            ch == '"' -> delimiterQuoted = !delimiterQuoted
            !delimiterQuoted && delimiterCounts.containsKey(ch) -> delimiterCounts[ch] = (delimiterCounts[ch] ?: 0) + 1
        }
        delimiterIndex++
    }
    val delimiter = delimiterCounts.entries.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key ?: ';'
    val rows = mutableListOf<List<String>>()
    val row = mutableListOf<String>()
    val cell = StringBuilder()
    var quoted = false
    var i = 0
    while (i < text.length) {
        val ch = text[i]
        when {
            ch == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> {
                cell.append('"'); i++
            }
            ch == '"' -> quoted = !quoted
            ch == delimiter && !quoted -> {
                row += cell.toString(); cell.setLength(0)
            }
            (ch == '\n' || ch == '\r') && !quoted -> {
                if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                row += cell.toString(); cell.setLength(0)
                if (row.any { it.isNotBlank() }) rows += row.toList()
                row.clear()
            }
            else -> cell.append(ch)
        }
        i++
    }
    row += cell.toString()
    if (row.any { it.isNotBlank() }) rows += row.toList()
    require(!quoted) { "CSV-filen indeholder an uafsluttet tekst med anførselstegn." }
    return rows
}

internal fun parseCsvDate(raw: String): String? {
    val value = raw.trim().removePrefix("\uFEFF")
    if (value.isBlank()) return null
    runCatching { return LocalDate.parse(value).toString() }
    val formats = listOf(
        "d.M.uuuu", "dd.MM.uuuu", "d/M/uuuu", "dd/MM/uuuu",
        "d-M-uuuu", "dd-MM-uuuu", "uuuu/M/d", "uuuu.MM.dd"
    )
    formats.forEach { pattern ->
        runCatching { return LocalDate.parse(value, java.time.format.DateTimeFormatter.ofPattern(pattern, Locale.ROOT)).toString() }
    }
    return null
}

internal fun parseCsvMoney(raw: String): Double? {
    var value = raw.trim()
    if (value.isBlank()) return null
    val parenthesized = value.startsWith("(") && value.endsWith(")")
    value = value.removePrefix("(").removeSuffix(")")
        .replace(Regex("(?i)kr\\.?|dkk|sek|eur|usd"), "")
        .replace("\u00A0", "").replace("\u202F", "").replace(" ", "")
        .replace(Regex("[^0-9,.+-]"), "")
    if (value.isBlank() || value in setOf(".", ",", "-", "+")) return null
    val negative = parenthesized || value.startsWith("-")
    value = value.removePrefix("+").removePrefix("-")
    val comma = value.lastIndexOf(',')
    val dot = value.lastIndexOf('.')
    val normalized = when {
        comma >= 0 && dot >= 0 -> {
            // The rightmost separator is the decimal separator: 1.234,56 or 1,234.56.
            if (comma > dot) value.replace(".", "").replace(',', '.') else value.replace(",", "")
        }
        comma >= 0 -> {
            val decimals = value.length - comma - 1
            when {
                value.count { it == ',' } > 1 && decimals in 1..2 -> value.substring(0, comma).replace(",", "") + "." + value.substring(comma + 1)
                value.count { it == ',' } > 1 -> value.replace(",", "")
                decimals in 1..2 -> value.replace(',', '.')
                decimals == 3 && value.substring(0, comma).length in 1..3 -> value.replace(",", "")
                else -> value.replace(',', '.')
            }
        }
        dot >= 0 -> {
            val decimals = value.length - dot - 1
            when {
                value.count { it == '.' } > 1 && decimals in 1..2 -> value.substring(0, dot).replace(".", "") + "." + value.substring(dot + 1)
                value.count { it == '.' } > 1 -> value.replace(".", "")
                decimals == 3 && value.substring(0, dot).length in 1..3 -> value.replace(".", "")
                else -> value
            }
        }
        else -> value
    }
    val parsed = normalized.toDoubleOrNull() ?: return null
    if (!parsed.isFinite() || kotlin.math.abs(parsed) > 1_000_000_000_000.0) return null
    return if (negative) -kotlin.math.abs(parsed) else kotlin.math.abs(parsed)
}

internal fun csvRecordFingerprint(collection: String, item: JSONObject): String {
    fun text(key: String) = item.s(key).trim().lowercase(Locale.ROOT)
    fun amount(key: String) = String.format(Locale.ROOT, "%.2f", item.n(key))
    fun owner() = normalizedOwner(item.s("owner", "Mig"))
    val parts = when (collection) {
        "transactions" -> listOf(text("name"), text("date"), text("type"), owner(), amount("amount"))
        "bills" -> listOf(text("name"), text("date"), owner(), amount("amount"))
        "budgets" -> listOf(text("category"), owner())
        "goals" -> listOf(text("name"), text("date"), amount("target"), amount("saved"))
        "debts" -> listOf(text("name"), amount("balance"))
        "subs" -> listOf(text("name"), text("renewalDate"), owner(), amount("monthly"))
        "fuel" -> listOf(text("date"), amount("liters"), amount("cost"), amount("km"))
        else -> listOf(item.toString())
    }
    return collection + "|" + parts.joinToString("\u001f")
}

internal fun csvRecordsEquivalent(collection: String, a: JSONObject, b: JSONObject): Boolean =
    csvRecordFingerprint(collection, a) == csvRecordFingerprint(collection, b)

internal fun csvContainsAny(value: String, vararg words: String): Boolean {
    val normalized = csvNormalized(value)
    return words.any { word -> normalized.contains(csvNormalized(word)) }
}

/** Maps a bank-export direction/type column to Saldo's two transaction types. */
internal fun csvDirection(value: String): String? {
    val n = csvNormalized(value)
    if (n.isBlank()) return null
    // Explicit card/purchase terms must win over incidental words such as "credit card".
    if (listOf("kortbetaling", "kortkoeb", "debitcard", "creditcard", "kreditkort", "withdrawal", "udbetaling", "udgift", "expense", "debit", "debet", "outflow", "cashwithdrawal", "purchase", "koeb").any { n.contains(it) }) {
        return "Udgift"
    }
    if (listOf("løn", "loen", "salary", "payroll", "indbetaling", "deposit", "refund", "refusion", "cashback", "credit", "kredit", "indtægt", "indtaegt", "income", "inflow", "incoming", "incomingtransfer", "børnepenge", "boernepenge", "dagpenge", "kontanthjælp", "kontanthjaelp", "feriepenge", "renteindtægt", "renteindtaegt", "received").any { n.contains(csvNormalized(it)) }) {
        return "Indtægt"
    }
    return when (n) {
        "ind", "indgaaende", "modtaget", "positiv", "plus", "tilgang" -> "Indtægt"
        "ud", "udgaaende", "negativ", "minus", "afgang", "betaling" -> "Udgift"
        else -> null
    }
}

internal fun csvDescriptionLooksLikeIncome(description: String): Boolean = csvContainsAny(
    description,
    "løn", "lønoverførsel", "loen", "salary", "payroll", "wages", "børnepenge", "boernepenge",
    "kontanthjælp", "kontanthjaelp", "dagpenge", "feriepenge", "su udbetaling", "udbetaling danmark",
    "pension", "refusion", "tilbagebetaling", "refund", "cashback", "renteindtægt", "renteindtaegt", "overførsel fra", "overfoersel fra", "modtaget fra", "indbetaling"
)

internal data class CsvCategorySuggestion(
    val category: String,
    val confidence: Int,
    val reason: String
)

internal fun csvMerchantKey(value: String): String {
    val expanded = Normalizer.normalize(
        value.lowercase(Locale.ROOT).replace("æ", "ae").replace("ø", "o").replace("å", "a"),
        Normalizer.Form.NFD
    ).replace(Regex("\\p{Mn}+"), "")
    val stopWords = setOf(
        "kort", "kortkoeb", "kortbetaling", "betaling", "betalingsservice", "pbs", "dankort", "visa",
        "mastercard", "purchase", "card", "payment", "transaction", "transaktion", "pos", "køb", "koeb", "outgoing", "outgoingpayment",
        "overfoersel", "overførsel", "udbetaling", "indbetaling", "fra", "til", "ref", "reference", "nr"
    )
    return Regex("[a-z0-9]+").findAll(expanded).map { it.value }
        .filter { token -> token.length >= 2 && !token.all { it.isDigit() } && token !in stopWords }
        .take(5).joinToString("-")
}

internal fun csvLearningKey(description: String, transactionType: String): String =
    "${csvNormalized(transactionType)}|${csvMerchantKey(description)}"

internal fun csvIsGenericCategory(value: String): Boolean = csvNormalized(value) in setOf(
    "", "diverse", "importeret", "ukendt", "unknown", "other", "andet", "ovrigt", "uncategorized",
    "uncategorised", "none", "na", "notcategorized", "generel", "indtaegt", "udgift", "expense",
    "income", "transaction", "transaktion", "standard"
)

internal fun csvPreferredCategory(context: CsvCategoryContext, candidates: List<String>, fallback: String): String {
    return candidates.firstNotNullOfOrNull { candidate ->
        context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(candidate) }
    } ?: fallback
}

internal data class CsvCategoryRule(
    val keywords: List<String>,
    val preferredCategories: List<String>,
    val fallback: String,
    val confidence: Int,
    val explanation: String
)

internal fun csvCategoryRules(transactionType: String): List<CsvCategoryRule> {
    if (transactionType == "Indtægt") return listOf(
        CsvCategoryRule(listOf("løn", "loen", "salary", "payroll", "wages", "lønoverførsel", "arbejdsgiver", "lonoverforsel"), listOf("Løn", "Lønindkomst"), "Løn", 98, "Beskrivelsen ligner en lønudbetaling"),
        CsvCategoryRule(listOf("børnepenge", "boernepenge", "kontanthjælp", "kontanthjaelp", "dagpenge", "feriepenge", "su udbetaling", "udbetaling danmark", "pension", "ydelse"), listOf("Ydelser", "Børnepenge", "Kontanthjælp"), "Ydelser", 94, "Beskrivelsen ligner en offentlig ydelse"),
        CsvCategoryRule(listOf("refusion", "tilbagebetaling", "refund", "cashback", "renteindtægt", "renteindtaegt", "returvare"), listOf("Tilbagebetaling", "Refunderinger"), "Tilbagebetaling", 93, "Beskrivelsen ligner en tilbagebetaling"),
        CsvCategoryRule(listOf("rente", "interest payment", "renteindtægt", "renteindtaegt"), listOf("Renteindtægter", "Renter"), "Renteindtægter", 87, "Beskrivelsen nævner renter"),
        CsvCategoryRule(listOf("overførsel fra", "overfoersel fra", "mobilepay fra", "modtaget fra", "indbetaling fra"), listOf("Overførsler", "Private overførsler"), "Overførsler", 78, "Beskrivelsen ligner en overførsel"),
    )
    return listOf(
        CsvCategoryRule(listOf("daginstitution", "dagpleje", "børnehave", "boernehave", "sfo", "fritidsordning", "skolebetaling", "børnepasning", "boernepasning"), listOf("Daginstitution", "Familie", "Børn"), "Daginstitution", 96, "Beskrivelsen ligner en udgift til pasning eller skole"),
        CsvCategoryRule(listOf("husleje", "boligforening", "realkredit", "boligafgift", "boliglaan", "boliglån", "ejendomsskat", "husleje"), listOf("Husleje", "Bolig"), "Husleje", 96, "Beskrivelsen ligner en boligbetaling"),
        CsvCategoryRule(listOf("forsikring", "insurance", "codan", "topdanmark", "tryg", "alm brand", "gjensidige"), listOf("Forsikring", "Regninger"), "Forsikring", 94, "Beskrivelsen ligner en forsikringsbetaling"),
        CsvCategoryRule(listOf("internet", "bredbånd", "bredbaand", "fiber", "yousee internet"), listOf("Internet", "Regninger"), "Internet", 94, "Beskrivelsen ligner en internetregning"),
        CsvCategoryRule(listOf("mobilabonnement", "mobilregning", "mobilbetaling", "telenor", "telia", "3 danmark", "telefonregning", "mobil"), listOf("Mobil", "Telefon", "Regninger"), "Mobil", 92, "Beskrivelsen ligner en mobil- eller telefonregning"),
        CsvCategoryRule(listOf("elregning", "elbetaling", "elselskab", "stromregning", "strømregning", "elafgift", "norlys el"), listOf("El", "El og vand", "Regninger"), "El", 91, "Beskrivelsen ligner en elregning"),
        CsvCategoryRule(listOf("varmeregning", "fjernvarme", "varmebetaling", "varmeværk", "varmevaerk", "varmeudgift"), listOf("Varme", "El og vand", "Regninger"), "Varme", 92, "Beskrivelsen ligner en varmeregning"),
        CsvCategoryRule(listOf("vandregning", "vandafgift", "vandforsyning", "vandværk", "vandvaerk"), listOf("Vand", "El og vand", "Regninger"), "Vand", 91, "Beskrivelsen ligner en vandregning"),
        CsvCategoryRule(listOf("netto", "føtex", "foetex", "rema1000", "rema 1000", "lidl", "coop", "superbrugsen", "brugsen", "meny", "bilka", "aldi", "dagli brugsen", "dagligvarer", "discount"), listOf("Dagligvarer", "Mad"), "Dagligvarer", 94, "Butikken ligner et dagligvareindkøb"),
        CsvCategoryRule(listOf("restaurant", "cafe", "café", "wolt", "justeat", "foodora", "pizza", "takeaway", "kantine", "mcdonald", "burger king", "sunset boulevard"), listOf("Spisesteder", "Mad ude", "Mad"), "Spisesteder", 91, "Beskrivelsen ligner mad ude eller takeaway"),
        CsvCategoryRule(listOf("okbenzin", "circlek", "q8", "shell", "benzin", "diesel", "tankstation", "brændstof", "braendstof", "fuel"), listOf("Brændstof", "Bil", "Transport"), "Brændstof", 94, "Beskrivelsen ligner brændstof eller tankning"),
        CsvCategoryRule(listOf("dsb", "rejsekort", "togbillet", "busbillet", "metro", "pendlerkort", "flextrafik", "taxa", "taxi", "uber", "bolt", "parkering", "brobizz"), listOf("Transport", "Parkering", "Bil"), "Transport", 90, "Beskrivelsen ligner transport"),
        CsvCategoryRule(listOf("netflix", "spotify", "disneyplus", "disney plus", "tv2play", "tv 2 play", "hbo", "viaplay", "youtube premium", "icloud", "google one", "streaming", "abonnement", "amzn prime"), listOf("Streaming", "Abonnementer"), "Abonnementer", 95, "Tjenesten ligner et abonnement"),
        CsvCategoryRule(listOf("apotek", "læge", "laege", "tandlæge", "tandlaege", "medicin", "hospital", "sundhed", "fysioterapi", "optiker"), listOf("Sundhed", "Medicin"), "Sundhed", 92, "Beskrivelsen ligner en sundhedsudgift"),
        CsvCategoryRule(listOf("fitness", "fitnesscenter", "fitness world", "puregym", "sportsklub", "motionscenter"), listOf("Fitness", "Sport"), "Fitness", 91, "Beskrivelsen ligner fitness eller sport"),
        CsvCategoryRule(listOf("ikea", "jysk", "amazon", "amzn", "zalando", "h&m", "zara", "jemogfix", "jem og fix", "harald nyborg", "bauhaus", "elgiganten", "power dk"), listOf("Shopping", "Hjem"), "Shopping", 89, "Beskrivelsen ligner et varekøb"),
        CsvCategoryRule(listOf("opsparing", "opsparingskonto", "fast overførsel til opsparing", "fast overfoersel til opsparing", "savings transfer"), listOf("Opsparing"), "Opsparing", 91, "Beskrivelsen ligner en overførsel til opsparing"),
        CsvCategoryRule(listOf("bankgebyr", "kortgebyr", "kontogebyr", "gebyr", "fee"), listOf("Gebyrer", "Regninger"), "Gebyrer", 88, "Beskrivelsen ligner et bank- eller servicegebyr"),
        CsvCategoryRule(listOf("afdrag", "lånebetaling", "laanebetaling", "kreditkortafdrag", "forbrugslån", "forbrugslaan"), listOf("Gæld", "Afdrag"), "Gæld", 87, "Beskrivelsen ligner et gældsafdrag"),
        CsvCategoryRule(listOf("hund", "dyrlæge", "dyrelaege", "dyreklinik", "kattefoder", "hundefoder", "dyrehandel"), listOf("Kæledyr", "Dyr"), "Kæledyr", 88, "Beskrivelsen ligner en udgift til kæledyr"),
    )
}

/** Uses explicit categories, corrections and transaction history before conservative text rules. */
internal fun resolveCsvCategory(
    rawCategory: String,
    description: String,
    transactionType: String,
    amount: Double,
    context: CsvCategoryContext
): CsvCategorySuggestion {
    val raw = rawCategory.trim()
    val n = csvNormalized(raw)
    if (!csvIsGenericCategory(raw)) {
        val aliases = when (n) {
            "food", "groceries", "dagligvarer", "madvarer" -> listOf("Dagligvarer", "Mad")
            "transportation", "transport" -> listOf("Transport")
            "housing", "rent", "bolig" -> listOf("Husleje", "Bolig")
            "utilities", "bills", "bill", "regninger" -> listOf("Regninger")
            "subscriptions", "subscription" -> listOf("Streaming", "Abonnementer")
            "health", "medical" -> listOf("Sundhed")
            "shopping" -> listOf("Shopping")
            "salary", "payroll" -> listOf("Løn")
            "income" -> if (transactionType == "Indtægt") listOf("Indtægt") else emptyList()
            "indtaegt" -> if (transactionType == "Indtægt") listOf("Indtægt") else emptyList()
            "expense", "udgift" -> if (transactionType == "Udgift") listOf("Diverse") else emptyList()
            else -> emptyList()
        }
        if (aliases.isNotEmpty()) {
            val fallback = if (n in setOf("subscriptions", "subscription")) "Abonnementer" else aliases.first()
            return CsvCategorySuggestion(csvPreferredCategory(context, aliases, fallback), 98, "Kategori fra CSV-filen")
        }
        val userExistingCategory = context.existingCategories.firstOrNull { csvNormalized(it) == n }
        return CsvCategorySuggestion(userExistingCategory ?: raw, 98, "Kategori fra CSV-filen")
    }

    val merchantKey = csvMerchantKey(description)
    if (merchantKey.isNotBlank()) {
        val learned = context.learnedMerchantCategories[csvLearningKey(description, transactionType)]
        if (!learned.isNullOrBlank()) {
            val existing = context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(learned) }
            return CsvCategorySuggestion(existing ?: learned, 99, "Din tidligere kategorisering af denne afsender")
        }

        val history = context.knownTransactions.filter { known ->
            known.type == transactionType && !csvIsGenericCategory(known.category) &&
                csvMerchantKey(known.name).isNotBlank() && csvMerchantKey(known.name) == merchantKey
        }
        if (history.isNotEmpty()) {
            val category = history.groupBy { it.category }.entries
                .maxByOrNull { it.value.size }?.key
            if (!category.isNullOrBlank()) {
                val closeAmount = history.any { known ->
                    val oldAmount = kotlin.math.abs(known.amount)
                    oldAmount > 0.0 && kotlin.math.abs(kotlin.math.abs(amount) - oldAmount) <= maxOf(5.0, oldAmount * 0.03)
                }
                val existing = context.existingCategories.firstOrNull { csvNormalized(it) == csvNormalized(category) }
                return CsvCategorySuggestion(existing ?: category, if (closeAmount) 99 else 95,
                    if (closeAmount) "Samme afsender og næsten samme beløb som før" else "Samme afsender som i dine tidligere poster")
            }
        }
    }

    val matchedRule = csvCategoryRules(transactionType).firstOrNull { rule -> csvContainsAny(description, *rule.keywords.toTypedArray()) }
    if (matchedRule != null) {
        return CsvCategorySuggestion(
            csvPreferredCategory(context, matchedRule.preferredCategories, matchedRule.fallback),
            matchedRule.confidence,
            matchedRule.explanation
        )
    }

    val descNormalized = csvNormalized(description)
    val categoryMention = context.existingCategories
        .filterNot(::csvIsGenericCategory)
        .filter { csvNormalized(it).length >= 4 && descNormalized.contains(csvNormalized(it)) }
        .maxByOrNull { csvNormalized(it).length }
    if (categoryMention != null) {
        return CsvCategorySuggestion(categoryMention, 80, "Beskrivelsen nævner en af dine eksisterende kategorier")
    }

    return if (transactionType == "Indtægt") {
        CsvCategorySuggestion("Indtægt", 42, "Ukendt indtægtstype – kontrollér kategorien")
    } else {
        CsvCategorySuggestion("Diverse", 32, "Der er ikke nok oplysninger til en sikker kategori")
    }
}

internal fun csvDirectionConfidence(
    explicitFlow: String?,
    splitColumnDirection: String?,
    rawAmount: Double,
    description: String
): Int = when {
    splitColumnDirection != null && explicitFlow != null && splitColumnDirection != explicitFlow -> 55
    splitColumnDirection != null -> 99
    explicitFlow == "Indtægt" && rawAmount < 0 -> 60
    explicitFlow != null -> 99
    rawAmount < 0 -> 97
    csvDescriptionLooksLikeIncome(description) -> 76
    else -> 54
}

internal val csvTransientFields = listOf(
    "_saldoCsvConfidence", "_saldoCsvReason", "_saldoCsvNeedsReview", "_saldoCsvSuggestedCategory",
    "_saldoCsvDirectionConfidence", "_saldoCsvDirectionReason", "_saldoCsvUserChangedCategory", "_saldoCsvUserChangedType"
)

internal val csvBuiltInCategories = listOf(
    "Løn", "Ydelser", "Tilbagebetaling", "Renteindtægter", "Overførsler", "Indtægt",
    "Bolig", "Husleje", "Familie", "Daginstitution", "Mad", "Dagligvarer", "Transport", "Brændstof",
    "Parkering", "Bil", "Regninger", "El", "Varme", "Vand", "Internet", "Mobil", "Forsikring",
    "Abonnementer", "Streaming", "Sundhed", "Fitness", "Shopping", "Opsparing", "Gæld", "Gebyrer",
    "Kæledyr", "Diverse"
)

internal fun csvCategoryOptions(plan: CsvImportPlan, context: CsvCategoryContext): List<String> {
    val seen = linkedSetOf<String>()
    return (csvBuiltInCategories + context.existingCategories + plan.recordsByCollection["transactions"].orEmpty().map { it.s("category") })
        .map(String::trim).filter(String::isNotBlank)
        .filter { seen.add(csvNormalized(it)) }
}

internal fun updateCsvPlanTransaction(
    plan: CsvImportPlan,
    id: String,
    newType: String? = null,
    newCategory: String? = null,
    context: CsvCategoryContext = CsvCategoryContext()
): CsvImportPlan {
    val updated = plan.recordsByCollection.mapValues { (_, rows) -> rows.map { row ->
        if (row.s("id") != id) return@map row
        val item = JSONObject(row.toString())
        if (newType != null && newType != item.s("type")) {
            val suggestion = resolveCsvCategory("", item.s("name"), newType, item.n("amount"), context)
            item.put("type", newType)
                .put("category", suggestion.category)
                .put("_saldoCsvSuggestedCategory", suggestion.category)
                .put("_saldoCsvConfidence", suggestion.confidence)
                .put("_saldoCsvReason", suggestion.reason)
                .put("_saldoCsvNeedsReview", suggestion.confidence < 72)
                .put("_saldoCsvDirectionConfidence", 100)
                .put("_saldoCsvDirectionReason", "Retning valgt af dig")
                .put("_saldoCsvUserChangedType", true)
                .put("_saldoCsvUserChangedCategory", false)
        }
        if (newCategory != null && newCategory != item.s("category")) {
            item.put("category", newCategory)
                .put("_saldoCsvConfidence", 100)
                .put("_saldoCsvReason", "Kategori valgt af dig")
                .put("_saldoCsvNeedsReview", false)
                .put("_saldoCsvUserChangedCategory", true)
        }
        item
    } }
    return plan.copy(recordsByCollection = updated)
}

internal fun csvLearnedCategoriesPreferenceKey(prefs: android.content.SharedPreferences): String {
    val userId = prefs.getString("active_account_user_id", null).orEmpty()
    return if (userId.isBlank()) "csv_learned_categories_local" else "csv_learned_categories_$userId"
}

internal fun loadCsvLearnedCategories(prefs: android.content.SharedPreferences): Map<String, String> {
    val raw = prefs.getString(csvLearnedCategoriesPreferenceKey(prefs), null).orEmpty()
    val json = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyMap()
    return json.keys().asSequence().mapNotNull { key ->
        json.optString(key).takeIf { it.isNotBlank() }?.let { key to it }
    }.toMap()
}

internal fun persistCsvCategoryCorrection(prefs: android.content.SharedPreferences, description: String, type: String, category: String) {
    val key = csvLearningKey(description, type)
    if (csvMerchantKey(description).isBlank() || category.isBlank()) return
    val prefKey = csvLearnedCategoriesPreferenceKey(prefs)
    val json = runCatching { JSONObject(prefs.getString(prefKey, "{}") ?: "{}") }.getOrElse { JSONObject() }
    json.put(key, category)
    // Keep the local learner bounded; recent corrections are useful, unbounded history is not.
    val keys = json.keys().asSequence().toList()
    if (keys.size > 300) keys.take(keys.size - 300).forEach(json::remove)
    prefs.edit().putString(prefKey, json.toString()).apply()
}

internal fun buildCsvCategoryContext(data: JSONObject, prefs: android.content.SharedPreferences): CsvCategoryContext {
    val categories = linkedSetOf<String>()
    val known = mutableListOf<CsvKnownTransaction>()
    fun collectCategories(collection: String, categoryKey: String) {
        (data.optJSONArray(collection) ?: JSONArray()).objects().forEach { item ->
            item.s(categoryKey).trim().takeIf { it.isNotBlank() && !csvIsGenericCategory(it) }?.let(categories::add)
        }
    }
    collectCategories("transactions", "category")
    collectCategories("bills", "category")
    collectCategories("budgets", "category")
    (data.optJSONArray("transactions") ?: JSONArray()).objects().takeLast(1500).forEach { item ->
        val name = item.s("name").trim()
        val category = item.s("category").trim()
        if (name.isNotBlank() && category.isNotBlank()) known += CsvKnownTransaction(name, category, item.s("type", "Udgift"), kotlin.math.abs(item.n("amount")))
    }
    (data.optJSONArray("bills") ?: JSONArray()).objects().takeLast(500).forEach { item ->
        val name = item.s("name").trim()
        val category = item.s("category").trim()
        if (name.isNotBlank() && category.isNotBlank()) known += CsvKnownTransaction(name, category, "Udgift", kotlin.math.abs(item.n("amount")))
    }
    return CsvCategoryContext(categories.toList(), known.takeLast(1800), loadCsvLearnedCategories(prefs))
}

internal fun parseSaldoCsv(raw: String, categoryContext: CsvCategoryContext = CsvCategoryContext()): CsvImportPlan {
    // Excel/bank exports may start with "sep=;" and with account metadata above the real header row.
    val sourceLines = raw.removePrefix("\uFEFF").lines().dropWhile { it.isBlank() }
    val csvText = (if (sourceLines.firstOrNull()?.trim()?.lowercase(Locale.ROOT)?.startsWith("sep=") == true) sourceLines.drop(1) else sourceLines).joinToString("\n")
    val allRows = parseCsvMatrix(csvText)
    val dateAliasSet = csvDateHeaderAliases.map(::csvNormalized).toSet()
    val amountAliasSet = csvAmountHeaderAliases.map(::csvNormalized).toSet()
    val headerRowIndex = allRows.take(20).indexOfFirst { row ->
        val cells = row.map(::csvNormalized)
        cells.any { it in dateAliasSet } && cells.any { it in amountAliasSet }
    }.coerceAtLeast(0)
    val rows = allRows.drop(headerRowIndex)
    require(rows.size >= 2) { "CSV-filen skal indeholde en overskriftsrække og mindst én datarække." }
    val originalHeaders = rows.first().map { it.trim().removePrefix("\uFEFF") }
    val headers = originalHeaders.map(::csvNormalized)
    // Aliases are tried in priority order, so e.g. Nordea's "Navn" wins over "Afsender" (own account number).
    fun indexOfAny(vararg aliases: String): Int {
        for (alias in aliases) {
            val index = headers.indexOf(csvNormalized(alias))
            if (index >= 0) return index
        }
        return -1
    }
    fun indicesOfAny(vararg aliases: String): List<Int> = aliases.map { headers.indexOf(csvNormalized(it)) }.filter { it >= 0 }.distinct()
    val typeIndex = indexOfAny("type", "posttype")
    val directionIndex = indexOfAny(
        "retning", "indtægt/udgift", "indtaegt/udgift", "transaktionsretning", "transaction type",
        "transaktionstype", "posteringstype", "transaktionsart", "betalingstype", "ind-/udbetaling",
        "debet/kredit", "debit/credit", "direction", "flow", "bevægelse", "bevægelsestype"
    )
    val nameAliases = arrayOf(
        "navn", "beskrivelse", "tekst", "posteringstekst", "description", "name", "modtager", "betalingstekst", "transaktion",
        "merchant", "payee", "modpart", "afsender", "reference", "details", "transaction details"
    )
    val nameIndex = indexOfAny(*nameAliases)
    val nameIndices = indicesOfAny(*nameAliases)
    val amountIndex = indexOfAny(
        "beløb", "belob", "amount", "value", "sum", "beløb dkk", "belob dkk", "transaktionsbeløb",
        "amount dkk", "amount (dkk)", "amount kr", "amount (kr)"
    )
    val creditIndex = indexOfAny(
        "indbetaling", "indbetalinger", "ind", "kredit", "credit", "deposit", "deposits", "income",
        "indtægt", "indtaegt", "beløb ind", "belob ind", "kreditbeløb", "kreditbelob", "kreditbeløb dkk", "credit amount", "deposit amount", "tilgang", "indgående beløb", "indgaaende beloeb"
    )
    val debitIndex = indexOfAny(
        "udbetaling", "udbetalinger", "ud", "debet", "debit", "withdrawal", "withdrawals", "expense",
        "udgift", "beløb ud", "belob ud", "debetbeløb", "debetbelob", "debetbeløb dkk", "debit amount", "withdrawal amount", "afgang", "udgående beløb", "udgaaende beloeb", "korttræk", "korttraek"
    )
    val categoryIndex = indexOfAny("kategori", "category", "gruppe", "expense category", "category name")
    val dateIndex = indexOfAny(*csvDateHeaderAliases.toTypedArray())
    val statusIndex = indexOfAny("status", "retning", "indtægt/udgift", "indtaegt/udgift")
    val ownerIndex = indexOfAny("ejer", "owner", "budgetejer")
    val isSaldoExport = typeIndex >= 0 && nameIndex >= 0 && amountIndex >= 0 && categoryIndex >= 0 && dateIndex >= 0 && statusIndex >= 0 && ownerIndex >= 0
    val hasSplitAmounts = creditIndex >= 0 || debitIndex >= 0
    if (nameIndex < 0 || dateIndex < 0 || (amountIndex < 0 && !hasSplitAmounts)) {
        throw IllegalArgumentException(
            "CSV-formatet blev ikke genkendt. Filen skal have dato og beskrivelse samt enten en beløbskolonne eller separate debet-/kreditkolonner."
        )
    }

    val collected = linkedMapOf<String, MutableList<JSONObject>>()
    val seenFingerprints = mutableSetOf<String>()
    var skipped = 0
    var invalid = 0
    var parsedRows = 0

    fun field(row: List<String>, index: Int): String = if (index in row.indices) row[index].trim() else ""
    val importIdPrefix = "csv-${System.currentTimeMillis()}"
    fun uniqueId(rowNumber: Int) = "$importIdPrefix-$rowNumber"
    fun append(collection: String, obj: JSONObject) {
        if (!seenFingerprints.add(csvRecordFingerprint(collection, obj))) {
            skipped++
        } else {
            collected.getOrPut(collection) { mutableListOf() }.add(obj)
        }
    }
    fun moneyInStatus(status: String): Double = Regex("[-+]?[0-9][0-9 .]*(?:,[0-9]+)?")
        .find(status)?.value?.let { parseCsvMoney(it) }?.let { kotlin.math.abs(it) } ?: 0.0

    for (rowIndex in 1 until rows.size) {
        val row = rows[rowIndex]
        if (row.all { it.isBlank() }) continue
        parsedRows++
        // Use the first non-empty description column (some banks leave "Navn" empty on transfers).
        val name = nameIndices.map { field(row, it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
        val rawDate = field(row, dateIndex)
        val date = parseCsvDate(rawDate)
        val categoryRaw = field(row, categoryIndex)
        val status = field(row, statusIndex)
        val owner = field(row, ownerIndex).ifBlank { "Mig" }
        val normalizedType = csvNormalized(field(row, typeIndex))

        var splitColumnDirection: String? = null
        var rawAmount: Double? = null
        if (hasSplitAmounts) {
            val credit = if (creditIndex >= 0) parseCsvMoney(field(row, creditIndex))?.let { kotlin.math.abs(it) } else null
            val debit = if (debitIndex >= 0) parseCsvMoney(field(row, debitIndex))?.let { kotlin.math.abs(it) } else null
            val hasCredit = (credit ?: 0.0) > 0.0
            val hasDebit = (debit ?: 0.0) > 0.0
            when {
                hasCredit && hasDebit -> {
                    // If both columns contain values, use an explicit amount column if present;
                    // otherwise skip rather than guessing and silently corrupting the balance.
                    val explicitAmount = if (amountIndex >= 0) parseCsvMoney(field(row, amountIndex)) else null
                    if (explicitAmount == null) { invalid++; continue }
                    rawAmount = explicitAmount
                    splitColumnDirection = csvDirection(field(row, directionIndex))
                }
                hasCredit -> { rawAmount = credit; splitColumnDirection = "Indtægt" }
                hasDebit -> { rawAmount = debit?.let { -it }; splitColumnDirection = "Udgift" }
                else -> rawAmount = if (amountIndex >= 0) parseCsvMoney(field(row, amountIndex)) else null
            }
        } else {
            rawAmount = parseCsvMoney(field(row, amountIndex))
        }
        val amount = rawAmount?.let { kotlin.math.abs(it) }
        if (name.isBlank() || rawAmount == null) { invalid++; continue }
        val explicitFlow = csvDirection(field(row, directionIndex))
            ?: csvDirection(field(row, typeIndex))
            ?: csvDirection(status)
        val directionConfidence = csvDirectionConfidence(explicitFlow, splitColumnDirection, rawAmount, name)

        if (isSaldoExport) {
            when (normalizedType) {
                "post", "transaction", "transaktion" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val transactionType = splitColumnDirection ?: explicitFlow ?: if (rawAmount < 0) "Udgift" else if (csvDescriptionLooksLikeIncome(name)) "Indtægt" else "Udgift"
                    val suggestion = resolveCsvCategory(categoryRaw, name, transactionType, amount, categoryContext)
                    append("transactions", record(
                        "id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "category" to suggestion.category,
                        "date" to date, "type" to transactionType, "owner" to owner,
                        "_saldoCsvConfidence" to suggestion.confidence, "_saldoCsvReason" to suggestion.reason,
                        "_saldoCsvNeedsReview" to (suggestion.confidence < 72), "_saldoCsvSuggestedCategory" to suggestion.category,
                        "_saldoCsvDirectionConfidence" to directionConfidence,
                        "_saldoCsvDirectionReason" to if (directionConfidence >= 90) "Retning bestemt af CSV-filen eller beløbets fortegn" else "Retningen er foreslået ud fra beskrivelsen"
                    ))
                }
                "regning", "bill", "invoice" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val paid = csvNormalized(status) in setOf("betalt", "paid", "true")
                    append("bills", record("id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "date" to date, "repeat" to "Engangsbetaling", "category" to categoryRaw.ifBlank { "Regninger" }, "owner" to owner, "paid" to paid))
                }
                "budget" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    append("budgets", record("id" to uniqueId(rowIndex), "category" to name, "limit" to amount, "owner" to owner))
                }
                "opsparingsmal", "savingsgoal", "goal" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    val saved = moneyInStatus(status)
                    append("goals", record("id" to uniqueId(rowIndex), "name" to name, "target" to amount, "saved" to saved, "date" to (date ?: "")))
                }
                "gaeld", "debt" -> {
                    if (amount == null || amount < 0.0) { invalid++; continue }
                    val rate = Regex("(?i)rente\\s+([0-9]+(?:[,.][0-9]+)?)%")
                        .find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    val payment = Regex("(?i)afdrag\\s+(.+)$").find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) }?.let { kotlin.math.abs(it) } ?: 0.0
                    append("debts", record("id" to uniqueId(rowIndex), "name" to name, "balance" to amount, "rate" to rate, "payment" to payment))
                }
                "abonnement", "subscription" -> {
                    if (amount == null || amount <= 0.0) { invalid++; continue }
                    val cancelDate = Regex("(?i)opsig senest\\s+(\\d{4}-\\d{2}-\\d{2})").find(status)?.groupValues?.getOrNull(1).orEmpty()
                    append("subs", record("id" to uniqueId(rowIndex), "name" to name, "monthly" to amount, "renewalDate" to (date ?: ""), "cancelByDate" to cancelDate, "cancelNote" to "", "owner" to owner, "active" to true))
                }
                "braendstof", "fuel" -> {
                    if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
                    val liters = Regex("(?i)([0-9]+(?:[,.][0-9]+)?)\\s*liter").find(categoryRaw)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    val km = Regex("(?i)kilometerstand\\s+([0-9 .]+)").find(status)?.groupValues?.getOrNull(1)?.let { parseCsvMoney(it) } ?: 0.0
                    append("fuel", record("id" to uniqueId(rowIndex), "date" to date, "liters" to liters, "cost" to amount, "km" to km))
                }
                else -> skipped++
            }
        } else {
            if (date == null || amount == null || amount <= 0.0) { invalid++; continue }
            val transactionType = splitColumnDirection ?: explicitFlow
                ?: if (rawAmount < 0) "Udgift"
                else if (csvDescriptionLooksLikeIncome(name)) "Indtægt"
                else "Udgift"
            val suggestion = resolveCsvCategory(categoryRaw, name, transactionType, amount, categoryContext)
            append("transactions", record(
                "id" to uniqueId(rowIndex), "name" to name, "amount" to amount, "category" to suggestion.category,
                "date" to date, "type" to transactionType, "owner" to owner,
                "_saldoCsvConfidence" to suggestion.confidence, "_saldoCsvReason" to suggestion.reason,
                "_saldoCsvNeedsReview" to (suggestion.confidence < 72), "_saldoCsvSuggestedCategory" to suggestion.category,
                "_saldoCsvDirectionConfidence" to directionConfidence,
                "_saldoCsvDirectionReason" to if (directionConfidence >= 90) "Retning bestemt af CSV-filen eller beløbets fortegn" else "Retningen er foreslået ud fra beskrivelsen"
            ))
        }
    }
    require(collected.values.sumOf { it.size } > 0) {
        "Ingen gyldige poster blev fundet. Kontrollér kolonnerne og datoformatet i CSV-filen. Ved debet-/kreditfiler skal mindst én af beløbskolonnerne være udfyldt pr. række."
    }
    val usedColumns = listOf(dateIndex, nameIndex, amountIndex, creditIndex, debitIndex, categoryIndex).filter { it >= 0 }.distinct()
    return CsvImportPlan(collected.mapValues { it.value.toList() }, parsedRows, skipped, invalid, usedColumns.joinToString(" · ") { originalHeaders[it] })
}
