package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// PDF report, CSV/JSON export and receipt images.

internal fun sharePdfReport(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>, income: Double, expenses: Double) {
    runCatching {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val left = 40f
        val maxTextWidth = 515f
        val ink = android.graphics.Color.rgb(31, 29, 55)
        val muted = android.graphics.Color.rgb(112, 112, 134)
        val purple = android.graphics.Color.rgb(105, 83, 224)
        val green = android.graphics.Color.rgb(35, 135, 107)
        val red = android.graphics.Color.rgb(205, 65, 83)
        val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 23f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val sectionPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = purple; textSize = 13f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val bodyPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; textSize = 10.5f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        val smallPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = muted; textSize = 9f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        var currentPage: PdfDocument.Page? = null
        var currentCanvas: android.graphics.Canvas? = null
        var y = 0f
        var pageNumber = 0

        fun startPage() {
            currentPage?.let { document.finishPage(it) }
            pageNumber += 1
            val newPage = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            currentPage = newPage
            currentCanvas = newPage.canvas
            val canvas = newPage.canvas
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.drawText("Saldo · Økonomirapport", left, 42f, titlePaint)
            canvas.drawText("Udarbejdet ${LocalDate.now()} · Privat økonomi", left, 62f, smallPaint)
            val rulePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(225, 222, 240); strokeWidth = 1f
            }
            canvas.drawLine(left, 77f, 555f, 77f, rulePaint)
            y = 99f
        }

        fun ensureSpace(height: Float = 18f) {
            if (y + height > 778f) startPage()
        }

        fun drawTextLine(text: String, paint: android.graphics.Paint = bodyPaint, lineHeight: Float = 16f) {
            ensureSpace(lineHeight)
            currentCanvas?.drawText(text, left, y, paint)
            y += lineHeight
        }

        fun drawWrapped(text: String, paint: android.graphics.Paint = bodyPaint, lineHeight: Float = 14f) {
            val words = text.replace('\n', ' ').trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            var line = ""
            for (word in words) {
                val candidate = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(candidate) <= maxTextWidth) {
                    line = candidate
                } else {
                    if (line.isNotEmpty()) drawTextLine(line, paint, lineHeight)
                    line = word
                }
            }
            if (line.isNotEmpty()) drawTextLine(line, paint, lineHeight)
        }

        fun drawSection(title: String) {
            ensureSpace(34f)
            y += 5f
            drawTextLine(title, sectionPaint, 23f)
        }

        try {
            startPage()
            drawSection("Økonomisk overblik")
            drawTextLine("Indtægter registreret: ${moneyPlain(income)}")
            drawTextLine("Udgifter registreret: ${moneyPlain(expenses)}")
            val netPaint = android.graphics.Paint(bodyPaint).apply { color = if (income - expenses >= 0) green else red; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
            drawTextLine("Netto: ${moneyPlain(income - expenses)}", netPaint)
            drawTextLine("Registrerede poster: ${transactions.size}")
            val unpaid = bills.filter { !it.optBoolean("paid", false) }
            drawTextLine("Regninger: ${bills.size} · Ubetalte: ${unpaid.size}")
            drawWrapped("Bemærk: Rapporten bygger på de oplysninger, der er indtastet i Saldo. Den er ikke en bankudskrift.", smallPaint, 13f)

            drawSection("Poster · seneste først")
            val rows = transactions.sortedByDescending { it.s("date") }.take(1000)
            if (rows.isEmpty()) {
                drawTextLine("Der er ingen registrerede poster endnu.", smallPaint)
            } else {
                rows.forEach { item ->
                    ensureSpace(37f)
                    val date = item.s("date", "Dato mangler")
                    val name = item.s("name", "Post uden navn").ifBlank { "Post uden navn" }.take(90)
                    drawWrapped("$date · $name", bodyPaint, 13f)
                    val amountColor = if (item.s("type") == "Indtægt") green else red
                    val detailPaint = android.graphics.Paint(smallPaint).apply { color = amountColor }
                    val detail = listOf(item.s("type", "Post"), item.s("category").takeIf { it.isNotBlank() }, moneyPlain(item.n("amount")))
                        .filterNotNull().joinToString(" · ")
                    drawWrapped(detail, detailPaint, 12f)
                    y += 4f
                }
                if (transactions.size > rows.size) drawWrapped("Viser de seneste ${rows.size} af ${transactions.size} poster.", smallPaint, 12f)
            }

            drawSection("Ubetalte regninger")
            val sortedUnpaid = unpaid.sortedBy { it.s("date", "9999-12-31") }
            if (sortedUnpaid.isEmpty()) {
                drawTextLine("Ingen ubetalte regninger er registreret.", smallPaint)
            } else {
                sortedUnpaid.forEach { bill ->
                    ensureSpace(30f)
                    val due = bill.s("date", "Dato mangler")
                    val name = bill.s("name", "Regning uden navn").ifBlank { "Regning uden navn" }.take(90)
                    drawWrapped("$due · $name · ${moneyPlain(bill.n("amount"))}", bodyPaint, 13f)
                }
            }
            drawSection("Privatliv")
            drawWrapped("Denne rapport kan indeholde følsomme økonomioplysninger. Del den kun med personer eller tjenester, du har tillid til.", smallPaint, 13f)
            currentPage?.let { document.finishPage(it) }
            currentPage = null
            val file = File(context.cacheDir, "Saldo-rapport-${exportFileStamp()}.pdf")
            FileOutputStream(file).use { document.writeTo(it) }
            val uri: Uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_SUBJECT, "Saldo-økonomirapport")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(intent, "Del PDF-rapport"))
        } finally {
            document.close()
        }
    }.onFailure {
        Toast.makeText(context, "Kunne ikke oprette PDF: ${it.message ?: "ukendt fejl"}", Toast.LENGTH_LONG).show()
    }
}

internal fun exportFileStamp(): String = java.text.SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(java.util.Date())

/** Copies a receipt photo into private app storage, downscaled to max ~1800 px. Returns the file name. */
internal fun saveReceiptImage(context: Context, uri: Uri): String {
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
    val bitmap = context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }) }
        ?: throw IllegalArgumentException("Billedet kunne ikke læses.")
    val dir = File(context.filesDir, "receipts").apply { mkdirs() }
    val name = "receipt-${System.currentTimeMillis()}.jpg"
    FileOutputStream(File(dir, name)).use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, it) }
    return name
}

internal fun receiptFile(context: Context, name: String): File = File(File(context.filesDir, "receipts"), name)

internal fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"")}\""

internal fun shareCsv(context: Context, data: JSONObject) {
    runCatching {
        val lines = mutableListOf("type;navn;beløb;kategori;dato;status;ejer")
        fun row(type: String, name: String, amount: Double, category: String, date: String, status: String, owner: String = "") {
            val amountText = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(amount)
            lines += listOf(type, name, amountText, category, date, status, owner).joinToString(";") { csvCell(it) }
        }
        (data.optJSONArray("transactions") ?: JSONArray()).objects().forEach {
            row("post", it.s("name"), it.n("amount"), it.s("category"), it.s("date"), it.s("type"), it.s("owner"))
        }
        (data.optJSONArray("bills") ?: JSONArray()).objects().forEach {
            row("regning", it.s("name"), it.n("amount"), it.s("category"), it.s("date"), if (it.optBoolean("paid")) "betalt" else "ubetalt", it.s("owner"))
        }
        (data.optJSONArray("budgets") ?: JSONArray()).objects().forEach {
            row("budget", it.s("category"), it.n("limit"), it.s("category"), "", "månedlig grænse", it.s("owner"))
        }
        (data.optJSONArray("goals") ?: JSONArray()).objects().forEach {
            row("opsparingsmål", it.s("name"), it.n("target"), "Opsparing", it.s("date"), "Sparet: ${moneyPlain(it.n("saved"))}")
        }
        (data.optJSONArray("debts") ?: JSONArray()).objects().forEach {
            row("gæld", it.s("name"), it.n("balance"), "Gæld", "", "Rente ${it.n("rate")}% · afdrag ${moneyPlain(it.n("payment"))}")
        }
        (data.optJSONArray("subs") ?: JSONArray()).objects().forEach {
            row("abonnement", it.s("name"), it.n("monthly"), "Abonnement", it.s("renewalDate"), "Opsig senest ${it.s("cancelByDate")}", it.s("owner"))
        }
        (data.optJSONArray("fuel") ?: JSONArray()).objects().forEach {
            row("brændstof", "Tankning", it.n("cost"), "${it.n("liters")} liter", it.s("date"), "Kilometerstand ${it.n("km")}")
        }
        val file = File(context.cacheDir, "Saldo-data-${exportFileStamp()}.csv")
        FileOutputStream(file).use { out -> out.write(("\uFEFF" + lines.joinToString("\r\n")).toByteArray(Charsets.UTF_8)) }
        val uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).setType("text/csv")
            .putExtra(Intent.EXTRA_SUBJECT, "Saldo CSV-eksport")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Eksportér Saldo-data"))
    }.onFailure { Toast.makeText(context, "Kunne ikke oprette CSV-eksport: ${it.message}", Toast.LENGTH_LONG).show() }
}

internal fun shareBackup(context: Context, json: String) {
    runCatching {
        val file = File(context.cacheDir, "Saldo-backup-${exportFileStamp()}.json")
        FileOutputStream(file).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        val uri = FileProvider.getUriForFile(context, "dk.saldo.app.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).setType("application/json")
            .putExtra(Intent.EXTRA_SUBJECT, "Saldo sikkerhedskopi")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Gem eller del sikkerhedskopi"))
    }.onFailure { Toast.makeText(context, "Kunne ikke oprette backupfil: ${it.message}", Toast.LENGTH_LONG).show() }
}
