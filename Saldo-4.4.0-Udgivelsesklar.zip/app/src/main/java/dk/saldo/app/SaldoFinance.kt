package dk.saldo.app

import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.text.NumberFormat
import java.time.temporal.ChronoUnit
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// Pure finance logic used by the UI. Kept free of Android/Compose so it is covered by JVM unit tests.

/** Creates every due occurrence of recurring posts up to [today]. Ids in [generatedBefore] are never re-created. */
internal fun generateRecurringOccurrences(existingTx: List<JSONObject>, today: LocalDate, generatedBefore: Set<String>): List<JSONObject> {
    val knownIds = existingTx.map { it.s("id") }.toMutableSet()
    val generated = mutableListOf<JSONObject>()
    existingTx.filter { it.s("recurrenceId").isNotBlank() || isRecurringRepeat(it.s("repeat")) }
        .groupBy { it.s("recurrenceId").ifBlank { it.s("id") } }
        .forEach { (seriesId, series) ->
            val latest = series.maxByOrNull { it.s("date") } ?: return@forEach
            val interval = recurrenceIntervalMonths(latest.s("repeat")) ?: return@forEach
            var lastDate = runCatching { LocalDate.parse(latest.s("date")) }.getOrNull() ?: return@forEach
            val anchorDay = latest.optInt("recurrenceDay", lastDate.dayOfMonth).coerceIn(1, 31)
            var guard = 0
            while (guard < 36) {
                val month = YearMonth.from(lastDate).plusMonths(interval)
                val next = month.atDay(anchorDay.coerceAtMost(month.lengthOfMonth()))
                if (next.isAfter(today)) break
                val newId = "rec-tx-$seriesId-$next"
                if (newId !in generatedBefore && knownIds.add(newId)) {
                    generated += JSONObject(latest.toString()).put("id", newId).put("date", next.toString())
                        .put("recurrenceId", seriesId).put("recurrenceDay", anchorDay).put("autoCreated", true)
                }
                lastDate = next
                guard++
            }
        }
    return generated
}

/** Monthly budget suggestions: average expense per category/owner over [transactions] (three months), rounded up to 100 kr. */
internal fun suggestBudgets(transactions: List<JSONObject>, existingBudgets: List<JSONObject>, months: Int = 3): List<Triple<String, String, Double>> {
    val existing = existingBudgets.map { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }.toSet()
    return transactions
        .filter { it.s("type") == "Udgift" && it.s("category").isNotBlank() }
        .groupBy { it.s("category").trim() to it.s("owner", "Mig").trim().ifBlank { "Mig" } }
        .map { (key, rows) -> Triple(key.first, key.second, kotlin.math.ceil(rows.sumOf { it.n("amount") } / months / 100.0) * 100.0) }
        .filter { (category, owner, limit) -> limit >= 100.0 && "${category.lowercase(Locale.ROOT)}|${owner.lowercase(Locale.ROOT)}" !in existing }
        .sortedByDescending { it.third }
        .take(12)
}

/** Expenses to the same merchant in at least 3 of the last 6 months with a stable amount (±15 %) that are not yet subscriptions. */
internal fun detectRecurringPayments(transactions: List<JSONObject>, subscriptions: List<JSONObject>, ignored: Set<String>, now: YearMonth): List<Triple<String, String, Double>> {
    val since = now.minusMonths(6)
    val known = subscriptions.map { csvMerchantKey(it.s("name")) }.toSet()
    return transactions.filter { item ->
        item.s("type") == "Udgift" && item.s("recurrenceId").isBlank() && !isRecurringRepeat(item.s("repeat")) &&
            runCatching { YearMonth.from(LocalDate.parse(item.s("date"))) }.getOrNull()?.let { it >= since && it <= now } == true
    }.groupBy { csvMerchantKey(it.s("name")) }
        .filter { (key, rows) -> key.length >= 3 && key !in known && key !in ignored && rows.map { it.s("date").take(7) }.distinct().size >= 3 }
        .mapNotNull { (key, rows) ->
            val average = rows.map { it.n("amount") }.average()
            if (rows.all { kotlin.math.abs(it.n("amount") - average) <= maxOf(5.0, average * .15) }) Triple(key, rows.maxBy { it.s("date") }.s("name"), average) else null
        }.sortedByDescending { it.third }.take(6)
}

/** Projected balance for each day from today (index 0) to [days], after unpaid bills and an average daily spend. */
internal fun projectBalance(balance: Double, bills: List<JSONObject>, today: LocalDate, days: Int, dailyVariable: Double): List<Double> =
    (0..days.coerceAtLeast(1)).map { offset ->
        val day = today.plusDays(offset.toLong())
        val billsUntil = bills.filter { bill ->
            !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due -> !due.isBefore(today) && !due.isAfter(day) } == true
        }.sumOf { it.n("amount") }
        balance - billsUntil - dailyVariable * offset
    }

private class SaldoAmountParser(private val text: String) {
    private var pos = 0
    fun parse(): Double? { val value = expression() ?: return null; return if (pos == text.length) value else null }
    private fun expression(): Double? {
        var value = term() ?: return null
        while (pos < text.length && (text[pos] == '+' || text[pos] == '-')) {
            val op = text[pos++]
            val right = term() ?: return null
            value = if (op == '+') value + right else value - right
        }
        return value
    }
    private fun term(): Double? {
        var value = factor() ?: return null
        while (pos < text.length && (text[pos] == '*' || text[pos] == '/')) {
            val op = text[pos++]
            val right = factor() ?: return null
            if (op == '/' && right == 0.0) return null
            value = if (op == '*') value * right else value / right
        }
        return value
    }
    private fun factor(): Double? {
        if (pos < text.length && text[pos] == '-') { pos++; return factor()?.let { -it } }
        if (pos < text.length && text[pos] == '(') {
            pos++
            val value = expression() ?: return null
            if (pos >= text.length || text[pos] != ')') return null
            pos++
            return value
        }
        val start = pos
        while (pos < text.length && (text[pos].isDigit() || text[pos] == '.' || text[pos] == ',')) pos++
        if (start == pos) return null
        return parseDanishAmount(text.substring(start, pos))
    }
}

/** Amount field calculator: "89,95+45", "1.000*2", "(300+150)/3". Danish number format; returns null when invalid. */
internal fun evaluateAmountExpression(raw: String): Double? {
    val text = raw.replace(" ", "").replace("\u00A0", "").replace("×", "*").replace("÷", "/").replace("−", "-")
    if (text.isBlank()) return null
    return SaldoAmountParser(text).parse()?.takeIf { it.isFinite() }?.let { kotlin.math.round(it * 100) / 100.0 }
}

internal fun updatePaid(bills: List<JSONObject>, target: JSONObject, store: (String, JSONArray) -> Unit) {
    val arr = JSONArray()
    val isMarkingPaid = !target.optBoolean("paid", false)
    bills.forEach { bill ->
        arr.put(if (bill.s("id") == target.s("id")) JSONObject(bill.toString()).put("paid", isMarkingPaid) else JSONObject(bill.toString()))
    }
    if (isMarkingPaid && isRecurringRepeat(target.s("repeat"))) {
        val paidDate = runCatching { LocalDate.parse(target.s("date")) }.getOrNull()
        val anchorDay = target.optInt("recurrenceDay", paidDate?.dayOfMonth ?: 1).coerceIn(1, 31)
        val nextDate = paidDate?.let { nextRecurringOccurrence(it, LocalDate.now(), target.s("repeat"), anchorDay) }
        if (nextDate != null) {
            val exists = bills.any {
                it.s("name").trim().equals(target.s("name").trim(), true) &&
                    it.s("date") == nextDate.toString() &&
                    kotlin.math.abs(it.n("amount") - target.n("amount")) < .01 &&
                    normalizedOwner(it.s("owner", "Mig")) == normalizedOwner(target.s("owner", "Mig"))
            }
            if (!exists) arr.put(JSONObject(target.toString()).put("id", "rec-${target.s("id")}-${nextDate}").put("date", nextDate.toString()).put("recurrenceDay", anchorDay).put("paid", false))
        }
    }
    store("bills", arr)
}

internal fun normalizedOwner(owner: String): String = when {
    owner.trim().equals("Kæreste", ignoreCase = true) || owner.trim().equals("Partner", ignoreCase = true) -> "partner"
    owner.trim().equals("Fælles", ignoreCase = true) -> "fælles"
    else -> "mig"
}

/** Occurrences belonging to different budgets/owners must not suppress one another. */
internal fun billOccurrenceKey(bill: JSONObject): String = listOf(
    bill.s("name").trim().lowercase(Locale.ROOT),
    bill.s("date"),
    kotlin.math.round(bill.n("amount") * 100.0).toLong().toString(),
    normalizedOwner(bill.s("owner", "Mig"))
).joinToString("|")

internal fun recurrenceIntervalMonths(value: String): Long? = when {
    value.contains("kvartal", true) || value.contains("quarter", true) -> 3L
    value.contains("årlig", true) || value.contains("hvert år", true) || value.contains("annual", true) || value.contains("yearly", true) -> 12L
    value.contains("måned", true) || value.contains("monthly", true) || value.contains("month", true) -> 1L
    else -> null
}

internal fun isRecurringRepeat(value: String): Boolean = recurrenceIntervalMonths(value) != null

internal fun nextRecurringOccurrence(baseDate: LocalDate, today: LocalDate, repeat: String, anchorDay: Int = baseDate.dayOfMonth): LocalDate? {
    val interval = recurrenceIntervalMonths(repeat) ?: return null
    val day = anchorDay.coerceIn(1, 31)
    var targetMonth = runCatching { java.time.YearMonth.from(baseDate).plusMonths(interval) }.getOrNull() ?: return null
    var next = targetMonth.atDay(day.coerceAtMost(targetMonth.lengthOfMonth()))
    var steps = 0
    while (next.isBefore(today) && steps < 600) {
        targetMonth = runCatching { targetMonth.plusMonths(interval) }.getOrNull() ?: return null
        next = targetMonth.atDay(day.coerceAtMost(targetMonth.lengthOfMonth()))
        steps++
    }
    return next.takeUnless { it.isBefore(today) }
}

internal data class DebtPlanResult(val months: Int?, val totalInterest: Double, val payoffOrder: List<Pair<String, Int>>)

/** Month-by-month simulation: interest accrues, minimum payments are made, extra money goes to the target debt. */
internal fun simulateDebtPlan(debts: List<JSONObject>, extra: Double, avalanche: Boolean): DebtPlanResult {
    class Debt(val name: String, var balance: Double, val rate: Double, val payment: Double, var paidOffMonth: Int? = null)
    val items = debts.filter { it.n("balance") > 0.0 }.map { Debt(it.s("name").ifBlank { "Gæld" }, it.n("balance"), it.n("rate") / 1200.0, it.n("payment").coerceAtLeast(0.0)) }
    if (items.isEmpty()) return DebtPlanResult(0, 0.0, emptyList())
    val monthlyBudget = items.sumOf { it.payment } + extra.coerceAtLeast(0.0)
    var interest = 0.0
    var month = 0
    while (items.any { it.balance > 0.005 } && month < 600) {
        month++
        items.filter { it.balance > 0.005 }.forEach { debt -> val accrued = debt.balance * debt.rate; interest += accrued; debt.balance += accrued }
        var available = monthlyBudget
        items.filter { it.balance > 0.005 }.forEach { debt -> val pay = minOf(debt.payment, debt.balance); debt.balance -= pay; available -= pay }
        val targets = items.filter { it.balance > 0.005 }.sortedWith(if (avalanche) compareByDescending<Debt> { it.rate } else compareBy { it.balance })
        for (target in targets) {
            if (available <= 0.005) break
            val pay = minOf(available, target.balance); target.balance -= pay; available -= pay
        }
        items.filter { it.balance <= 0.005 && it.paidOffMonth == null }.forEach { it.paidOffMonth = month }
    }
    return DebtPlanResult(if (items.any { it.balance > 0.005 }) null else month, interest, items.filter { it.paidOffMonth != null }.sortedBy { it.paidOffMonth }.map { it.name to it.paidOffMonth!! })
}

// ---------------------------------------------------------------- pay cycle
/** Pay frequencies: "monthly" (most common in Denmark), "biweekly" (every 14 days) and "weekly". */
internal val saldoPayFrequencies = listOf("monthly" to "Månedlig", "biweekly" to "Hver 14. dag", "weekly" to "Ugentlig")

internal fun payFrequencyLabel(frequency: String): String = saldoPayFrequencies.firstOrNull { it.first == frequency }?.second ?: "Månedlig"

/** The first payday on or after [from], given one known payday ([reference]). Monthly keeps the day of month (clamped). */
internal fun paydayOnOrAfter(reference: LocalDate, from: LocalDate, frequency: String): LocalDate = when (frequency) {
    "weekly", "biweekly" -> {
        val step = if (frequency == "weekly") 7L else 14L
        val diff = java.time.temporal.ChronoUnit.DAYS.between(reference, from)
        reference.plusDays(Math.floorDiv(diff + step - 1, step) * step)
    }
    else -> {
        val day = reference.dayOfMonth
        var month = YearMonth.from(from)
        var candidate = month.atDay(minOf(day, month.lengthOfMonth()))
        if (candidate.isBefore(from)) {
            month = month.plusMonths(1)
            candidate = month.atDay(minOf(day, month.lengthOfMonth()))
        }
        candidate
    }
}

/** Days until the next payday (0 = today) and the length of the current pay period in days. */
internal fun payCycle(reference: LocalDate, today: LocalDate, frequency: String): Pair<Int, Int> {
    val next = paydayOnOrAfter(reference, today, frequency)
    val daysToPay = java.time.temporal.ChronoUnit.DAYS.between(today, next).toInt()
    val periodDays = if (daysToPay == 0) java.time.temporal.ChronoUnit.DAYS.between(today, paydayOnOrAfter(reference, today.plusDays(1), frequency)).toInt() else daysToPay
    return daysToPay to periodDays.coerceAtLeast(1)
}

/** Converts one payout to an average monthly income. */
internal fun monthlyIncomeFromPay(pay: Double, frequency: String): Double = when (frequency) {
    "weekly" -> pay * 52.0 / 12.0
    "biweekly" -> pay * 26.0 / 12.0
    else -> pay
}
