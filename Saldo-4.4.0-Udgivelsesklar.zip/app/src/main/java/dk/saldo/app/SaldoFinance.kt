package dk.saldo.app

import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

// Pure finance logic used by the UI. Kept free of Android/Compose so it is covered by JVM unit tests.

/** Creates every due occurrence of recurring posts up to [today]. Ids in [generatedBefore] are never re-created. */
internal fun generateRecurringOccurrences(existingTx: List<JSONObject>, today: LocalDate, generatedBefore: Set<String>): List<JSONObject> {
    val knownIds = existingTx.map { it.s("id") }.toMutableSet()
    val generated = mutableListOf<JSONObject>()
    existingTx.filter { it.s("recurrenceId").isNotBlank() || isRecurringRepeat(it.s("repeat")) }
        .groupBy { it.s("recurrenceId").ifBlank { it.s("id") } }
        .forEach { (seriesId, series) ->
            val latest = series.maxByOrNull { it.s("date") } ?: return@forEach
            val interval = recurrenceIntervalMonths(latest.s("repeat")) ?: return@forEach
            var lastDate = runCatching { LocalDate.parse(latest.s("date")) }.getOrNull() ?: return@forEach
            val anchorDay = latest.optInt("recurrenceDay", lastDate.dayOfMonth).coerceIn(1, 31)
            var guard = 0
            while (guard < 36) {
                val month = YearMonth.from(lastDate).plusMonths(interval)
                val next = month.atDay(anchorDay.coerceAtMost(month.lengthOfMonth()))
                if (next.isAfter(today)) break
                val newId = "rec-tx-$seriesId-$next"
                if (newId !in generatedBefore && knownIds.add(newId)) {
                    generated += JSONObject(latest.toString()).put("id", newId).put("date", next.toString())
                        .put("recurrenceId", seriesId).put("recurrenceDay", anchorDay).put("autoCreated", true)
                }
                lastDate = next
                guard++
            }
        }
    return generated
}

/** Monthly budget suggestions: average expense per category/owner over [transactions] (three months), rounded up to 100 kr. */
internal fun suggestBudgets(transactions: List<JSONObject>, existingBudgets: List<JSONObject>, months: Int = 3): List<Triple<String, String, Double>> {
    val existing = existingBudgets.map { "${it.s("category").trim().lowercase(Locale.ROOT)}|${it.s("owner", "Mig").trim().lowercase(Locale.ROOT)}" }.toSet()
    return transactions
        .filter { it.s("type") == "Udgift" && it.s("category").isNotBlank() }
        .groupBy { it.s("category").trim() to it.s("owner", "Mig").trim().ifBlank { "Mig" } }
        .map { (key, rows) -> Triple(key.first, key.second, kotlin.math.ceil(rows.sumOf { it.n("amount") } / months / 100.0) * 100.0) }
        .filter { (category, owner, limit) -> limit >= 100.0 && "${category.lowercase(Locale.ROOT)}|${owner.lowercase(Locale.ROOT)}" !in existing }
        .sortedByDescending { it.third }
        .take(12)
}

/** Expenses to the same merchant in at least 3 of the last 6 months with a stable amount (±15 %) that are not yet subscriptions. */
internal fun detectRecurringPayments(transactions: List<JSONObject>, subscriptions: List<JSONObject>, ignored: Set<String>, now: YearMonth): List<Triple<String, String, Double>> {
    val since = now.minusMonths(6)
    val known = subscriptions.map { csvMerchantKey(it.s("name")) }.toSet()
    return transactions.filter { item ->
        item.s("type") == "Udgift" && item.s("recurrenceId").isBlank() && !isRecurringRepeat(item.s("repeat")) &&
            runCatching { YearMonth.from(LocalDate.parse(item.s("date"))) }.getOrNull()?.let { it >= since && it <= now } == true
    }.groupBy { csvMerchantKey(it.s("name")) }
        .filter { (key, rows) -> key.length >= 3 && key !in known && key !in ignored && rows.map { it.s("date").take(7) }.distinct().size >= 3 }
        .mapNotNull { (key, rows) ->
            val average = rows.map { it.n("amount") }.average()
            if (rows.all { kotlin.math.abs(it.n("amount") - average) <= maxOf(5.0, average * .15) }) Triple(key, rows.maxBy { it.s("date") }.s("name"), average) else null
        }.sortedByDescending { it.third }.take(6)
}

/** Projected balance for each day from today (index 0) to [days], after unpaid bills and an average daily spend. */
internal fun projectBalance(balance: Double, bills: List<JSONObject>, today: LocalDate, days: Int, dailyVariable: Double): List<Double> =
    (0..days.coerceAtLeast(1)).map { offset ->
        val day = today.plusDays(offset.toLong())
        val billsUntil = bills.filter { bill ->
            !bill.optBoolean("paid", false) && runCatching { LocalDate.parse(bill.s("date")) }.getOrNull()?.let { due -> !due.isBefore(today) && !due.isAfter(day) } == true
        }.sumOf { it.n("amount") }
        balance - billsUntil - dailyVariable * offset
    }

private class SaldoAmountParser(private val text: String) {
    private var pos = 0
    fun parse(): Double? { val value = expression() ?: return null; return if (pos == text.length) value else null }
    private fun expression(): Double? {
        var value = term() ?: return null
        while (pos < text.length && (text[pos] == '+' || text[pos] == '-')) {
            val op = text[pos++]
            val right = term() ?: return null
            value = if (op == '+') value + right else value - right
        }
        return value
    }
    private fun term(): Double? {
        var value = factor() ?: return null
        while (pos < text.length && (text[pos] == '*' || text[pos] == '/')) {
            val op = text[pos++]
            val right = factor() ?: return null
            if (op == '/' && right == 0.0) return null
            value = if (op == '*') value * right else value / right
        }
        return value
    }
    private fun factor(): Double? {
        if (pos < text.length && text[pos] == '-') { pos++; return factor()?.let { -it } }
        if (pos < text.length && text[pos] == '(') {
            pos++
            val value = expression() ?: return null
            if (pos >= text.length || text[pos] != ')') return null
            pos++
            return value
        }
        val start = pos
        while (pos < text.length && (text[pos].isDigit() || text[pos] == '.' || text[pos] == ',')) pos++
        if (start == pos) return null
        return parseDanishAmount(text.substring(start, pos))
    }
}

/** Amount field calculator: "89,95+45", "1.000*2", "(300+150)/3". Danish number format; returns null when invalid. */
internal fun evaluateAmountExpression(raw: String): Double? {
    val text = raw.replace(" ", "").replace("\u00A0", "").replace("×", "*").replace("÷", "/").replace("−", "-")
    if (text.isBlank()) return null
    return SaldoAmountParser(text).parse()?.takeIf { it.isFinite() }?.let { kotlin.math.round(it * 100) / 100.0 }
}
