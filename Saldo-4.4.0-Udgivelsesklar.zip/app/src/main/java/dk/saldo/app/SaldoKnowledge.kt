package dk.saldo.app

// Built-in knowledge base for "Spørg Saldo": short, general explanations of common Danish personal-finance topics.
// Everything runs on the phone and costs nothing. Rates and limits change every year, so the texts explain the
// concepts and point to skat.dk / borger.dk / the bank for current numbers instead of hard-coding them.

internal data class SaldoKnowledgeEntry(
    val title: String,
    /** Word starts matched against the normalised question (which is padded with spaces). */
    val keywords: List<String>,
    val text: String,
    val actionLabel: String? = null,
    val actionTab: String? = null
)

internal val saldoKnowledgeBase: List<SaldoKnowledgeEntry> = listOf(
    SaldoKnowledgeEntry("ÅOP", listOf(" åop", " årlige omkostninger", " omkostninger i procent"),
        "ÅOP (årlige omkostninger i procent) er den samlede pris for et lån pr. år: rente plus gebyrer, oprettelse og andre omkostninger. Brug ÅOP til at sammenligne lån – jo lavere, jo billigere. Kig også på de samlede tilbagebetalinger i kroner, fordi et lån med lav ydelse over lang tid kan blive dyrt alligevel."),
    SaldoKnowledgeEntry("Rente og rentes rente", listOf(" rentes rente", " renters rente", " hvad er rente", " rente ", " renten "),
        "Rente er prisen for at låne penge – eller det du får for at spare op. Ved rentes rente får du også rente af tidligere renter, så beløbet vokser hurtigere over tid. Eksempel: 10.000 kr. til 5 % om året bliver til ca. 16.300 kr. efter 10 år. Det samme virker imod dig på gæld: jo længere tid den står, jo mere koster den."),
    SaldoKnowledgeEntry("Inflation", listOf(" inflation", " prisstigning", " priserne stiger", " købekraft"),
        "Inflation betyder, at priserne generelt stiger, så hver krone kan købe lidt mindre. Penge på en konto med lavere rente end inflationen taber altså værdi over tid. Derfor kan det give mening at have en buffer på kontoen, men investere langsigtet opsparing. Følg dit eget forbrug pr. kategori i Rapporter for at se, hvor stigningerne rammer dig.", "Se rapport", "Rapporter"),
    SaldoKnowledgeEntry("Nødopsparing", listOf(" nødopsparing", " buffer", " uforudsete", " nødfond", " stødpude"),
        "En nødopsparing er penge, der kun bruges til det uforudsete – fx tandlæge, reparation af bil eller tab af job. En god tommelfingerregel er 1-3 måneders faste udgifter, og gerne mere hvis din indkomst svinger. Læg den på en separat konto, så den ikke bruges i hverdagen. Opret et mål under Opsparing, så kan du følge den.", "Opret mål", "Opsparing"),
    SaldoKnowledgeEntry("Budgetregler", listOf(" 50 30 20", " lægge et budget", " lave et budget", " hvordan budgetter", " budgetregel", " hvor meget skal jeg bruge på"),
        "En enkel start er 50/30/20-reglen: ca. 50 % af lønnen efter skat til faste nødvendige udgifter (bolig, mad, transport), 30 % til ønsker og fritid og 20 % til opsparing og ekstra afdrag på gæld. Tilpas fordelingen til dit liv. I Saldo kan du trykke på budgetforslag, så laver appen budgetter ud fra dit faktiske forbrug de sidste tre måneder.", "Åbn Budget", "Budget"),
    SaldoKnowledgeEntry("Gæld eller opsparing først", listOf(" gæld eller spare", " spare op eller betale", " betale gæld af eller", " afdrage eller spare", " før jeg sparer", " gæld før"),
        "Som tommelfingerregel: 1) Byg en lille nødopsparing først, så nye uforudsete udgifter ikke ender som ny gæld. 2) Betal derefter dyr gæld af (kviklån, kreditkort, forbrugslån) – renten her er næsten altid højere end det, du kan tjene ved at spare op. 3) Billig gæld som realkreditlån haster mindre; her kan opsparing og pension give mening ved siden af. Gældfri-planen i Saldo viser, hvornår du er gældfri.", "Se gældfri-plan", "Gæld"),
    SaldoKnowledgeEntry("Sneboldmetoden og lavinemetoden", listOf(" snebold", " lavine", " avalanche", " snowball", " hvilken gæld først", " betale gæld af hurtigt", " blive gældfri"),
        "To populære metoder til at blive gældfri: Lavinemetoden betaler ekstra af på lånet med den højeste rente først – det er billigst. Sneboldmetoden betaler det mindste lån af først – det giver hurtige sejre og motivation. Uanset metode betaler du minimumsydelsen på alle lån og lægger alt ekstra på ét lån ad gangen. Gældfri-planen i Saldo kan beregne begge.", "Se gældfri-plan", "Gæld"),
    SaldoKnowledgeEntry("Kviklån og forbrugslån", listOf(" kviklån", " forbrugslån", " sms lån", " lån til forbrug", " hurtigt lån"),
        "Kviklån og forbrugslån er typisk dyre lån med høj ÅOP. De kan være lette at få, men svære at komme ud af. Undgå dem til forbrug, og betal dem af som det første, hvis du har dem. Har du flere dyre lån, så spørg din bank om en samlet og billigere løsning – eller søg gratis gældsrådgivning."),
    SaldoKnowledgeEntry("Kreditkort", listOf(" kreditkort", " kredit kort", " mastercard", " visa kort", " rentefri periode"),
        "Et kreditkort er en lånefacilitet: betaler du hele saldoen hver måned inden for den rentefri periode, koster det typisk ikke rente. Betaler du kun en del, bliver renten ofte høj. Brug det helst som betalingsmiddel og betal fuldt af, og registrér købene i Saldo, så du kan se dem i budgettet."),
    SaldoKnowledgeEntry("Rykker, inkasso og RKI", listOf(" rykker", " inkasso", " rki", " skyldnerregister", " kan ikke betale", " betalingsproblemer", " gældsrådgivning"),
        "Kan du ikke betale en regning, så kontakt kreditor hurtigst muligt og bed om en afdragsordning – det er næsten altid billigere end rykkergebyrer og inkasso. Ved manglende betaling kan sagen ende hos inkasso og eventuelt i et skyldnerregister som RKI, hvilket gør det svært at få lån og abonnementer. Der findes gratis, uvildig gældsrådgivning (fx via kommunen eller frivillige gældsrådgivninger), som kan hjælpe med overblik og forhandling."),
    SaldoKnowledgeEntry("Realkreditlån", listOf(" realkredit", " boliglån", " fast rente", " variabel rente", " flexlån", " afdragsfrihed", " bidragssats", " omlægning"),
        "Et realkreditlån er lån med pant i boligen, typisk op til 80 % af værdien. Fast rente giver samme ydelse i hele lånets løbetid og beskytter mod rentestigninger; variabel rente (fx F-lån) er ofte lavere nu, men kan stige. Udover renten betaler du bidrag til realkreditinstituttet. Afdragsfrihed giver lavere ydelse i en periode, men du betaler ikke af på gælden imens. Få altid beregninger fra flere banker."),
    SaldoKnowledgeEntry("Boligkøb", listOf(" købe bolig", " købe lejlighed", " købe hus", " boligkøb", " udbetaling", " første bolig", " hvor meget kan jeg låne"),
        "Ved boligkøb skal du typisk selv betale mindst 5 % i udbetaling; resten finansieres som regel med realkreditlån (op til 80 %) og banklån. Banken vurderer, hvor meget du kan låne, ud fra indkomst, gæld og rådighedsbeløb. Husk også handelsomkostninger (advokat, tinglysning, gebyrer) og løbende udgifter som ejendomsskat, forsikring og vedligehold. Saldos opsparingsmål kan hjælpe dig med at spare udbetalingen op.", "Opret opsparingsmål", "Opsparing"),
    SaldoKnowledgeEntry("Billån og leasing", listOf(" billån", " leasing", " købe bil", " lease"),
        "Ved billån ejer du bilen og betaler lånet af; ved leasing lejer du den og afleverer den igen. Leasing kan give en fast månedlig pris, men har ofte kilometerbegrænsning og krav ved aflevering, og du ejer ikke noget bagefter. Sammenlign den samlede pris over hele perioden – inklusive forsikring, brændstof, service og værditab. Brændstof-siden i Saldo viser dit forbrug og pris pr. km.", "Åbn Brændstof", "Brændstof"),
    SaldoKnowledgeEntry("Aktiesparekonto", listOf(" aktiesparekonto", " aktie sparekonto", " ask "),
        "En aktiesparekonto er en særlig konto til investering i aktier og investeringsfonde med en lav skat, der beregnes af årets gevinst eller tab (lagerbeskatning), og du skal ikke selv indberette den. Der er et loft over, hvor meget du kan indskyde. Den er god til langsigtet opsparing for mange. Se det aktuelle loft og skattesats på skat.dk eller hos din bank."),
    SaldoKnowledgeEntry("Investering for begyndere", listOf(" investere", " investering", " aktier", " indeksfond", " etf", " fonde", " værdipapir"),
        "Investering giver mulighed for højere afkast end en bankkonto, men værdien kan også falde. Gode grundprincipper: invester kun penge, du ikke skal bruge de næste 5+ år, spred risikoen (fx bredt globale indeksfonde i stedet for enkeltaktier), hold omkostningerne lave og invester løbende i stedet for at prøve at ramme det rigtige tidspunkt. Hav en nødopsparing først. Dette er generel vejledning – tal med banken før store beslutninger."),
    SaldoKnowledgeEntry("Kryptovaluta", listOf(" krypto", " bitcoin", " ethereum", " coin"),
        "Kryptovaluta svinger meget i værdi og kan miste det meste af værdien på kort tid. Invester kun beløb, du har råd til at tabe, og vær særligt opmærksom på svindel og 'garanterede' afkast. Gevinster og tab på krypto skal som udgangspunkt oplyses til Skat – se skat.dk."),
    SaldoKnowledgeEntry("Pension", listOf(" pension", " ratepension", " aldersopsparing", " livrente", " folkepension", " pensionsalder"),
        "De fleste får pension fra tre kilder: folkepension fra staten, arbejdsmarkedspension via jobbet og eventuel privat opsparing (fx ratepension, livrente eller aldersopsparing). Indbetaling til ratepension og livrente giver fradrag nu, men beskattes ved udbetaling; aldersopsparing er omvendt. Se dine pensioner samlet på pensionsinfo.dk, og spørg din pensionskasse, om du sparer nok op."),
    SaldoKnowledgeEntry("Skat og trækprocent", listOf(" trækprocent", " personfradrag", " skattekort", " hovedkort", " bikort", " frikort", " skat af løn", " hvordan beregnes skat"),
        "Din skat beregnes ud fra forskudsopgørelsen. Arbejdsgiveren trækker først 8 % AM-bidrag af bruttolønnen og derefter A-skat efter din trækprocent; personfradraget (et beløb pr. måned, du ikke betaler skat af) står på dit skattekort. Har du flere job, skal hovedkortet bruges ét sted og bikortet de andre steder. Ret forskudsopgørelsen på skat.dk, hvis din indkomst eller dine fradrag ændrer sig."),
    SaldoKnowledgeEntry("Fradrag", listOf(" fradrag", " befordring", " kørselsfradrag", " servicefradrag", " håndværkerfradrag", " rentefradrag", " fagforening"),
        "Kendte fradrag er bl.a. kørselsfradrag (befordring) ved lang vej til arbejde, rentefradrag for renter af lån, fradrag for fagforening og a-kasse, og servicefradrag for visse håndværks- og serviceydelser i hjemmet. Mange fradrag kommer automatisk, men tjek altid din forskudsopgørelse og årsopgørelse på skat.dk – satser og regler ændres hvert år."),
    SaldoKnowledgeEntry("Årsopgørelse og restskat", listOf(" årsopgørelse", " restskat", " overskydende skat", " penge tilbage i skat", " forskudsopgørelse", " skat tilbage"),
        "Årsopgørelsen kommer i foråret og viser, om du har betalt for meget eller for lidt i skat sidste år. Overskydende skat udbetales til din NemKonto. Restskat skal betales med et procenttillæg; et mindre beløb kan blive lagt over i næste års skat. Undgå restskat ved at holde forskudsopgørelsen opdateret på skat.dk, fx når du skifter job eller får ny løn."),
    SaldoKnowledgeEntry("Lønseddel og bruttoløn", listOf(" lønseddel", " bruttoløn", " nettoløn", " am bidrag", " efter skat", " før skat", " udbetalt løn"),
        "Bruttoløn er lønnen før skat. Af den trækkes typisk pension (din andel), 8 % AM-bidrag og A-skat efter trækprocent og personfradrag – resten er nettoløn, som udbetales til din NemKonto. I Saldo skal du indtaste nettolønnen (efter skat) under Indstillinger → Løn og lønrytme, så rådighedsbeløbet bliver rigtigt.", "Ret løn", "Indstillinger"),
    SaldoKnowledgeEntry("Feriepenge", listOf(" feriepenge", " ferietillæg", " ferie med løn", " optjen ferie"),
        "Du optjener ferie løbende, mens du arbejder. Har du løn under ferie, får du typisk også et ferietillæg; ellers indbetaler arbejdsgiveren feriepenge, som du kan få udbetalt, når du holder ferie. Du kan se dine feriepenge via borger.dk (Feriepengeinfo). Registrér udbetalingen som indtægt i Saldo."),
    SaldoKnowledgeEntry("SU", listOf(" su ", " su lån", " statens uddannelsesstøtte", " fribeløb", " studielån"),
        "SU er statens uddannelsesstøtte til studerende. Ud over SU-stipendiet kan du tage SU-lån med lav rente under studiet, som skal betales tilbage efter studiet. Tjener du for meget ved siden af studiet, kan du komme over fribeløbet og skulle betale SU tilbage. Se aktuelle satser og fribeløb på su.dk."),
    SaldoKnowledgeEntry("Dagpenge og a-kasse", listOf(" a kasse", " akasse", " dagpenge", " arbejdsløs", " mister mit job", " ledig"),
        "Er du medlem af en a-kasse og opfylder kravene, kan du få dagpenge, hvis du bliver ledig. Kontingentet til a-kasse giver fradrag. Bliver du ledig, så meld dig ledig på jobnet.dk første dag og kontakt din a-kasse. Lav et nyt budget med den lavere indkomst – Saldo kan hjælpe med at se, hvilke udgifter der kan skæres.", "Åbn Budget", "Budget"),
    SaldoKnowledgeEntry("Boligstøtte", listOf(" boligstøtte", " boligsikring", " boligydelse", " hjælp til husleje"),
        "Boligstøtte (boligsikring eller boligydelse for pensionister) er et tilskud til huslejen for lejere med lav indkomst. Om du kan få det, afhænger af husleje, indkomst, formue og husstandens størrelse. Søg og beregn på borger.dk."),
    SaldoKnowledgeEntry("Børneopsparing og børnecheck", listOf(" børneopsparing", " børnecheck", " børne og ungeydelse", " børneydelse", " spare op til børn"),
        "Børne- og ungeydelsen (børnechecken) udbetales kvartalsvis til forældre. En børneopsparing er en bunden opsparing til barnet med et årligt og et samlet indskudsloft, som barnet kan få udbetalt som ung. Se aktuelle beløb på borger.dk og hos din bank. Opret et opsparingsmål i Saldo for at følge den.", "Opret mål", "Opsparing"),
    SaldoKnowledgeEntry("Forsikringer", listOf(" forsikring", " indboforsikring", " ansvarsforsikring", " ulykkesforsikring", " rejseforsikring", " bilforsikring"),
        "En indboforsikring (typisk med ansvarsforsikring) er for de fleste den vigtigste – den dækker dine ting ved fx brand, indbrud og vandskade. Ulykkes-, rejse- og bilforsikring afhænger af din situation. Tjek om du er dobbeltforsikret (fx rejseforsikring via kreditkort), og indhent tilbud hvert år eller to. Læg forsikringerne ind som faste regninger i Saldo.", "Se regninger", "Regninger"),
    SaldoKnowledgeEntry("Spare på faste udgifter", listOf(" faste udgifter", " skære ned på", " billigere el", " mobilabonnement", " spare penge på"),
        "De største besparelser findes ofte i de faste udgifter: gennemgå abonnementer, skift mobil- og internetabonnement, indhent tilbud på forsikringer, sammenlign elaftaler og overvej om bilen kan erstattes eller deles. Abonnementsradaren i Saldo finder faste betalinger i dine poster, så du kan se, hvad der kan opsiges.", "Åbn Abonnementer", "Abonnementer"),
    SaldoKnowledgeEntry("Madbudget", listOf(" madbudget", " spare på mad", " billig mad", " madspild", " indkøb"),
        "Gode råd til et lavere madbudget: lav madplan og indkøbsliste, køb ind én gang om ugen, brug tilbudsaviser og discountkæder, lav større portioner til madpakker og frysning, og undgå madspild. Sæt et budget for Mad i Saldo og følg det i løbet af måneden.", "Åbn Budget", "Budget"),
    SaldoKnowledgeEntry("NemKonto", listOf(" nemkonto", " nem konto"),
        "Din NemKonto er den bankkonto, hvor det offentlige udbetaler penge til dig – fx overskydende skat, SU, børnecheck og feriepenge. Du kan se og ændre den via din bank eller nemkonto.dk."),
    SaldoKnowledgeEntry("Kreditvurdering", listOf(" kreditvurdering", " kreditværdighed", " få et lån", " afslag på lån", " rådighedsbeløb banken"),
        "Når du søger lån, ser banken på din indkomst, din eksisterende gæld, dit rådighedsbeløb efter faste udgifter og om du er registreret i et skyldnerregister. Du står stærkere med lav gæld, en stabil indkomst, en opsparing og et overblik over dit budget – fx en PDF-rapport fra Saldo.", "Lav PDF-rapport", "Rapporter"),
    SaldoKnowledgeEntry("Svindel", listOf(" svindel", " phishing", " snyd", " falsk sms", " mitid kode", " investeringssvindel"),
        "Banker, Skat og myndigheder beder aldrig om din MitID-godkendelse, kode eller kortoplysninger via sms, mail eller telefon. Tryk ikke på links i uventede beskeder, og godkend aldrig noget i MitID, du ikke selv har startet. Lyder en investering for god til at være sand, er den det som regel. Har du været udsat for svindel, så kontakt straks din bank og politiet."),
    SaldoKnowledgeEntry("Fælles økonomi", listOf(" fælles økonomi", " fælleskonto", " deler udgifter", " min partner", " min kæreste", " dele regninger"),
        "Par deler ofte økonomien efter én af tre modeller: alt fælles, en fælleskonto til faste udgifter (hver betaler efter indkomst eller ligeligt) og resten privat, eller helt adskilt med deling af regninger. Det vigtigste er at aftale det tydeligt. I Saldo kan poster og regninger markeres med ejer (Mig, Partner eller Fælles), så I kan se, hvem der betaler hvad.", "Se poster", "Poster"),
)

/** Best matching knowledge entry for a normalised question, or null when nothing matches. */
internal fun findSaldoKnowledge(normalizedQuestion: String): SaldoKnowledgeEntry? =
    saldoKnowledgeBase
        .map { entry -> entry to entry.keywords.count { normalizedQuestion.contains(it) } }
        .filter { it.second > 0 }
        .maxByOrNull { it.second }
        ?.first
