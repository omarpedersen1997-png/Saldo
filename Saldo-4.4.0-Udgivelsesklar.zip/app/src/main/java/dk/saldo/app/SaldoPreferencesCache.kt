package dk.saldo.app

import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * In-memory front for the encrypted preferences.
 *
 * EncryptedSharedPreferences decrypts on every read and encrypts on every write. The UI reads
 * dozens of settings on each recomposition and saves the full data JSON on every change, so doing
 * that work on the main thread made the app feel slow. This wrapper decrypts everything once,
 * serves reads from memory, and writes the encrypted copy on one background thread in order.
 * `commit()` still waits for the disk write, so callers that need durability keep it.
 */
internal class SaldoMemoryPreferences(private val delegate: SharedPreferences) : SharedPreferences {
    private val lock = Any()
    private val values: MutableMap<String, Any?> = HashMap(delegate.all)
    private val listeners = mutableSetOf<SharedPreferences.OnSharedPreferenceChangeListener>()
    private val writer = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "saldo-prefs-writer").apply { isDaemon = true } }
    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }

    override fun getAll(): MutableMap<String, *> = synchronized(lock) { HashMap(values) }
    override fun getString(key: String?, defValue: String?): String? = synchronized(lock) { values[key] as? String ?: defValue }
    @Suppress("UNCHECKED_CAST")
    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? = synchronized(lock) {
        (values[key] as? Set<String>)?.toMutableSet() ?: defValues
    }
    override fun getInt(key: String?, defValue: Int): Int = synchronized(lock) { values[key] as? Int ?: defValue }
    override fun getLong(key: String?, defValue: Long): Long = synchronized(lock) { values[key] as? Long ?: defValue }
    override fun getFloat(key: String?, defValue: Float): Float = synchronized(lock) { values[key] as? Float ?: defValue }
    override fun getBoolean(key: String?, defValue: Boolean): Boolean = synchronized(lock) { values[key] as? Boolean ?: defValue }
    override fun contains(key: String?): Boolean = synchronized(lock) { values.containsKey(key) }
    override fun edit(): SharedPreferences.Editor = MemoryEditor()

    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) synchronized(lock) { listeners.add(listener) }
    }
    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) synchronized(lock) { listeners.remove(listener) }
    }

    /** Waits (bounded) until every queued encrypted write has reached disk. */
    fun flush() {
        runCatching { writer.submit {}.get(5, TimeUnit.SECONDS) }
    }

    private inner class MemoryEditor : SharedPreferences.Editor {
        private val puts = LinkedHashMap<String, Any?>()
        private val removals = mutableSetOf<String>()
        private var clearAll = false

        override fun putString(key: String, value: String?): SharedPreferences.Editor { puts[key] = value; removals.remove(key); return this }
        override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor { puts[key] = values?.toSet(); removals.remove(key); return this }
        override fun putInt(key: String, value: Int): SharedPreferences.Editor { puts[key] = value; removals.remove(key); return this }
        override fun putLong(key: String, value: Long): SharedPreferences.Editor { puts[key] = value; removals.remove(key); return this }
        override fun putFloat(key: String, value: Float): SharedPreferences.Editor { puts[key] = value; removals.remove(key); return this }
        override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor { puts[key] = value; removals.remove(key); return this }
        override fun remove(key: String): SharedPreferences.Editor { removals.add(key); puts.remove(key); return this }
        override fun clear(): SharedPreferences.Editor { clearAll = true; return this }

        /** Updates memory now and returns the keys that changed. */
        private fun applyToMemory(): List<String> = synchronized(lock) {
            val changed = mutableListOf<String>()
            if (clearAll) { changed += values.keys; values.clear() }
            removals.forEach { key -> if (values.containsKey(key)) { values.remove(key); changed += key } }
            puts.forEach { (key, value) ->
                if (value == null) { values.remove(key) } else values[key] = value
                changed += key
            }
            changed
        }

        private fun writeToDisk(): Boolean {
            val editor = delegate.edit()
            if (clearAll) editor.clear()
            removals.forEach { editor.remove(it) }
            puts.forEach { (key, value) ->
                @Suppress("UNCHECKED_CAST")
                when (value) {
                    null -> editor.remove(key)
                    is String -> editor.putString(key, value)
                    is Set<*> -> editor.putStringSet(key, (value as Set<String>).toMutableSet())
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                }
            }
            return editor.commit()
        }

        private fun notify(changed: List<String>) {
            val current = synchronized(lock) { listeners.toList() }
            if (current.isEmpty() || changed.isEmpty()) return
            val dispatch = { changed.forEach { key -> current.forEach { it.onSharedPreferenceChanged(this@SaldoMemoryPreferences, key) } } }
            if (Looper.myLooper() == Looper.getMainLooper()) dispatch() else mainHandler.post(dispatch)
        }

        override fun apply() {
            val changed = applyToMemory()
            writer.execute { runCatching { writeToDisk() } }
            notify(changed)
        }

        override fun commit(): Boolean {
            val changed = applyToMemory()
            val ok = runCatching { writer.submit<Boolean> { writeToDisk() }.get() }.getOrDefault(false)
            notify(changed)
            return ok
        }
    }
}

/** Makes sure queued preference writes are on disk, e.g. before the app goes to the background. */
internal fun flushSaldoPreferences() {
    (cachedSaldoPreferences as? SaldoMemoryPreferences)?.flush()
}
