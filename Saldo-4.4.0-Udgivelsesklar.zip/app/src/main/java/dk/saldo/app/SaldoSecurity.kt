package dk.saldo.app
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.widget.Toast
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.os.Bundle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.automirrored.filled.FactCheck
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.outlined.Home as OutlinedHome
import androidx.compose.material.icons.outlined.CalendarMonth as OutlinedCalendarMonth
import androidx.compose.material.icons.outlined.PieChart as OutlinedPieChart
import androidx.compose.material.icons.outlined.GridView as OutlinedGridView
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong as OutlinedReceiptLong
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.text.Normalizer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.ln

// App lock: biometric prompt and salted PIN hashing.

internal fun startBiometric(activity: FragmentActivity, context: Context, onSuccess: () -> Unit = {}) {
    val manager = BiometricManager.from(context)
    if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
        Toast.makeText(context, "Ingen biometrisk oplåsning er sat op på telefonen.", Toast.LENGTH_LONG).show(); return
    }
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onSuccess()
        }
        override fun onAuthenticationFailed() { Toast.makeText(context, "Fingeraftryk blev ikke genkendt.", Toast.LENGTH_SHORT).show() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { Toast.makeText(context, errString, Toast.LENGTH_SHORT).show() }
    })
    prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Lås Saldo op").setSubtitle("Bekræft din identitet").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Annuller").build())
}

internal fun newPinSalt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }
    .joinToString("") { "%02x".format(it) }

internal fun hashPin(pin: String, saltHex: String): String {
    val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
    return try {
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            .joinToString("") { "%02x".format(it) }
    } finally { spec.clearPassword() }
}

internal fun hexToBytes(hex: String): ByteArray? = runCatching {
    require(hex.isNotBlank() && hex.length % 2 == 0)
    hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}.getOrNull()

internal fun verifyAndUpgradePin(prefs: android.content.SharedPreferences, candidate: String): Boolean {
    val storedHash = prefs.getString("pin_hash", null)
    val storedSalt = prefs.getString("pin_salt", null)
    if (!storedHash.isNullOrBlank() && !storedSalt.isNullOrBlank()) {
        val expected = hexToBytes(storedHash) ?: return false
        val actual = hexToBytes(hashPin(candidate, storedSalt)) ?: return false
        return MessageDigest.isEqual(expected, actual)
    }
    // Existing installations used a plaintext PIN; upgrade it only after a correct unlock.
    val legacyPin = prefs.getString("pin", null)
    if (legacyPin != null && candidate == legacyPin) {
        val salt = newPinSalt()
        prefs.edit().putString("pin_salt", salt).putString("pin_hash", hashPin(candidate, salt))
            .remove("pin").apply()
        return true
    }
    return false
}
