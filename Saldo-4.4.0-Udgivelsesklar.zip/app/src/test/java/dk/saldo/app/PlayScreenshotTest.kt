package dk.saldo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onLast
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.time.LocalDate
import java.util.Locale

/**
 * Renders the real app with illustrative demo data and saves Google Play screenshots to app/build/play-screenshots.
 * Only runs with -PsaldoScreenshots=true (see app/build.gradle.kts); the normal test run excludes it.
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "da-rDK-w393dp-h852dp-night-xxhdpi")
class PlayScreenshotTest {
    private val seed = object : ExternalResource() {
        override fun before() = seedDemoData()
    }
    private val compose = createAndroidComposeRule<MainActivity>()

    @get:Rule
    val rules: RuleChain = RuleChain.outerRule(seed).around(compose)

    private val outDir = File(System.getProperty("user.dir"), "build/play-screenshots").apply { mkdirs() }
    private val errors = mutableListOf<String>()

    private fun settle(ms: Long = 3000) {
        compose.mainClock.advanceTimeBy(ms)
        compose.waitForIdle()
    }

    /** All window root views (activity and dialogs), oldest first. */
    private fun rootViews(): List<View> {
        val global = Class.forName("android.view.WindowManagerGlobal")
        val instance = global.getMethod("getInstance").invoke(null)
        val field = global.getDeclaredField("mViews").apply { isAccessible = true }
        return (field.get(instance) as List<*>).filterIsInstance<View>().filter { it.isShown && it.width > 0 }
    }

    private fun save(name: String, view: () -> View) {
        settle()
        val root = view()
        val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFF0D1224.toInt())
        root.draw(canvas)
        File(outDir, "$name.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun mainRoot(): () -> View = { rootViews().first() }
    private fun topRoot(): () -> View = { rootViews().last() }

    private fun click(text: String, scroll: Boolean = false) {
        val matcher = hasText(text) and hasClickAction()
        if (scroll && compose.onAllNodes(matcher).fetchSemanticsNodes().isEmpty()) {
            // Tiles further down a lazy list are not composed until scrolled into view.
            compose.onAllNodes(hasScrollAction()).onFirst().performScrollToNode(matcher)
            settle(800)
        }
        val node = compose.onAllNodes(matcher).onFirst()
        if (scroll) runCatching { node.performScrollTo() }
        node.performClick()
        settle(1500)
    }

    /** Shows the previous month early in a month, so lists and budgets have a full month of data. */
    private fun showFullMonth() {
        if (LocalDate.now().dayOfMonth < 12) {
            compose.onAllNodesWithContentDescription("Forrige måned").onFirst().performClick()
            settle(1500)
        }
    }

    private fun step(name: String, block: () -> Unit) {
        runCatching(block).onFailure { errors += "$name: ${it::class.simpleName}: ${it.message?.take(300)}" }
    }

    @Test
    fun capturePlayScreenshots() {
        settle(4000)
        step("01_overblik") { save("01_overblik", mainRoot()) }
        step("02_sporg_saldo") {
            click("Spørg")
            click("Hvor meget kan jeg bruge i dag?")
            click("Hvilke regninger skal betales?")
            save("02_sporg_saldo", topRoot())
            compose.onAllNodesWithContentDescription("Luk").onLast().performClick()
            settle(1500)
        }
        step("03_poster") { click("Poster"); showFullMonth(); save("03_poster", mainRoot()) }
        step("04_budget") { click("Budget"); showFullMonth(); save("04_budget", mainRoot()) }
        step("05_regninger") { click("Regninger"); save("05_regninger", mainRoot()) }
        step("06_rapporter") { click("Mere"); click("Rapporter", scroll = true); showFullMonth(); save("06_rapporter", mainRoot()) }
        step("07_gaeld") { click("Mere"); click("Gæld", scroll = true); save("07_gaeld", mainRoot()) }
        step("08_opsparing") { click("Mere"); click("Opsparing", scroll = true); save("08_opsparing", mainRoot()) }
        step("09_abonnementer") { click("Mere"); click("Abonnementer", scroll = true); save("09_abonnementer", mainRoot()) }
        File(outDir, "errors.txt").writeText(errors.joinToString("\n"))
        assertTrue("Ingen skærmbilleder: ${errors.joinToString(" | ")}", outDir.listFiles { f -> f.extension == "png" }.orEmpty().isNotEmpty())
    }

    // ------------------------------------------------------------------------------------------- demo data
    private fun seedDemoData() {
        Locale.setDefault(Locale("da", "DK"))
        val context = ApplicationProvider.getApplicationContext<Context>()
        runCatching { androidx.work.testing.WorkManagerTestInitHelper.initializeTestWorkManager(context) }
        val prefs = context.getSharedPreferences("saldo-play-screenshots", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        cachedSaldoPreferences = prefs

        val today = LocalDate.now()
        var id = 0
        fun next() = "demo-${++id}"
        fun day(month: LocalDate, dayOfMonth: Int) = month.withDayOfMonth(minOf(dayOfMonth, month.lengthOfMonth()))

        val tx = JSONArray()
        fun post(name: String, amount: Double, date: LocalDate, category: String, owner: String = "Fælles", type: String = "Udgift") {
            if (!date.isAfter(today)) tx.put(JSONObject().put("id", next()).put("name", name).put("amount", amount).put("date", date.toString())
                .put("category", category).put("type", type).put("owner", owner))
        }
        for (back in 0..5) {
            val m = today.minusMonths(back.toLong()).withDayOfMonth(1)
            val k = back % 3
            post("Løn", 24500.0, day(m, 1), "Løn", "Mig", "Indtægt")
            post("Løn – Partner", 21800.0, day(m, 1), "Løn", "Partner", "Indtægt")
            post("Husleje", 9850.0, day(m, 1), "Bolig")
            post("Netto", 412.50 + k * 37, day(m, 3), "Mad")
            post("Rema 1000", 689.75 - k * 41, day(m, 7), "Mad")
            post("Føtex", 954.20 + k * 55, day(m, 12), "Mad")
            post("Lidl", 318.40, day(m, 17), "Mad")
            post("Netto", 527.95 - k * 23, day(m, 22), "Mad")
            post("Rejsekort", 450.0, day(m, 2), "Transport", "Mig")
            post("Circle K", 612.30 + k * 48, day(m, 14), "Transport", "Partner")
            post("Netflix", 129.0, day(m, 5), "Abonnementer")
            post("Spotify Duo", 149.0, day(m, 8), "Abonnementer")
            post("Fitness World", 299.0, day(m, 1), "Fritid", "Mig")
            post("Café Norden", 285.0 + k * 60, day(m, 10), "Fritid", "Mig")
            post("Biograf", 230.0, day(m, 19), "Fritid", "Partner")
            post("Matas", 214.95, day(m, 15), "Personlig pleje", "Partner")
            post("H&M", 399.0 - k * 50, day(m, 20), "Tøj", "Mig")
            post("Opsparing – ferie", 1000.0, day(m, 2), "Opsparing", "Fælles", "Udgift")
        }

        val bills = JSONArray()
        fun bill(name: String, amount: Double, due: LocalDate, category: String, paid: Boolean = false, repeat: String = "Månedlig") {
            bills.put(JSONObject().put("id", next()).put("name", name).put("amount", amount).put("date", due.toString())
                .put("category", category).put("owner", "Fælles").put("repeat", repeat).put("paid", paid))
        }
        bill("El – Andel Energi", 685.0, today.plusDays(4), "Bolig", repeat = "Engangsbetaling")
        bill("Internet – Hiper", 299.0, today.plusDays(9), "Bolig", repeat = "Engangsbetaling")
        bill("Indboforsikring", 154.0, today.plusDays(13), "Forsikring", repeat = "Engangsbetaling")
        bill("Bilforsikring", 1140.0, today.plusDays(19), "Forsikring", repeat = "Engangsbetaling")
        bill("Vand og varme", 1320.0, today.plusDays(33), "Bolig", repeat = "Engangsbetaling")
        bill("Licens til TV-pakke", 219.0, today.minusDays(6), "Abonnementer", paid = true, repeat = "Engangsbetaling")

        val budgets = JSONArray()
        fun budget(category: String, limit: Double, owner: String) =
            budgets.put(JSONObject().put("id", next()).put("category", category).put("limit", limit).put("owner", owner))
        budget("Mad", 3200.0, "Fælles")
        budget("Transport", 1100.0, "Partner")
        budget("Fritid", 900.0, "Mig")
        budget("Tøj", 500.0, "Mig")
        budget("Personlig pleje", 300.0, "Partner")

        val goals = JSONArray()
        goals.put(JSONObject().put("id", next()).put("name", "Ferie til Mallorca").put("target", 18000.0).put("saved", 11400.0).put("date", today.plusMonths(7).withDayOfMonth(1).toString()))
        goals.put(JSONObject().put("id", next()).put("name", "Nødopsparing").put("target", 30000.0).put("saved", 21750.0).put("date", today.plusMonths(14).withDayOfMonth(1).toString()))
        goals.put(JSONObject().put("id", next()).put("name", "Ny cykel").put("target", 6500.0).put("saved", 1800.0).put("date", today.plusMonths(5).withDayOfMonth(1).toString()))

        val subs = JSONArray()
        fun sub(name: String, monthly: Double, renewal: LocalDate) =
            subs.put(JSONObject().put("id", next()).put("name", name).put("monthly", monthly).put("renewalDate", renewal.toString()).put("cancelByDate", "").put("cancelNote", "").put("owner", "Fælles").put("active", true))
        sub("Netflix", 129.0, today.plusDays(4))
        sub("Spotify Duo", 149.0, today.plusDays(7))
        sub("Fitness World", 299.0, today.plusDays(12))
        sub("Viaplay", 149.0, today.plusDays(21))
        sub("iCloud+", 29.0, today.plusDays(26))

        val debts = JSONArray()
        debts.put(JSONObject().put("id", next()).put("name", "Billån").put("balance", 68400.0).put("rate", 4.9).put("payment", 2150.0))
        debts.put(JSONObject().put("id", next()).put("name", "Kreditkort").put("balance", 6400.0).put("rate", 19.9).put("payment", 650.0))
        debts.put(JSONObject().put("id", next()).put("name", "SU-lån").put("balance", 41200.0).put("rate", 4.0).put("payment", 520.0))

        val fuel = JSONArray()
        for (back in 0..4) fuel.put(JSONObject().put("id", next()).put("date", today.minusDays(9L + back * 16).toString()).put("liters", 38.5 - back).put("cost", Math.round((38.5 - back) * (13.79 + back * 0.12) * 100) / 100.0).put("km", 610.0 + back * 15))

        val data = JSONObject().put("transactions", tx).put("bills", bills).put("budgets", budgets).put("goals", goals)
            .put("debts", debts).put("subs", subs).put("fuel", fuel)

        val nextPayday = if (today.dayOfMonth < 28) today.withDayOfMonth(28) else today.plusMonths(1).withDayOfMonth(28)
        check(
            prefs.edit()
                .putString("data", data.toString())
                .putBoolean("onboarding_done", true)
                .putBoolean("design_2026_dark_applied", true)
                .putBoolean("dark_mode", true)
                .putString("theme_mode", "dark")
                .putString("online_access_token", "demo")
                .putString("online_refresh_token", "demo")
                .putString("active_account_user_id", "demo-user")
                .putString("account_email", "maja@eksempel.dk")
                .putString("payday", nextPayday.toString())
                .putString("pay_frequency", "monthly")
                .putSaldoMoney("pay_amount", 24500.0)
                .putSaldoMoney("cash_balance", 14862.40)
                .putString("month_recap_dismissed", java.time.YearMonth.from(today).minusMonths(1).toString())
                .putBoolean("weekly_summary_enabled", true)
                .commit()
        )
    }
}
