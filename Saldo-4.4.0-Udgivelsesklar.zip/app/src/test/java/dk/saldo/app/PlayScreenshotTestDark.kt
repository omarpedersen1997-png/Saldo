package dk.saldo.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onLast
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/**
 * Review screenshots (not for Google Play): every secondary screen, dialogs and sheets in the dark theme.
 * Runs only with -PsaldoScreenshots=true; files are prefixed "audit_".
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "da-rDK-w393dp-h852dp-notnight-xxhdpi")
class PlayScreenshotTestDark {
    private val seed = object : ExternalResource() {
        override fun before() = PlayScreenshotTest().seedDemoData(dark = true)
    }
    private val compose = createAndroidComposeRule<MainActivity>()

    @get:Rule
    val rules: RuleChain = RuleChain.outerRule(seed).around(compose)

    private val outDir = File(System.getProperty("user.dir"), "build/play-screenshots").apply { mkdirs() }
    private val errors = mutableListOf<String>()

    private fun settle(ms: Long = 3000) { compose.mainClock.advanceTimeBy(ms); compose.waitForIdle() }

    private fun rootViews(): List<View> {
        val global = Class.forName("android.view.WindowManagerGlobal")
        val instance = global.getMethod("getInstance").invoke(null)
        val field = global.getDeclaredField("mViews").apply { isAccessible = true }
        return (field.get(instance) as List<*>).filterIsInstance<View>().filter { it.isShown && it.width > 0 }
    }

    private fun save(name: String, top: Boolean = false) {
        settle()
        val views = rootViews()
        val root = if (top) views.last() else views.first()
        val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFF000000.toInt())
        root.draw(canvas)
        File(outDir, "audit_$name.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun click(text: String, scroll: Boolean = false) {
        val matcher = hasText(text) and hasClickAction()
        if (scroll && compose.onAllNodes(matcher).fetchSemanticsNodes().isEmpty()) {
            compose.onAllNodes(hasScrollAction()).onFirst().performScrollToNode(matcher)
            settle(800)
        }
        val byDescription = hasContentDescription(text) and hasClickAction()
        val node = if (compose.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty()) compose.onAllNodes(matcher).onFirst() else compose.onAllNodes(byDescription).onFirst()
        if (scroll) runCatching { node.performScrollTo() }
        node.performClick()
        settle(1500)
    }

    private fun back() {
        runCatching { compose.activityRule.scenario.onActivity { it.onBackPressedDispatcher.onBackPressed() } }
        settle(1500)
    }

    private fun step(name: String, block: () -> Unit) {
        runCatching(block).onFailure { errors += "$name: ${it::class.simpleName}: ${it.message?.take(300)}" }
    }

    /** Dialogs and sheets can contain a blinking cursor, so Compose never reports idle: capture without waiting. */
    private fun saveNoIdle(name: String) {
        compose.mainClock.autoAdvance = false
        compose.mainClock.advanceTimeBy(2500)
        val root = rootViews().last()
        val bitmap = Bitmap.createBitmap(root.width, root.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFF000000.toInt())
        root.draw(canvas)
        File(outDir, "audit_$name.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    @Test
    fun captureAuditScreenshots() {
        settle(4000)
        step("overblik") { save("01_overblik") }
        step("poster") { click("Poster"); save("02_poster") }
        step("regninger") { click("Regninger"); save("05_regninger") }
        step("budget") { click("Budget"); save("06_budget") }
        step("mere") { click("Mere"); save("07_mere") }
        listOf("Faste poster", "Kategorier", "Abonnementer", "Hvad nu hvis?", "Bil", "Indstillinger", "Rapporter", "Gæld", "Opsparing").forEachIndexed { index, screen ->
            step(screen) { click("Mere"); click(screen, scroll = true); save("${(8 + index).toString().padStart(2, '0')}_${screen.lowercase().replace(" ", "_").replace("?", "").replace("æ", "ae")}") }
        }
        // Dialogs last: each may keep Compose busy, and they are not closed afterwards.
        step("handlingsark") {
            click("Poster")
            compose.onAllNodes(hasClickAction() and hasContentDescription(" kr.", substring = true)).onFirst().performClick()
            saveNoIdle("03_handlingsark")
        }
        File(outDir, "errors-dark.txt").writeText(errors.joinToString("\n"))
    }

    @Test
    fun captureNewPostDialog() {
        settle(4000)
        step("ny_post") { compose.onAllNodesWithContentDescription("Ny post").onLast().performClick(); saveNoIdle("04_ny_post") }
        File(outDir, "errors-dark-dialog.txt").writeText(errors.joinToString("\n"))
    }
}
