package dk.saldo.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class SaldoAssistantTest {
    private val fmt: (Double) -> String = { String.format(java.util.Locale.ROOT, "%.2f kr.", it) }
    private fun tx(name: String, amount: Double, date: String, category: String, type: String = "Udgift") =
        JSONObject().put("name", name).put("amount", amount).put("date", date).put("category", category).put("type", type).put("owner", "Mig")

    private val ctx = SaldoAssistantContext(
        today = LocalDate.parse("2026-11-10"), available = 4200.0, dailyAllowance = 300.0, daysToPay = 14,
        payFrequency = "monthly", payAmount = 21000.0, hasBalance = true,
        transactions = listOf(
            tx("Netto", 450.0, "2026-10-05", "Mad"), tx("Føtex", 550.0, "2026-10-20", "Mad"), tx("DSB", 200.0, "2026-10-21", "Transport"),
            tx("Netto", 300.0, "2026-11-02", "Mad"), tx("Spotify", 129.0, "2026-11-03", "Abonnementer")
        ),
        bills = listOf(
            JSONObject().put("name", "El").put("amount", 800.0).put("date", "2026-11-05").put("paid", false),
            JSONObject().put("name", "Husleje").put("amount", 6000.0).put("date", "2026-12-01").put("paid", false)
        ),
        budgets = listOf(JSONObject().put("category", "Mad").put("owner", "Mig").put("limit", 250.0)),
        goals = emptyList(), subscriptions = emptyList(), debts = emptyList()
    )

    @Test
    fun answersAvailableAmountWithNumbers() {
        val answer = answerSaldoQuestion("Hvor meget kan jeg bruge i dag?", ctx, fmt)
        assertTrue(answer.text.contains("4200.00 kr.") && answer.text.contains("300.00 kr."))
        assertEquals("Overblik", answer.actionTab)
    }

    @Test
    fun answersCategorySpendForNamedOrRelativeMonth() {
        assertTrue(answerSaldoQuestion("Hvor meget brugte jeg på mad sidste måned?", ctx, fmt).text.contains("1000.00 kr."))
        assertTrue(answerSaldoQuestion("Hvor meget har jeg brugt på mad i oktober", ctx, fmt).text.contains("1000.00 kr."))
        assertTrue(answerSaldoQuestion("hvor meget brugte jeg på netto", ctx, fmt).text.contains("300.00 kr."))
    }

    @Test
    fun listsOverdueAndUpcomingBills() {
        val answer = answerSaldoQuestion("Hvilke regninger skal betales?", ctx, fmt)
        assertTrue(answer.text.contains("forfalden") && answer.text.contains("El") && answer.text.contains("Husleje"))
        assertEquals("Regninger", answer.actionTab)
    }

    @Test
    fun topCategoriesAndBudgetStatus() {
        assertTrue(answerSaldoQuestion("Hvad bruger jeg mest på?", ctx, fmt).text.contains("1. Mad"))
        assertTrue(answerSaldoQuestion("Hvordan går mit budget?", ctx, fmt).text.contains("Overskredet: Mad"))
    }

    @Test
    fun paydayAndHowToQuestions() {
        assertTrue(answerSaldoQuestion("Hvornår får jeg løn?", ctx, fmt).text.contains("om 14 dage"))
        assertEquals("Indstillinger", answerSaldoQuestion("Hvordan importerer jeg fra banken?", ctx, fmt).actionTab)
        assertTrue(answerSaldoQuestion("Hvordan kan jeg spare?", ctx, fmt).text.contains("Mad"))
    }

    @Test
    fun unknownQuestionIsFlaggedForAiAndKnownIsNot() {
        val unknown = answerSaldoQuestion("Hvad er forskellen på aktiesparekonto og frie midler?", ctx, fmt)
        assertTrue(unknown.unknown && unknown.text.contains("AI-svar"))
        assertTrue(!answerSaldoQuestion("Hvornår får jeg løn?", ctx, fmt).unknown)
    }

    @Test
    fun nuancedQuestionsPreferAi() {
        assertTrue(saldoQuestionNeedsAi("Skal jeg betale mit lån af før jeg sparer op?"))
        assertTrue(saldoQuestionNeedsAi("Hvad er ÅOP?"))
        assertTrue(!saldoQuestionNeedsAi("Hvilke regninger skal betales?"))
        assertTrue(!saldoQuestionNeedsAi("Hvor meget kan jeg bruge i dag?"))
    }

    @Test
    fun aiSummaryAggregatesWithoutIndividualTransactions() {
        val summary = buildSaldoAiSummary(ctx)
        val months = summary.getJSONArray("months")
        assertEquals("2026-11", months.getJSONObject(0).getString("month"))
        val october = months.getJSONObject(1)
        assertEquals(1200.0, october.getDouble("expenses"), 0.001)
        assertEquals(1000.0, october.getJSONObject("expensesByCategory").getDouble("Mad"), 0.001)
        assertEquals(450.0, october.getJSONObject("largestPlaces").getDouble("Netto"), 0.001)
        assertEquals(300.0, summary.getJSONArray("budgets").getJSONObject(0).getDouble("spentThisMonth"), 0.001)
        assertEquals(2, summary.getJSONArray("unpaidBills").length())
        assertEquals("Månedlig", summary.getJSONObject("pay").getString("frequency"))
        assertTrue(!summary.toString().contains("\"date\":\"2026-10-05\""))
    }
}
