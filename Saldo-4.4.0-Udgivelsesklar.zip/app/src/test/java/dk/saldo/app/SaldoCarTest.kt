package dk.saldo.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class SaldoCarTest {
    private val today = LocalDate.of(2026, 11, 4)

    @Test
    fun noSetupGivesNoStatus() {
        assertNull(carServiceStatus(JSONObject(), 50000.0, today))
        assertNull(carSynStatus(JSONObject(), today))
        assertNull(carAttentionText(null))
    }

    @Test
    fun serviceIsDueByTime() {
        val m = JSONObject().put("lastServiceDate", "2026-01-10").put("serviceMonths", 12)
        val status = carServiceStatus(m, null, today)!!
        assertEquals(LocalDate.of(2027, 1, 10), status.dueDate)
        assertEquals(67L, status.daysLeft)
        assertFalse(status.overdue)
        assertFalse(status.soon)
        assertEquals("Om 67 dage", status.headline)
    }

    @Test
    fun serviceIsDueByKilometresFirst() {
        val m = JSONObject().put("lastServiceDate", "2026-06-01").put("lastServiceKm", 40000.0).put("serviceMonths", 12).put("serviceKm", 15000.0)
        val soon = carServiceStatus(m, 54500.0, today)!!
        assertEquals(500.0, soon.kmLeft!!, 0.001)
        assertTrue(soon.soon)
        assertEquals("Om 500 km", soon.headline)
        val over = carServiceStatus(m, 56000.0, today)!!
        assertTrue(over.overdue)
        assertEquals("1.000 km over", over.headline)
        assertEquals("Service er overskredet (1.000 km over)", carAttentionText(over))
    }

    @Test
    fun synWarnsAMonthAheadAndWhenOverdue() {
        assertTrue(carSynStatus(JSONObject().put("nextSyn", "2026-11-20"), today)!!.soon)
        assertFalse(carSynStatus(JSONObject().put("nextSyn", "2027-03-01"), today)!!.soon)
        val over = carSynStatus(JSONObject().put("nextSyn", "2026-11-01"), today)!!
        assertTrue(over.overdue)
        assertEquals("3 dage over", over.headline)
        assertEquals("Syn: i morgen", carAttentionText(carSynStatus(JSONObject().put("nextSyn", "2026-11-05"), today)))
    }

    @Test
    fun recordingSynMovesItTwoYearsAndKeepsHistory() {
        val done = carRecordDone(JSONObject().put("nextSyn", "2026-11-20"), "syn", LocalDate.of(2026, 11, 10), 61000.0, 550.0)
        assertEquals("2028-11-10", done.getString("nextSyn"))
        assertEquals(61000.0, done.getDouble("odometer"), 0.001)
        val history = done.getJSONArray("history")
        assertEquals(1, history.length())
        assertEquals(550.0, history.getJSONObject(0).getDouble("cost"), 0.001)
    }

    @Test
    fun recordingServiceResetsDateAndKm() {
        val done = carRecordDone(JSONObject().put("lastServiceDate", "2025-10-01").put("lastServiceKm", 40000.0), "service", today, 55000.0, null)
        assertEquals(today.toString(), done.getString("lastServiceDate"))
        assertEquals(55000.0, done.getDouble("lastServiceKm"), 0.001)
        assertFalse(done.getJSONArray("history").getJSONObject(0).has("cost"))
        assertFalse(carServiceStatus(done, 55000.0, today)!!.soon)
    }

    @Test
    fun currentKmUsesHighestKnownReading() {
        val fuel = listOf(JSONObject().put("km", 52000.0), JSONObject().put("km", 53500.0))
        assertEquals(53500.0, carCurrentKm(JSONObject().put("lastServiceKm", 40000.0), fuel)!!, 0.001)
        assertEquals(60000.0, carCurrentKm(JSONObject().put("odometer", 60000.0), fuel)!!, 0.001)
        assertNull(carCurrentKm(JSONObject(), emptyList()))
    }
}
