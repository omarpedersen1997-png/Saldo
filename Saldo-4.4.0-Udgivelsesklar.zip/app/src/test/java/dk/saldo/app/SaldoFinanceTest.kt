package dk.saldo.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class SaldoFinanceTest {
    private fun tx(id: String, name: String, amount: Double, date: String, type: String = "Udgift", category: String = "Diverse", repeat: String? = null) =
        JSONObject().put("id", id).put("name", name).put("amount", amount).put("date", date).put("type", type).put("category", category).put("owner", "Mig").apply {
            if (repeat != null) put("repeat", repeat)
        }

    // ---------------------------------------------------------------- recurring posts
    @Test
    fun monthlyPostCreatesEveryDueOccurrenceUpToToday() {
        val salary = tx("s1", "Løn", 20000.0, "2026-08-15", "Indtægt", "Løn", "Månedlig")
        val generated = generateRecurringOccurrences(listOf(salary), LocalDate.parse("2026-11-01"), emptySet())
        assertEquals(listOf("2026-09-15", "2026-10-15"), generated.map { it.getString("date") })
        assertTrue(generated.all { it.getString("recurrenceId") == "s1" && it.getBoolean("autoCreated") })
    }

    @Test
    fun alreadyGeneratedOrDeletedOccurrencesAreNotRecreated() {
        val rent = tx("r1", "Husleje", 6000.0, "2026-08-01", repeat = "Månedlig")
        val generated = generateRecurringOccurrences(listOf(rent), LocalDate.parse("2026-10-05"), setOf("rec-tx-r1-2026-09-01"))
        assertEquals(listOf("2026-10-01"), generated.map { it.getString("date") })
    }

    @Test
    fun stoppedSeriesCreatesNothing() {
        val first = tx("i1", "Forsikring", 300.0, "2026-08-10", repeat = "Månedlig")
        val latest = tx("rec-tx-i1-2026-09-10", "Forsikring", 300.0, "2026-09-10", repeat = "Engangsbetaling").put("recurrenceId", "i1")
        assertTrue(generateRecurringOccurrences(listOf(first, latest), LocalDate.parse("2026-12-01"), emptySet()).isEmpty())
    }

    @Test
    fun anchorDayIsClampedToShortMonths() {
        val post = tx("e1", "Opsparing", 500.0, "2027-01-31", repeat = "Månedlig").put("recurrenceDay", 31)
        val generated = generateRecurringOccurrences(listOf(post), LocalDate.parse("2027-03-31"), emptySet())
        assertEquals(listOf("2027-02-28", "2027-03-31"), generated.map { it.getString("date") })
    }

    // ---------------------------------------------------------------- debt plan
    @Test
    fun interestFreeDebtIsPaidInExpectedMonths() {
        val plan = simulateDebtPlan(listOf(JSONObject().put("name", "Lån").put("balance", 10000.0).put("rate", 0.0).put("payment", 1000.0)), 0.0, avalanche = true)
        assertEquals(10, plan.months)
        assertEquals(0.0, plan.totalInterest, 0.001)
    }

    @Test
    fun avalanchePaysHighestRateFirstAndExtraShortensPlan() {
        val debts = listOf(
            JSONObject().put("name", "Billån").put("balance", 20000.0).put("rate", 4.0).put("payment", 600.0),
            JSONObject().put("name", "Kreditkort").put("balance", 5000.0).put("rate", 22.0).put("payment", 200.0)
        )
        val base = simulateDebtPlan(debts, 0.0, avalanche = true)
        val faster = simulateDebtPlan(debts, 1000.0, avalanche = true)
        assertEquals("Kreditkort", faster.payoffOrder.first().first)
        assertTrue(faster.months!! < base.months!!)
        assertTrue(faster.totalInterest < base.totalInterest)
    }

    @Test
    fun paymentBelowInterestNeverFinishes() {
        val plan = simulateDebtPlan(listOf(JSONObject().put("name", "Lån").put("balance", 100000.0).put("rate", 12.0).put("payment", 500.0)), 0.0, avalanche = true)
        assertNull(plan.months)
    }

    // ---------------------------------------------------------------- budget suggestions
    @Test
    fun budgetSuggestionsUseThreeMonthAverageRoundedUpAndSkipExisting() {
        val rows = listOf(
            tx("a", "Netto", 1000.0, "2026-08-10", category = "Mad"),
            tx("b", "Netto", 1500.0, "2026-09-10", category = "Mad"),
            tx("c", "Netto", 2020.0, "2026-10-10", category = "Mad"),
            tx("d", "DSB", 900.0, "2026-10-12", category = "Transport")
        )
        val existing = listOf(JSONObject().put("category", "Transport").put("owner", "Mig").put("limit", 500.0))
        val suggestions = suggestBudgets(rows, existing)
        assertEquals(1, suggestions.size)
        assertEquals("Mad", suggestions.single().first)
        assertEquals(1600.0, suggestions.single().third, 0.001)
    }

    // ---------------------------------------------------------------- subscription radar
    @Test
    fun radarFindsStableMonthlyPaymentButNotVaryingOrKnownOnes() {
        val now = YearMonth.parse("2026-11")
        val rows = listOf(
            tx("n1", "Netflix", 129.0, "2026-08-03"), tx("n2", "Netflix", 129.0, "2026-09-03"), tx("n3", "Netflix", 129.0, "2026-10-03"),
            tx("f1", "Fitness World", 299.0, "2026-08-01"), tx("f2", "Fitness World", 299.0, "2026-09-01"), tx("f3", "Fitness World", 299.0, "2026-10-01"),
            tx("m1", "Bilka", 300.0, "2026-08-05"), tx("m2", "Bilka", 900.0, "2026-09-05"), tx("m3", "Bilka", 150.0, "2026-10-05")
        )
        val subs = listOf(JSONObject().put("name", "Fitness World"))
        val found = detectRecurringPayments(rows, subs, emptySet(), now)
        assertEquals(listOf("Netflix"), found.map { it.second })
        assertEquals(129.0, found.single().third, 0.001)
        assertTrue(detectRecurringPayments(rows, subs, setOf(found.single().first), now).isEmpty())
    }

    // ---------------------------------------------------------------- balance projection
    @Test
    fun balanceProjectionSubtractsBillsOnDueDateAndDailySpend() {
        val bills = listOf(JSONObject().put("name", "El").put("amount", 1000.0).put("date", "2026-11-04").put("paid", false))
        val projection = projectBalance(5000.0, bills, LocalDate.parse("2026-11-01"), 5, 100.0)
        assertEquals(listOf(5000.0, 4900.0, 4800.0, 3700.0, 3600.0, 3500.0), projection)
    }

    // ---------------------------------------------------------------- calculator
    @Test
    fun amountCalculatorHandlesDanishNumbersAndOperators() {
        assertEquals(134.95, evaluateAmountExpression("89,95+45")!!, 0.001)
        assertEquals(2000.0, evaluateAmountExpression("1.000*2")!!, 0.001)
        assertEquals(150.0, evaluateAmountExpression("(300+150)/3")!!, 0.001)
        assertEquals(250.0, evaluateAmountExpression("250")!!, 0.001)
        assertEquals(40.0, evaluateAmountExpression("100 − 60")!!, 0.001)
        assertNull(evaluateAmountExpression("10/0"))
        assertNull(evaluateAmountExpression("12+"))
        assertNull(evaluateAmountExpression(""))
    }
}
