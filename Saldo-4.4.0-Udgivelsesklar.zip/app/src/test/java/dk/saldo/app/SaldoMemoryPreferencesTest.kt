package dk.saldo.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class SaldoMemoryPreferencesTest {
    private fun disk() = ApplicationProvider.getApplicationContext<Context>().getSharedPreferences("memory-prefs-test", Context.MODE_PRIVATE)

    @Test
    fun readsExistingValuesAndWritesThroughInOrder() {
        disk().edit().clear().putString("data", "{\"a\":1}").putBoolean("flag", true).commit()
        val prefs = SaldoMemoryPreferences(disk())
        assertEquals("{\"a\":1}", prefs.getString("data", null))
        assertTrue(prefs.getBoolean("flag", false))

        // Memory is updated immediately, disk after the background writer has run.
        repeat(50) { i -> prefs.edit().putString("data", "{\"a\":$i}").putLong("time", i.toLong()).apply() }
        assertEquals("{\"a\":49}", prefs.getString("data", null))
        prefs.flush()
        assertEquals("{\"a\":49}", disk().getString("data", null))
        assertEquals(49L, disk().getLong("time", 0L))
    }

    @Test
    fun removeClearAndCommitReachDisk() {
        disk().edit().clear().putString("keep", "x").putString("drop", "y").commit()
        val prefs = SaldoMemoryPreferences(disk())
        prefs.edit().remove("drop").putInt("count", 3).putStringSet("ids", mutableSetOf("1", "2")).apply()
        assertFalse(prefs.contains("drop"))
        assertTrue(prefs.edit().putFloat("rate", 1.5f).commit())
        assertFalse(disk().contains("drop"))
        assertEquals(3, disk().getInt("count", 0))
        assertEquals(setOf("1", "2"), disk().getStringSet("ids", null))
        assertEquals(1.5f, disk().getFloat("rate", 0f))

        prefs.edit().clear().commit()
        assertTrue(prefs.all.isEmpty())
        assertTrue(disk().all.isEmpty())
    }

    @Test
    fun wrongTypeFallsBackToDefault() {
        disk().edit().clear().putString("n", "abc").commit()
        val prefs = SaldoMemoryPreferences(disk())
        assertEquals(7, prefs.getInt("n", 7))
        assertEquals("d", prefs.getString("missing", "d"))
    }
}
