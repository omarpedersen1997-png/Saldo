# Saldo – brand og Google Play-assets (4.4.0 · design "Klar")

- `app-icon-512.png`: komplet Google Play-ikon (512×512).
- `saldo-s-mark-transparent.png`: fritstående logo uden baggrund; brug på appens lyse eller mørke flader.
- `saldo-wordmark-dark.png` / `saldo-wordmark-light.png`: logo + Saldo-ordmærke med gennemsigtig baggrund.
- `feature-graphic-1024x500.jpg`: Google Play-feature graphic, 1024×500.
- `screenshots/`: otte Google Play-billeder (1080×1920) med rigtige skærme fra appen, taget automatisk af `PlayScreenshotTest` med eksempeldata og sat i ramme med overskrift.

Skærmbilledernes tal er illustrative testdata, ikke en rigtig brugers økonomi. Android-statuslinjen og systemnavigationsknapperne er fjernet; appens egen navigation er bevaret.
