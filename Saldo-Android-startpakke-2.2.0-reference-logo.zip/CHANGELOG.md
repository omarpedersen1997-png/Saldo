# Changelog

## 2.0.0 — Nyt designfundament
- Nyt mørkt fintech-design med lilla/blå gradienter.
- Nyt Saldo-branding og appikonressource.
- Ny dashboard-, budget-, regnings-, statistik- og mere-visning.
- Nyt GitHub Actions-workflow, der bygger projektet fra ZIP-arkivet.
- Markeret prototypefunktioner tydeligt i UI og dokumentation.


## 2.1.0
- Added a custom gradient Saldo mark based on the approved visual reference.
- Updated launcher icon and in-app branding.
- Updated sample dashboard values and version number.
