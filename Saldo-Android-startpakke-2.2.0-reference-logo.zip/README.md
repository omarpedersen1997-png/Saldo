# Saldo Android 2.0.0

Et nyt, selvstændigt Android-projekt til Saldo med Kotlin og Jetpack Compose. Designretningen er mørk marineblå med lilla/blå gradienter, kort med afrundede hjørner og dansk brugerflade.

## Indeholder
- Nyt dashboard med saldo, råderum, indtægter/udgifter og kommende regninger.
- Navigation mellem Overblik, Budgetter, Regninger og Statistik.
- Visning af budgetter for Mit budget, Partners budget og Fælles.
- Dialog til at registrere en post i den aktuelle session.
- Prototypevisning til import af regninger fra skærmbilleder.
- Nyt Saldo-logo og Android-version 2.0.0.
- GitHub Actions-workflow til APK-bygning.

## Vigtigt
Dette er en ny designprototype. Budgetbeløb er eksempeldata; indtastede poster gemmes endnu ikke permanent. Automatisk OCR/import fra Betalingsservice, rigtig lokal database, notifikationer og fuld budgetberegning skal færdigimplementeres og testes, før appen bør bruges til faktiske økonomiske beslutninger.

## Build
GitHub Actions bruger Gradle 8.14.3 og Java 17 og bygger `assembleDebug`.


## Version 2.1.0 – designreference

- Opdateret Saldo-logo inspireret af brugerens designreference.
- Mere ensartet mørkt navy/lilla/blåt visuelt udtryk.
- Opdateret versionsnummer, så den nye APK kan skelnes fra tidligere builds.
- Dashboardets eksempelbeløb og regningsdatoer tilpasset designskitsen.

Bemærk: Dette er fortsat en UI-prototype. Billedimport/OCR fra Betalingsservice, vedvarende budgetdata og alle skærme fra designreferencen er ikke færdigimplementeret.
