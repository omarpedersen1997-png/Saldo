package dk.saldo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF0D1020)
private val Panel = Color(0xFF171B30)
private val Panel2 = Color(0xFF202641)
private val Violet = Color(0xFF8B73FF)
private val Blue = Color(0xFF39C8FF)
private val Mint = Color(0xFF62E6C2)
private val Muted = Color(0xFF9AA2BD)
private val White = Color(0xFFF5F6FF)
private val Coral = Color(0xFFFF7F9D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SaldoApp() }
    }
}

private enum class Page(val label: String) {
    Overview("Overblik"), Budgets("Budgetter"), Bills("Regninger"), Stats("Statistik"), More("Mere")
}

@Composable
private fun SaldoApp() {
    var page by remember { mutableStateOf(Page.Overview) }
    var selectedBudget by remember { mutableStateOf("Alle") }
    var showAdd by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var newExpense by remember { mutableStateOf("") }
    var addedExpenses by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Blue,
            background = Night,
            surface = Panel,
            onBackground = White,
            onSurface = White
        )
    ) {
        Box(Modifier.fillMaxSize().background(Night)) {
            Column(Modifier.fillMaxSize()) {
                TopBar(onNotifications = { page = Page.Bills })
                AnimatedContent(targetState = page, label = "page", modifier = Modifier.weight(1f)) { target ->
                    when (target) {
                        Page.Overview -> OverviewScreen(selectedBudget, { selectedBudget = it }, { page = it }, { showAdd = true }, { showImport = true }, addedExpenses)
                        Page.Budgets -> BudgetsScreen(selectedBudget, { selectedBudget = it }, { showAdd = true })
                        Page.Bills -> BillsScreen({ showImport = true })
                        Page.Stats -> StatsScreen(addedExpenses)
                        Page.More -> MoreScreen()
                    }
                }
                BottomNavigation(page, onSelect = { page = it }, onAdd = { showAdd = true })
            }
            if (showAdd) {
                AddExpenseDialog(
                    amount = newExpense,
                    onAmount = { newExpense = it },
                    onDismiss = { showAdd = false },
                    onSave = {
                        if (newExpense.toDoubleOrNull() != null) addedExpenses++
                        newExpense = ""
                        showAdd = false
                    }
                )
            }
            if (showImport) {
                AlertDialog(
                    onDismissRequest = { showImport = false },
                    containerColor = Panel,
                    title = { Text("Importér regning", color = White, fontWeight = FontWeight.Bold) },
                    text = { Text("Vælg et skærmbillede fra Betalingsservice eller dine filer. I denne version er importskærmen en prototype; automatisk aflæsning og kontrol skal færdigimplementeres.", color = Muted) },
                    confirmButton = { TextButtonSaldo("Forstået") { showImport = false } },
                    dismissButton = { TextButtonSaldo("Luk") { showImport = false } }
                )
            }
        }
    }
}

@Composable
private fun TopBar(onNotifications: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 16.dp, top = 12.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_saldo_logo),
            contentDescription = "Saldo-logo",
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(15.dp))
        )
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("Saldo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = White, letterSpacing = (-0.7).sp)
            Text("DIT ØKONOMISKE OVERBLIK", fontSize = 9.sp, color = Muted, letterSpacing = 1.2.sp)
        }
        Box(Modifier.size(42.dp).clip(CircleShape).background(Panel).clickable { onNotifications() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.NotificationsNone, contentDescription = "Notifikationer", tint = White)
            Box(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp).size(6.dp).clip(CircleShape).background(Blue))
        }
    }
}

@Composable
private fun OverviewScreen(
    selected: String,
    onSelect: (String) -> Unit,
    onPage: (Page) -> Unit,
    onAdd: () -> Unit,
    onImport: () -> Unit,
    addedExpenses: Int
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Mandag, 26. oktober", color = Muted, fontSize = 12.sp)
                Text("Dit overblik", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
            }
            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Panel).clickable { onPage(Page.Budgets) }.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(selected, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.width(5.dp)); Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.size(16.dp)) }
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Alle", "Mit budget", "Partners budget", "Fælles").forEach { item ->
                val active = selected == item
                Box(Modifier.clip(CircleShape).background(if (active) Violet else Panel).clickable { onSelect(item) }.padding(horizontal = 15.dp, vertical = 9.dp)) {
                    Text(item, color = if (active) White else Muted, fontSize = 12.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
        BalanceCard()
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniMetric("Indtægter", "10.000 kr.", Icons.Default.ArrowDownward, Mint, Modifier.weight(1f))
            MiniMetric("Udgifter", if (addedExpenses > 0) "4.280 kr. +" else "4.280 kr.", Icons.Default.ArrowUpward, Coral, Modifier.weight(1f))
        }
        SectionHeader("Hurtige handlinger", "")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("Tilføj post", Icons.Default.Add, Violet, onAdd, Modifier.weight(1f))
            QuickAction("Importér", Icons.Default.CameraAlt, Blue, onImport, Modifier.weight(1f))
            QuickAction("Budgetter", Icons.Default.PieChart, Mint, { onPage(Page.Budgets) }, Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionHeader("Kommende regninger", "3 regninger")
            Spacer(Modifier.weight(1f))
            Text("Se alle", color = Blue, fontSize = 12.sp, modifier = Modifier.clickable { onPage(Page.Bills) })
        }
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            BillRow("Husleje", "Forfalder 1. dec.", "5.875 kr.", "H", Violet)
            BillRow("Varme · kvartal", "Forfalder 1. dec.", "3.630 kr.", "V", Blue)
            BillRow("Daginstitution", "Forfalder 5. dec.", "3.392 kr.", "D", Mint)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun BalanceCard() {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF5F4BE8), Color(0xFF292F79), Color(0xFF153D65)))).padding(22.dp)) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width; val h = size.height
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(w * .52f, h * .62f); cubicTo(w * .62f, h * .34f, w * .70f, h * .85f, w * .82f, h * .53f); cubicTo(w * .89f, h * .35f, w * .92f, h * .52f, w * 1.02f, h * .28f)
            }
            drawPath(path, Blue.copy(alpha = .55f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
        }
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("SAMLET SALDO", color = Color.White.copy(alpha = .78f), fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Box(Modifier.clip(CircleShape).background(Color.White.copy(alpha = .15f)).padding(horizontal = 9.dp, vertical = 5.dp)) { Text("↑ 8,2%", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(12.dp))
            Text("12.436 kr.", color = White, fontSize = 36.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.5).sp)
            Text("På tværs af dine budgetter", color = Color.White.copy(alpha = .72f), fontSize = 12.sp)
            Spacer(Modifier.height(25.dp))
            HorizontalProgress(0.76f, Color.White.copy(alpha = .24f), Blue)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Råderum til næste løn", color = Color.White.copy(alpha = .78f), fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("7.245 kr.", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text("5 dage til næste løn", color = Color.White.copy(alpha = .62f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun MiniMetric(title: String, amount: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Panel).padding(15.dp)) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.height(12.dp))
        Text(title, color = Muted, fontSize = 12.sp)
        Text(amount, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SectionHeader(title: String, trailing: String) {
    Column(Modifier.padding(top = 1.dp)) {
        Text(title, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (trailing.isNotBlank()) Text(trailing, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).clickable { onClick() }.padding(vertical = 14.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(tint.copy(alpha = .13f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun BillRow(title: String, subtitle: String, amount: String, initials: String, tint: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Text(initials, color = tint, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)) }
        Column(horizontalAlignment = Alignment.End) { Text(amount, color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold); Text("Afventer", color = Blue, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp)) }
    }
}

@Composable
private fun BudgetsScreen(selected: String, onSelect: (String) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Budgetter", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButtonSaldo(onAdd) }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mit budget", "Partners budget", "Fælles").forEach { item ->
                val active = selected == item
                Box(Modifier.clip(CircleShape).background(if (active) Violet else Panel).clickable { onSelect(item) }.padding(horizontal = 14.dp, vertical = 10.dp)) { Text(item, color = if (active) White else Muted, fontSize = 12.sp) }
            }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
            Text("MÅNEDENS FORBRUG", color = Muted, fontSize = 11.sp, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Bottom) { Text("5.255 kr.", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(6.dp)); Text("af 11.500 kr.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 5.dp)); Spacer(Modifier.weight(1f)); Text("46%", color = Blue, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(14.dp)); HorizontalProgress(.46f, Panel2, Brush.horizontalGradient(listOf(Violet, Blue)))
            Text("Du er godt med i forhold til dit budget", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        }
        SectionHeader("Kategorier", "")
        CategoryRow("Bolig", "5.875 kr. af 5.875 kr.", 1f, Violet, "100%")
        CategoryRow("Mad og dagligvarer", "1.428 kr. af 2.750 kr.", .52f, Mint, "52%")
        CategoryRow("Brændstof", "840 kr. af 2.000 kr.", .42f, Blue, "42%")
        CategoryRow("Diverse", "620 kr. af 1.500 kr.", .41f, Color(0xFFFFB86B), "41%")
        CategoryRow("Forsikringer", "293 kr. af 293 kr.", 1f, Coral, "100%")
        CategoryRow("Mobil og internet", "388 kr. af 388 kr.", 1f, Violet, "100%")
    }
}

@Composable
private fun CategoryRow(title: String, detail: String, progress: Float, tint: Color, percent: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(37.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.PieChart, null, tint = tint, modifier = Modifier.size(18.dp)) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)) }
            Text(percent, color = tint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp)); HorizontalProgress(progress, Panel2, tint)
    }
}

@Composable
private fun BillsScreen(onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Regninger", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Hold styr på det, der skal betales", color = Muted, fontSize = 12.sp) }; IconButtonSaldo(onImport, Icons.Default.CameraAlt) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MiniMetric("Denne måned", "12.677 kr.", Icons.Default.ReceiptLong, Violet, Modifier.weight(1f)); MiniMetric("Kommende", "3", Icons.Default.CalendarMonth, Blue, Modifier.weight(1f)) }
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Importér fra skærmbillede", fontWeight = FontWeight.SemiBold) }
        SectionHeader("Kommende", "Oktober / november")
        BillRow("Husleje", "1. december · Fast betaling", "5.875 kr.", "H", Violet)
        BillRow("Varme · kvartal", "1. december · Fast betaling", "3.630 kr.", "V", Blue)
        BillRow("Daginstitution", "5. december · Fast betaling", "3.392 kr.", "D", Mint)
        Text("Import fra Betalingsservice er endnu ikke koblet til automatisk billedaflæsning i denne version.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun StatsScreen(addedExpenses: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        Text("Statistik", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Din økonomi i bevægelse", color = Muted, fontSize = 12.sp)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
            Text("MÅNEDENS RESULTAT", color = Muted, fontSize = 11.sp, letterSpacing = 1.1.sp)
            Text("+1.745 kr.", color = Mint, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text("Indtægter minus udgifter", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth().height(125.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                val values = listOf(.52f, .72f, .58f, .86f, .68f, .96f)
                val months = listOf("Maj", "Jun", "Jul", "Aug", "Sep", "Okt")
                values.forEachIndexed { index, value ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f)) {
                        Box(Modifier.width(20.dp).fillMaxHeight(value).clip(RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp)).background(if (index == 5) Brush.verticalGradient(listOf(Blue, Violet)) else Brush.verticalGradient(listOf(Violet.copy(alpha = .55f), Blue.copy(alpha = .25f)))))
                        Spacer(Modifier.height(8.dp)); Text(months[index], color = Muted, fontSize = 10.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { MiniMetric("Indtægter", "10.000 kr.", Icons.Default.ArrowDownward, Mint, Modifier.weight(1f)); MiniMetric("Udgifter", "8.255 kr.", Icons.Default.ArrowUpward, Coral, Modifier.weight(1f)) }
        CategoryRow("Registrerede nye poster", "$addedExpenses i denne session", .15f, Blue, "$addedExpenses")
    }
}

@Composable
private fun MoreScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Mere", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Tilpas Saldo til din hverdag", color = Muted, fontSize = 12.sp)
        MoreRow("Flere budgetter", "Dig, partner og fælles", Icons.Default.PieChart, Violet)
        MoreRow("Opsparingsmål", "Følg dine mål og fremskridt", Icons.Default.Savings, Mint)
        MoreRow("Rapporter", "Se økonomien over tid", Icons.Default.BarChart, Blue)
        MoreRow("Importér regninger", "Skærmbilleder og bilag", Icons.Default.CameraAlt, Color(0xFFFFB86B))
        MoreRow("Privatliv og sikkerhed", "Dine data bliver på enheden i denne prototype", Icons.Default.CheckCircle, Mint)
        MoreRow("Om Saldo", "Version 2.0.0 · Designprototype", Icons.Default.TrendingUp, Violet)
    }
}

@Composable
private fun MoreRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable { }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)) }; Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun BottomNavigation(current: Page, onSelect: (Page) -> Unit, onAdd: () -> Unit) {
    Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Color(0xFF101426)).padding(start = 7.dp, end = 7.dp, top = 9.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceAround) {
        NavItem(Page.Overview, current, Icons.Default.Home, onSelect)
        NavItem(Page.Budgets, current, Icons.Default.PieChart, onSelect)
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Violet, Color(0xFF5D6BFF)))).clickable { onAdd() }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, null, tint = White, modifier = Modifier.size(26.dp)) }
        NavItem(Page.Bills, current, Icons.Default.ReceiptLong, onSelect)
        NavItem(Page.Stats, current, Icons.Default.BarChart, onSelect)
    }
}

@Composable
private fun NavItem(page: Page, current: Page, icon: androidx.compose.ui.graphics.vector.ImageVector, onSelect: (Page) -> Unit) {
    val selected = page == current
    Column(Modifier.width(62.dp).clip(RoundedCornerShape(14.dp)).clickable { onSelect(page) }.padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (selected) Violet else Muted, modifier = Modifier.size(21.dp))
        Spacer(Modifier.height(3.dp)); Text(page.label, color = if (selected) White else Muted, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun HorizontalProgress(progress: Float, track: Color, fill: Any) {
    Box(Modifier.fillMaxWidth().height(7.dp).clip(CircleShape).background(track)) {
        val fillModifier = Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape)
        when (fill) {
            is Color -> Box(fillModifier.background(fill))
            is Brush -> Box(fillModifier.background(fill))
        }
    }
}

@Composable
private fun IconButtonSaldo(onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Add) {
    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Panel).clickable { onClick() }, contentAlignment = Alignment.Center) { Icon(icon, null, tint = White) }
}

@Composable
private fun TextButtonSaldo(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = Blue, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun AddExpenseDialog(amount: String, onAmount: (String) -> Unit, onDismiss: () -> Unit, onSave: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Tilføj post", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Registrér en udgift i dit overblik.", color = Muted, fontSize = 13.sp)
                Text("Beløb i kroner", color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                BasicTextField(
                    value = amount,
                    onValueChange = { input -> if (input.matches(Regex("[0-9]*[.,]?[0-9]*"))) onAmount(input.replace(',', '.')) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel2).padding(15.dp),
                    decorationBox = { inner -> if (amount.isEmpty()) Text("0,00 kr.", color = Muted, fontSize = 22.sp); inner() }
                )
            }
        },
        confirmButton = { Button(onClick = onSave, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Gem post") } },
        dismissButton = { TextButtonSaldo("Annuller", onDismiss) }
    )
}
