# Saldo – ændringslog

## 2.3.0
- Bevarer det beskårne S-logo fra den godkendte designreference som app-logo.
- Udvider navigationen med kalender, opsparing, rapporter og indstillinger.
- Tilføjer visuelle skærme til kalender, opsparingsmål, rapporter og indstillinger i samme mørke marineblå/lilla stil.
- Versionsnummer hævet, så denne APK kan skelnes fra tidligere builds.

Bemærk: Dette er en UI-prototype. Import af Betalingsservice-skærmbilleder med automatisk OCR, vedvarende lagring, ægte PDF-eksport og fuld temaændring er ikke færdigimplementeret.
