# Saldo Android – 2.3.0

Et Kotlin/Jetpack Compose Android-projekt med designretning baseret på den medsendte Saldo-reference: mørk marineblå baggrund, lilla/blå gradienter og det beskårne S-logo fra referencen.

## Skærme
- Overblik
- Budgetter (Mit budget, Partners budget og Fælles)
- Regninger
- Statistik
- Kalender
- Opsparing
- Rapporter
- Indstillinger

## Build via GitHub Actions
Upload indholdet af denne pakke som `Saldo-Android-startpakke.zip` i roden af repositoryet. Workflowet `.github/workflows/android-build.yml` pakker ZIP-filen ud, bygger debug-APK og uploader APK'en som artifact.

## Vigtigt
Dette er en designprototype og ikke en fuldt færdig økonomiapp. Data gemmes endnu ikke permanent. OCR/import fra Betalingsservice, rigtig PDF-eksport, vedvarende indstillinger og end-to-end test skal implementeres før produktionsbrug. Projektet er ikke kompileret i dette miljø; GitHub Actions skal bekræfte buildet.
