# Start her – Saldo 2.0.0

1. Upload denne ZIP som `Saldo-Android-startpakke.zip` i roden af dit GitHub-repository.
2. Sørg for at `.github/workflows/android-build.yml` i selve repositoryet er den workflow-fil, der pakker ZIP-filen ud og bygger projektet.
3. Åbn GitHub → Actions → Build Saldo → Run workflow.
4. Ved grønt flueben: hent `Saldo-Android-debug-APK` under Artifacts og pak artefaktets ZIP ud på telefonen.
5. Installér APK-filen.

Dette er en ny designprototype, ikke en færdig produktionsapp. Se README.md for begrænsninger.
