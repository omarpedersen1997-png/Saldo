package dk.saldo.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.security.MessageDigest
import kotlin.math.ceil
import kotlin.math.ln

private val Night = Color(0xFF0D1020)
private val Panel = Color(0xFF171B30)
private val Violet = Color(0xFF8B73FF)
private val Blue = Color(0xFF39C8FF)
private val Mint = Color(0xFF62E6C2)
private val Muted = Color(0xFF9AA2BD)
private val White = Color(0xFFF5F6FF)
private fun money(v: Double) = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(v) + " kr."
private fun JSONObject.s(k: String, d: String = "") = optString(k, d).let { if (it == "null") d else it }
private fun JSONObject.n(k: String, d: Double = 0.0) = optDouble(k, d)
private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
private fun record(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(13, 16, 32)
        setContent { SaldoApp() }
    }
}

private val mainTabs = listOf("Overblik", "Poster", "Regninger", "Budget", "Mere")
private val moreTabs = listOf("Opsparing", "Gæld", "Bil", "Abonnementer", "Kalender", "Rapporter", "Indstillinger")

@Composable private fun SaldoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("saldo_data_v4", Context.MODE_PRIVATE) }
    var data by remember { mutableStateOf(runCatching { JSONObject(prefs.getString("data", "{}") ?: "{}") }.getOrElse { JSONObject() }) }
    fun list(key: String) = data.optJSONArray(key) ?: JSONArray()
    fun store(key: String, arr: JSONArray) { data.put(key, arr); prefs.edit().putString("data", data.toString()).apply(); data = JSONObject(data.toString()) }
    fun add(key: String, obj: JSONObject) { val arr = list(key); arr.put(obj); store(key, arr) }
    fun delete(key: String, id: String) { val arr = JSONArray(); list(key).objects().filterNot { it.s("id") == id }.forEach { arr.put(it) }; store(key, arr) }
    var tab by remember { mutableStateOf("Overblik") }
    var dialog by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginConfirm by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loginMode by remember { mutableStateOf(prefs.getString("account_hash", null) == null) }
    var accountUnlocked by remember { mutableStateOf(prefs.getBoolean("account_session", false)) }
    var unlocked by remember { mutableStateOf(prefs.getString("pin", null) == null) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1000); splash = false }
    val tx = list("transactions").objects()
    val bills = list("bills").objects()
    val income = tx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
    val expenses = tx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
    val unpaid = bills.filter { !it.optBoolean("paid", false) }.sumOf { it.n("amount") }
    val payday = runCatching { LocalDate.parse(prefs.getString("payday", LocalDate.now().toString())) }.getOrElse { LocalDate.now() }
    val payAmount = prefs.getFloat("pay_amount", 10000f).toDouble()
    val daysToPay = ChronoUnit.DAYS.between(LocalDate.now(), payday).toInt().let { ((it % 14) + 14) % 14 }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Blue, background = Night, surface = Panel, onSurface = White)) {
        if (splash) {
            Box(Modifier.fillMaxSize().background(Color(0xFF080B20)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(145.dp))
                    Spacer(Modifier.height(22.dp)); Text("SALDO", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = 4.sp)
                    Spacer(Modifier.height(7.dp)); Text("Dit overblik. Din økonomi.", color = Muted)
                    Spacer(Modifier.height(35.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf(Violet, Blue, Mint).forEach { Box(Modifier.size(6.dp).background(it, RoundedCornerShape(50))) } }
                }
            }
        } else if (!accountUnlocked) {
            Column(Modifier.fillMaxSize().background(Night).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(112.dp))
                Spacer(Modifier.height(18.dp))
                Text(if (loginMode) "Opret lokal konto" else "Log ind på Saldo", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Din konto gemmes kun på denne telefon", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))
                Field("E-mail", loginEmail, { loginEmail = it }, password = false)
                Field("Adgangskode", loginPassword, { loginPassword = it }, password = true)
                if (loginMode) Field("Gentag adgangskode", loginConfirm, { loginConfirm = it }, password = true)
                if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF7F9D), fontSize = 12.sp)
                Button(onClick = {
                    val email = loginEmail.trim().lowercase(Locale.ROOT)
                    if (!email.contains("@") || loginPassword.length < 8) { loginError = "Indtast en gyldig e-mail og adgangskode på mindst 8 tegn." }
                    else if (loginMode && loginPassword != loginConfirm) { loginError = "Adgangskoderne er ikke ens." }
                    else {
                        val hash = passwordHash(loginPassword)
                        if (loginMode) {
                            prefs.edit().putString("account_email", email).putString("account_hash", hash).putBoolean("account_session", true).apply()
                            accountUnlocked = true; loginError = ""
                        } else if (email == prefs.getString("account_email", "") && hash == prefs.getString("account_hash", "")) {
                            prefs.edit().putBoolean("account_session", true).apply(); accountUnlocked = true; loginError = ""
                        } else loginError = "E-mail eller adgangskode er forkert."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (loginMode) "Opret konto" else "Log ind") }
                TextButton(onClick = { loginMode = !loginMode; loginError = "" }) { Text(if (loginMode) "Jeg har allerede en konto" else "Opret lokal konto", color = Blue) }
                Text("Dette er lokal adgangskodebeskyttelse – ikke en onlinekonto eller cloud-synkronisering.", color = Muted, fontSize = 11.sp)
            }
        } else if (!unlocked) {
            Column(Modifier.fillMaxSize().background(Night).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(90.dp)); Text("Saldo er låst", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Field("PIN-kode", pin, { pin = it }, numeric = true, password = true)
                Button(onClick = { if (pin == prefs.getString("pin", "")) unlocked = true else pin = "" }) { Text("Lås op") }
            }
        } else {
            Scaffold(containerColor = Night, bottomBar = {
                NavigationBar(containerColor = Color(0xFF101426)) {
                    mainTabs.forEach { t -> NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(when (t) { "Overblik" -> Icons.Default.Home; "Poster" -> Icons.Default.ReceiptLong; "Regninger" -> Icons.Default.CalendarMonth; "Budget" -> Icons.Default.PieChart; else -> Icons.Default.MoreHoriz }, null) }, label = { Text(t, fontSize = 10.sp) }) }
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(40.dp)); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text("Saldo", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(tab.uppercase(), color = Muted, fontSize = 10.sp) }
                        IconButton(onClick = { dialog = "post" }) { Icon(Icons.Default.Add, "Tilføj", tint = Blue) }
                    }
                    when (tab) {
                        "Overblik" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                            item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF39357B)), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp)) { Text("RÅDIGHED EFTER REGNINGER", color = White.copy(.75f), fontSize = 11.sp); Text(money(income - expenses - unpaid), color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Næste løn om $daysToPay dage · ${money(payAmount)}", color = White.copy(.85f), fontSize = 12.sp) } } }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Indtægter", money(income), Modifier.weight(1f)); Metric("Udgifter", money(expenses), Modifier.weight(1f)) } }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Ubetalte regninger", money(unpaid), Modifier.weight(1f)); Metric("Registrerede poster", tx.size.toString(), Modifier.weight(1f)) } }
                            item { Text("Kommende regninger", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                            items(bills.filter { !it.optBoolean("paid", false) }.sortedBy { it.s("date") }.take(5), key = { it.s("id") }) { b -> RecordRow(b.s("name"), "Forfalder ${b.s("date")}", money(b.n("amount")), false, { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) }
                            item { Button(onClick = { tab = "Poster" }, modifier = Modifier.fillMaxWidth()) { Text("Se alle poster") } }
                        }
                        "Poster" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Indtægter og udgifter", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "post" }) { Text("Tilføj") } }; LazyColumn { items(tx.reversed(), key = { it.s("id") }) { x -> RecordRow(x.s("name"), "${x.s("date")} · ${x.s("category")} · ${x.s("owner", "Mig")}", money(x.n("amount")), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }) } } }
                        "Regninger" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Regninger", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "bill" }) { Text("Tilføj") } }; Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { dialog = "ocr" }) { Icon(Icons.Default.DocumentScanner, null); Text("Scan regning") }; OutlinedButton(onClick = { tab = "Kalender" }) { Text("Kalender") } }; LazyColumn { items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("name"), "${b.s("date")} · ${if (b.optBoolean("paid")) "Betalt" else "Ubetalt"} · ${b.s("repeat", "Engangsbetaling")}", money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) } } }
                        "Budget" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Budgetter", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "budget" }) { Text("Tilføj") } }; Text("Forbrug måles på poster med samme kategori.", color = Muted, fontSize = 12.sp); LazyColumn { items(list("budgets").objects(), key = { it.s("id") }) { b -> val spent = tx.filter { it.s("type") == "Udgift" && it.s("category").equals(b.s("category"), true) }.sumOf { it.n("amount") }; Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(b.s("category"), color = White, fontWeight = FontWeight.SemiBold); Text(b.s("owner", "Husstand"), color = Muted, fontSize = 11.sp) }; Text("${money(spent)} / ${money(b.n("limit"))}", color = Blue) }; LinearProgressIndicator(progress = { (spent / b.n("limit", 1.0)).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) } } } }
                        "Mere" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { item { Text("Flere værktøjer", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(moreTabs) { t -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { tab = t }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(t, Modifier.weight(1f), color = White, fontWeight = FontWeight.Medium); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
                        "Opsparing" -> ManagedList("Opsparingsmål", list("goals").objects(), { dialog = "goal" }, { g -> RecordRow(g.s("name"), "Mål ${money(g.n("target"))} · ${g.s("date")}", "Sparet ${money(g.n("saved"))}", true, { delete("goals", g.s("id")) }) })
                        "Gæld" -> ManagedList("Gæld", list("debts").objects(), { dialog = "debt" }, { d -> val balance = d.n("balance"); val payment = d.n("payment"); val rate = d.n("rate") / 1200.0; val months = if (payment <= balance * rate || payment <= 0) null else if (rate > 0) ceil(ln(payment / (payment - balance * rate)) / ln(1 + rate)).toInt() else ceil(balance / payment).toInt(); RecordRow(d.s("name"), "Rente ${d.n("rate")}% · ${months?.let { "$it mdr." } ?: "Afdrag dækker ikke renten"}", money(balance), false, { delete("debts", d.s("id")) }) })
                        "Bil" -> ManagedList("Brændstof", list("fuel").objects(), { dialog = "fuel" }, { f -> RecordRow(f.s("date"), "${f.n("liters")} liter · ${f.n("km")} km", money(f.n("cost")), true, { delete("fuel", f.s("id")) }) })
                        "Abonnementer" -> ManagedList("Abonnementer", list("subs").objects(), { dialog = "sub" }, { s -> RecordRow(s.s("name"), "Årligt ${money(s.n("monthly") * 12)}", "${money(s.n("monthly"))}/md.", false, { delete("subs", s.s("id")) }) })
                        "Kalender" -> LazyColumn { item { Text("Regningskalender", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("date"), b.s("name"), money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) } }
                        "Rapporter" -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Rapporter", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Metric("Indtægter", money(income), Modifier.fillMaxWidth()); Metric("Udgifter", money(expenses), Modifier.fillMaxWidth()); Metric("Netto", money(income - expenses), Modifier.fillMaxWidth()); Metric("Abonnementer pr. år", money(list("subs").objects().sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth()); Button(onClick = { shareCsv(context, tx, bills) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér CSV") }; Button(onClick = { shareBackup(context, data.toString()) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") } }
                        "Indstillinger" -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Indstillinger", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "payday" }, modifier = Modifier.fillMaxWidth()) { Text("Løn og næste løndato") }; Button(onClick = { dialog = "pin" }, modifier = Modifier.fillMaxWidth()) { Text("Opret / ændr PIN") }; Button(onClick = { shareBackup(context, data.toString()) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") }; Button(onClick = { prefs.edit().putBoolean("account_session", false).apply(); accountUnlocked = false; loginMode = false; loginPassword = ""; loginConfirm = "" }, modifier = Modifier.fillMaxWidth()) { Text("Log ud af lokal konto") }; Text("Data gemmes lokalt på telefonen. Synkronisering og bankbetalinger er ikke aktiveret.", color = Muted, fontSize = 12.sp) }
                    }
                }
            }
        }
        if (dialog.isNotEmpty()) {
            DataDialog(dialog, onDismiss = { dialog = "" }, onSave = { kind, obj ->
                when (kind) {
                    "post" -> add("transactions", obj)
                    "bill" -> {
                        val duplicate = list("bills").objects().any { it.s("name").equals(obj.s("name"), true) && it.s("date") == obj.s("date") && kotlin.math.abs(it.n("amount") - obj.n("amount")) < 0.01 }
                        if (duplicate) Toast.makeText(context, "Mulig dublet: regningen findes allerede", Toast.LENGTH_LONG).show() else add("bills", obj)
                    }
                    "budget" -> add("budgets", obj)
                    "goal" -> add("goals", obj)
                    "debt" -> add("debts", obj)
                    "fuel" -> add("fuel", obj)
                    "sub" -> add("subs", obj)
                    "payday" -> prefs.edit().putFloat("pay_amount", obj.n("pay").toFloat()).putString("payday", obj.s("date")).apply()
                    "pin" -> { prefs.edit().putString("pin", obj.s("pin")).apply(); unlocked = true }
                    "backup" -> { prefs.edit().putString("data", obj.s("json")).apply(); data = JSONObject(obj.s("json")) }
                }
                dialog = ""
            })
        }
    }
}

private fun passwordHash(password: String): String = MessageDigest.getInstance("SHA-256").digest(password.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

private fun updatePaid(bills: List<JSONObject>, target: JSONObject, store: (String, JSONArray) -> Unit) { val arr = JSONArray(); bills.forEach { b -> arr.put(if (b.s("id") == target.s("id")) JSONObject(b.toString()).put("paid", !b.optBoolean("paid")) else b) }; store("bills", arr) }

@Composable private fun Metric(label: String, value: String, modifier: Modifier = Modifier) { Column(modifier.background(Panel, RoundedCornerShape(15.dp)).padding(14.dp)) { Text(label, color = Muted, fontSize = 11.sp); Spacer(Modifier.height(5.dp)); Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold) } }
@Composable private fun RecordRow(title: String, detail: String, amount: String, positive: Boolean, onDelete: () -> Unit, onToggle: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(13.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 11.sp) }; Column(horizontalAlignment = Alignment.End) { Text(amount, color = if (positive) Mint else White, fontWeight = FontWeight.Bold); Row { if (onToggle != null) TextButton(onClick = onToggle) { Text("Betalt", fontSize = 10.sp) }; TextButton(onClick = onDelete) { Text("Slet", color = Color(0xFFFF7F9D), fontSize = 10.sp) } } } } }
@Composable private fun ManagedList(title: String, records: List<JSONObject>, onAdd: () -> Unit, row: @Composable (JSONObject) -> Unit) { Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Button(onClick = onAdd) { Text("Tilføj") } }; LazyColumn { items(records, key = { it.s("id") }) { row(it) } } } }

@Composable private fun DataDialog(kind: String, onDismiss: () -> Unit, onSave: (String, JSONObject) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Diverse") }; var date by remember { mutableStateOf(LocalDate.now().toString()) }; var type by remember { mutableStateOf("Udgift") }; var owner by remember { mutableStateOf("Mig") }; var extra by remember { mutableStateOf("") }; var extra2 by remember { mutableStateOf("") }; var extra3 by remember { mutableStateOf("") }; var json by remember { mutableStateOf("") }; var ocrText by remember { mutableStateOf("") }; var ocrBusy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching { InputImage.fromFilePath(context, uri) }.onSuccess { image ->
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result -> ocrText = result.text; ocrBusy = false }
                    .addOnFailureListener { ocrText = "Kunne ikke læse billedet. Prøv et skarpere billede."; ocrBusy = false }
            }.onFailure { ocrText = "Filen kunne ikke åbnes som et billede."; ocrBusy = false }
        }
    }
    val title = when (kind) { "post" -> "Ny post"; "bill" -> "Ny regning"; "budget" -> "Budgetgrænse"; "goal" -> "Opsparingsmål"; "debt" -> "Ny gæld"; "fuel" -> "Ny tankning"; "sub" -> "Abonnement"; "payday" -> "Lønindstillinger"; "pin" -> "PIN-kode"; "backup" -> "Backup / gendannelse"; "ocr" -> "Importér regning"; else -> "Saldo" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (kind) {
                "post" -> { Field("Beskrivelse", name, { name = it }); Field("Beløb i kr.", amount, { amount = it }, true); Field("Kategori", category, { category = it }); Field("Dato (ÅÅÅÅ-MM-DD)", date, { date = it }); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Udgift", "Indtægt").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
                }
                "bill" -> { Field("Regning / modtager", name, { name = it }); Field("Beløb", amount, { amount = it }, true); Field("Forfaldsdato", date, { date = it }); Field("Gentagelse (fx månedlig)", extra, { extra = it }); Field("Kategori", category, { category = it }); Row { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "budget" -> { Field("Kategori", name, { name = it }); Field("Månedlig grænse", amount, { amount = it }, true); Row { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "goal" -> { Field("Opsparingsmål", name, { name = it }); Field("Målsum", amount, { amount = it }, true); Field("Allerede sparet", extra, { extra = it }, true); Field("Måldato", date, { date = it }) }
                "debt" -> { Field("Kreditor", name, { name = it }); Field("Restgæld", amount, { amount = it }, true); Field("Årlig rente (%)", extra, { extra = it }, true); Field("Månedligt afdrag", extra2, { extra2 = it }, true) }
                "fuel" -> { Field("Dato", date, { date = it }); Field("Liter", amount, { amount = it }, true); Field("Samlet pris", extra, { extra = it }, true); Field("Kilometerstand", extra2, { extra2 = it }, true) }
                "sub" -> { Field("Abonnement", name, { name = it }); Field("Pris pr. måned", amount, { amount = it }, true) }
                "payday" -> { Field("Løn hver 14. dag", amount, { amount = it }, true); Field("Næste løndato", date, { date = it }) }
                "pin" -> Field("PIN (4-8 cifre)", amount, { amount = it }, true, true)
                "backup" -> { Field("Indsæt backup-JSON for at gendanne", json, { json = it }); Text("Kopiér backup-JSON fra appdata via eksport eller gem det sikkert eksternt.", color = Muted, fontSize = 11.sp) }
                "ocr" -> { Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Vælg billede") }; Text(if (ocrBusy) "Læser tekst fra billedet…" else ocrText.ifBlank { "Vælg et billede af regningen. OCR læser teksten, så du kan kontrollere oplysningerne." }, color = Muted) }
            }
        }
    }, confirmButton = { TextButton(onClick = {
        val a = amount.replace(",", ".").toDoubleOrNull() ?: 0.0; val id = System.currentTimeMillis().toString()
        val obj = when (kind) {
            "post" -> record("id" to id, "name" to name, "amount" to a, "category" to category, "date" to date, "type" to type, "owner" to owner)
            "bill" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to extra, "category" to category, "owner" to owner, "paid" to false)
            "budget" -> record("id" to id, "category" to name, "limit" to a, "owner" to owner)
            "goal" -> record("id" to id, "name" to name, "target" to a, "saved" to (extra.toDoubleOrNull() ?: 0.0), "date" to date)
            "debt" -> record("id" to id, "name" to name, "balance" to a, "rate" to (extra.toDoubleOrNull() ?: 0.0), "payment" to (extra2.toDoubleOrNull() ?: 0.0))
            "fuel" -> record("id" to id, "date" to date, "liters" to a, "cost" to (extra.toDoubleOrNull() ?: 0.0), "km" to (extra2.toDoubleOrNull() ?: 0.0))
            "sub" -> record("id" to id, "name" to name, "monthly" to a)
            "payday" -> record("pay" to a, "date" to date)
            "pin" -> record("pin" to amount)
            "backup" -> record("json" to json)
            else -> JSONObject()
        }
        if (kind == "pin" && !amount.matches(Regex("\\d{4,8}"))) return@TextButton
        if (kind == "backup" && runCatching { JSONObject(json) }.isFailure) return@TextButton
        if (kind != "ocr") onSave(kind, obj) else onDismiss()
    }) { Text(if (kind == "ocr") "Luk" else "Gem", color = Blue) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } })
}

@Composable private fun Field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false, password: Boolean = false) { OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = Muted, focusedLabelColor = Violet, unfocusedLabelColor = Muted)) }

private fun shareCsv(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>) { val lines = mutableListOf("type;navn;beløb;kategori;dato;status;ejer"); transactions.forEach { lines += "post;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${it.s("type")};${it.s("owner")}" }; bills.forEach { lines += "regning;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${if (it.optBoolean("paid")) "betalt" else "ubetalt"};${it.s("owner")}" }; val intent = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_SUBJECT, "Saldo CSV-eksport").putExtra(Intent.EXTRA_TEXT, lines.joinToString("\n")); context.startActivity(Intent.createChooser(intent, "Eksportér Saldo-data")) }

private fun shareBackup(context: Context, json: String) {
    val intent = Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_SUBJECT, "Saldo sikkerhedskopi").putExtra(Intent.EXTRA_TEXT, json)
    context.startActivity(Intent.createChooser(intent, "Gem eller del sikkerhedskopi"))
}
