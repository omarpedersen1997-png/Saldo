package dk.saldo.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.security.MessageDigest
import kotlin.math.ceil
import kotlin.math.ln

private val Night = Color(0xFF090B13)
private val Panel = Color(0xFF141827)
private val PanelRaised = Color(0xFF1B2033)
private val Violet = Color(0xFF9B83FF)
private val Blue = Color(0xFF43D3FF)
private val Mint = Color(0xFF6BE7C8)
private val Muted = Color(0xFFA4ADC5)
private val White = Color(0xFFF7F8FF)
private fun money(v: Double) = NumberFormat.getNumberInstance(Locale("da", "DK")).apply { maximumFractionDigits = 2 }.format(v) + " kr."
private fun JSONObject.s(k: String, d: String = "") = optString(k, d).let { if (it == "null") d else it }
private fun JSONObject.n(k: String, d: Double = 0.0) = optDouble(k, d)
private fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
private fun record(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(13, 16, 32)
        setContent { SaldoApp() }
    }
}

private val mainTabs = listOf("Overblik", "Poster", "Regninger", "Budget", "Mere")
private val moreTabs = listOf("Opsparing", "Gæld", "Bil", "Abonnementer", "Kalender", "Rapporter", "Indstillinger")

@Composable private fun SaldoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("saldo_data_v4", Context.MODE_PRIVATE) }
    var data by remember { mutableStateOf(runCatching { JSONObject(prefs.getString("data", "{}") ?: "{}") }.getOrElse { JSONObject() }) }
    fun list(key: String) = data.optJSONArray(key) ?: JSONArray()
    fun store(key: String, arr: JSONArray) { data.put(key, arr); prefs.edit().putString("data", data.toString()).apply(); data = JSONObject(data.toString()) }
    fun add(key: String, obj: JSONObject) { val arr = list(key); arr.put(obj); store(key, arr) }
    fun delete(key: String, id: String) { val arr = JSONArray(); list(key).objects().filterNot { it.s("id") == id }.forEach { arr.put(it) }; store(key, arr) }
    var tab by remember { mutableStateOf("Overblik") }
    var dialog by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginConfirm by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loginMode by remember { mutableStateOf(prefs.getString("account_hash", null) == null) }
    var accountUnlocked by remember { mutableStateOf(prefs.getBoolean("account_session", false)) }
    var unlocked by remember { mutableStateOf(prefs.getString("pin", null) == null) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1000); splash = false }
    val tx = list("transactions").objects()
    val bills = list("bills").objects()
    val income = tx.filter { it.s("type") == "Indtægt" }.sumOf { it.n("amount") }
    val expenses = tx.filter { it.s("type") == "Udgift" }.sumOf { it.n("amount") }
    val unpaid = bills.filter { !it.optBoolean("paid", false) }.sumOf { it.n("amount") }
    val payday = runCatching { LocalDate.parse(prefs.getString("payday", LocalDate.now().toString())) }.getOrElse { LocalDate.now() }
    val payAmount = prefs.getFloat("pay_amount", 10000f).toDouble()
    val daysToPay = ChronoUnit.DAYS.between(LocalDate.now(), payday).toInt().let { ((it % 14) + 14) % 14 }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Blue, background = Night, surface = Panel, onSurface = White)) {
        if (splash) {
            Box(Modifier.fillMaxSize().background(Color(0xFF080B20)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(145.dp))
                    Spacer(Modifier.height(22.dp)); Text("SALDO", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = 4.sp)
                    Spacer(Modifier.height(7.dp)); Text("Dit overblik. Din økonomi.", color = Muted)
                    Spacer(Modifier.height(35.dp)); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf(Violet, Blue, Mint).forEach { Box(Modifier.size(6.dp).background(it, RoundedCornerShape(50))) } }
                }
            }
        } else if (!accountUnlocked) {
            Column(Modifier.fillMaxSize().background(Night).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(112.dp))
                Spacer(Modifier.height(18.dp))
                Text(if (loginMode) "Opret lokal konto" else "Log ind på Saldo", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Din konto gemmes kun på denne telefon", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))
                Field("E-mail", loginEmail, { loginEmail = it }, password = false)
                Field("Adgangskode", loginPassword, { loginPassword = it }, password = true)
                if (loginMode) Field("Gentag adgangskode", loginConfirm, { loginConfirm = it }, password = true)
                if (loginError.isNotBlank()) Text(loginError, color = Color(0xFFFF7F9D), fontSize = 12.sp)
                Button(onClick = {
                    val email = loginEmail.trim().lowercase(Locale.ROOT)
                    if (!email.contains("@") || loginPassword.length < 8) { loginError = "Indtast en gyldig e-mail og adgangskode på mindst 8 tegn." }
                    else if (loginMode && loginPassword != loginConfirm) { loginError = "Adgangskoderne er ikke ens." }
                    else {
                        val hash = passwordHash(loginPassword)
                        if (loginMode) {
                            prefs.edit().putString("account_email", email).putString("account_hash", hash).putBoolean("account_session", true).apply()
                            accountUnlocked = true; loginError = ""
                        } else if (email == prefs.getString("account_email", "") && hash == prefs.getString("account_hash", "")) {
                            prefs.edit().putBoolean("account_session", true).apply(); accountUnlocked = true; loginError = ""
                        } else loginError = "E-mail eller adgangskode er forkert."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (loginMode) "Opret konto" else "Log ind") }
                TextButton(onClick = { loginMode = !loginMode; loginError = "" }) { Text(if (loginMode) "Jeg har allerede en konto" else "Opret lokal konto", color = Blue) }
                Text("Dette er lokal adgangskodebeskyttelse – ikke en onlinekonto eller cloud-synkronisering.", color = Muted, fontSize = 11.sp)
            }
        } else if (!unlocked) {
            Column(Modifier.fillMaxSize().background(Night).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(90.dp)); Text("Saldo er låst", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Field("PIN-kode", pin, { pin = it }, numeric = true, password = true)
                Button(onClick = { if (pin == prefs.getString("pin", "")) unlocked = true else pin = "" }) { Text("Lås op") }
            }
        } else {
            Scaffold(containerColor = Night, bottomBar = {
                Surface(
                    color = Color(0xFF101421),
                    shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
                    tonalElevation = 0.dp,
                    shadowElevation = 18.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        mainTabs.forEach { t ->
                            val selected = tab == t
                            val icon = when (t) {
                                "Overblik" -> Icons.Default.Home
                                "Poster" -> Icons.Default.ReceiptLong
                                "Regninger" -> Icons.Default.CalendarMonth
                                "Budget" -> Icons.Default.PieChart
                                else -> Icons.Default.GridView
                            }
                            Surface(
                                onClick = { tab = t },
                                color = if (selected) Color(0xFF252542) else Color.Transparent,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = if (selected) 10.dp else 4.dp, vertical = 11.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(icon, contentDescription = t, tint = if (selected) Blue else Muted, modifier = Modifier.size(20.dp))
                                    if (selected) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(t, color = White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).background(Brush.verticalGradient(listOf(Color(0xFF0D1020), Night, Color(0xFF090B13)))).padding(horizontal = 20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.ic_saldo_logo), "Saldo-logo", Modifier.size(44.dp)); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(if (tab == "Overblik") "Goddag" else "Saldo", color = Muted, fontSize = 12.sp)
                            Text(if (tab == "Overblik") "Dit overblik" else tab, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp)
                        }
                        Surface(shape = RoundedCornerShape(15.dp), color = PanelRaised) {
                            IconButton(onClick = { dialog = "post" }) { Icon(Icons.Default.Add, "Tilføj post", tint = Blue) }
                        }
                    }
                    when (tab) {
                        "Overblik" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Color.Transparent), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                                    Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF403A88), Color(0xFF25294F), Color(0xFF17283D)))).padding(22.dp)) {
                                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AccountBalanceWallet, null, tint = Blue, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("RÅDIGHED EFTER REGNINGER", color = White.copy(.78f), fontSize = 11.sp, letterSpacing = 1.1.sp) }
                                            Text(money(income - expenses - unpaid), color = White, fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
                                            Row(verticalAlignment = Alignment.CenterVertically) { Surface(color = White.copy(.12f), shape = RoundedCornerShape(10.dp)) { Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null, tint = Mint, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(6.dp)); Text("Løn om $daysToPay dage", color = White, fontSize = 11.sp) } }; Spacer(Modifier.width(8.dp)); Text(money(payAmount), color = White.copy(.8f), fontSize = 11.sp) }
                                        }
                                    }
                                }
                            }
                            item { Text("Din økonomi", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Indtægter", money(income), Modifier.weight(1f)); Metric("Udgifter", money(expenses), Modifier.weight(1f)) } }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Metric("Regninger tilbage", money(unpaid), Modifier.weight(1f)); Metric("Antal poster", tx.size.toString(), Modifier.weight(1f)) } }
                            item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Kommende regninger", Modifier.weight(1f), color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold); TextButton(onClick = { tab = "Regninger" }) { Text("Se alle", color = Blue) } } }
                            if (bills.none { !it.optBoolean("paid", false) }) item { Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.CheckCircle, null, tint = Mint, modifier = Modifier.size(28.dp)); Spacer(Modifier.height(8.dp)); Text("Du er ajour", color = White, fontWeight = FontWeight.SemiBold); Text("Ingen ubetalte regninger", color = Muted, fontSize = 12.sp) } } }
                            items(bills.filter { !it.optBoolean("paid", false) }.sortedBy { it.s("date") }.take(5), key = { it.s("id") }) { b -> RecordRow(b.s("name"), "Forfalder ${b.s("date")}", money(b.n("amount")), false, { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) }
                            item { OutlinedButton(onClick = { tab = "Poster" }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("Se alle poster", color = Blue); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null, tint = Blue) } }
                        }
                        "Poster" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Indtægter og udgifter", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "post" }) { Text("Tilføj") } }; LazyColumn { items(tx.reversed(), key = { it.s("id") }) { x -> RecordRow(x.s("name"), "${x.s("date")} · ${x.s("category")} · ${x.s("owner", "Mig")}", money(x.n("amount")), x.s("type") == "Indtægt", { delete("transactions", x.s("id")) }) } } }
                        "Regninger" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Regninger", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "bill" }) { Text("Tilføj") } }; Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { dialog = "ocr" }) { Icon(Icons.Default.DocumentScanner, null); Text("Scan regning") }; OutlinedButton(onClick = { tab = "Kalender" }) { Text("Kalender") } }; LazyColumn { items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("name"), "${b.s("date")} · ${if (b.optBoolean("paid")) "Betalt" else "Ubetalt"} · ${b.s("repeat", "Engangsbetaling")}", money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) } } }
                        "Budget" -> Column(Modifier.fillMaxSize()) { Row(verticalAlignment = Alignment.CenterVertically) { Text("Budgetter", Modifier.weight(1f), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "budget" }) { Text("Tilføj") } }; Text("Forbrug måles på poster med samme kategori.", color = Muted, fontSize = 12.sp); LazyColumn { items(list("budgets").objects(), key = { it.s("id") }) { b -> val spent = tx.filter { it.s("type") == "Udgift" && it.s("category").equals(b.s("category"), true) }.sumOf { it.n("amount") }; Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(b.s("category"), color = White, fontWeight = FontWeight.SemiBold); Text(b.s("owner", "Husstand"), color = Muted, fontSize = 11.sp) }; Text("${money(spent)} / ${money(b.n("limit"))}", color = Blue) }; LinearProgressIndicator(progress = { (spent / b.n("limit", 1.0)).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) } } } }
                        "Mere" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { item { Text("Flere værktøjer", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(moreTabs) { t -> Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { tab = t }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(t, Modifier.weight(1f), color = White, fontWeight = FontWeight.Medium); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
                        "Opsparing" -> ManagedList("Opsparingsmål", list("goals").objects(), { dialog = "goal" }, { g -> RecordRow(g.s("name"), "Mål ${money(g.n("target"))} · ${g.s("date")}", "Sparet ${money(g.n("saved"))}", true, { delete("goals", g.s("id")) }) })
                        "Gæld" -> ManagedList("Gæld", list("debts").objects(), { dialog = "debt" }, { d -> val balance = d.n("balance"); val payment = d.n("payment"); val rate = d.n("rate") / 1200.0; val months = if (payment <= balance * rate || payment <= 0) null else if (rate > 0) ceil(ln(payment / (payment - balance * rate)) / ln(1 + rate)).toInt() else ceil(balance / payment).toInt(); RecordRow(d.s("name"), "Rente ${d.n("rate")}% · ${months?.let { "$it mdr." } ?: "Afdrag dækker ikke renten"}", money(balance), false, { delete("debts", d.s("id")) }) })
                        "Bil" -> ManagedList("Brændstof", list("fuel").objects(), { dialog = "fuel" }, { f -> RecordRow(f.s("date"), "${f.n("liters")} liter · ${f.n("km")} km", money(f.n("cost")), true, { delete("fuel", f.s("id")) }) })
                        "Abonnementer" -> ManagedList("Abonnementer", list("subs").objects(), { dialog = "sub" }, { s -> RecordRow(s.s("name"), "Årligt ${money(s.n("monthly") * 12)}", "${money(s.n("monthly"))}/md.", false, { delete("subs", s.s("id")) }) })
                        "Kalender" -> LazyColumn { item { Text("Regningskalender", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(bills.sortedBy { it.s("date") }, key = { it.s("id") }) { b -> RecordRow(b.s("date"), b.s("name"), money(b.n("amount")), b.optBoolean("paid"), { delete("bills", b.s("id")) }, { updatePaid(bills, b, ::store) }) } }
                        "Rapporter" -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Rapporter", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Metric("Indtægter", money(income), Modifier.fillMaxWidth()); Metric("Udgifter", money(expenses), Modifier.fillMaxWidth()); Metric("Netto", money(income - expenses), Modifier.fillMaxWidth()); Metric("Abonnementer pr. år", money(list("subs").objects().sumOf { it.n("monthly") * 12 }), Modifier.fillMaxWidth()); Button(onClick = { shareCsv(context, tx, bills) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér CSV") }; Button(onClick = { shareBackup(context, data.toString()) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") } }
                        "Indstillinger" -> Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Indstillinger", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Button(onClick = { dialog = "payday" }, modifier = Modifier.fillMaxWidth()) { Text("Løn og næste løndato") }; Button(onClick = { dialog = "pin" }, modifier = Modifier.fillMaxWidth()) { Text("Opret / ændr PIN") }; Button(onClick = { shareBackup(context, data.toString()) }, modifier = Modifier.fillMaxWidth()) { Text("Eksportér sikkerhedskopi") }; Button(onClick = { dialog = "backup" }, modifier = Modifier.fillMaxWidth()) { Text("Gendan sikkerhedskopi") }; Button(onClick = { prefs.edit().putBoolean("account_session", false).apply(); accountUnlocked = false; loginMode = false; loginPassword = ""; loginConfirm = "" }, modifier = Modifier.fillMaxWidth()) { Text("Log ud af lokal konto") }; Text("Data gemmes lokalt på telefonen. Synkronisering og bankbetalinger er ikke aktiveret.", color = Muted, fontSize = 12.sp) }
                    }
                }
            }
        }
        if (dialog.isNotEmpty()) {
            DataDialog(dialog, onDismiss = { dialog = "" }, onSave = { kind, obj ->
                when (kind) {
                    "post" -> add("transactions", obj)
                    "bill" -> {
                        val duplicate = list("bills").objects().any { it.s("name").equals(obj.s("name"), true) && it.s("date") == obj.s("date") && kotlin.math.abs(it.n("amount") - obj.n("amount")) < 0.01 }
                        if (duplicate) Toast.makeText(context, "Mulig dublet: regningen findes allerede", Toast.LENGTH_LONG).show() else add("bills", obj)
                    }
                    "budget" -> add("budgets", obj)
                    "goal" -> add("goals", obj)
                    "debt" -> add("debts", obj)
                    "fuel" -> add("fuel", obj)
                    "sub" -> add("subs", obj)
                    "payday" -> prefs.edit().putFloat("pay_amount", obj.n("pay").toFloat()).putString("payday", obj.s("date")).apply()
                    "pin" -> { prefs.edit().putString("pin", obj.s("pin")).apply(); unlocked = true }
                    "backup" -> { prefs.edit().putString("data", obj.s("json")).apply(); data = JSONObject(obj.s("json")) }
                }
                dialog = ""
            })
        }
    }
}

private fun passwordHash(password: String): String = MessageDigest.getInstance("SHA-256").digest(password.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

private fun updatePaid(bills: List<JSONObject>, target: JSONObject, store: (String, JSONArray) -> Unit) { val arr = JSONArray(); bills.forEach { b -> arr.put(if (b.s("id") == target.s("id")) JSONObject(b.toString()).put("paid", !b.optBoolean("paid")) else b) }; store("bills", arr) }

@Composable private fun Metric(label: String, value: String, modifier: Modifier = Modifier) { Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(20.dp), tonalElevation = 0.dp) { Column(Modifier.padding(horizontal = 16.dp, vertical = 17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(label, color = Muted, fontSize = 11.sp, letterSpacing = .2.sp); Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.3).sp) } } }
@Composable private fun RecordRow(title: String, detail: String, amount: String, positive: Boolean, onDelete: () -> Unit, onToggle: (() -> Unit)? = null) { Surface(Modifier.fillMaxWidth().padding(vertical = 3.dp), color = Panel, shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) { Surface(color = if (positive) Color(0xFF15362F) else Color(0xFF29243D), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) { Box(contentAlignment = Alignment.Center) { Icon(if (positive) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (positive) Mint else Violet, modifier = Modifier.size(19.dp)) } }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(detail, color = Muted, fontSize = 11.sp) }; Column(horizontalAlignment = Alignment.End) { Text(amount, color = if (positive) Mint else White, fontWeight = FontWeight.Bold, fontSize = 13.sp); Row { if (onToggle != null) TextButton(onClick = onToggle, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Betalt", fontSize = 10.sp) }; TextButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) { Text("Slet", color = Color(0xFFFF7F9D), fontSize = 10.sp) } } } } } }
@Composable private fun ManagedList(title: String, records: List<JSONObject>, onAdd: () -> Unit, row: @Composable (JSONObject) -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = (-.4).sp); Button(onClick = onAdd, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Tilføj") } }; if (records.isEmpty()) { Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Muted, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(8.dp)); Text("Her er tomt endnu", color = White, fontWeight = FontWeight.SemiBold); Text("Tilføj din første post for at komme i gang.", color = Muted, fontSize = 12.sp) } } }; LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) { items(records, key = { it.s("id") }) { row(it) } } } }

@Composable private fun DataDialog(kind: String, onDismiss: () -> Unit, onSave: (String, JSONObject) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Diverse") }; var date by remember { mutableStateOf(LocalDate.now().toString()) }; var type by remember { mutableStateOf("Udgift") }; var owner by remember { mutableStateOf("Mig") }; var extra by remember { mutableStateOf("") }; var extra2 by remember { mutableStateOf("") }; var extra3 by remember { mutableStateOf("") }; var json by remember { mutableStateOf("") }; var ocrText by remember { mutableStateOf("") }; var ocrBusy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ocrBusy = true
            runCatching { InputImage.fromFilePath(context, uri) }.onSuccess { image ->
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text
                        val parsed = parseBillText(result.text)
                        if (name.isBlank()) name = parsed.first
                        if (amount.isBlank()) amount = parsed.second
                        if (parsed.third.isNotBlank()) date = parsed.third
                        ocrBusy = false
                    }
                    .addOnFailureListener { ocrText = "Kunne ikke læse billedet. Prøv et skarpere og mere tydeligt skærmbillede."; ocrBusy = false }
            }.onFailure { ocrText = "Filen kunne ikke åbnes som et billede. Vælg et almindeligt PNG/JPG-skærmbillede."; ocrBusy = false }
        }
    }
    val title = when (kind) { "post" -> "Ny post"; "bill" -> "Ny regning"; "budget" -> "Budgetgrænse"; "goal" -> "Opsparingsmål"; "debt" -> "Ny gæld"; "fuel" -> "Ny tankning"; "sub" -> "Abonnement"; "payday" -> "Lønindstillinger"; "pin" -> "PIN-kode"; "backup" -> "Backup / gendannelse"; "ocr" -> "Importér regning"; else -> "Saldo" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = White, fontWeight = FontWeight.Bold) }, text = {
        Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (kind) {
                "post" -> { Field("Beskrivelse", name, { name = it }); Field("Beløb i kr.", amount, { amount = it }, true); Field("Kategori", category, { category = it }); Field("Dato (ÅÅÅÅ-MM-DD)", date, { date = it }); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Udgift", "Indtægt").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
                }
                "bill" -> { Field("Regning / modtager", name, { name = it }); Field("Beløb", amount, { amount = it }, true); Field("Forfaldsdato", date, { date = it }); Field("Gentagelse (fx månedlig)", extra, { extra = it }); Field("Kategori", category, { category = it }); Row { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "budget" -> { Field("Kategori", name, { name = it }); Field("Månedlig grænse", amount, { amount = it }, true); Row { listOf("Mig", "Kæreste", "Fælles").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } } }
                "goal" -> { Field("Opsparingsmål", name, { name = it }); Field("Målsum", amount, { amount = it }, true); Field("Allerede sparet", extra, { extra = it }, true); Field("Måldato", date, { date = it }) }
                "debt" -> { Field("Kreditor", name, { name = it }); Field("Restgæld", amount, { amount = it }, true); Field("Årlig rente (%)", extra, { extra = it }, true); Field("Månedligt afdrag", extra2, { extra2 = it }, true) }
                "fuel" -> { Field("Dato", date, { date = it }); Field("Liter", amount, { amount = it }, true); Field("Samlet pris", extra, { extra = it }, true); Field("Kilometerstand", extra2, { extra2 = it }, true) }
                "sub" -> { Field("Abonnement", name, { name = it }); Field("Pris pr. måned", amount, { amount = it }, true) }
                "payday" -> { Field("Løn hver 14. dag", amount, { amount = it }, true); Field("Næste løndato", date, { date = it }) }
                "pin" -> Field("PIN (4-8 cifre)", amount, { amount = it }, true, true)
                "backup" -> { Field("Indsæt backup-JSON for at gendanne", json, { json = it }); Text("Kopiér backup-JSON fra appdata via eksport eller gem det sikkert eksternt.", color = Muted, fontSize = 11.sp) }
                "ocr" -> {
                    Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth(), enabled = !ocrBusy) { Text(if (ocrBusy) "Læser skærmbillede…" else "Vælg skærmbillede af regningen") }
                    Text(if (ocrText.isBlank()) "Vælg et skærmbillede fra dit galleri. Saldo forsøger at finde afsender, beløb og dato. Kontrollér altid felterne før gemning." else "Tekst genkendt – kontrollér oplysningerne nedenfor:", color = Muted)
                    if (ocrBusy) CircularProgressIndicator(color = Violet)
                    if (ocrText.isNotBlank()) {
                        Field("Afsender / regning", name, { name = it })
                        Field("Beløb i kr.", amount, { amount = it }, true)
                        Field("Forfaldsdato (ÅÅÅÅ-MM-DD)", date, { date = it })
                        Text("Genkendt tekst", color = White, fontWeight = FontWeight.SemiBold)
                        Text(ocrText.take(1800), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = {
        val a = amount.replace(",", ".").toDoubleOrNull() ?: 0.0; val id = System.currentTimeMillis().toString()
        val obj = when (kind) {
            "post" -> record("id" to id, "name" to name, "amount" to a, "category" to category, "date" to date, "type" to type, "owner" to owner)
            "bill" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to extra, "category" to category, "owner" to owner, "paid" to false)
            "budget" -> record("id" to id, "category" to name, "limit" to a, "owner" to owner)
            "goal" -> record("id" to id, "name" to name, "target" to a, "saved" to (extra.toDoubleOrNull() ?: 0.0), "date" to date)
            "debt" -> record("id" to id, "name" to name, "balance" to a, "rate" to (extra.toDoubleOrNull() ?: 0.0), "payment" to (extra2.toDoubleOrNull() ?: 0.0))
            "fuel" -> record("id" to id, "date" to date, "liters" to a, "cost" to (extra.toDoubleOrNull() ?: 0.0), "km" to (extra2.toDoubleOrNull() ?: 0.0))
            "sub" -> record("id" to id, "name" to name, "monthly" to a)
            "payday" -> record("pay" to a, "date" to date)
            "pin" -> record("pin" to amount)
            "backup" -> record("json" to json)
            "ocr" -> record("id" to id, "name" to name, "amount" to a, "date" to date, "repeat" to "Engangsbetaling", "category" to category, "owner" to owner, "paid" to false, "source" to "OCR-skærmbillede")
            else -> JSONObject()
        }
        if (kind == "pin" && !amount.matches(Regex("\\d{4,8}"))) return@TextButton
        if (kind == "backup" && runCatching { JSONObject(json) }.isFailure) return@TextButton
        if (kind == "ocr") {
            if (ocrText.isBlank() || name.isBlank() || a <= 0.0 || runCatching { LocalDate.parse(date) }.isFailure) {
                Toast.makeText(context, "Kontrollér afsender, beløb og dato før gemning", Toast.LENGTH_LONG).show()
                return@TextButton
            }
            onSave("bill", obj)
        } else onSave(kind, obj)
    }) { Text(if (kind == "ocr") "Opret regning" else "Gem", color = Blue) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller", color = Muted) } })
}

@Composable private fun Field(label: String, value: String, onValue: (String) -> Unit, numeric: Boolean = false, password: Boolean = false) { OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White, focusedBorderColor = Violet, unfocusedBorderColor = Muted, focusedLabelColor = Violet, unfocusedLabelColor = Muted)) }

private fun parseBillText(text: String): Triple<String, String, String> {
    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
    val vendor = lines.firstOrNull { line ->
        line.length in 3..70 && line.any { it.isLetter() } &&
            !line.contains("faktura", true) && !line.contains("invoice", true) &&
            !line.contains("betalingsoversigt", true)
    }?.take(70).orEmpty()

    val datePatterns = listOf(
        Regex("(?<!\\d)(20\\d{2})[-./](0?[1-9]|1[0-2])[-./]([0-2]?\\d|3[01])(?!\\d)"),
        Regex("(?<!\\d)([0-3]?\\d)[./-](0?[1-9]|1[0-2])[./-](20\\d{2})(?!\\d)")
    )
    var date = ""
    for ((index, pattern) in datePatterns.withIndex()) {
        val match = pattern.find(text) ?: continue
        date = if (index == 0) {
            runCatching { LocalDate.of(match.groupValues[1].toInt(), match.groupValues[2].toInt(), match.groupValues[3].toInt()).toString() }.getOrDefault("")
        } else {
            runCatching { LocalDate.of(match.groupValues[3].toInt(), match.groupValues[2].toInt(), match.groupValues[1].toInt()).toString() }.getOrDefault("")
        }
        if (date.isNotBlank()) break
    }

    val moneyRegex = Regex("(?i)(?:i alt|total|at betale|beløb|amount|kr\\.?)[^\\d]{0,18}([0-9][0-9 .]*[,\\.][0-9]{2})")
    val match = moneyRegex.find(text) ?: Regex("(?<!\\d)([0-9]{1,3}(?:[ .][0-9]{3})*(?:[,\\.][0-9]{2}))(?!\\d)").find(text)
    val amount = match?.groupValues?.lastOrNull()?.replace(" ", "")?.replace(".", "")?.replace(",", ".")?.toDoubleOrNull()?.takeIf { it > 0 }?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
    return Triple(vendor, amount, date)
}

private fun shareCsv(context: Context, transactions: List<JSONObject>, bills: List<JSONObject>) { val lines = mutableListOf("type;navn;beløb;kategori;dato;status;ejer"); transactions.forEach { lines += "post;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${it.s("type")};${it.s("owner")}" }; bills.forEach { lines += "regning;${it.s("name").replace(";", ",")};${it.n("amount")};${it.s("category")};${it.s("date")};${if (it.optBoolean("paid")) "betalt" else "ubetalt"};${it.s("owner")}" }; val intent = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_SUBJECT, "Saldo CSV-eksport").putExtra(Intent.EXTRA_TEXT, lines.joinToString("\n")); context.startActivity(Intent.createChooser(intent, "Eksportér Saldo-data")) }

private fun shareBackup(context: Context, json: String) {
    val intent = Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_SUBJECT, "Saldo sikkerhedskopi").putExtra(Intent.EXTRA_TEXT, json)
    context.startActivity(Intent.createChooser(intent, "Gem eller del sikkerhedskopi"))
}
