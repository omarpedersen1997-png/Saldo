# Ændringer i Saldo 3.2.0

- Større redesign af startsidens rådighedskort med tydeligere hierarki.
- Opdateret topbjælke med mere kompakt brandlabel og tydeligere sidetitel.
- Opdaterede økonomikort med indikatorfarver, mere luft og diskrete kanter.
- Mere ensartede hjørner og afstande på poster.
- Originalt S-logo bevaret byte-for-byte; ingen logoressourcer er tegnet om.

Bemærk: Kildekoden er ændret, men Android APK er ikke bygget/testet i dette miljø.

## 3.2.1 – UI polish
- Refined the app shell, header hierarchy, spacing and bottom navigation.
- Tightened dashboard typography and adjusted card shapes/contrast for a calmer finance-app presentation.
- Preserved existing logo image resources without modification.
