# Changelog

## 4.1.0 — Saldo 2026 UI-redesign
- Redesignet overblik med et stort, gradientbaseret rådighedsbeløbskort, animeret forbrugsindikator og hurtige handlinger.
- Opdateret budgetskærm med samlet status, animerede budgetbjælker og tydeligere kategorikort.
- Redesignet Poster- og Regninger-skærme med forbedret søgning, statusoversigter og mere kompakte handlinger.
- Redesignet Mere-menuen med ikonbaserede værktøjskort og korte forklaringer.
- Opdateret fælles postrækker, knapfarver, typografisk hierarki og kortstile.
- Beholdt eksisterende Saldo-logo, datalagring, budgetberegninger, PIN/biometri, PDF/backup og Supabase-funktioner.
- Brugerrettet ejerbetegnelse er Partner; ældre lokale ejerfelter med Kæreste migreres til Partner ved indlæsning.

## 4.0.0
- Tidligere opdateringer af online-login, lokal sikkerhed og UI-komponenter.
