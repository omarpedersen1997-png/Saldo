# Saldo — Android

Saldo er en privatøkonomi-app til Android bygget med Kotlin og Jetpack Compose.

## Version 4.1.0 — 2026-redesign
Denne version opdaterer centrale dele af brugeroplevelsen: dashboard, budgetter, poster, regninger og værktøjsmenu. Designet bruger et mørkt fintech-udtryk med lilla/cyan-accenter, animerede budgetindikatorer, hurtige handlinger og mere kompakte kort. Saldo-logoet er bevaret uændret.

## Byg appen
- JDK 17
- Android SDK 36
- Gradle 8.14.3 eller en kompatibel Gradle-installation
- Byg debug-APK med `gradle assembleDebug` fra projektroden.

GitHub Actions-workflowet i `.github/workflows/android-build.yml` forventer, at projektets ZIP-fil (`Saldo-2026-redesign.zip`) ligger i roden af repositoryet. GitHub Secrets `SUPABASE_URL` og `SUPABASE_ANON_KEY` bruges ved build. Brug kun en Supabase publishable/anon key i mobilappen — aldrig en secret/service-role key.

Online-login og cloud-backup kræver opsætningen beskrevet i `ONLINE-LOGIN.md` og SQL-skemaet i `SUPABASE-SCHEMA.sql`.
